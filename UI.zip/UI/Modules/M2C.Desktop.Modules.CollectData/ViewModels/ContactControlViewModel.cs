﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ContactControlViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.Enums;
using M2C.Desktop.Modules.CollectData.Events;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Contact control inside Create New project window
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <summary>
    /// Class ContactControlViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="System.IDisposable" />
    /// <summary>
    /// Class ContactControlViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="System.IDisposable" />
    public class ContactControlViewModel : BindableBase, IDisposable
    {
        /// <summary>
        /// The event aggregator
        /// </summary>
        /// <summary>
        /// The event aggregator
        /// </summary>
        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// The dialog service
        /// </summary>
        /// <summary>
        /// The dialog service
        /// </summary>
        /// <summary>
        /// The dialog service
        /// </summary>
        private readonly IDialogService _dialogService;

        /// <summary>
        /// My profile
        /// </summary>
        /// <summary>
        /// My profile
        /// </summary>
        /// <summary>
        /// My profile
        /// </summary>
        private readonly IMyProfileLogic myProfile;

        /// <summary>
        /// The contacts
        /// </summary>
        /// <summary>
        /// The contacts
        /// </summary>
        /// <summary>
        /// The contacts
        /// </summary>
        private ObservableCollection<ContactModel> _contacts = new ObservableCollection<ContactModel>();

        /// <summary>
        /// The selected contact
        /// </summary>
        /// <summary>
        /// The selected contact
        /// </summary>
        /// <summary>
        /// The selected contact
        /// </summary>
        private ContactModel _selectedContact = new ContactModel();

        /// <summary>
        /// The contact type
        /// </summary>
        /// <summary>
        /// The contact type
        /// </summary>
        /// <summary>
        /// The contact type
        /// </summary>
        private ContactType _contactType;

        /// <summary>
        /// Gets or sets the project create mode.
        /// </summary>
        /// <value>
        /// The project create mode.
        /// </value>
        /// <summary>
        /// Gets or sets the project create mode.
        /// </summary>
        /// <value>The project create mode.</value>
        /// <summary>
        /// Gets or sets the project create mode.
        /// </summary>
        /// <value>The project create mode.</value>
        public ProjectCreateModes ProjectCreateMode
        {
            get => _projectCreateMode; set
            {
                SetProperty(ref _projectCreateMode, value);
                if (_projectCreateMode != ProjectCreateModes.NONE)
                {
                    ContactControlInit();
                }
            }
        }

        /// <summary>
        /// The project create mode
        /// </summary>
        /// <summary>
        /// The project create mode
        /// </summary>
        private ProjectCreateModes _projectCreateMode;
        /// <summary>
        /// The shared context service
        /// </summary>
        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService _sharedContextService;
        /// <summary>
        /// The context model
        /// </summary>
        /// <summary>
        /// The context model
        /// </summary>
        private ProjectContextModel ContextModel;
        /// <summary>
        /// The project dialogue trigger token
        /// </summary>
        private SubscriptionToken projectDialogueTriggerToken;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContactControlViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="myProfile">My profile.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        public ContactControlViewModel(IEventAggregator eventAggregator, IDialogService dialogService, IMyProfileLogic myProfile, ISharedContextService sharedContextService)
        {
            _dialogService = dialogService;
            this.myProfile = myProfile;
            _eventAggregator = eventAggregator;
            this._sharedContextService = sharedContextService;

            ContactDialog = new DelegateCommand<string>(showContactDialog);
            UpdateContactDialog = new DelegateCommand<string>(showContactDialog, canUpdate).ObservesProperty(() => SelectedContact);
            DeleteCommand = new DelegateCommand(onDelete, canDelete).ObservesProperty(() => SelectedContact);

            //Dynamic View Filter
            ContactsItemsView.Filter = new Predicate<object>(o => Filter(o as ContactModel));

            AddProjectContact = new DelegateCommand(onAddContact, canAddContact).ObservesProperty(() => SelectedContact);
            RemoveProjectContact = new DelegateCommand(onRemoveProjectContact, canRemoveProjectContact).ObservesProperty(() => LinkedContact);

            SelectLinkedContact = new DelegateCommand<object>(onSelectLinkedContact);

            Contacts.CollectionChanged += Contacts_CollectionChanged;
            CustomersTV.CollectionChanged += Contacts_CollectionChanged;
            SchneiderTV.CollectionChanged += Contacts_CollectionChanged;
        }

        /// <summary>
        /// Handles the CollectionChanged event of the Contacts control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void Contacts_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems?.Count != e.NewItems?.Count)
            {
                _eventAggregator.GetEvent<ContactDataChangeEvent>().Publish(Contacts.ToList<ContactModel>());
            }
        }

        #region Contact ADD/update/Delete

        /// <summary>
        /// Gets or sets the selected contact.
        /// </summary>
        /// <value>The selected contact.</value>
        public ContactModel SelectedContact
        {
            get => _selectedContact; set => SetProperty(ref _selectedContact, value);
        }

        /// <summary>
        /// Gets or sets the contacts.
        /// </summary>
        /// <value>The contacts.</value>
        public ObservableCollection<ContactModel> Contacts
        {
            get => _contacts; set
            {
                _contacts = value;
            }
        }

        /// <summary>
        /// Gets the contacts items view. Filter View
        /// </summary>
        /// <value>The contacts items view.</value>
        public ICollectionView ContactsItemsView
        {
            get { return CollectionViewSource.GetDefaultView(Contacts); }
        }

        /// <summary>
        /// Filters the specified contact.
        /// </summary>
        /// <param name="Contact">The contact.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool Filter(ContactModel Contact)
        {
            return Contact.ContactType == this.ContactType;
        }

        /// <summary>
        /// Gets or sets the type of the contact.
        /// </summary>
        /// <value>The type of the contact.</value>
        public ContactType ContactType
        {
            get => _contactType; set
            {
                SetProperty(ref _contactType, value);
                ContactsItemsView.Refresh();
            }
        }

        /// <summary>
        /// Gets or sets the contact dialog.
        /// </summary>
        /// <value>The contact dialog.</value>
        public DelegateCommand<string> ContactDialog { get; set; }

        /// <summary>
        /// Gets or sets the update contact dialog.
        /// </summary>
        /// <value>The update contact dialog.</value>
        public DelegateCommand<string> UpdateContactDialog { get; set; }

        /// <summary>
        /// Determines whether this instance can update the specified diaglog parameter.
        /// </summary>
        /// <param name="DiaglogParam">The diaglog parameter.</param>
        /// <returns><c>true</c> if this instance can update the specified diaglog parameter; otherwise, <c>false</c>.</returns>
        private bool canUpdate(string DiaglogParam)
        {
            return (SelectedContact != null && !SelectedContact.IsEmpty());
        }

        /// <summary>
        /// Shows the contact dialog.
        /// </summary>
        /// <param name="dialogParam">The dialog parameter.</param>
        private void showContactDialog(string dialogParam)
        {
            IDialogParameters contactParam = new DialogParameters();
            if (dialogParam?.ToUpper() == "NEW")
            {
                contactParam.Add("Command", "Save");
                contactParam.Add("Data", ContactType);
            }
            else if (dialogParam?.ToUpper() == "UPDATE")
            {
                if (SelectedContact.IsDefaultContact)
                {
                    MessageBox.Show($"Default contact cannot be updated.", "Alert Contact", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }
                contactParam.Add("Command", "Update");
                if (SelectedContact == null ||
                    SelectedContact.IsEmpty()) return;
                contactParam.Add("Data", SelectedContact);
            }

            _dialogService.ShowDialog("AddNewContactDialog", contactParam, (result) =>
            {
                if (result.Result == ButtonResult.OK)
                {
                    string CommandType = result.Parameters.GetValue<string>("Command");
                    if (CommandType == "Save")
                    {
                        var newContact = result.Parameters.GetValue<ContactModel>("data");
                        Contacts.Add(newContact);
                        SelectedContact = newContact;
                    }
                    else if (CommandType == "Update")
                    {
                        SelectedContact = result.Parameters.GetValue<ContactModel>("data");
                    }
                }
            });
        }

        /// <summary>
        /// Gets or sets the delete command.
        /// </summary>
        /// <value>The delete command.</value>
        public DelegateCommand DeleteCommand { get; set; }

        /// <summary>
        /// Determines whether this instance can delete.
        /// </summary>
        /// <returns><c>true</c> if this instance can delete; otherwise, <c>false</c>.</returns>
        private bool canDelete()
        {
            return (SelectedContact != null && !SelectedContact.IsEmpty());
        }

        /// <summary>
        /// Ons the delete.
        /// </summary>
        private void onDelete()
        {
            if (SelectedContact.IsDefaultContact)
            {
                MessageBox.Show($"Default contact cannot be removed.", "Alert Contact", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            if (MessageBox.Show($"Do you want to delete {SelectedContact?.FirstName} ?", "Delete Contact", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                RemoveFromLinkedContacts(SelectedContact);
                Contacts.Remove(SelectedContact);
            }
        }

        #endregion Contact ADD/update/Delete

        #region Tree-view Contact ADD/Delete

        /// <summary>
        /// The customers tv
        /// </summary>
        private ObservableCollection<ContactModel> _customersTV = new ObservableCollection<ContactModel>();

        /// <summary>
        /// The schneider tv
        /// </summary>
        private ObservableCollection<ContactModel> _SchneiderTV = new ObservableCollection<ContactModel>();

        /// <summary>
        /// The linked contact
        /// </summary>
        private ContactModel _linkedContact;

        /// <summary>
        /// Gets or sets the customers tv.
        /// </summary>
        /// <value>The customers tv.</value>
        public ObservableCollection<ContactModel> CustomersTV { get => _customersTV; set => SetProperty(ref _customersTV, value); }

        /// <summary>
        /// Gets or sets the schneider tv.
        /// </summary>
        /// <value>The schneider tv.</value>
        public ObservableCollection<ContactModel> SchneiderTV { get => _SchneiderTV; set => SetProperty(ref _SchneiderTV, value); }

        /// <summary>
        /// Gets or sets the linked contact.
        /// </summary>
        /// <value>The linked contact.</value>
        public ContactModel LinkedContact
        {
            get => _linkedContact; set => SetProperty(ref _linkedContact, value);
        }

        /// <summary>
        /// Gets or sets the add project contact.
        /// </summary>
        /// <value>The add project contact.</value>
        public DelegateCommand AddProjectContact { get; set; }

        /// <summary>
        /// Determines whether this instance [can add contact].
        /// </summary>
        /// <returns><c>true</c> if this instance [can add contact]; otherwise, <c>false</c>.</returns>
        private bool canAddContact()
        {
            return (SelectedContact != null && !SelectedContact.IsEmpty());
        }

        /// <summary>
        /// Ons the add contact.
        /// </summary>
        public void onAddContact()
        {
            if (CustomersTV.Contains<ContactModel>(SelectedContact) || SchneiderTV.Contains<ContactModel>(SelectedContact))
            {
                MessageBox.Show($"{SelectedContact.FirstName} already exist");
                return;
            }

            SelectedContact.IsLinked = true;
            if (this.ContactType == ContactType.CUSTOMER)
            {
                CustomersTV.Add(SelectedContact);
            }
            else
            {
                SchneiderTV.Add(SelectedContact);
            }
        }

        /// <summary>
        /// Gets or sets the remove project contact.
        /// </summary>
        /// <value>The remove project contact.</value>
        public DelegateCommand RemoveProjectContact { get; set; }

        /// <summary>
        /// Determines whether this instance [can remove project contact].
        /// </summary>
        /// <returns><c>true</c> if this instance [can remove project contact]; otherwise, <c>false</c>.</returns>
        private bool canRemoveProjectContact()
        {
            return (LinkedContact != null);
        }

        /// <summary>
        /// Ons the remove project contact.
        /// </summary>
        private void onRemoveProjectContact()
        {
            if (MessageBox.Show($"Do you want to remove {LinkedContact?.FirstName} ?", "Remove Contact", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                RemoveFromLinkedContacts(LinkedContact);
            }
        }

        /// <summary>
        /// Gets or sets the select linked contact.
        /// </summary>
        /// <value>The select linked contact.</value>
        public DelegateCommand<object> SelectLinkedContact { get; set; }

        /// <summary>
        /// Ons the select linked contact.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void onSelectLinkedContact(object obj)
        {
            var e = obj as RoutedPropertyChangedEventArgs<object>;
            if (e != null)
            {
                LinkedContact = e.NewValue as ContactModel ?? null;
            }
        }

        /// <summary>
        /// Removes from linked contacts.
        /// </summary>
        /// <param name="contact">The contact.</param>
        private void RemoveFromLinkedContacts(ContactModel contact)
        {
            contact.IsLinked = false;
            if (contact.ContactType == ContactType.CUSTOMER)
            {
                CustomersTV.Remove(contact);
            }
            else
            {
                SchneiderTV.Remove(contact);
            }
        }

        #endregion Tree-view Contact ADD/Delete

        /// <summary>
        /// Adds the default contact as logged in user
        /// </summary>
        private void AddDefaultContact()
        {
            try
            {
                ProfileModel profile = myProfile.GetProfile();

                ContactModel newContact = new ContactModel()
                {
                    ContactType = ContactType.SCHNEIDER,
                    Country = profile.Country,
                    Email = profile.Email,
                    Fax = profile.Fax,
                    FirstName = profile.FirstName,
                    IsLinked = false,
                    LastName = profile.LastName,
                    MobileNumber = profile.MobileNumber,
                    Position = profile.Position,
                    PostalCode = profile.PostalCode,
                    Region = profile.Region,
                    Street = profile.Street,
                    Telephone = profile.Telephone,
                    Town = profile.Town,
                    IsDefaultContact = true
                };
                Contacts.Add(newContact);
                newContact.IsLinked = true;
                SchneiderTV.Add(newContact);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Default contact has some error : {ex.Message}", UIConstants.ERROR, MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        /// <summary>
        /// Contacts the control initialize.
        /// </summary>
        public void ContactControlInit()
        {
            if (ProjectCreateMode == ProjectCreateModes.EDIT)
            {
                ContextModel = this._sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
                if (ContextModel != null)
                {
                    Contacts.Clear();
                    CustomersTV.Clear();
                    SchneiderTV.Clear();
                    foreach (var Contactitem in ContextModel.Contacts)
                    {
                        Contacts.Add(Contactitem);

                        if (Contactitem.IsLinked && Contactitem.ContactType == ContactType.CUSTOMER)
                        {
                            CustomersTV.Add(Contactitem);
                        }
                        else if (Contactitem.IsLinked && Contactitem.ContactType == ContactType.SCHNEIDER)
                        {
                            SchneiderTV.Add(Contactitem);
                        }
                    }
                }
            }
            else
            {
                AddDefaultContact();
            }

            ContactType = ContactType.CUSTOMER;
        }

        /// <summary>
        /// Disposes this instance.
        /// </summary>
        public void Dispose()
        {
        }
    }
}