﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="EditInventoryControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;

namespace M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls
{
    /// <summary>
    /// ViewModel for EditInventory.
    /// Provide Binding Data and Event
    /// </summary>
    public class EditInventoryControlViewModel : BindableBase, IDialogAware
    {
        #region Class Fiels

        /// <summary>
        /// The selected product
        /// </summary>
        private ProductModel _selectedProduct;
        /// <summary>
        /// The selected invetory
        /// </summary>
        private Inventory _selectedInvetory;

        #endregion Class Fiels

        /// <summary>
        /// Event of Close Dialog Box
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }

        /// <summary>
        /// Get Selected Product
        /// </summary>
        /// <value>The selected product.</value>
        public ProductModel SelectedProduct
        {
            get => _selectedProduct;
            set
            {
                SetProperty(ref _selectedProduct, value);
            }
        }

        /// <summary>
        /// Initialize class fields
        /// </summary>
        public EditInventoryControlViewModel()
        {
            CloseDialogCommand = new DelegateCommand<string>(OnSaveAction);
        }

        /// <summary>
        /// Called when [save action].
        /// </summary>
        /// <param name="commandParam">The command parameter.</param>
        private void OnSaveAction(string commandParam)
        {
            if (commandParam.ToUpper() == CollectionConstant.Ok)
            {
                _selectedInvetory.Comment = SelectedProduct.Comments;
                _selectedInvetory.PvNumber = SelectedProduct.PvNumber;
                _selectedInvetory.SvNumber = SelectedProduct.SvNumber;
                _selectedInvetory.Quantity = int.TryParse(SelectedProduct.Quantity, out var quantity) ? quantity : 1;
                var parameters = new DialogParameters { { CollectionConstant.Edit, _selectedInvetory } };

                RequestClose?.Invoke(new DialogResult(ButtonResult.OK, parameters));
            }
            else
            {
                RequestClose?.Invoke(new DialogResult(ButtonResult.Cancel));
            }
        }

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
        }

        /// <summary>
        /// Called when the dialog is opened.
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            if (parameters.TryGetValue(CollectionConstant.Edit, out _selectedInvetory))
            {
                SelectedProduct = new ProductModel()
                {
                    Description = _selectedInvetory.Name,
                    Identifier = _selectedInvetory.Reference,
                    PvNumber = _selectedInvetory.PvNumber,
                    SvNumber = _selectedInvetory.SvNumber,
                    Comments = _selectedInvetory.Comment,
                    Quantity = _selectedInvetory.Quantity.ToString(),
                };
            }
        }

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => "Edit Inventory";

        /// <summary>
        /// Occurs when [request close].
        /// </summary>
        public event Action<IDialogResult> RequestClose;
    }
}