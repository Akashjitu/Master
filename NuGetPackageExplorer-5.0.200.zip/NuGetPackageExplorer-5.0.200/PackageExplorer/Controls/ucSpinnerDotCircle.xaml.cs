﻿using System.Windows.Controls;

namespace xamlSpinnersWPF
{
    /// <summary>
    /// Interaction logic for ucSpinnerDotCircle.xaml
    /// </summary>
    public partial class ucSpinnerDotCircle : UserControl
    {
#pragma warning disable CS8618 // Non-nullable field is uninitialized.
        public ucSpinnerDotCircle()
#pragma warning restore CS8618 // Non-nullable field is uninitialized.
        {
            InitializeComponent();
        }
    }
}
