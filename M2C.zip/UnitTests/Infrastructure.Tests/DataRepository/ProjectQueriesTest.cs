﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.Common;
using DomainModels.IbCatalogModels;
using DomainModels.ProjectModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class ProjectQueriesTest : TestBase
    {
        private IQueryable<Project> projectList;
        private Mock<DbSet<Project>> projectMock;

        private IQueryable<ProjectInventory> projectInvntryList;
        private Mock<DbSet<ProjectInventory>> projectInvntryMock;

        private IQueryable<InventoryComments> invntryCommentsList;
        private Mock<DbSet<InventoryComments>> invntryCommentsMock;

        private IQueryable<IBProjectComponent> iBProjectComponentList;
        private Mock<DbSet<IBProjectComponent>> iBProjectComponentMock;


        private IQueryable<Contact> contactsList;
        private Mock<DbSet<Contact>> contactsMock;



        [TestInitialize]
        public void TestIniTialize()
        {

            List<Project> project = new List<Project>() { new Project() { ProjectID = 1, Customer = new Customer() { CustomerID = 1 }, Contacts = new List<Contact>() { new Contact() { ContactID = 1 } } } };
            projectList = project.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProjectDbContextMock = MockRepo.Create<IProjectDbContext>();

            projectMock = MockRepo.Create<DbSet<Project>>();
            projectMock.As<IQueryable<Project>>().Setup(m => m.Provider).Returns(projectList.Provider);
            projectMock.As<IQueryable<Project>>().Setup(m => m.Expression).Returns(projectList.Expression);
            projectMock.As<IQueryable<Project>>().Setup(m => m.ElementType).Returns(projectList.ElementType);
            projectMock.As<IQueryable<Project>>().Setup(m => m.GetEnumerator()).Returns(projectList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.Projects).Returns(projectMock.Object);


            List<ProjectInventory> prjctInventory = new List<ProjectInventory>() { new ProjectInventory() { ProjectId = 1 } };
            projectInvntryList = prjctInventory.AsQueryable();

            projectInvntryMock = MockRepo.Create<DbSet<ProjectInventory>>();
            projectInvntryMock.As<IQueryable<ProjectInventory>>().Setup(m => m.Provider).Returns(projectInvntryList.Provider);
            projectInvntryMock.As<IQueryable<ProjectInventory>>().Setup(m => m.Expression).Returns(projectInvntryList.Expression);
            projectInvntryMock.As<IQueryable<ProjectInventory>>().Setup(m => m.ElementType).Returns(projectInvntryList.ElementType);
            projectInvntryMock.As<IQueryable<ProjectInventory>>().Setup(m => m.GetEnumerator()).Returns(projectInvntryList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.ProjectInventories).Returns(projectInvntryMock.Object);

            List<InventoryComments> inventoryComent = new List<InventoryComments>() { new InventoryComments() { ProjectId = 1 } };
            invntryCommentsList = inventoryComent.AsQueryable();
            invntryCommentsMock = MockRepo.Create<DbSet<InventoryComments>>();
            invntryCommentsMock.As<IQueryable<InventoryComments>>().Setup(m => m.Provider).Returns(invntryCommentsList.Provider);
            invntryCommentsMock.As<IQueryable<InventoryComments>>().Setup(m => m.Expression).Returns(invntryCommentsList.Expression);
            invntryCommentsMock.As<IQueryable<InventoryComments>>().Setup(m => m.ElementType).Returns(invntryCommentsList.ElementType);
            invntryCommentsMock.As<IQueryable<InventoryComments>>().Setup(m => m.GetEnumerator()).Returns(invntryCommentsList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.InventoryComments).Returns(invntryCommentsMock.Object);

            List<IBProjectComponent> iBProjectComponent = new List<IBProjectComponent>() { new IBProjectComponent() { Project = new Project() { ProjectID = 1 } } };
            iBProjectComponentList = iBProjectComponent.AsQueryable();
            iBProjectComponentMock = MockRepo.Create<DbSet<IBProjectComponent>>();
            iBProjectComponentMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.Provider).Returns(iBProjectComponentList.Provider);
            iBProjectComponentMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.Expression).Returns(iBProjectComponentList.Expression);
            iBProjectComponentMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.ElementType).Returns(iBProjectComponentList.ElementType);
            iBProjectComponentMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.GetEnumerator()).Returns(iBProjectComponentList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.IBProjectComponents).Returns(iBProjectComponentMock.Object);


            List<Contact> contact = new List<Contact>() { new Contact() { Project = new Project() { ProjectID = 1 } } };
            contactsList = contact.AsQueryable();
            contactsMock = MockRepo.Create<DbSet<Contact>>();
            contactsMock.As<IQueryable<Contact>>().Setup(m => m.Provider).Returns(contactsList.Provider);
            contactsMock.As<IQueryable<Contact>>().Setup(m => m.Expression).Returns(contactsList.Expression);
            contactsMock.As<IQueryable<Contact>>().Setup(m => m.ElementType).Returns(contactsList.ElementType);
            contactsMock.As<IQueryable<Contact>>().Setup(m => m.GetEnumerator()).Returns(contactsList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.Contacts).Returns(contactsMock.Object);


            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);


        }

        [TestMethod]
        public void GetOnlyProjectsTest()
        {
            IProjectQueries project = new ProjectQueries(IDbContextFactoryMock.Object);
            List<Project> projectRes = project.GetOnlyProjects();
            projectRes.Should().HaveCount(1);

            ((IDisposable)project).Dispose();
        }
        [TestMethod]
        public void GetProjectTest()
        {
            IProjectQueries project = new ProjectQueries(IDbContextFactoryMock.Object);
            Project projectRes = project.GetProject(1);
            projectRes.Should().NotBeNull();
            ((IDisposable)project).Dispose();
        }
        [TestMethod]
        public void GetAllProjectsTest()
        {
            IProjectQueries project = new ProjectQueries(IDbContextFactoryMock.Object);
            List<Project> projectRes = project.GetAllProjects();
            projectRes.Should().NotBeNull();
            ((IDisposable)project).Dispose();

        }
    }
}
