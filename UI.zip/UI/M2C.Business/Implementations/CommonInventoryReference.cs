﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="CommonInventoryReference.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DomainModels.IbCatalogModels;
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Models;
using System.Collections.Generic;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class CommonInventoryReference.
    /// Implements the <see cref="M2C.Business.Contracts.ICommonInventoryReference" />
    /// </summary>
    /// <seealso cref="M2C.Business.Contracts.ICommonInventoryReference" />
    public class CommonInventoryReference : ICommonInventoryReference
    {
        /// <summary>
        /// The brand model mapper
        /// </summary>
        private readonly IBrandModelMapper _brandModelMapper;
        /// <summary>
        /// The range model mapper
        /// </summary>
        private readonly IRangeModelMapper _rangeModelMapper;
        /// <summary>
        /// The device type model mapper
        /// </summary>
        private readonly IDeviceTypeModelMapper _deviceTypeModelMapper;
        /// <summary>
        /// The product model mapper
        /// </summary>
        private readonly IProductModelMapper _productModelMapper;

        /// <summary>
        /// The product queries
        /// </summary>
        private readonly IProductQueries _productQueries;
        /// <summary>
        /// The brand queries
        /// </summary>
        private readonly IBrandQueries _brandQueries;
        /// <summary>
        /// The range queries
        /// </summary>
        private readonly IRangeQueries _rangeQueries;
        /// <summary>
        /// The device type queries
        /// </summary>
        private readonly IDeviceTypeQueries _deviceTypeQueries;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommonInventoryReference" /> class.
        /// </summary>
        /// <param name="brandModelMapper">The brand model mapper.</param>
        /// <param name="rangeModelMapper">The range model mapper.</param>
        /// <param name="deviceTypeModelMapper">The device type model mapper.</param>
        /// <param name="productModelMapper">The product model mapper.</param>
        /// <param name="productQueries">The product queries.</param>
        /// <param name="brandQueries">The brand queries.</param>
        /// <param name="rangeQueries">The range queries.</param>
        /// <param name="deviceTypeQueries">The device type queries.</param>
        public CommonInventoryReference(
            IBrandModelMapper brandModelMapper,
            IRangeModelMapper rangeModelMapper,
            IDeviceTypeModelMapper deviceTypeModelMapper,
            IProductModelMapper productModelMapper,
            IProductQueries productQueries,
            IBrandQueries brandQueries,
            IRangeQueries rangeQueries,
            IDeviceTypeQueries deviceTypeQueries)
        {
            _brandModelMapper = brandModelMapper;
            _rangeModelMapper = rangeModelMapper;
            _deviceTypeModelMapper = deviceTypeModelMapper;
            _productModelMapper = productModelMapper;

            _productQueries = productQueries;
            this._brandQueries = brandQueries;
            this._rangeQueries = rangeQueries;
            this._deviceTypeQueries = deviceTypeQueries;
        }

        /// <summary>
        /// Gets the products
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<ProductModel> GetProductsStartWithIdentifier(string identifier)
        {
            var products = _productQueries.GetProductsStartWithIdentifier(identifier);
            return _productModelMapper.Map(products);
        }

        /// <summary>
        /// Gets the products Start With Identifier and Config Node
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <param name="configNodeType">Type of the node.</param>
        /// <param name="isSe"></param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<ProductModel> GetProductsStartWithIdentifierByNode(string identifier, string configNodeType, bool isSe=true)
        {
            var products = _productQueries.GetProductsStartWithIdentifier(identifier, configNodeType, isSe);
            return _productModelMapper.Map(products);
        }

        /// <summary>
        /// Get Products Only
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<ProductModel> GetOnlyProducts(string identifier)
        {
            var products = _productQueries.GetProducts(identifier);
            return _productModelMapper.Map(products);
        }

        /// <summary>
        /// Get Products
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>ProductModel.</returns>
        public ProductModel GetProductsByIdentifier(string identifier)
        {
            var products = _productQueries.GetProductsByIdentifier(identifier);
            return _productModelMapper.Map(products);
        }

        /// <summary>
        /// Gets the database products.
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> GetDbProducts(string identifier)
        {
            return _productQueries.GetProductsStartWithIdentifier(identifier);
        }

        /// <summary>
        /// Gets the brand models.
        /// </summary>
        /// <param name="brandName">Name of the brand.</param>
        /// <param name="isSe"></param>
        /// <returns>List&lt;BrandModel&gt;.</returns>
        public List<BrandModel> GetBrandModels(string brandName, bool isSe=true)
        {
            return _brandModelMapper.Map(_brandQueries.LoadBrands(brandName, isSe));
        }

        /// <summary>
        /// Gets the range by brand.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <returns>List&lt;RangeModel&gt;.</returns>
        public List<RangeModel> GetRangeByBrand(int brandId)
        {
            return _rangeModelMapper.Map(_rangeQueries.GetRangeByBrand(brandId));
        }

        /// <summary>
        /// Gets the range by brand and device type ids.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="deviceTypeId">The device type identifier.</param>
        /// <returns>List&lt;RangeModel&gt;.</returns>
        public List<RangeModel> GetRangeByBrandAndDeviceTypeIds(int brandId, int deviceTypeId)
        {
            return _rangeModelMapper.Map(_rangeQueries.GetRangeByBrandAndDeviceTypeIds(brandId, deviceTypeId));
        }

        /// <summary>
        /// Gets the device types by brand and range identifier.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="rangeId">The range identifier.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceTypeModel> GetDeviceTypesByBrandAndRangeId(int brandId, int rangeId)
        {
            return _deviceTypeModelMapper.Map(_deviceTypeQueries.GetDeviceTypesByBrandAndRangeId(brandId, rangeId));
        }

        /// <summary>
        /// Gets the device types by brand.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceTypeModel> GetDeviceTypesByBrand(int brandId)
        {
            return _deviceTypeModelMapper.Map(_deviceTypeQueries.GetDeviceTypesByBrandId(brandId));
        }

        /// <summary>
        /// Gets the device types by brand Id config Node Type.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="nodeType">Type of the node.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceTypeModel> GetDeviceTypesByBrandIdAndNodeType(int brandId, string nodeType)
        {
            return _deviceTypeModelMapper.Map(_deviceTypeQueries.GetDeviceTypesByBrandIdAndNodeType(brandId, nodeType));
        }

        /// <summary>
        /// Gets the products.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="deviceTypeId">The device type identifier.</param>
        /// <param name="rangeId">The range identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<ProductModel> GetProducts(int brandId, int deviceTypeId, int rangeId)
        {
            var products = _productQueries.GetProductByIds(brandId, rangeId, deviceTypeId);
            return _productModelMapper.Map(products);
        }

        /// <summary>
        /// Gets the device types.
        /// </summary>
        /// <param name="deviceName">Name of the device.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceTypeModel> GetDeviceTypes(string deviceName)
        {
            return _deviceTypeModelMapper.Map(_deviceTypeQueries.LoadDeviceTypes(deviceName));
        }

        /// <summary>
        /// Gets the device types with Config Node Type.
        /// </summary>
        /// <param name="configNodeType">Type of the configuration node.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceTypeModel> GetDeviceTypesByNodeType(string configNodeType)
        {
            return _deviceTypeModelMapper.Map(_deviceTypeQueries.GetDeviceTypesByNodeType(configNodeType));
        }

        /// <summary>
        /// Gets the products by device identifier and range identifier.
        /// </summary>
        /// <param name="deviceId">The device identifier.</param>
        /// <param name="rangeId">The range identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<ProductModel> GetProductsByDeviceIdAndRangeId(int deviceId, int rangeId)
        {
            return _productModelMapper.Map(_productQueries.GetProductsByDeviceIdAndRangeId(rangeId, deviceId));
        }

        /// <summary>
        /// Gets the range by device type ids.
        /// </summary>
        /// <param name="deviceId">The device identifier.</param>
        /// <returns>List&lt;RangeModel&gt;.</returns>
        public List<RangeModel> GetRangeByDeviceTypeIds(int deviceId)
        {
            return _rangeModelMapper.Map(_rangeQueries.GetRangeByDeviceId(deviceId));
        }
    }
}