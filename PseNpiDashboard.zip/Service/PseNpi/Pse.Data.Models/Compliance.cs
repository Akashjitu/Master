﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class Compliance
    {
       
        [Columns("p_ID")]
        public int id { get; set; }

        [Columns("p_KEYCODE")]
        public string Keycode { get; set; }

        [Columns("p_HEATMAPVALID")]
        public string HeatmapValid { get; set; }

        [Columns("p_HEATMAPCOMMENT")]
        public string HeatmapComment { get; set; }

        [Columns("p_OTLVALID")]
        public string OTLValid { get; set; }

        [Columns("p_OTLCOMMENT")]
        public string OTLComment { get; set; }

        [Columns("p_ESEVALID")]
        public string ESEValid { get; set; }

        [Columns("p_ESECOMMENT")]
        public string ESEComment { get; set; }

        [Columns("p_APQPPLANVALID")]
        public string APQPPlanValid { get; set; }

        [Columns("p_APQPPLANCOMMENT")]
        public string APQPPlanComment { get; set; }

        [Columns("p_SIMPARTVALID")]
        public string SimPartValid { get; set; }

        [Columns("p_SIMILARPARTCOMMENT")]
        public string SimilarPartComment { get; set; }

        [Columns("p_IPTVALID")]
        public string IPTValid { get; set; }

        [Columns("p_IPTCOMMENT")]
        public string IPTComment { get; set; }

        [Columns("p_PARTVALID")]
        public string PartValid { get; set; }

        [Columns("p_PARTCOMMENT")]
        public string PartComment { get; set; }

        [Columns("p_RTYVALID")]
        public string RTYValid { get; set; }

        [Columns("p_RTYCOMMENT")]
        public string RTYComment { get; set; }

        [Columns("p_UPCVALID")]
        public string UPCValid { get; set; }

        [Columns("p_UPCCOMMENT")]
        public string UPCComment { get; set; }


        [Columns("p_CREATEDBY")]
        public string CreatedBy { get; set; }


        [Columns("p_CREATEDON")]
        public DateTime CreateDon { get; set; }


        [Columns("p_UPDARTEDBY")]
        public string UpdartedBy { get; set; }

        [Columns("p_UPDATEDON")]
        public DateTime UpdateDon { get; set; }


        [Columns("p_ISACTIVE")]
        public int IsActive { get; set; }
    }
}
