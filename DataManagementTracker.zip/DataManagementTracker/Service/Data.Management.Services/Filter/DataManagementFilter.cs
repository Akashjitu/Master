﻿using Data.Management.Data.Models;
using Data.Management.Data.Models.Enum;
using Data.Management.Services.DataBaseAccessObject;
using DataManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Data.Management.Services.Filter
{
    public class DataManagementFilter : IDataManagementFilter
    {
        private readonly IDataManagementDbAccess _database;

        public DataManagementFilter(IDataManagementDbAccess db)
        {
            _database = db;
        }

        public List<DataManagementTrack> FilterAccess(string eid, List<DataManagementTrack> dataManagementTrack)
        {

            if (string.IsNullOrEmpty(eid) || dataManagementTrack == null)
                return new List<DataManagementTrack>();

            EmployeeInfo employeesInfo = _database.GetEmployeeAccessByEid(new EmployeeInfo { EID = eid });

            var cms = dataManagementTrack.Where(i => string.Compare(i.Cm, eid, StringComparison.OrdinalIgnoreCase) == 0).ToList();
            var dms = dataManagementTrack.Where(i => string.Compare(i.DataManager, eid, StringComparison.OrdinalIgnoreCase) == 0).ToList();
            var rqs = dataManagementTrack.Where(i => string.Compare(i.Requestor, eid, StringComparison.OrdinalIgnoreCase) == 0).ToList();

            cms.ForEach(i => i.AccessUIType = AccessUIType.Comment);
            dms.ForEach(i => i.AccessUIType = AccessUIType.Edit);
            rqs.ForEach(i => i.AccessUIType = AccessUIType.ReadOnly);

            if (employeesInfo != null )
            {
                var emp = employeesInfo;
                AccessDbType accessDbType = (AccessDbType)emp.AccessType;

                switch (accessDbType)
                {
                    //case AccessDbType.NoAccess:
                    //    var datamng = new List<DataManagementTrack>();
                    //    datamng.AddRange(cms);
                    //    datamng.AddRange(dms);
                    //    datamng.AddRange(rqs);
                    //    return datamng.Distinct().ToList();

                    case AccessDbType.FullAccess:
                        dataManagementTrack.ForEach(i => i.AccessUIType = AccessUIType.Edit);
                        return dataManagementTrack;

                    case AccessDbType.NoAccess:
                    case AccessDbType.ViewOnly:
                        return dataManagementTrack;

                    default:
                        break;
                }
            }
            else
            {

                return dataManagementTrack;
                //var datamng = new List<DataManagementTrack>();
                //datamng.AddRange(cms);
                //datamng.AddRange(dms);
                //datamng.AddRange(rqs);
                //return datamng.Distinct().ToList();
            }

            return new List<DataManagementTrack>();
        }
    }
}