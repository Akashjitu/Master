﻿//using Microsoft.Practices.Unity;
//using Pse.Services.DataBaseAccessObject.Loader;
//using Pse.Services.Manager;
//using Pse.Services.Service;
//using Spea.Service.DataBaseAccessObject.Saver;
//using System.Web.Mvc;
//using Unity;
//using Unity.Mvc5;

//namespace PSENPI.App_Start
//{
//    public class IOCConfig
//    {
//        public static void RegisterComponents()
//        {
//            var container = new UnityContainer();

//            container.RegisterType<ISpeService, SpeService>();
//            container.RegisterType<ISpeServiceManage, SpeServiceManage>();
//            container.RegisterType<IServiceDataLoader, ServiceDataLoader>();
//            container.RegisterType<ISeviceDataSave, SeviceDataSave>();
//            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
//        }
//    }
//}