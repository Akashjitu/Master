﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;

namespace Pse.Services.Manager
{
    public interface ICoreIptManager
    {
        List<CoreIpt> LoadAllCoreIpt();

        List<CoreIpt> LoadCoreIptByCreationDate(DateTime creationDate);

        List<CoreIpt> LoadCoreIptByKeyCode(string keycode);

        List<CoreIpt> LoadLatestCoreIpt();

        List<CoreIpt> LoadCoreIptById(int Id);

        CoreIpt AddCoreIpt(CoreIpt CoreIpt);

        CoreIpt UpdateCoreIpt(CoreIpt CoreIpt);
    }
}