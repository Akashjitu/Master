import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlGraduatesComponent } from './otl-graduates.component';

describe('OtlGraduatesComponent', () => {
  let component: OtlGraduatesComponent;
  let fixture: ComponentFixture<OtlGraduatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlGraduatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlGraduatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
