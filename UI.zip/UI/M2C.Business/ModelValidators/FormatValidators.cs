﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="FormatValidators.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Text.RegularExpressions;

namespace M2C.Business.ModelValidators
{
    /// <summary>
    /// Class FormatValidators.
    /// </summary>
    public class FormatValidators
    {
        /// <summary>
        /// validate the zip code.
        /// </summary>
        /// <param name="zipCode">The zip code.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public static bool IsvalidZipCode(string zipCode)
        {
            string usZip = @"^[0-9]{5}(?:-[0-9]{4})?$";
            string indZip = @"^\d{3}\s?\d{3}$";
            string zip = @"\d{6}$";
            if (string.IsNullOrEmpty(zipCode)) { return false; }
            var validZipCode = true;
            if ((!Regex.Match(zipCode, usZip).Success)
                && (!Regex.Match(zipCode, indZip).Success)
                 && (!Regex.Match(zipCode, zip).Success))
            {
                validZipCode = false;
            }
            return validZipCode;
        }

        /// <summary>
        /// Determines whether [is valid email] [the specified email].
        /// </summary>
        /// <param name="Email">The email.</param>
        /// <returns><c>true</c> if [is valid email] [the specified email]; otherwise, <c>false</c>.</returns>
        public static bool IsValidEmail(string Email)
        {
            return Regex.IsMatch(Email,
                @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z",
                RegexOptions.IgnoreCase);
        }

        /// <summary>
        /// Determines whether [is valid phone] [the specified phone number].
        /// </summary>
        /// <param name="PhoneNumber">The phone number.</param>
        /// <returns><c>true</c> if [is valid phone] [the specified phone number]; otherwise, <c>false</c>.</returns>
        public static bool IsValidPhone(string PhoneNumber)
        {
            string interNational = @"^\s*\+?[0-9]\d?[- .]?(\([2-9]\d{2}\)|[2-9]\d{2})[- .]?\d{3}[- .]?\d{4}$";
            return Regex.IsMatch(PhoneNumber, interNational, RegexOptions.IgnoreCase);
        }

        /// <summary>
        /// Determines whether [is valid fax] [the specified fax number].
        /// </summary>
        /// <param name="faxNumber">The fax number.</param>
        /// <returns><c>true</c> if [is valid fax] [the specified fax number]; otherwise, <c>false</c>.</returns>
        public static bool IsValidFax(string faxNumber)
        {
            string interNational = @"^(\+?\d{1,}(\s?|\-?)\d*(\s?|\-?)\(?\d{2,}\)?(\s?|\-?)\d{3,}\s?\d{3,})$";
            return Regex.IsMatch(faxNumber, interNational, RegexOptions.IgnoreCase);
        }
    }
}