import { DatePipe } from '@angular/common';

export class OtlSummaryGridColumns {
    constructor(private datePipe: DatePipe){}



    static  columns =[
        {
          headerName: "Key Code",
          field: "keyCode",
          colId: "keyCode", hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Program Name",
          field: "programName",
          colId: "programName",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "SBU",
          field: "productSbu",
          colId: "productSbu",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, };
          }
        },
        {
          headerName: "HMR Baseline",
          field: "hmrBaseline",
          colId: "hmrBaseline",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        }, {
          headerName: "RTY",
          field: "rty",
          colId: "rty",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'syid', 'border-color': 'white' };
          }
        }, {
          headerName: "UPC",
          field: "upc",
          colId: "upc",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "Escapes",
          field: "escapes",
          colId: "escapes",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "PPAP",
          field: "ppap",
          colId: "ppap",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "PRR",
          field: "prr",
          colId: "prr",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "MRA",
          field: "mra",
          colId: "mra",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "OTL Health",
          field: "otlHealth",
          colId: "otlHealth",
          hide: false,
          editable: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Created Date",
          field: "createdDate",
          colId: "createdDate",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "Created By",
          field: "createdBy",
          colId: "createdBy",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
  
        {
          headerName: "Updated By",
          field: "updatedBy",
          colId: "updatedBy",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "Active",
          field: "active",
          colId: "active",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Id",
          field: "id",
          colId: "id",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "updated Date",
          field: "updatedDate",
          colId: "updatedDate",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Updated By DashBoard",
          field: "updatedByDashBoard",
          colId: "updatedByDashBoard",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        }

      ];
}