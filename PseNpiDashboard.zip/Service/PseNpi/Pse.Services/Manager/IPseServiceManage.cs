﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;

namespace Pse.Services.Manager
{
    public interface ISpeServiceManage
    {
        List<TtiPartAlignment> LoadTtiByParameter(TtiPartAlignment ttiPartAlignment);

        List<TtiPartAlignment> LoadTti();

        List<Compliance> LoadCompliance();

        int DeleteCompliance(Compliance compliance);

        int UpdateCompliance(Compliance compliance);

        int SubmitCompliances(List<Compliance> compliances);

        int SubmitTTi(List<TtiPartAlignment> tti);

        int AddCompliance(Compliance compliance);

        int AddTTiInfo(TtiPartAlignment ttiPartAlignment);

        int UpdateTTiInfo(TtiPartAlignment ttiPartAlignment);

        List<TtiPartAlignment> LoadTtiByDate(TtiPartAlignment ttiPartAlignment);

        List<Effectiveness> LoadEffectivenesByPart(Effectiveness effectiveness);

        List<Effectiveness> LoadEffectivenesById(Effectiveness effectiveness);

        List<Effectiveness> LoadEffectivenesByDate(Effectiveness effectiveness);

        List<Effectiveness> LoadPppPartInfo(Effectiveness effectiveness);

        int SubmitEffectivenes(List<Effectiveness> effectiveness);

        List<EffectivenessAnalysis> LoadEffectivenesAnalysis();

        List<EffectivenessAnalysis> LoadEffectivenessAnalysisByCreationDate(EffectivenessAnalysis effectivenessAnalysis);

        List<EffectivenessAnalysis> LoadEffectivenessAnalysisById(EffectivenessAnalysis effectivenessAnalysis);

        List<EffectivenessAnalysis> LoadEffectivenessAnalysisByPart(EffectivenessAnalysis effectivenessAnalysis);

        int SubmitOtlDisposition(List<OtlDispositionDetails> lstOTL);

        List<OtlDispositionDetails> LoadOtlDispositionById(OtlDispositionDetails otlDisposition);

        List<OtlDispositionDetails> LoadOtlDispositionByDate(OtlDispositionDetails otlDisposition);

        List<OtlDispositionDetails> LoadOtlDispositionByKeyCode(OtlDispositionDetails otlDisposition);

        int UpdateOtlDispositionByID(OtlDispositionDetails otlDisposition);

        byte[] ExportEffectivenesAnalysis(EffectivenessAnalysis effectivenessAnalysis);

        byte[] ExportOtlDisposition(OtlDispositionDetails otlDisposition);

        byte[] ExportEffectivene(Effectiveness effectiveness);

        byte[] ExportTti(TtiPartAlignment tti);

        byte[] ExportCompliance(Compliance ompliance);

        byte[] ExportPliByDate(Pli ompliance);

        byte[] ExportAllPli();

        byte[] ExportPliByFilter(Pli ompliance);

        byte[] ExportOtlAnalysisByDate(OtlAnalysis otlAnalysis);


        List<Pli> LoadPli();

        List<Pli> LoadPliByDate(Pli pli);

        List<Pli> LoadPliById(Pli pli);

        List<Pli> LoadPliByKeyCode(Pli pli);




        List<OtlAnalysis> LoadOtlAnalysis();
        List<OtlAnalysis> LoadOtlAnalysisByDate(OtlAnalysis otl);
        List<OtlAnalysis> LoadOtlAnalysisById(OtlAnalysis otl);

        List<OtlAnalysis> LoadOtlAnalysisByKeyCode(OtlAnalysis otl);

        int SubmitOtlAnalysisById(List< OtlAnalysis> otl);


        EscapesManufacturedOtl EscapesManufacturedOtl(DateTime fromdate, int subtractMonth);

        byte[] ExportEscapesManufacturedOtl(DateTime fromdate, int subtractMonth);

    }
}