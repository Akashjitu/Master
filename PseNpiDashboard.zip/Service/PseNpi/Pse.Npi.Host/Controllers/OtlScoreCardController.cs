﻿using Pse.Data.Models;
using Pse.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class OtlScoreCardController : ApiController
    {
        private IOtlScoreCardService _service;

        public OtlScoreCardController(IOtlScoreCardService service)
        {
            _service = service;
        }

        [HttpGet]
        public HttpResponseMessage GeOtlSummery()
        {
            var cp = _service.LoadAllOtlScoreCards();
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        public HttpResponseMessage AddOtlSummery(OtlScoreCard otlScoreCard)
        {
            var cp = _service.AddOtlScoreCard(otlScoreCard);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPut]
        public HttpResponseMessage UpdateOtlSummery(int id, OtlScoreCard otlScoreCard)
        {
            var cp = _service.UpdateOtlScoreCard(otlScoreCard);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}
