﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Prism.Ioc;
using Prism.Regions;

namespace M2C.Desktop.Modules.CollectData.Test
{
    [TestClass]
    public class CollectDataModuleTest
    {
        IContainerRegistry _containerRegistry;
        IContainerProvider _containerProvider;
        private IRegionManager _regionManager;
        private CollectDataModule _collectDataModule;
        [TestInitialize]
        public void Setup()
        {
            _containerRegistry = Substitute.For<IContainerRegistry>();
            _containerProvider = Substitute.For<IContainerProvider>();
            _regionManager = Substitute.For<IRegionManager>();
            _collectDataModule = new CollectDataModule(_regionManager);
        }

        [TestMethod]
        public void ShouldCallOnInitializedForContainerProvider()
        {
            _collectDataModule.OnInitialized(_containerProvider);
        }

        [TestMethod]
        public void ShouldCallRegisterTypesForContainerRegistry()
        {
            _collectDataModule.RegisterTypes(_containerRegistry);
        }
    }
}