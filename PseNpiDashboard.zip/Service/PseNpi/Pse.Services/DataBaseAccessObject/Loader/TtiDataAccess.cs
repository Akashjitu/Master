﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class TtiDataAccess : ITtiDataAccess
    {
        public List<TtiPartAlignment> LoadTti()
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.Load("PK_PSE_TTI.SP_LOAD_TTI");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<TtiPartAlignment> LoadTtiByParameter(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_TTI.SP_LOAD_TTI_BY_KC_AND_DATE");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<TtiPartAlignment> LoadTtiByDate(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_TTI.SP_LOAD_TTI_BY_MO_YY");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<TtiPartAlignment> LoadTtiById(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_TTI.SP_LOAD_TTI_BY_ID");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public int UpdateTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.Post(ttiPartAlignment, "PK_PSE_TTI.SP_UPDATE_TTI_INFO");
                return data;
            }
        }

        public int AddTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.Post(ttiPartAlignment, "PK_PSE_TTI.SP_ADD_TTI_INFO");
                return data;
            }
        }
    }
}