﻿using Data.Management.Service.Host.ExceptionFilters;
using Data.Management.Service.Host.Mail;
using Data.Management.Service.Host.Providers;
using Data.Management.Services;
using Data.Management.Services.Filter;
using DataManagement.Data.Models;
using Honeywell.ActiveDirectory;
using Hts.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Data.Management.Service.Host.Controllers
{
    [LogExceptionFilterAttribute]
    public class DataManagementController : ApiController
    {
        private readonly IDataManagementServices _dataManagementServices;
        private readonly IMailProvider _mailService;
        IActiveDirectoryHelper _activeDirectoryHelper;
        private readonly IDataManagementFilter _filter;
       
        public DataManagementController(IDataManagementServices dataManagementServices,
            IMailProvider mailService, IDataManagementFilter filter,
            IActiveDirectoryHelper activeDirectoryHelper)
        {
            _dataManagementServices = dataManagementServices;
            _mailService = mailService;
            _filter = filter;
            _activeDirectoryHelper = activeDirectoryHelper;
    }

        [HttpGet]
        public HttpResponseMessage LoadAllDataManagements()
        {
            
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
          
            //if (string.IsNullOrEmpty(eid))
           ////eid = "H161961";
            var data = _dataManagementServices.LoadAllDataManagements();

             data = _filter.FilterAccess(eid, data);

            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpGet]
        public HttpResponseMessage LoadById(int id)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //if (string.IsNullOrEmpty(eid))
           ////eid = "H161961";
            var data = _dataManagementServices.LoadById(id);

             data = _filter.FilterAccess(eid,data);


            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }

        //[HttpGet]
        //public HttpResponseMessage LoadByDate(DateTime created)
        //{
        //    var data = _dataManagementServices.LoadByDate(created);
        //    return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        //}

        [HttpPost]
        public HttpResponseMessage AddNew(DataManagementTrack dataManagement)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //if (string.IsNullOrEmpty(eid))
          ////eid = "H161961";
            dataManagement.CreatedBy = eid;
            dataManagement.CreatedDate = DateTime.Today;
            var data = _dataManagementServices.AddNew(dataManagement);

             var filterData = _filter.FilterAccess(eid, new List<DataManagementTrack>() { data });

            if (filterData != null)
                SendMail(filterData[0]);

            return Request.CreateResponse(HttpStatusCode.OK, filterData[0], JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPut]
        public HttpResponseMessage UpdateData(int id, DataManagementTrack dataManagement)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
           //if (string.IsNullOrEmpty(eid))
                ////eid = "H161961";

            dataManagement.UpdatedBy = eid;
            dataManagement.UpdatedDate = DateTime.Today;

            var data = _dataManagementServices.UpdateData(dataManagement);

            var filterData = _filter.FilterAccess(eid, new List<DataManagementTrack>() { data });

            if (filterData != null)
                SendMail(filterData[0]);

            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        [Route("api/DataManagement/loadbycriteria")]
        public HttpResponseMessage LoadByFilter(DataManagementTrack dataManagement)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //if (string.IsNullOrEmpty(eid))
           ////eid = "H161961";


            var data = _dataManagementServices.LoadAllDataManagements();

            if (dataManagement.CustomerId > 0)
                data = data.Where(i => i.CustomerId == dataManagement.CustomerId).ToList();

            if (!string.IsNullOrEmpty(dataManagement.Cm))
                data = data.Where(i => i.Cm == dataManagement.Cm).ToList();

            if (!string.IsNullOrEmpty(dataManagement.Requestor))
                data = data.Where(i => i.Requestor == dataManagement.Requestor).ToList();

             data = _filter.FilterAccess(eid, data);
            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }

        private void SendMail(DataManagementTrack dataManagement)
        {
          
            var requestor = _activeDirectoryHelper.GetUsersByLoginName(dataManagement.Requestor);
            var dm = _activeDirectoryHelper.GetUsersByLoginName(dataManagement.DataManager);
            var cm = _activeDirectoryHelper.GetUsersByLoginName(dataManagement.Cm);

            if ((requestor != null && requestor.Count > 0) && (dm != null && dm.Count > 0) && (cm != null && cm.Count > 0))
                _mailService.SendMail(requestor[0].DisplayName, requestor[0].EmailAddress, dm[0].EmailAddress, cm[0].EmailAddress);
        }
    }
}