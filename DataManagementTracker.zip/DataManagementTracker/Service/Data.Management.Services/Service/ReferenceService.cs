﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.Management.Data.Models;
using Data.Management.Services.Manager;

namespace Data.Management.Services.Service
{
    public class ReferenceService : IReferenceService
    {
        IReferenceManager _manager;
        public ReferenceService(IReferenceManager manager)
        {
            _manager = manager;
        }
        public Reference LoadReference(string eid)
        {
            return _manager.LoadReference(eid);
        }
    }
}
