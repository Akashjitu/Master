﻿using M2C.Business.Contracts;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Modules.ProjectPane.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Prism.Commands;
using Prism.Regions;
using Prism.Services.Dialogs;

namespace M2C.UI.Tests.ProjectPlanModule
{
    [TestClass]
    public class EmptyProjectAreaViewModelTest : TestBase
    {
        private Mock<IGlobalMenuComands> mockGlobalMenuComands;
        private Mock<IRegionManager> mockRegionManager;
        private Mock<IMyProfileLogic> mockMyProfileLogic;
        private Mock<IDialogService> mockDialogService;
        private Mock<ISharedContextService> mockSharedContextService;

        [TestInitialize]
        public void TestIniTialize()
        {
            mockGlobalMenuComands = MockRepo.Create<IGlobalMenuComands>();
            mockGlobalMenuComands.SetupGet(x => x.NewProjectCommand).Returns(new CompositeCommand());
            mockGlobalMenuComands.SetupGet(x => x.SaveCommand).Returns(new CompositeCommand());
            mockRegionManager = MockRepo.Create<IRegionManager>();
            mockMyProfileLogic = MockRepo.Create<IMyProfileLogic>();
            mockDialogService = MockRepo.Create<IDialogService>();
            mockSharedContextService = MockRepo.Create<ISharedContextService>();
        }

        [TestMethod]
        public void EmptyProjectAreaViewModelObjectTest()
        {
            EmptyProjectAreaViewModel vm = new EmptyProjectAreaViewModel(mockRegionManager.Object, mockGlobalMenuComands.Object,
                mockDialogService.Object, mockMyProfileLogic.Object, mockSharedContextService.Object);
            if (vm.GlobalMenuComands != null)
                Assert.IsTrue(true, "MainWindowViewModel Created");
        }
    }
}