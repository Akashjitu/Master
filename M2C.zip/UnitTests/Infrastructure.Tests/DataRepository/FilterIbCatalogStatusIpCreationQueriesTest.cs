﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogFilter;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class FilterIbCatalogStatusIpCreationQueriesTest : TestBase
    {
        private IQueryable<FilterIbCatalogStatusIpCreation> filterList;
        private Mock<DbSet<FilterIbCatalogStatusIpCreation>> filterMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            FilterIbCatalogStatusIpCreation filterObj = new FilterIbCatalogStatusIpCreation() { Id = 1, Name = "Name1" };
            List<FilterIbCatalogStatusIpCreation> filter = new List<FilterIbCatalogStatusIpCreation>() { filterObj };
            filterList = filter.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();
            filterMock = MockRepo.Create<DbSet<FilterIbCatalogStatusIpCreation>>();
            filterMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(filterList.Provider);
            filterMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(filterList.Expression);
            filterMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(filterList.ElementType);
            filterMock.As<IQueryable<FilterIbCatalogStatusIpCreation>>().Setup(m => m.GetEnumerator()).Returns(filterList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.FilterIbCatalogStatusIpCreations).Returns(filterMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void FilterIbCatalogStatusIpCreationQueriesConstructorTest()
        {
            IFilterIbCatalogStatusIpCreationQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            filter.Should().NotBeNull();
            ((IDisposable)filter).Dispose();
        }

        [TestMethod]
        public void FilterIbCatalogStatusIpCreationQueriesFilterIbCatalogStatusIpCreationsTest()
        {
            IFilterIbCatalogStatusIpCreationQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            List<FilterIbCatalogStatusIpCreation> filterRes = filter.FilterIbCatalogStatusIpCreations();
            filterRes.Should().HaveCount(1);
            ((IDisposable)filter).Dispose();
        }

        [TestMethod]
        public void FilterIbCatalogStatusIpCreationQueriesFilterIbCatalogStatusIpCreationsbyFilterTest()
        {
            FilterIbCatalogStatusIpCreation filters = null;
            IFilterIbCatalogStatusIpCreationQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            List<FilterIbCatalogStatusIpCreation> filterRes = filter.FilterIbCatalogStatusIpCreations(filters);
            filterRes.Should().BeNull();
            filters = new FilterIbCatalogStatusIpCreation() { Id = 1, Name = "Name1" };
            filterRes = filter.FilterIbCatalogStatusIpCreations(filters);
            filterRes.Should().HaveCount(1);
            ((IDisposable)filter).Dispose();
        }
    }
}