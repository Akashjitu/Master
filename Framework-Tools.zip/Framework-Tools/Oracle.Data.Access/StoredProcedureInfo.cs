﻿
namespace Oracle.Data.Access
{
   public class StoredProcedureInfo
    {
        public string OWNER { get; set; }
        public string OBJECT_NAME { get; set; }
        public string PACKAGE_NAME { get; set; }
        public string OBJECT_ID { get; set; }
        public string OVERLOAD { get; set; }
        public string SUBPROGRAM_ID { get; set; }
        public string ARGUMENT_NAME { get; set; }
        public string POSITION { get; set; }
        public string SEQUENCE { get; set; }
        public string DATA_LEVEL { get; set; }
        public string DATA_TYPE { get; set; }
        public string DEFAULTED { get; set; }
        public string DEFAULT_VALUE { get; set; }
        public string DEFAULT_LENGTH { get; set; }
        public string IN_OUT { get; set; }
        public string DATA_LENGTH { get; set; }
        public string DATA_PRECISION { get; set; }
        public string DATA_SCALE { get; set; }
        public string RADIX { get; set; }
        public string CHARACTER_SET_NAME { get; set; }
        public string TYPE_OWNER { get; set; }
        public string TYPE_NAME { get; set; }
        public string TYPE_SUBNAME { get; set; }
        public string TYPE_LINK { get; set; }
        public string PLS_TYPE { get; set; }
        public string CHAR_LENGTH { get; set; }
        public string CHAR_USED { get; set; }
        public string ORIGIN_CON_ID { get; set; }
    }
}
