﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="Node.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using M2C.Business.Filters;
using Newtonsoft.Json;
using Prism.Mvvm;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Base class for IBComponents
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Node : BindableBase, INode
    {
        /// <summary>
        /// Gets or sets the identifier counter.
        /// </summary>
        /// <value>The identifier counter.</value>
        /// 
        [JsonIgnore]
        public static int ID_Counter { get; set; } = 1;

        /// <summary>
        /// Gets or sets the factory count.
        /// </summary>
        /// <value>The factory count.</value>
        /// 
        [JsonIgnore]
        public static int factoryCount { get; set; } = 1;

        /// <summary>
        /// Gets or sets the workshop count.
        /// </summary>
        /// <value>The workshop count.</value>
        /// 
        [JsonIgnore]
        public static int workshopCount { get; set; } = 1;

        /// <summary>
        /// Gets or sets the line count.
        /// </summary>
        /// <value>The line count.</value>
        /// 
        [JsonIgnore]
        public static int lineCount { get; set; } = 1;

        /// <summary>
        /// Gets or sets the machine count.
        /// </summary>
        /// <value>The machine count.</value>
        /// 
        [JsonIgnore]
        public static int machineCount { get; set; } = 1;

        /// <summary>
        /// Gets or sets the configuration count.
        /// </summary>
        /// <value>The configuration count.</value>
        /// 
        [JsonIgnore]
        public static int configCount { get; set; } = 1;

        /// <summary>
        /// Gets or sets the stock count.
        /// </summary>
        /// <value>The stock count.</value>
        /// 
        [JsonIgnore]
        public static int stockCount { get; set; } = 1;

        /// <summary>
        /// Gets or sets the stock count.
        /// </summary>
        /// <value>The stock count.</value>
        /// 
        [JsonIgnore]
        public static int Tr_Counter { get; set; } = 1;

        /// <summary>
        /// Gets or sets the maintenance count.
        /// </summary>
        /// <value>The maintenance count.</value>
        /// 
        [JsonIgnore]
        public static int maintenanceCount { get; set; } = 1;

        /// <summary>
        /// The identifier
        /// </summary>
        private int? id;

        /// <summary>
        /// The name
        /// </summary>
        private string name;

        /// <summary>
        /// The nullable name
        /// </summary>
        private string nullableName;

        /// <summary>
        /// The node type
        /// </summary>
        private NodeType nodeType = NodeType.NONE;

        /// <summary>
        /// The master inventories
        /// </summary>
        private ObservableCollection<Inventory> _masterInventories;

        /// <summary>
        /// The parent node
        /// </summary>
        private INode _parentNode;

        /// <summary>
        /// Gets or sets the type of the node parent name and node.
        /// </summary>
        /// <value>The type of the node parent name and node.</value>
        /// 
        [JsonIgnore]
        public Dictionary<NodeType, string> _nodeParentNameAndNodeType { get; set; }

        /// <summary>
        /// The filter node inventory
        /// </summary>
        private IFilterNodeInventory _filterNodeInventory;

        /// <summary>
        /// The parent node and node type
        /// </summary>
        private Dictionary<NodeType, INode> _parentNodeAndNodeType;

        /// <summary>
        /// The customer documents
        /// </summary>
        private ObservableCollection<CustomerDocument> _customerDocuments;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int? Id { get => id; set => SetProperty(ref id, value); }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get => name; set
            {
                SetProperty(ref name, value, OnNameChange);
                nullableName = value;
            }
        }

        /// <summary>
        /// Rename Inventories Based on Node Rename
        /// </summary>
        private void OnNameChange()
        {
            switch (NodeType)
            {
                case NodeType.FACTORY:
                    MasterInventories.Where(i => i.FactoryId == id).ToList().ForEach(i => i.Factory = Name);
                    break;

                case NodeType.WORKSHOP:
                    MasterInventories.Where(i => i.WorkshopId == id).ToList().ForEach(i => i.Workshop = Name);
                    break;

                case NodeType.LINE:
                    MasterInventories.Where(i => i.LineId == id).ToList().ForEach(i => i.Line = Name);
                    break;

                case NodeType.MACHINE:
                    MasterInventories.Where(i => i.MachineId == id).ToList().ForEach(i => i.Machine = Name);
                    break;

                case NodeType.PLC_CONFIG:
                case NodeType.MD_CONFIG:
                case NodeType.SHMI_CONFIG:
                case NodeType.OPEN_CONFIG:
                case NodeType.STOCK:
                    MasterInventories.Where(i => i.ConfigurationId == id).ToList().ForEach(i => i.Configuration = Name);
                    break;

                case NodeType.MAINTENANCEZONE:
                    MasterInventories.Where(i => i.MaintenanceZoneId == id).ToList().ForEach(i => i.MaintenanceZone = Name);
                    break;
            }
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        /// 
        [JsonIgnore]
        public string NullableName { get => nullableName; set => SetProperty(ref nullableName, value, validateName); }

        /// <summary>
        /// Gets or sets the type of the node.
        /// </summary>
        /// <value>The type of the node.</value>
        public NodeType NodeType { get => nodeType; set => SetProperty(ref nodeType, value); }

        /// <summary>
        /// Gets or sets the parent node.
        /// </summary>
        /// <value>The parent node.</value>
        [JsonIgnore]
        public INode ParentNode { get => _parentNode; set => SetProperty(ref _parentNode, value, OnParentNode); }

        /// <summary>
        /// Initialize Class Fields
        /// </summary>
        public Node()
        {
            FilterNodeInventory = new FilterNodeInventory();
            _masterInventories = ParentNode == null ? new ObservableCollection<Inventory>() : ParentNode.MasterInventories;
            _nodeParentNameAndNodeType = new Dictionary<NodeType, string>();
            _customerDocuments = new ObservableCollection<CustomerDocument>();
            CopyOfNodeInventories = new List<Inventory>();
        }

        /// <summary>
        /// Gets or sets the filter node inventory.
        /// </summary>
        /// <value>The filter node inventory.</value>
        [JsonIgnore]
        public IFilterNodeInventory FilterNodeInventory { get; set; }

        /// <summary>
        /// Provide Node Level Comments
        /// </summary>
        /// <value>The comment.</value>
        public string Comment { get; set; }

        /// <summary>
        /// Get  node level Inventories
        /// </summary>
        /// <value>The inventories.</value>
        [JsonIgnore]
        public ObservableCollection<Inventory> Inventories => FilterNodeInventory.GetFilterNodeInventoriesById(this);

        /// <summary>
        /// Get Parent Node Type with Name.
        /// </summary>
        /// <value>The type of the node parent name and node.</value>
        [JsonIgnore]
        public Dictionary<NodeType, string> NodeParentNameAndNodeType => GetNodeParentNameAndNodeType();

        /// <summary>
        /// Get or set All Inventories
        /// </summary>
        /// <value>The master inventories.</value>
        public ObservableCollection<Inventory> MasterInventories { get => _masterInventories; set => SetProperty(ref _masterInventories, value, OnCollectionChanged); }

        /// <summary>
        /// Get Parent node Names And NodeTypes
        /// </summary>
        /// <value>The type of the parent node and node.</value>
        [JsonIgnore]
        public Dictionary<NodeType, INode> ParentNodeAndNodeType => GetParentNodeAndNodeType();

        /// <summary>
        /// Customer Documents
        /// </summary>
        /// <value>The customer documents.</value>
        public ObservableCollection<CustomerDocument> CustomerDocuments
        {
            get => _customerDocuments;
            set => SetProperty(ref _customerDocuments, value);
        }

        /// <summary>
        /// Get Copy of Current node Inventories
        /// </summary>
        /// <value>The copy of node inventories.</value>
        /// 
        [JsonIgnore]
        public List<Inventory> CopyOfNodeInventories { get; set; }

        /// <summary>
        /// Get Copy of Current node Inventories
        /// </summary>
        /// <returns>List&lt;Inventory&gt;.</returns>
        public List<Inventory> GetCopyOfNodeInventories()
        {
            var inventories = Inventories.Select(i => new Inventory()
            {
                Year = i.Year,
                Year1 = i.Year1,
                Year2 = i.Year2,
                Year3 = i.Year3,
                Year4 = i.Year4,
                Name = i.Name,
                DeviceType = i.DeviceType,
                DeviceTypeId = i.DeviceTypeId,
                Range = i.Range,
                RangeId = i.RangeId,
                Brand = i.Brand,
                BrandId = i.BrandId,
                Quantity = i.Quantity,
                Comment = i.Comment,
                UnitPrice = i.UnitPrice,
                PvNumber = i.PvNumber,
                SvNumber = i.SvNumber,
                Reference = i.Reference,
                Dosa = i.Dosa,
                DoS = i.DoS,
                EoS = i.EoS,
                ConfigType = i.ConfigType,
                FactoryId = i.FactoryId,
                Factory = i.Factory,
                WorkshopId = i.WorkshopId,
                Workshop = i.Workshop,
                MachineId = i.MachineId,
                Machine = i.Machine,
                LineId = i.LineId,
                Line = i.Line,
                Configuration = i.Configuration,
                ConfigurationId = i.ConfigurationId,
                Criticality = i.Criticality,
                MaintenanceZone = i.MaintenanceZone,
                MaintenanceZoneId = i.MaintenanceZoneId,
                OperationMode = i.OperationMode,
                Strategic = i.Strategic,
                SubRange = i.SubRange,
                SubRangeId = i.SubRangeId,
                IsSelected = i.IsSelected
            }).ToList();
            return inventories;
        }

        /// <summary>
        /// Gets or sets the criticality.
        /// </summary>
        /// <value>The criticality.</value>
        public string Criticality { get; set; }

        /// <summary>
        /// Called when [parent node].
        /// </summary>
        private void OnParentNode()
        {
            _masterInventories = ParentNode == null ? new ObservableCollection<Inventory>() : ParentNode.MasterInventories;
            _parentNodeAndNodeType = GetParentNodeAndNodeType();
            _nodeParentNameAndNodeType = GetNodeParentNameAndNodeType();
        }

        /// <summary>
        /// Get Parent Node Type with Name.
        /// it's recursive function
        /// </summary>
        /// <returns>Dictionary with Node Type and node Name</returns>
        public Dictionary<NodeType, string> GetNodeParentNameAndNodeType()
        {
            var dic = new Dictionary<NodeType, string>();
            return GetParentNameAndNodeType(this, ref dic);
        }

        /// <summary>
        /// Get Parent Node Type with Name.
        /// it's recursive function
        /// </summary>
        /// <param name="node">selected node object</param>
        /// <param name="parentNodeTypeAndName">Dictionary with Node Type and node Name</param>
        /// <returns>Dictionary&lt;NodeType, System.String&gt;.</returns>
        private Dictionary<NodeType, string> GetParentNameAndNodeType(INode node, ref Dictionary<NodeType, string> parentNodeTypeAndName)
        {
            if (parentNodeTypeAndName == null)
                parentNodeTypeAndName = new Dictionary<NodeType, string>();

            if (node == null || node.NodeType == NodeType.NONE || string.IsNullOrEmpty(node.Name))
                return parentNodeTypeAndName;

            parentNodeTypeAndName.Add(node.NodeType, node.Name);

            GetParentNameAndNodeType(node.ParentNode, ref parentNodeTypeAndName);

            return parentNodeTypeAndName;
        }

        /// <summary>
        /// Gets the type of the parent node and node.
        /// </summary>
        /// <returns>Dictionary&lt;NodeType, INode&gt;.</returns>
        private Dictionary<NodeType, INode> GetParentNodeAndNodeType()
        {
            var dic = new Dictionary<NodeType, INode>();
            return GetParentAndNodeType(this, ref dic);
        }

        /// <summary>
        /// Gets the type of the parent and node.
        /// </summary>
        /// <param name="node">The node.</param>
        /// <param name="parentTypeAndName">Name of the parent type and.</param>
        /// <returns>Dictionary&lt;NodeType, INode&gt;.</returns>
        private Dictionary<NodeType, INode> GetParentAndNodeType(INode node, ref Dictionary<NodeType, INode> parentTypeAndName)
        {
            if (parentTypeAndName == null)
                parentTypeAndName = new Dictionary<NodeType, INode>();

            if (node == null || node.NodeType == NodeType.NONE)
                return parentTypeAndName;

            parentTypeAndName.Add(node.NodeType, node);

            GetParentAndNodeType(node.ParentNode, ref parentTypeAndName);

            return parentTypeAndName;
        }

        /// <summary>
        /// Get Filter Inventories based on the Current node
        /// </summary>
        private void OnCollectionChanged()
        {
            CollectionViewSource.GetDefaultView(MasterInventories).Refresh();
            if (Inventories != null)
                CollectionViewSource.GetDefaultView(Inventories).Refresh();
        }

        /// <summary>
        /// Sets the parent node.
        /// </summary>
        /// <param name="parent">The parent.</param>
        /// <param name="ID">The identifier.</param>
        public void SetParentNode(Node parent, int ID)
        {
            this.ParentNode = parent;
            if (this.Id == null)
            {
                this.Id = ID;
            }
        }

        /// <summary>
        /// Sets the parent node.
        /// </summary>
        /// <param name="parent">The parent.</param>
        public void SetParentNode(INode parent)
        {
            ParentNode = parent;
        }

        /// <summary>
        /// The is editable
        /// </summary>
        private bool _isEditable = false;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is editable.
        /// </summary>
        /// <value><c>true</c> if this instance is editable; otherwise, <c>false</c>.</value>
        [JsonIgnore]
        public bool IsEditable { get => _isEditable; set { SetProperty(ref _isEditable, value); } }

        /// <summary>
        /// Validates the name.
        /// </summary>
        private void validateName()
        {
            if (!string.IsNullOrWhiteSpace(NullableName))
            {
                Name = NullableName;
            }
            else
            {
                MessageBox.Show("Name cannot be empty string.", "M2C", MessageBoxButton.OK, MessageBoxImage.Warning);
                NullableName = Name;
            }
        }
    }
}