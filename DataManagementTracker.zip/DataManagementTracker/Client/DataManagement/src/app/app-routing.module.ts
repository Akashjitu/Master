import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserControlComponent } from './admin/user-control/user-control.component';
import { UserInfoComponent } from './admin/user-info/user-info.component';
import { DataManagmentGridComponent } from './dataManagmentView/dataManagmentGrid.component';
import { DataManagementEntryComponent } from './data-management-entry/data-management-entry.component';
import { RequestorEntryComponent } from './requestor-entry/requestor-entry.component';
import { FeedbackComponent } from './feedback/feedback.component';

const routes: Routes = [
  { path: 'home',      component: DataManagmentGridComponent },
  { path: 'usersetting',      component: UserControlComponent },
  { path: 'userinfo',      component: UserInfoComponent },
  { path: 'dm',      component: DataManagementEntryComponent },
  { path: 'requestor',      component: RequestorEntryComponent },
  { path: 'feedback',      component: FeedbackComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
