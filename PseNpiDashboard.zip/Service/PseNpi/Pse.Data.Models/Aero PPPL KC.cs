//using Oracle.Data.Access;

//namespace Pse.Data.Models
//{
//    public class AeroPpplKC
//    {
//        [Columns("Aero")]
//        public string Aero { get; set; }

//        [Columns("Program_Name")]
//        public string Program_Name { get; set; }

//        [Columns("IPDS_Phase")]
//        public string IPDS_Phase { get; set; }

//        [Columns("Waterline_Status")]
//        public string Waterline_Status { get; set; }

//        [Columns("Authorized_to_Spend")]
//        public string Authorized_to_Spend { get; set; }

//        [Columns("Finance_Category")]
//        public string Finance_Category { get; set; }

//        [Columns("SBU")]
//        public string SBU { get; set; }

//        [Columns("GBE")]
//        public string GBE { get; set; }

//        [Columns("PAC")]
//        public string PAC { get; set; }

//        [Columns("Program_Manager")]
//        public string Program_Manager { get; set; }

//        [Columns("AME")]
//        public string AME { get; set; }

//        [Columns("Sourcing")]
//        public string Sourcing { get; set; }

//        [Columns("FRP_Annual_Shipset")]
//        public string FRP_Annual_Shipset_Volume { get; set; }

//        [Columns("Software_Development")]
//        public string Software_Development_Scope { get; set; }

//        [Columns("Hardware_Development")]
//        public string Hardware_Development_Scope { get; set; }

//        [Columns("AME_Support_Required")]
//        public string AME_Support_Required { get; set; }

//        [Columns("Target_K_SS")]
//        public string Shipset_G_S_UPC_Target_K_SS { get; set; }

//        [Columns("Estimate_K_SS")]
//        public string Shipset_FRP_UPC_Estimate_K_SS { get; set; }

//        [Columns("Actual_K_SS")]
//        public string Shipset_UPC_Actual_K_SS_ { get; set; }

//        [Columns("UPC_Part_Blue")]
//        public string UPC_Part_Count_Blue_ { get; set; }

//        [Columns("UPC_Part_Green")]
//        public string UPC_Part_Count_Green { get; set; }

//        [Columns("UPC_Part_Red")]
//        public string UPC_Part_Count_Red_ { get; set; }

//        [Columns("RTY_Part_Green")]
//        public string RTY_Part_Count_Green { get; set; }

//        [Columns("RTY_Part_Yellow")]
//        public string RTY_Part_Count_Yellow { get; set; }

//        [Columns("RTY_Part_Red")]
//        public string RTY_Part_Count_Red { get; set; }

//        [Columns("RTY_Minimum")]
//        public string RTY_Minimum { get; set; }

//        [Columns("Program_UPC_Health")]
//        public string Program_UPC_Health { get; set; }

//        [Columns("Program_RTY_Health")]
//        public string Program_RTY_Health { get; set; }

//        [Columns("UPC_5YR_FI_M_")]
//        public string UPC_5YR_FI_M_ { get; set; }

//        [Columns("UPC_5YR_FI_M_Health")]
//        public string UPC_5YR_FI_M_Health { get; set; }

//        [Columns("Total_Part_Count")]
//        public string Total_Part_Count { get; set; }

//        [Columns("Transition_Y_N_")]
//        public string New_Factory_or_Transition_Y_N_ { get; set; }

//        [Columns("Transition_Health")]
//        public string New_Factory_or_Transition_Health { get; set; }

//        [Columns("Process_Y_N")]
//        public string New_Alt_Process_Y_N_ { get; set; }

//        [Columns("Process_Health")]
//        public string New_Alt_Process_Health { get; set; }

//        [Columns("MRL_Score")]
//        public string MRL_Score { get; set; }

//        [Columns("MRL_Health")]
//        public string MRL_Health { get; set; }

//        [Columns("MRL_Risk")]
//        public string MRL_Risk { get; set; }

//        [Columns("Contract")]
//        public string New_Parts_on_Contract { get; set; }

//        [Columns("Contract_Health")]
//        public string New_Parts_on_Contract_Health { get; set; }

//        [Columns("ESE_Feedback")]
//        public string New_Parts_w_ESE_Feedback { get; set; }

//        [Columns("ESE_Feedback_Health")]
//        public string New_Parts_w_ESE_Feedback_Health { get; set; }

//        [Columns("TRL_Score")]
//        public string TRL_Score { get; set; }

//        [Columns("TRL_Health")]
//        public string TRL_Health { get; set; }

//        [Columns("CRL_Score")]
//        public string CRL_Score { get; set; }

//        [Columns("CRL_Health")]
//        public string CRL_Health { get; set; }

//        [Columns("EIS_Date")]
//        public string EIS_Date { get; set; }
//    }
//}