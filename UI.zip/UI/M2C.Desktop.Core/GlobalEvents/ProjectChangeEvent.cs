﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProjectChangeEvent.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project;
using Prism.Events;

namespace M2C.Desktop.Core.GlobalEvents
{
    /// <summary>
    /// When ever active project context update happen
    /// This event will be triggered
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{M2C.Business.Models.Project.ProjectContextModel}" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ProjectChangeEvent : PubSubEvent<ProjectContextModel>
    {
        /// <summary>
        /// Creates new data.
        /// </summary>
        /// <value>The new data.</value>
        public object NewData { get; set; }
    }
}