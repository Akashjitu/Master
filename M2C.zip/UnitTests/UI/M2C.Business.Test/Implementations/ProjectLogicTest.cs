﻿using DataRepository.DBContracts;
using DomainModels.ProjectModels;
using FluentAssertions;
using M2C.Business.Contracts;
using M2C.Business.Implementations;
using M2C.Business.Mappers;
using M2C.Business.Models.Project;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using M2C.Business.Mappers.ProjectMap;
using ContactTypeDomain = DomainModels.ProjectModels.ContactType;

namespace M2C.Business.Test.Implementations
{
    [TestClass]
    public class ProjectLogicTest : TestBase
    {
        protected Mock<IDbContextFactory> IDbContextFactoryMock { get; set; }
        protected Mock<IProjectDbContext> IProjectDbContextMock { get; set; }
        private Mock<DbSet<Customer>> CustomerMock;
        private Mock<DbSet<Project>> ProjectMock;
        private Mock<DbSet<IBProjectComponent>> IBProjectComponentsMock;
        private Mock<DbSet<IBComponenetType>> IBComponenetTypesMock;
        private Mock<DbSet<Contact>> ContactMock;
        private Mock<DbSet<ContactTypeDomain>> ContactTypeMock;
        private IQueryable<Customer> customerList;
        private IQueryable<Project> projectList;
        private IQueryable<ContactTypeDomain> ContactTypeList;
        private IQueryable<IBProjectComponent> IBProjectComponents;
        private IQueryable<IBComponenetType> IBComponenetTypes;
        private Mock<IProjectQueries> MockIprojectQueries;
        private Mock<IInventoryMapper> inventoryMapper;
        private Mock<IProjectBusinessModelBuilder> projectBusinessModelBuilder;
        private IQueryable<Contact> contactList;
        private Mock<ISyncServiceQueries> mockISyncServiceQueries;

        private Mock<IProjectDbModelBuilder> projectDbModelBuilder;
        //  IDbContextFactory dbContextFactory
        [TestInitialize]
        public void TestIniTialize()
        {
            Customer customerObj = new Customer() { CustomerID = 1, BfoId = 1 };
            List<Customer> brand = new List<Customer>() { customerObj };
            customerList = brand.AsQueryable();

            List<IBComponenetType> ibComponenetTypes = new List<IBComponenetType>() { new IBComponenetType() { ComponentTypeID = 0 }, new IBComponenetType() { ComponentTypeID = 1 } };
            IBComponenetTypes = ibComponenetTypes.AsQueryable();

            IBProjectComponent ibProjectComponent = new IBProjectComponent() { ComponentId = 1, Project = new Project(), Products = new List<XrefProduct>() };
            List<IBProjectComponent> ibProjectComponents = new List<IBProjectComponent>() { ibProjectComponent };
            IBProjectComponents = ibProjectComponents.AsQueryable();

            Project projectObj = new Project() { ProjectID = 1, Customer = customerObj };
            List<Project> project = new List<Project>() { projectObj };
            projectList = project.AsQueryable();

            Contact contactObj = new Contact() { ContactID = 1, Project = projectObj };
            List<Contact> contact = new List<Contact>() { contactObj };
            contactList = contact.AsQueryable();

            ContactTypeDomain contactTypeObj = new ContactTypeDomain() { ContactTypeID = 1, Contacts = contact };
            List<ContactTypeDomain> contactType = new List<ContactTypeDomain> { contactTypeObj };
            ContactTypeList = contactType.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProjectDbContextMock = MockRepo.Create<IProjectDbContext>();
            inventoryMapper = MockRepo.Create<IInventoryMapper>();
            projectBusinessModelBuilder = MockRepo.Create<IProjectBusinessModelBuilder>();
            projectDbModelBuilder = MockRepo.Create<IProjectDbModelBuilder>();
            IBComponenetTypesMock = MockRepo.Create<DbSet<IBComponenetType>>();
            IBProjectComponentsMock = MockRepo.Create<DbSet<IBProjectComponent>>();
            CustomerMock = MockRepo.Create<DbSet<Customer>>();
            ProjectMock = MockRepo.Create<DbSet<Project>>();
            ContactMock = MockRepo.Create<DbSet<Contact>>();
            ContactTypeMock = MockRepo.Create<DbSet<ContactTypeDomain>>();

            IBComponenetTypesMock.As<IQueryable<IBComponenetType>>().Setup(m => m.Provider).Returns(IBComponenetTypes.Provider);
            IBComponenetTypesMock.As<IQueryable<IBComponenetType>>().Setup(m => m.Expression).Returns(IBComponenetTypes.Expression);
            IBComponenetTypesMock.As<IQueryable<IBComponenetType>>().Setup(m => m.ElementType).Returns(IBComponenetTypes.ElementType);
            IBComponenetTypesMock.As<IQueryable<IBComponenetType>>().Setup(m => m.GetEnumerator()).Returns(IBComponenetTypes.GetEnumerator());

            IBProjectComponentsMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.Provider).Returns(IBProjectComponents.Provider);
            IBProjectComponentsMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.Expression).Returns(IBProjectComponents.Expression);
            IBProjectComponentsMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.ElementType).Returns(IBProjectComponents.ElementType);
            IBProjectComponentsMock.As<IQueryable<IBProjectComponent>>().Setup(m => m.GetEnumerator()).Returns(IBProjectComponents.GetEnumerator());

            CustomerMock.As<IQueryable<Customer>>().Setup(m => m.Provider).Returns(customerList.Provider);
            CustomerMock.As<IQueryable<Customer>>().Setup(m => m.Expression).Returns(customerList.Expression);
            CustomerMock.As<IQueryable<Customer>>().Setup(m => m.ElementType).Returns(customerList.ElementType);
            CustomerMock.As<IQueryable<Customer>>().Setup(m => m.GetEnumerator()).Returns(customerList.GetEnumerator());

            ProjectMock.As<IQueryable<Project>>().Setup(m => m.Provider).Returns(projectList.Provider);
            ProjectMock.As<IQueryable<Project>>().Setup(m => m.Expression).Returns(projectList.Expression);
            ProjectMock.As<IQueryable<Project>>().Setup(m => m.ElementType).Returns(projectList.ElementType);
            ProjectMock.As<IQueryable<Project>>().Setup(m => m.GetEnumerator()).Returns(projectList.GetEnumerator());

            ContactMock.As<IQueryable<Contact>>().Setup(m => m.Provider).Returns(contactList.Provider);
            ContactMock.As<IQueryable<Contact>>().Setup(m => m.Expression).Returns(contactList.Expression);
            ContactMock.As<IQueryable<Contact>>().Setup(m => m.ElementType).Returns(contactList.ElementType);
            ContactMock.As<IQueryable<Contact>>().Setup(m => m.GetEnumerator()).Returns(contactList.GetEnumerator());

            ContactTypeMock.As<IQueryable<ContactTypeDomain>>().Setup(m => m.Provider).Returns(ContactTypeList.Provider);
            ContactTypeMock.As<IQueryable<ContactTypeDomain>>().Setup(m => m.Expression).Returns(ContactTypeList.Expression);
            ContactTypeMock.As<IQueryable<ContactTypeDomain>>().Setup(m => m.ElementType).Returns(ContactTypeList.ElementType);
            ContactTypeMock.As<IQueryable<ContactTypeDomain>>().Setup(m => m.GetEnumerator()).Returns(ContactTypeList.GetEnumerator());

            IProjectDbContextMock.Setup(x => x.IBComponenetTypes).Returns(IBComponenetTypesMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);

            IProjectDbContextMock.Setup(x => x.IBProjectComponents).Returns(IBProjectComponentsMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);

            IProjectDbContextMock.Setup(x => x.Customers).Returns(CustomerMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);

            IProjectDbContextMock.Setup(x => x.Projects).Returns(ProjectMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);

            IProjectDbContextMock.Setup(x => x.Contacts).Returns(ContactMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);

            IProjectDbContextMock.Setup(x => x.ContactTypes).Returns(ContactTypeMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);
            MockIprojectQueries = MockRepo.Create<IProjectQueries>();
            mockISyncServiceQueries = MockRepo.Create<ISyncServiceQueries>();
        }

        [TestMethod]
        public void ProjectLogicConstructorTest()
        {
            IProjectLogic projectLogic = new ProjectLogic(IDbContextFactoryMock.Object, MockIprojectQueries.Object,
                projectBusinessModelBuilder.Object, inventoryMapper.Object,
                projectDbModelBuilder.Object, mockISyncServiceQueries.Object);
            projectLogic.Should().NotBeNull();
        }

        [TestMethod]
        public void SaveTest()
        {
            CustomerModel customerModel = new CustomerModel() { BfoId = "101", City = "City1", ProjectName = "Project1", CustomerID = 1 };
            List<ContactModel> contactModel = new List<ContactModel>() {
                new ContactModel() { ProjectId = 101, ContactType =  Business.Models.Project.ContactType.CUSTOMER },
                new ContactModel() { ProjectId = 102,ContactType =  Business.Models.Project.ContactType.CUSTOMER }
            };
            ProjectContextModel contextModel = new ProjectContextModel() { Customer = customerModel, Contacts = contactModel };
            IProjectLogic projectLogic = new ProjectLogic(IDbContextFactoryMock.Object, MockIprojectQueries.Object, 
                projectBusinessModelBuilder.Object, inventoryMapper.Object, 
                projectDbModelBuilder.Object, mockISyncServiceQueries.Object);

            projectDbModelBuilder.Setup(x=>x.GetProject(contextModel, IProjectDbContextMock.Object)).Returns(new Project());
          
            projectLogic.Save(ref contextModel).Should().BeTrue();
        }

        [TestMethod]
        public void GetAllProjectIdsTest()
        {
            IProjectLogic projectLogic = new ProjectLogic(IDbContextFactoryMock.Object, MockIprojectQueries.Object,
                projectBusinessModelBuilder.Object, inventoryMapper.Object,
                projectDbModelBuilder.Object, mockISyncServiceQueries.Object);

            Action act = () => projectLogic.GetAllProjects();
            act.Should().Throw<Exception>();
        }

        [TestMethod]
        public void GetProjectTestIfProjectIsWrong()
        {
            IProjectLogic projectLogic = new ProjectLogic(IDbContextFactoryMock.Object, MockIprojectQueries.Object,
                projectBusinessModelBuilder.Object, inventoryMapper.Object,
                projectDbModelBuilder.Object, mockISyncServiceQueries.Object);
            var project = projectLogic.GetProject(0);
            Assert.IsNull(project);
        }

        [TestMethod]
        public void GetProjectTestWhenProvideProductId()
        {
            var project = new Project();
            MockIprojectQueries.Setup(x => x.GetProject(1)).Returns(project);
            projectBusinessModelBuilder.Setup(x => x.GetProjectContextModel(project)).Returns(new ProjectContextModel());

            IProjectLogic projectLogic = new ProjectLogic(IDbContextFactoryMock.Object, MockIprojectQueries.Object,
                projectBusinessModelBuilder.Object, inventoryMapper.Object,
                projectDbModelBuilder.Object, mockISyncServiceQueries.Object);
            var projectContextModel = projectLogic.GetProject(1);
            Assert.IsNotNull(projectContextModel);
        }
    }
}