﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Product.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.IbCatalogModels
{
    /// <summary>
    /// Class Product.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Product
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Product" /> class.
        /// </summary>
        public Product()
        {
        }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets the identifier category.
        /// </summary>
        /// <value>The identifier category.</value>
        public string IdentifierCategory { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the serviceable.
        /// </summary>
        /// <value>The serviceable.</value>
        public string Serviceable { get; set; }

        /// <summary>
        /// Gets or sets the traceable.
        /// </summary>
        /// <value>The traceable.</value>
        public string Traceable { get; set; }

        /// <summary>
        /// Gets or sets the service business value.
        /// </summary>
        /// <value>The service business value.</value>
        public string ServiceBusinessValue { get; set; }

        /// <summary>
        /// Gets or sets the end production or phase out.
        /// </summary>
        /// <value>The end production or phase out.</value>
        public int EndProductionOrPhaseOut { get; set; }
        /// <summary>
        /// Gets or sets the end commercialization.
        /// </summary>
        /// <value>The end commercialization.</value>
        public int EndCommercialization { get; set; }

        /// <summary>
        /// Gets or sets the end ObsolescenceYear.
        /// </summary>
        /// <value>The end ObsolescenceYear.</value>
        public int ObsolescenceYear { get; set; }

        /// <summary>
        /// Gets or sets the end services withdrawal support.
        /// </summary>
        /// <value>The end services withdrawal support.</value>
        public int EndServicesWithdrawalSupport { get; set; }
        /// <summary>
        /// Gets or sets the default unit price.
        /// </summary>
        /// <value>The default unit price.</value>
        public double DefaultUnitPrice { get; set; }
        /// <summary>
        /// Gets or sets the latest product version.
        /// </summary>
        /// <value>The latest product version.</value>
        public double LatestProductVersion { get; set; }
        /// <summary>
        /// Gets or sets the latest software version.
        /// </summary>
        /// <value>The latest software version.</value>
        public double LatestSoftwareVersion { get; set; }
        /// <summary>
        /// Gets or sets the latest hardware version.
        /// </summary>
        /// <value>The latest hardware version.</value>
        public double LatestHardwareVersion { get; set; }
        /// <summary>
        /// Gets or sets the include in report.
        /// </summary>
        /// <value>The include in report.</value>
        public string IncludeInReport { get; set; }
        /// <summary>
        /// Gets or sets the include in calculate.
        /// </summary>
        /// <value>The include in calculate.</value>
        public string IncludeInCalc { get; set; }
        /// <summary>
        /// Gets or sets the configuration.
        /// </summary>
        /// <value>The configuration.</value>
        public string Configuration { get; set; }
        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>The created date.</value>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the updated date.
        /// </summary>
        /// <value>The updated date.</value>
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Gets or sets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int BrandId { get; set; }
        /// <summary>
        /// Gets or sets the device type identifier.
        /// </summary>
        /// <value>The device type identifier.</value>
        public int DeviceTypeId { get; set; }
        /// <summary>
        /// Gets or sets the range identifier.
        /// </summary>
        /// <value>The range identifier.</value>
        public int RangeId { get; set; }
        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public virtual Brand Brand { get; set; }
        /// <summary>
        /// Gets or sets the type of the device.
        /// </summary>
        /// <value>The type of the device.</value>
        public virtual DeviceType DeviceType { get; set; }
        /// <summary>
        /// Gets or sets the range.
        /// </summary>
        /// <value>The range.</value>
        public virtual Range Range { get; set; }
        /// <summary>
        /// Gets or sets the product entries.
        /// </summary>
        /// <value>The product entries.</value>
        public virtual List<ProductEntry> ProductEntries { get; set; }
        /// <summary>
        /// Gets or sets the full name.
        /// </summary>
        /// <value>The full name.</value>
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public int Version { get; set; }

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public static void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
            .HasMany(s => s.ProductEntries).WithOne(i => i.Product).HasForeignKey(oi => oi.ProductId);
            modelBuilder.Entity<Product>().Property(a => a.Id).ValueGeneratedOnAdd();
        }
    }
}