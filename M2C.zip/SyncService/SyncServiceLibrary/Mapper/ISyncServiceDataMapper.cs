﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ISyncServiceDataMapper.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace SyncServiceLibrary.Mapper
{
    /// <summary>
    /// ISyncServiceDataMapper
    /// </summary>
    public interface ISyncServiceDataMapper
    {
        /// <summary>
        /// Brands the map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;Brand&gt;.</returns>
        List<Brand> BrandMap( OneIbCatalog[] oneIbCatalogs);
        /// <summary>
        /// Devices the type map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        List<DeviceType> DeviceTypeMap(OneIbCatalog[] oneIbCatalogs);
        /// <summary>
        /// Ranges the map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        List<Range> RangeMap( OneIbCatalog[] oneIbCatalogs);
        /// <summary>
        /// Subs the range map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <param name="ranges">The ranges.</param>
        /// <returns>List&lt;SubRange&gt;.</returns>
        List<SubRange> SubRangeMap(List<OneIbCatalog> oneIbCatalogs, List<Range> ranges);
        /// <summary>
        /// Products the map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <param name="brands">The brands.</param>
        /// <param name="deviceTypes">The device types.</param>
        /// <param name="ranges">The ranges.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> ProductMap(List<OneIbCatalog> oneIbCatalogs, List<Brand> brands, List<DeviceType> deviceTypes, List<Range> ranges);
        /// <summary>
        /// Synchronizes the history map.
        /// </summary>
        /// <param name="attempt">The attempt.</param>
        /// <param name="status">The status.</param>
        /// <returns>SyncHistory.</returns>
        SyncHistory SyncHistoryMap(int attempt, int status);
    }
}
