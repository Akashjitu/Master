﻿using Data.Management.Data.Models;
using Data.Management.Services.DataBaseAccessObject;
using Data.Management.Services.MemoryCachers;
using System;
using System.Collections.Generic;

namespace Data.Management.Services.Manager
{
    public class ReferenceManager : IReferenceManager
    {
        private IDataManagementDbAccess _dbAccess;

        public ReferenceManager(IDataManagementDbAccess dbAccess)
        { _dbAccess = dbAccess; }

        public Reference LoadReference(string eid)
        {
            var sites = MemoryCacher.GetValue("sites") as List<Site>;
            var programs = MemoryCacher.GetValue("programs") as List<Program>;
            var customers = MemoryCacher.GetValue("customers") as List<Customer>;

            if (sites == null)
            {
                MemoryCacher.Add("sites", _dbAccess.LoadSites(), DateTimeOffset.Now.AddHours(5));
                sites = MemoryCacher.GetValue("sites") as List<Site>;
            }
            if (programs == null)
            {
                MemoryCacher.Add("programs", _dbAccess.LoadPrograms(), DateTimeOffset.Now.AddHours(5));
                programs = MemoryCacher.GetValue("programs") as List<Program>;
            }
            if (customers == null)
            {
                MemoryCacher.Add("customers", _dbAccess.LoadCustomers(), DateTimeOffset.Now.AddHours(5));
                customers = MemoryCacher.GetValue("customers") as List<Customer>;
            }

            return new Reference
            {
                Customers = customers,
                Programs = programs,
                Sites = sites,
                Access = _dbAccess.GetEmployeeAccessByEid(new EmployeeInfo { EID = eid }) ?? new EmployeeInfo { EID = eid, AccessType = 0 }
            };
        }
    }
}