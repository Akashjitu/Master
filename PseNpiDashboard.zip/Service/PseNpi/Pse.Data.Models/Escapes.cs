﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class Escapes
    {
        [Columns("P_SITE")]
        public string Site { get; set; }

        [Columns("P_SBU")]
        public string Sbu { get; set; }

        [Columns("P_PART")]
        public string Part { get; set; }

        [Columns("P_QN")]
        public string Qn { get; set; }

        [Columns("P_NOTIFICATIONDATE")]
        public string NotificationDate { get; set; }

        [Columns("P_MATERIALDESCRIPTION")]
        public string MaterialDescription { get; set; }

        [Columns("P_CAUSE_CODE")]
        public string CauseCode { get; set; }

        [Columns("P_CAUSE_CODE_DESCRIPTION")]
        public string CauseCodeDescription { get; set; }

        [Columns("P_CAR_ISSUE_DATE")]
        public string CarIssueDate { get; set; }

        [Columns("P_TITLE")]
        public string Title { get; set; }

        [Columns("P_MAKE")]
        public string Make { get; set; }

        [Columns("P_CAUSE_TEXT")]
        public string CauseText { get; set; }

        [Columns("P_RCCA_CAUSE")]
        public string RccaCause { get; set; }

        [Columns("P_RCCACAUSE_GROUP")]
        public string RccaCauseGroup { get; set; }

        [Columns("P_IDO_CAUSED")]
        public string IdoCaused { get; set; }

        [Columns("P_STATUS")]
        public string Status { get; set; }

        [Columns("P_REQ_TEXT")]
        public string ReqText { get; set; }

        [Columns("P_FINDING_TEXT")]
        public string FindingText { get; set; }

        [Columns("P_FINDING_CODE")]
        public string FindingCode { get; set; }

        [Columns("P_FINDING_TYPE")]
        public string FindingType { get; set; }

        [Columns("P_DIRECT_CAUSE")]
        public string DirectCause { get; set; }

        [Columns("P_CONTRIBUTING_CAUSE")]
        public string ContributingCause { get; set; }

        [Columns("P_ROOT_CAUSE")]
        public string RootCause { get; set; }

        [Columns("P_SPECIFIC_ACTION")]
        public string SpecificAction { get; set; }

        [Columns("P_PREVENTIVE_ACTION")]
        public string PreventiveAction { get; set; }

        [Columns("P_SYSTEMIC_ACTION")]
        public string SystemicAction { get; set; }

        [Columns("P_QN_AGE")]
        public string QnAge { get; set; }

        [Columns("P_CAR_TITLE")]
        public string CarTitle { get; set; }

        [Columns("P_LEVEL_DESCRIPTION")]
        public string LevelDescription { get; set; }

        [Columns("P_REQUESTER")]
        public string Requester { get; set; }

        [Columns("P_EXPORT_CONTROL")]
        public string ExportControl { get; set; }

        [Columns("P_MONTH")]
        public string Month { get; set; }

        [Columns("P_YEAR")]
        public string Year { get; set; }

        [Columns("P_ORIGINAL_SHIP_DATE")]
        public DateTime OriginalShipDate { get; set; }

        [Columns("P_ID")]
        public int Id { get; set; }

        [Columns("P_CREATED_BY")]
        public string CreatedBy { get; set; }

        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("P_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("P_UPDATED_DATE")]
        public DateTime UpdatedDate { get; set; }

        [Columns("P_ACTIVE")]
        public string Active { get; set; }

        [Columns("P_SERIAL_NO")]
        public string SerialNo { get; set; }

        [Columns("p_OTL_GRADUATION")]
        public DateTime OtlGraduation { get; set; }
    }
}