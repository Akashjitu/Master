import { Component, Input } from '@angular/core';
import { FracaInfo } from './Models/fraca-info';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'HoneywellFraca';
  @Input('selectedRow') selectedRow : FracaInfo;

  public editorValue: string = '';
  
  output:Observable<FracaInfo>;
  constructor() {
   
  }
}