﻿using System;
using System.Web;

namespace FracaServiceHost.Authorizes
{
    public class RequestDataProvider
    {
        public static string GetValue(HttpContext current, TypeOfData type)
        {
            switch (type)
            {
                case TypeOfData.UserName:


                    var aray = current.User.Identity.Name.Split('\\');
                    if (aray.Length > 1)
                        return aray[1];

                    if (aray.Length == 1)
                        return aray[0];

                    break;
                default:
                    return string.Empty;
            }

            return string.Empty;
        }

    }


    public enum TypeOfData
    {
        UserName
    }
}