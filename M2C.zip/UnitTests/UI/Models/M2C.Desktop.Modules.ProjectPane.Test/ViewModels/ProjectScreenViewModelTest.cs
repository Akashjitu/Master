﻿using M2C.Business.Contracts;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Modules.ProjectPane.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;

namespace M2C.Desktop.Modules.ProjectPane.Test.ViewModels
{
    [TestClass]
    public class ProjectScreenViewModelTest
    {
        private ProjectScreenViewModel _projectScreenViewModel;
        private IGlobalMenuComands _globalMenuComands;
        private IRegionManager _regionManager;
        private ISharedContextService mockSharedContextService;
        IProjectLogic mockProjectLogic;
        IEventAggregator eventAggregator;

        [TestInitialize]
        public void Setup()
        {
            _regionManager = Substitute.For<IRegionManager>();
            mockProjectLogic = Substitute.For<IProjectLogic>();
            mockSharedContextService = Substitute.For<ISharedContextService>();
            _globalMenuComands = Substitute.For<IGlobalMenuComands>();
            eventAggregator = Substitute.For<IEventAggregator>();
            _globalMenuComands.SaveCommand.Returns(new CompositeCommand());
            _globalMenuComands.NewProjectCommand.Returns(new CompositeCommand());
            _globalMenuComands.ExportProjectCommand.Returns(new CompositeCommand());

            _projectScreenViewModel = new ProjectScreenViewModel(_globalMenuComands, _regionManager, mockSharedContextService, mockProjectLogic, eventAggregator);
        }

        [TestMethod]
        public void TestAsyncCommand()
        {
            var viewModel = _projectScreenViewModel;
            Assert.IsNotNull(viewModel.ExportProjectCommand);
        }

        [TestMethod]
        public void TestSaveCommand()
        {
            var viewModel = _projectScreenViewModel;
            Assert.IsNotNull(viewModel.SaveCommand);
        }
    }
}