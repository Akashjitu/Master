import { Component, OnInit, TemplateRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PliSummaryService } from '../services/pli-summary.service';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/pliSummary/pliSummaryReducer';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { PliSummary } from '../model/pliSummary';
import { PliSummaryColumns } from './pli-summary-columns';

@Component({
  selector: 'app-pli-summary',
  templateUrl: './pli-summary.component.html',
  styleUrls: ['./pli-summary.component.css']
})
export class PliSummaryComponent implements OnInit {
  modalRef: BsModalRef;
  gridApi;
  gridColumnApi;
  isExportFilter = false;
  columnDefs;
  defaultColDef;
  rowData: any;
  searchText;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  theme = 'ag-theme-balham';
  pliModel = {
    sbu: '',
    ipdsPhase: '',
    pliRating: '',
    gbe: ''
  }


  ngOnInit() {
  }
  constructor(private http: HttpClient, private service: PliSummaryService, public store: Store<IAppState>, private modalService: BsModalService, ) {
    this.initColumns();

    this.defaultColDef = {
      resizable: true,
      sortable: true,
      enableFilter: true,
      //width: 100,
      //editable: true,
      filter: true
    };
    service.getAllPliSummary();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    this.store.select('pliSummaryReducer').subscribe(data => {
      this.rowData = data;
    });
    this.initColumnsList();
  }

  initColumns() {
    this.columnDefs = PliSummaryColumns.columns;
  }

  autoSizeAll() {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  export() {
    if (this.isExportFilter == false) {
      this.service.reportDownloadAll();
    } else {
      this.service.reportDownloadByFilter(this.pliModel);
    }

  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(this.searchText);
  }
  onItemSelect(item: any) {
   
    this.gridColumnApi.setColumnsVisible([item], true);

  }
  onDeSelect(item: any) {
    
    this.gridColumnApi.setColumnsVisible([item], false);

  }
  onSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], true);
    }
  }

  onDeSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], false);
    }
  }
  initColumnsList() {
    var allColumnIds = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'colId',
      textField: 'headerName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.gridColumnApi.getAllColumns().forEach(function (column) {
      console.log("colId :- " + column.colId);
      allColumnIds.push({ colId: column.colId, headerName: column.colId });

    });
    this.selectedItems = [
      { colId: 'keyCode', headerName: 'keyCode' },
      { colId: 'programName', headerName: 'programName' }
    ];

    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      if (allColumns[index].visible === true) {
        this.selectedItems.push({ colId: allColumns[index].colId, headerName: allColumns[index].colId })
      }

    }
    this.dropdownList = allColumnIds;

  }

  showTemplate(template: TemplateRef<any>) {
      this.modalRef = this.modalService.show(template);
  }

  onFilterSubmit() {
    this.service.loadPliByFilter(this.pliModel);
    this.modalRef.hide();
  }

  onExportChange(value) {
    this.isExportFilter = value;
  }

  clearFilters() {

    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }
}

