﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 01-23-2020
// ***********************************************************************
// <copyright file="PropertisePaneViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.Events;
using M2C.Desktop.Modules.CollectData.Test.MOCK;
using M2C.Desktop.Modules.CollectData.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Prism.Commands;
using Prism.Events;
using Prism.Services.Dialogs;

namespace M2C.Desktop.Modules.CollectData.Test.ViewModels
{
    [TestClass]
    public class PropertisePanelViewModelTest
    {
        private PropertisePaneViewModel _propertisePanelViewModel;
        private IDialogService _dialogService;
        private IEventAggregator _eventAggregator;
        private ISharedContextService _contextService;
        private IGlobalIBComponentsCommand _globalIbComponentsCommand;
        private INode _node;

        [TestInitialize]
        public void Setup()
        {
            _globalIbComponentsCommand = Substitute.For<IGlobalIBComponentsCommand>();
            _dialogService = Substitute.For<IDialogService>();
            _eventAggregator = new EventAggregator();
            _contextService = Substitute.For<ISharedContextService>();


            _dialogService.ShowDialog(Arg.Any<string>(), null, null);
            _contextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT).Returns(new ProjectContextModel());


            _propertisePanelViewModel = new PropertisePaneViewModel(_dialogService, _eventAggregator, _contextService,
                _globalIbComponentsCommand);

            _node = new Node() { Name = "InstalledBased", NodeType = NodeType.INSTALLEDBASE };
            _eventAggregator.GetEvent<IBTreeViewChangeEvent>().Publish(_node);

        }


        [TestMethod]
        public void ShouldCallShowDialogBoxWhenCallAddCriticalityCommand()
        {
            _propertisePanelViewModel.AddCriticalityCommand.Execute();
        }

        [TestMethod]
        public void ShouldSetNodeCommentOnCommentText()
        {
            _propertisePanelViewModel.NodeComments = "TestComment";
            Assert.IsNotNull(_node);
            Assert.IsNotNull(_node.Comment);
            Assert.IsTrue(_node.Comment == "TestComment");
        }

        [TestMethod]
        public void ShouldAddInventoriesToNodeLevelCollection()
        {
            _eventAggregator.GetEvent<InventoryModelEvent>().Publish(MockProvider.GetInventories());
            Assert.IsNotNull(_propertisePanelViewModel.Inventories);
            Assert.IsTrue(_propertisePanelViewModel.Inventories.Any());
            Assert.IsTrue(_node.MasterInventories.Any());
        }

        [TestMethod]
        public void ShouldTheChangeTheGridBehaviorWhenNodeChangeEventRaise()
        {
            _node = new Node() { Name = "Workshop", NodeType = NodeType.WORKSHOP };
            _eventAggregator.GetEvent<IBTreeViewChangeEvent>().Publish(_node);

            Assert.IsTrue(_propertisePanelViewModel.IsFirstTabSelected);
            Assert.IsTrue(string.IsNullOrEmpty(_propertisePanelViewModel.FilterText));
            Assert.IsTrue(_propertisePanelViewModel.NodeComments == _node.Comment);
        }
    }
}
