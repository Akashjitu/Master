﻿// ***********************************************************************
// Assembly         : AppConfiguration
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-20-2020
// ***********************************************************************
// <copyright file="AppConfigConstants.cs" company="AppConfiguration">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace AppConfiguration
{
    /// <summary>
    /// AppConfigConstants
    /// </summary>
    public static class AppConfigConstants
    {
        #region CONFIG CONSTANTS
        /// <summary>
        /// The installbasedcolumns
        /// </summary>
        public const string INSTALLBASEDCOLUMNS = "InstallBasedColumns";
        /// <summary>
        /// The technicalresourcecolumns
        /// </summary>
        public const string TECHNICALRESOURCECOLUMNS = "TechnicalResourceColumns";
        /// <summary>
        /// The customerdocumentcolumns
        /// </summary>
        public const string CUSTOMERDOCUMENTCOLUMNS = "CustomerDocumentColumns";
        /// <summary>
        /// The syncserviceurl
        /// </summary>
        public const string SYNCSERVICEURL = "SyncServiceUrl";
        /// <summary>
        /// The idmsurlformat
        /// </summary>
        public const string IDMSURLFORMAT = "IDMSUrlFormat";
        /// <summary>
        /// The idmsurlbaseurl
        /// </summary>
        public const string IDMSURLBASEURL = "IDMSUrlBaseUrl";
        /// <summary>
        /// The idmsapplication
        /// </summary>
        public const string IDMSAPPLICATION = "IDMSApplication";
        /// <summary>
        /// The clientid
        /// </summary>
        public const string CLIENTID = "ClientID";
        /// <summary>
        /// The responsetype
        /// </summary>
        public const string RESPONSETYPE = "ResponseType";
        /// <summary>
        /// The redirecturi
        /// </summary>
        public const string REDIRECTURI = "RedirectUri";
        /// <summary>
        /// The idmsauthurlformat
        /// </summary>
        public const string IDMSAUTHURLFORMAT = "IDMSauthUrlFormat";
        /// <summary>
        /// The authserviceurl
        /// </summary>
        public const string AUTHSERVICEURL = "AuthServiceUrl";
        /// <summary>
        /// The retry count
        /// </summary>
        public const string RETRY_COUNT = "RetryCount";
        #endregion
    }
}
