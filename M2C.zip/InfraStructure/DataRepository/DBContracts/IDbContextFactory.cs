﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IDbContextFactory.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IDbContextFactory
    /// </summary>
    public interface IDbContextFactory
    {
        /// <summary>
        /// Creates this instance.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>T.</returns>
        T Create<T>();
    }
}