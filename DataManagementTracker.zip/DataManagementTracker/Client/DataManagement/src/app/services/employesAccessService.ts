

import { environment } from 'src/environments/environment';
import { IAppState } from '../store/dataManagement/dataManagementReducer';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { NotifierService } from 'angular-notifier';
import * as UserAccesstAction from '../store/userAccessRight/userAccesstAction';
import { throwError } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class EmployesAccessService {

    headers: any;

    url = environment.apiBaseUrl;
    fileBaseUrl = environment.fileBaseUrl;

    constructor(private http: HttpClient, private store: Store<IAppState>,
        private spinner: NgxSpinnerService,
        private notifier: NotifierService) {
        this.headers = new HttpHeaders({
            Accept: 'application/json',
            'zumo-api-version': '2.0.0',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
            withCredentials: 'true',
        });
    }


    addEmployeeAccess(selectedRow: any) {
        this.spinner.show();
        return this.http.post(this.url + 'AccessRight/',selectedRow, { headers: this.headers })
          .pipe(
            catchError(this.handleError)
          ).subscribe(infoData => {
            this.store.dispatch(new UserAccesstAction.AddUserAccess(infoData));
            this.spinner.hide();
            this.showNotification('success', 'Successfully  Add New User');
          },
            err => {
              console.log(`ERROR: ${err}`),
              this.showNotification('error', 'Whoops, something went wrong.'); 
              this.spinner.hide();
            },
          );
    }


    updateEmployeeAccess(selectedRow: any) {
        this.spinner.show();
    return this.http.put(this.url + 'AccessRight/' + selectedRow.id, selectedRow, { headers: this.headers })
      .pipe(
        catchError(this.handleError)
      ).subscribe(infoData => {
        this.store.dispatch(new UserAccesstAction.UpdateUserAccess(infoData));
        this.spinner.hide();
        this.showNotification('success', 'Successfully Updated');
      },
        err => {
          console.log(`ERROR: ${err}`),
          this.showNotification('error', 'Whoops, something went wrong.'); 
          this.spinner.hide();
        },
      );
    }



    getAllEmployeeAccess() {
        this.spinner.show();
        return this.http.get(this.url + 'AccessRight/', { headers: this.headers })
            .pipe(
                catchError(this.handleError)
            ).subscribe(infoData => {
                this.store.dispatch(new UserAccesstAction.LoadUserAccess(infoData));
                this.spinner.hide();
            },
                err => {
                    console.log(`ERROR: ${err}`),
                        this.showNotification('error', 'Whoops, something went wrong.'); 
                        this.spinner.hide();
                },
            );
    }


    private handleError(error: HttpErrorResponse) {
        if (error.error instanceof ErrorEvent) {
            console.error('An error occurred:', error.error.message);
            this.showNotification('error', error.error.message)
        } else {
            console.error(
                `Backend returned code ${error.status}, ` +
                `body was: ${error.error}`);
        }
        return throwError(
            'Something bad happened; please try again later.');
    }

    public showNotification(type: string, message: string): void {
        this.notifier.notify(type, message);
    }
}