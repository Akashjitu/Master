﻿
using System;

namespace Fraca.Data.Models
{
    public class FracaInfo
    {
        public string FracaNo { get; set; }
        public string PartNo { get; set; }
        public string OpenDate { get; set; }
        public string CloseDate { get; set; }
        public string FailedDate { get; set; }
        public string Product { get; set; }
        public string Program { get; set; }
        public string Customer { get; set; }
        public string TestEnv { get; set; }
        public string Originator { get; set; }
        public string RespEng { get; set; }
        public string System { get; set; }
        public string Electrical { get; set; }
        public string Emi { get; set; }
        public string ClosedBy { get; set; }
        public string TestDoc { get; set; }
        public string Paragraph { get; set; }
        public string TestType { get; set; }
        public string FailureCode { get; set; }
        public string EndUnit { get; set; }
        public string Level1 { get; set; }
        public string Level2 { get; set; }
        public string Nomenclature { get; set; }
        public string SerialNumber { get; set; }
        public string Designator { get; set; }
        /// <summary>
        /// //
        /// </summary>
        public bool InflightShutdown { get; set; }
        public bool InflightPowerLoss { get; set; }

        public bool Chargeability { get; set; }
        public bool SafetyAffected { get; set; }
        public bool FailureToStart { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ProblemDescription { get; set; }
        public string Finding { get; set; }
        public string Analysis { get; set; }


        public string LAST_UPDATE_BY { get; set; }

        public DateTime LAST_UPDATE { get; set; }

    }
}