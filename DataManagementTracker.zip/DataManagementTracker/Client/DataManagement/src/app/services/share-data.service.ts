import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DataManagement } from '../model/data.management';

@Injectable({
    providedIn: 'root'
})
export class ShareDataService {
    private messageSourse = new BehaviorSubject<DataManagement>({
        id: 0,
        requestor: '',
        requestReceivedDate : null,
        site: '',
        siteId:0,
        documentPartNumber: '',
        revision:  '',
        documentTitle: '',
        ecn: '',
        customerName: '',
        customerId:0,
        programNames: '',
        programId:0,
        priority: '',
        dataManager: '',
        cm: '',
        requestorComments: '',
        documentType: '',
        endItemPartNumber: '',
        categoryOfChange: '',
        exportDisclosure:'',
        scnNumber: '',
        cmComments: '',
        sdrlNumber: '',
        sdrlTitle: '',
        nomenclature: '',
        customerReferenceNumber: '',
        honeywellTransmittalLetter: '',
        dmDateSentToCustomer : null,
        honStatus: '',
        requiredDispositionDate: '',
        dispositionStatus: '',
        customerStatus: '',
        apProgram: '',
        impactedPoDate: '',
        bcaPrimaryReviewerEngineer: '',
        bcaPa: '',
        dmComments: '',
        honeywellComments: '',
        createdBy: '',
        createdDate : null,
        updatedBy: '',
        updatedDate : null,
        isActive: '',
        requestorId:''
    });

    currentMessage = this.messageSourse.asObservable()

    constructor() { }

    changeMessage(message) {
        this.messageSourse.next(message);
    }

}





