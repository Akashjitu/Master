import { Injectable } from '@angular/core';
import * as OtlDispositionAction from './../store/otlDisposition/otlDispositionAction';
import { saveAs } from 'file-saver';
import { Store } from '@ngrx/store';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IAppState } from '../store/accoladeReducer';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OtlDispositionService {

  headers: any;
  
  url = environment.apiBaseUrl;
  fileBaseUrl = environment.fileBaseUrl;
  constructor(private http: HttpClient, private store: Store<IAppState>, ) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
      withCredentials: 'true',
    });
  }


  reportDownload(date) {
    
    this.http.get(this.url+'otldisposition?date=' + date, { responseType: 'blob', headers: this.headers })
      .subscribe(response => {
        saveAs(response, 'EffectivenessAnalysis-' + date + '.xlsx',
          { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
      },
        err => {
          console.log(`ERROR: ${err}`),
          console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service');
        });
  }

  getOtlDisposition(date) {
   
    this.http.get<any>(this.url+'OtlDisposition?date=' + date)
      .subscribe(values => this.store.dispatch(new OtlDispositionAction.LoadOtlDisposition(values),
      ),
        err => { console.log(`ERROR: ${err}`); });
  }


  saveOtlDisposition(modifieditems) {
   
    return this.http.post(this.url+'OtlDisposition', modifieditems,  { headers: this.headers})
      .subscribe(infoData => console.log(infoData)      );
  }
}