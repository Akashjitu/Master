﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CollectDataModule.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Core;
using M2C.Desktop.Modules.Charts.ReportData.Views;
using M2C.Desktop.Modules.Charts.Views;
using M2C.Desktop.Modules.CollectData.ViewModels;
using M2C.Desktop.Modules.CollectData.ViewModels.DialogBoxes;
using M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls;
using M2C.Desktop.Modules.CollectData.Views;
using M2C.Desktop.Modules.CollectData.Views.DialogBoxes;
using M2C.Desktop.Modules.CollectData.Views.InventoryControls;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;

namespace M2C.Desktop.Modules.CollectData
{
    /// <summary>
    /// Class CollectDataModule.
    /// Implements the <see cref="Prism.Modularity.IModule" />
    /// </summary>
    /// <seealso cref="Prism.Modularity.IModule" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CollectDataModule : IModule
    {
        /// <summary>
        /// The region manager
        /// </summary>
        private readonly IRegionManager _regionManager;

        /// <summary>
        /// Initializes a new instance of the <see cref="CollectDataModule" /> class.
        /// </summary>
        /// <param name="regionManager">The region manager.</param>
        public CollectDataModule(IRegionManager regionManager)
        {
            _regionManager = regionManager;
        }

        /// <summary>
        /// Notifies the module that it has been initialized.
        /// </summary>
        /// <param name="containerProvider">The container provider.</param>
        public void OnInitialized(IContainerProvider containerProvider)
        {
            _regionManager.RegisterViewWithRegion(RegionNames.CollectDataRegion, typeof(CollectDataMainTab));
            _regionManager.RegisterViewWithRegion(RegionNames.SideBarTreeVewRegion, typeof(SideBarTreeView));
            _regionManager.RegisterViewWithRegion(RegionNames.PropertisePaneRegion, typeof(PropertisePane));

            _regionManager.RegisterViewWithRegion(RegionNames.AnalysisChartRegion, typeof(AnalysisChart));
            _regionManager.RegisterViewWithRegion(RegionNames.SideChartToolBarRegion, typeof(ChartToolBar));

            _regionManager.RegisterViewWithRegion(RegionNames.AnalyzeDataRegion, typeof(ChartContainer));


            _regionManager.RegisterViewWithRegion(RegionNames.ReportExportToolsRegion, typeof(ReportExportTools));
            _regionManager.RegisterViewWithRegion(RegionNames.ReportDataRegion, typeof(ReportDataContainer));

            _regionManager.RegisterViewWithRegion(RegionNames.TechnicalResourceSideBarTreeVewRegion, typeof(TRSideBarTree));
            _regionManager.RegisterViewWithRegion(RegionNames.TechnicalResourcePropertisePaneRegion, typeof(TechnicalResourcePropertisePane));
        }

        /// <summary>
        /// Registers the types.
        /// </summary>
        /// <param name="containerRegistry">The container registry.</param>
        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterDialog<AddInventoryDialog, AddInventoryDialogViewModel>("AddInventoryDialog");
            containerRegistry.RegisterForNavigation<CompetitorControl>();
            containerRegistry.RegisterForNavigation<DeviceTypeControl>();
            containerRegistry.RegisterForNavigation<ReadConfigurationControl>();
            containerRegistry.RegisterForNavigation<ReferenceControl>();
            containerRegistry.RegisterDialog<CreateNewProjectDialog, CreateNewProjectDialogViewModel>("CreateNewProjectDialog");
            containerRegistry.RegisterDialog<AddNewContact, AddNewContactViewModel>("AddNewContactDialog");
            containerRegistry.RegisterDialog<CustomerDocumentFileDialog, CustomerDocumentFileDialogViewModel>("CustomerDocumentFileDialog");
            containerRegistry.RegisterDialog<CustomMessageCollectionDialog, CustomMessageCollectionDialogViewModel>("CustomMessageCollectionDialog");
            containerRegistry.RegisterDialog<EditInventoryControl, EditInventoryControlViewModel>("EditInventoryControl");
            containerRegistry.RegisterDialog<InventoryDetailsControl, InventoryDetailsControlViewModel>("InventoryDetailsControl");
            containerRegistry.RegisterDialog<CriticalityDialog, CriticalityDialogViewModel>("CriticalityDialog");
            containerRegistry.RegisterDialog<OpenProjectDialog, OpenProjectDialogViewModel>("OpenProjectDialog");
            containerRegistry.RegisterDialog<OperationModeDialogue, OperationModeDialogueViewModel>("OperationModeDialogue");
        }
    }
}