﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProjectDbContext.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DataRepository.Seeds;
using DomainModels;
using DomainModels.Common;
using DomainModels.ErrorLogs;
using DomainModels.ProjectModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;

namespace DataRepository
{
    /// <summary>
    /// Class ApplicationDbContext.
    /// Implements the <see cref="Microsoft.EntityFrameworkCore.DbContext" />
    /// Implements the <see cref="DataRepository.DBContracts.IProductDbContext" />
    /// Implements the <see cref="DataRepository.DBContracts.IProjectDbContext" />
    /// </summary>
    /// <seealso cref="Microsoft.EntityFrameworkCore.DbContext" />
    /// <seealso cref="DataRepository.DBContracts.IProductDbContext" />
    /// <seealso cref="DataRepository.DBContracts.IProjectDbContext" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ProjectDbContext : DbContext, IProjectDbContext
    {
        /// <summary>
        /// Gets or sets the countries.
        /// </summary>
        /// <value>The countries.</value>
        public DbSet<Country> Countries { get; set; }

        /// <summary>
        /// Gets or sets the positions.
        /// </summary>
        /// <value>The positions.</value>
        public DbSet<Position> Positions { get; set; }

        /// <summary>
        /// Gets or sets the profiles.
        /// </summary>
        /// <value>The profiles.</value>
        public DbSet<Profile> Profiles { get; set; }

        /// <summary>
        /// Gets or sets the exception logs.
        /// </summary>
        /// <value>The exception logs.</value>
        public DbSet<ExceptionLog> ExceptionLogs { get; set; }

        /// <summary>
        /// Gets or sets the Criticalities.
        /// </summary>
        /// <value>The criticalities.</value>
        public DbSet<Criticality> Criticalities { get; set; }

        /// <summary>
        /// Migrates this instance.
        /// </summary>
        public void Migrate()
        {
            if (Database.GetPendingMigrations().Count() > 0)
            {
                Database.Migrate();
            }
        }

        /// <summary>
        /// <para>
        /// Saves all changes made in this context to the database.
        /// </para>
        /// <para>
        /// This method will automatically call <see cref="M:Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.DetectChanges" /> to discover any
        /// changes to entity instances before saving to the underlying database. This can be disabled via
        /// <see cref="P:Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.AutoDetectChangesEnabled" />.
        /// </para>
        /// </summary>
        /// <returns>The number of state entries written to the database.</returns>
        int IDbContext.SaveChanges()
        {
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.Entity is ChangeTrack && (
                                e.State == EntityState.Added
                                || e.State == EntityState.Modified));

            foreach (var entityEntry in entries)
            {
                if (entityEntry.State == EntityState.Added) ((ChangeTrack)entityEntry.Entity).CreatedOn = DateTime.Now;

                ((ChangeTrack)entityEntry.Entity).ModifiedOn = DateTime.Now;
            }

            return SaveChanges();
        }

        /// <summary>
        /// Gets or sets the projects.
        /// </summary>
        /// <value>The projects.</value>
        public DbSet<Project> Projects { get; set; }

        /// <summary>
        /// Gets or sets the customers.
        /// </summary>
        /// <value>The customers.</value>
        public DbSet<Customer> Customers { get; set; }

        /// <summary>
        /// Gets or sets the contacts.
        /// </summary>
        /// <value>The contacts.</value>
        public DbSet<Contact> Contacts { get; set; }

        /// <summary>
        /// Gets or sets the contact types.
        /// </summary>
        /// <value>The contact types.</value>
        public DbSet<ContactType> ContactTypes { get; set; }

        /// <summary>
        /// Gets or sets the ib project components.
        /// </summary>
        /// <value>The ib project components.</value>
        public DbSet<IBProjectComponent> IBProjectComponents { get; set; }

        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>The comments.</value>
        public DbSet<Comment> Comments { get; set; }

        /// <summary>
        /// Gets or sets the ib componenet types.
        /// </summary>
        /// <value>The ib componenet types.</value>
        public DbSet<IBComponenetType> IBComponenetTypes { get; set; }

        /// <summary>
        /// Gets or sets the metadatas.
        /// </summary>
        /// <value>The metadatas.</value>
        public DbSet<Metadata> Metadatas { get; set; }

        /// <summary>
        /// Gets or sets the xref products.
        /// </summary>
        /// <value>The xref products.</value>
        public DbSet<XrefProduct> xrefProducts { get; set; }

        /// <summary>
        /// Gets or sets the OperationModes.
        /// </summary>
        /// <value>The OperationModes.</value>
        public DbSet<OperationMode> OperationModes { get; set; }

        /// <summary>
        /// Collection of Project Inventories
        /// </summary>
        /// <value>The project inventories.</value>
        public DbSet<ProjectInventory> ProjectInventories { get; set; }

        /// <summary>
        /// Collection of Project Inventories
        /// </summary>
        /// <value>The inventory comments.</value>
        public DbSet<InventoryComments> InventoryComments { get; set; }

        /// <summary>
        /// <para>
        /// Override this method to configure the database (and other options) to be used for this context.
        /// This method is called for each instance of the context that is created.
        /// The base implementation does nothing.
        /// </para>
        /// <para>
        /// In situations where an instance of <see cref="T:Microsoft.EntityFrameworkCore.DbContextOptions" /> may or may not have been passed
        /// to the constructor, you can use <see cref="P:Microsoft.EntityFrameworkCore.DbContextOptionsBuilder.IsConfigured" /> to determine if
        /// the options have already been set, and skip some or all of the logic in
        /// <see cref="M:Microsoft.EntityFrameworkCore.DbContext.OnConfiguring(Microsoft.EntityFrameworkCore.DbContextOptionsBuilder)" />.
        /// </para>
        /// </summary>
        /// <param name="optionsBuilder">A builder used to create or modify options for this context. Databases (and other extensions)
        /// typically define extension methods on this object that allow you to configure the context.</param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var dbpath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\schneider electric\\m2c Renewal\\";
            if (!Directory.Exists(dbpath)) Directory.CreateDirectory(dbpath);
            optionsBuilder.UseSqlite("Data Source = " + dbpath + "\\M2CRenewalProject.db");
            base.OnConfiguring(optionsBuilder);
        }

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="builder">The builder.</param>
        protected override void OnModelCreating(ModelBuilder builder)
        {
            Customer.OnModelCreating(builder);
            Contact.OnModelCreating(builder);
            IBProjectComponent.OnModelCreating(builder);

            Country.OnModelCreating(builder);
            Position.OnModelCreating(builder);
            Profile.OnModelCreating(builder);
            ExceptionLog.OnModelCreating(builder);

            Project.OnModelCreating(builder);
            base.OnModelCreating(builder);
            builder.Seed();
        }
    }
}