﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Business.Mappers.ProjectMap
{
    /// <summary>
    /// Builder Director
    /// </summary>
    public class ProjectMapper : IProjectMapper
    {
        /// <summary>
        /// Creates the database model.
        /// </summary>
        /// <param name="builder">The builder.</param>
        public void CreateDbModel(IProjectDbModelBuilder builder)
        {
            builder.BuildProject()
                .BuildCustomer()
                .BuildContact()
                .BuildIbComponents().BuildTrComponents()
                .BuildOperationMode().BuildProjectInventories().BuildInventoryComments()
                .BuildCriticality();
        }

        /// <summary>
        /// Creates the bussiness model.
        /// </summary>
        /// <param name="builder">The builder.</param>
        public void CreateBusinessModel(IProjectBusinessModelBuilder builder)
        {
            builder.BuildProject()
                .BuildCustomer()
                .BuildContact()
                .BuildIb().BuildTr()
                .BuildOperationMode().BuildProjectInventories().BuildInventoryComments()
                .BuildCriticality();
        }

        /// <summary>
        /// Loads the projects with customers.
        /// </summary>
        /// <param name="builder">The builder.</param>
        public void LoadProjectsWithCustomers(IProjectBusinessModelBuilder builder)
        {
            builder.BuildProject()
                .BuildCustomer();
        }
        /// <summary>
        /// Creates the business model.
        /// </summary>
        /// <param name="builder">The builder.</param>
        public void CreateProjectsOnlyBusinessModel(IProjectBusinessModelBuilder builder)
        {
            builder.BuildProject();
        }
    }
}