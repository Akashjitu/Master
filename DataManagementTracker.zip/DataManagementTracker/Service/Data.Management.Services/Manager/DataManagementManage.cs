﻿using Data.Management.Data.Models;
using Data.Management.Services.DataBaseAccessObject;
using Data.Management.Services.MemoryCachers;
using DataManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Data.Management.Services.Manager
{
    public class DataManagementManage : IDataManagementManage
    {
        private readonly IDataManagementDbAccess _dataManagementDbAccess;

        public DataManagementManage(IDataManagementDbAccess dataManagementDbAccess)
        {
            _dataManagementDbAccess = dataManagementDbAccess;
        }

        public DataManagementTrack AddNew(DataManagementTrack dataManagement)
        {
            dataManagement = GetUpdateRequestorID(dataManagement);

            return _dataManagementDbAccess.AddNew(dataManagement);
        }

        private DataManagementTrack GetUpdateRequestorID(DataManagementTrack dataManagement)
        {
            var sites = MemoryCacher.GetValue("sites") as List<Site>;

            if (sites != null)
            {
                var site = sites.Where(i => i.ID == dataManagement.SiteId).FirstOrDefault();

                if (site != null && site.Code != null)
                {
                    var dataManagementTracks = _dataManagementDbAccess.LoadMaxRequestorId(string.Format("HON_{0}_", site.Code));
                    if (dataManagementTracks != null && dataManagementTracks.Count > 0)
                    {
                        var datamanger = dataManagementTracks[0];
                        if (!string.IsNullOrEmpty(datamanger.RequestorId))
                        {
                            int result = int.Parse(Regex.Replace(datamanger.RequestorId, @"[^\d]", ""));
                            dataManagement.RequestorId = string.Format("HON_{0}_{1}", site.Code, (++result).ToString("D5"));
                        }
                        else
                        {
                            dataManagement.RequestorId = string.Format("HON_{0}_{1}", site.Code, 1.ToString("D5"));
                        }
                    }
                    else
                    {
                        dataManagement.RequestorId = string.Format("HON_{0}_{1}", site.Code, 1.ToString("D5"));
                    }
                }
            }
            return dataManagement;
        }

        public List<DataManagementTrack> LoadAllDataManagements()
        {
            return _dataManagementDbAccess.LoadAllDataManagements();
        }

        public List<DataManagementTrack> LoadByDate(DateTime created)
        {
            return _dataManagementDbAccess.LoadByDate(created);
        }

        public List<DataManagementTrack> LoadById(int id)
        {
            return _dataManagementDbAccess.LoadById(id);
        }

        public DataManagementTrack UpdateData(DataManagementTrack dataManagement)
        {
            return _dataManagementDbAccess.UpdateData(dataManagement);
        }

        private void UpdateNullToEmpty(DataManagementTrack dataManagement)
        {
        }
    }
}