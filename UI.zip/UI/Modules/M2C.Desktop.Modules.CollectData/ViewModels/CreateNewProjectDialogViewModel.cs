﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CreateNewProjectDialogViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.Enums;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Events;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// CreateNewProjectDialog ViewModel
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <seealso cref="System.IDisposable" />
    public class CreateNewProjectDialogViewModel : BindableBase, IDialogAware, IDisposable
    {
        /// <summary>
        /// Gets the event aggregator.
        /// </summary>
        /// <value>The event aggregator.</value>
        private IEventAggregator EventAggregator { get; }

        /// <summary>
        /// The context model
        /// </summary>
        private ProjectContextModel contextModel = new ProjectContextModel();

        /// <summary>
        /// The current command parameter
        /// </summary>
        private string currentCommandParam = string.Empty;

        /// <summary>
        /// The project logic
        /// </summary>
        private readonly IProjectLogic projectLogic;

        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService sharedContextService;

        /// <summary>
        /// Gets or sets the context model.
        /// </summary>
        /// <value>The context model.</value>
        private ProjectContextModel ContextModel
        {
            get => contextModel;
            set
            {
                SetProperty(ref contextModel, value);
            }
        }

        /// <summary>
        /// The message
        /// </summary>
        private string message = UIConstants.SaveCancelMessage;

        /// <summary>
        /// The title
        /// </summary>
        private string title = "Create Project";

        /// <summary>
        /// Gets or sets the project create mode.
        /// </summary>
        /// <value>The project create mode.</value>
        public ProjectCreateModes ProjectCreateMode { get => _projectCreateMode; set => SetProperty(ref _projectCreateMode, value); }

        /// <summary>
        /// The project create mode
        /// </summary>
        private ProjectCreateModes _projectCreateMode;

        /// <summary>
        /// Gets or sets the close dialog command.
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => title;

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateNewProjectDialogViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="projectLogic">The project logic.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        public CreateNewProjectDialogViewModel(IEventAggregator eventAggregator, IProjectLogic projectLogic, ISharedContextService sharedContextService)
        {
            EventAggregator = eventAggregator;
            this.projectLogic = projectLogic;
            this.sharedContextService = sharedContextService;
            EventAggregator.GetEvent<ContextDataChangeEvent>().Subscribe(ChangedModel);
            EventAggregator.GetEvent<ContactDataChangeEvent>().Subscribe(ChangedContactsModel);
            CloseDialogCommand = new DelegateCommand<string>(OnSaveAction, CanSave)
                 .ObservesProperty(() => ContextModel.Customer.ProjectName)
                  .ObservesProperty(() => ContextModel.Customer.BfoId)
                   .ObservesProperty(() => ContextModel.Customer.CompanyName);
        }

        /// <summary>
        /// Subscribe call back for ProjectContextModel changes from child VM
        /// </summary>
        /// <param name="contextModel">Project context model.</param>
        public void ChangedModel(ProjectContextModel contextModel)
        {
            if (contextModel != null)
            {
                ContextModel.Customer = contextModel.Customer;
            }
        }

        /// <summary>
        /// Changes the contacts model.
        /// </summary>
        /// <param name="contactModels">The contact models.</param>
        public void ChangedContactsModel(List<ContactModel> contactModels)
        {
            if (contactModels != null)
            {
                ContextModel.Contacts = contactModels;
            }
        }

        /// <summary>
        /// Determines whether this instance can save the specified command parameter.
        /// </summary>
        /// <param name="CommandParam">The command parameter.</param>
        /// <returns><c>true</c> if this instance can save the specified command parameter; otherwise, <c>false</c>.</returns>
        private bool CanSave(string CommandParam)
        {
            currentCommandParam = CommandParam.ToUpper();
            if (currentCommandParam == "OK")
            {
                return !string.IsNullOrWhiteSpace(ContextModel?.Customer?.ProjectName)
                    && (ContextModel?.Customer?.BfoIdValue != null)
                    && !string.IsNullOrWhiteSpace(ContextModel?.Customer?.CompanyName);
            }
            else
            { return true; }
        }

        /// <summary>
        /// Called when [save action].
        /// </summary>
        /// <param name="CommandParam">The command parameter.</param>
        private void OnSaveAction(string CommandParam)
        {
            var projectContextModel = ContextModel;
            try
            {
                if (CommandParam.ToUpper() == "OK")
                {
                    if (projectContextModel.Contacts.Count(x => x.IsLinked == true) <= 0)
                    {
                        MessageBox.Show($"Please select at least one contact", "Alert Project", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                        return;
                    }
                    if (!projectLogic.Save(ref projectContextModel))
                    {
                        MessageBox.Show("Save Failed!", "ERROR", MessageBoxButton.OK, MessageBoxImage.Error, MessageBoxResult.OK);
                    }
                    else
                    {
                        ContextModel = projectContextModel;
                        //setting up context service
                        sharedContextService.Remove(UIConstants.PROJECTCONTEXT);
                        sharedContextService.Add<ProjectContextModel>(UIConstants.PROJECTCONTEXT, ContextModel);
                        EventAggregator.GetEvent<ProjectChangeEvent>().Publish(ContextModel);
                        RaiseRequestClose(new DialogResult(ButtonResult.OK));
                    }
                }
                else
                {
                    RaiseRequestClose(new DialogResult(ButtonResult.Cancel));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ERROR", MessageBoxButton.OK, MessageBoxImage.Error, MessageBoxResult.OK);
            }
        }

        #region DIALOG PROPERTISE

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            if (currentCommandParam == "CANCEL")
            {
                if (MessageBox.Show(message, "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
            Dispose();
        }

        /// <summary>
        /// Called when [dialog opened].
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            if (parameters != null)
            {
                if (parameters.TryGetValue("Mode", out ProjectCreateModes mode))
                {
                    if (mode == ProjectCreateModes.EDIT)
                    {
                        message = UIConstants.EditCancelMessage;
                        this.title = UIConstants.ProjectPropertyHeader;
                        //getting project from Context Service
                        ContextModel = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
                    }
                    else if (mode == ProjectCreateModes.NEW)
                    {
                        this.title = UIConstants.ProjectCreateHeader;
                    }

                    ProjectCreateMode = mode;
                }
            }
        }

        /// <summary>
        /// Disposes this instance.
        /// </summary>
        public void Dispose()
        {
            EventAggregator.GetEvent<ContactDataChangeEvent>().Unsubscribe(ChangedContactsModel);
        }

        #endregion DIALOG PROPERTISE
    }
}