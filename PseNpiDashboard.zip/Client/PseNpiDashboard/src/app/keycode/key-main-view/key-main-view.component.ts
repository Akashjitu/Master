import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-key-main-view',
  templateUrl: './key-main-view.component.html',
  styleUrls: ['./key-main-view.component.css']
})
export class KeyMainViewComponent implements OnInit {


  
  constructor() { }

  ngOnInit() {
  }

}
