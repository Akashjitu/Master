﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Navigation
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="NavigationModule.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Core;
using M2C.Desktop.Modules.Navigation.Views;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;

namespace M2C.Desktop.Modules.Navigation
{
    /// <summary>
    /// Class NavigationModule.
    /// Implements the <see cref="Prism.Modularity.IModule" />
    /// </summary>
    /// <seealso cref="Prism.Modularity.IModule" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class NavigationModule : IModule
    {

        /// <summary>
        /// The region manager
        /// </summary>
        private readonly IRegionManager _regionManager;
        /// <summary>
        /// Initializes a new instance of the <see cref="NavigationModule" /> class.
        /// </summary>
        /// <param name="regionManager">The region manager.</param>
        public NavigationModule(IRegionManager regionManager)
        {
            _regionManager = regionManager;
        }
        /// <summary>
        /// Notifies the module that it has been initialized.
        /// </summary>
        /// <param name="containerProvider">The container provider.</param>
        public void OnInitialized(IContainerProvider containerProvider)
        {
            //TODO : Remove as we progress navigation
            _regionManager.RegisterViewWithRegion(RegionNames.RibbonRegion, typeof(MainRibbonBar));
        }

        /// <summary>
        /// Registers the types.
        /// </summary>
        /// <param name="containerRegistry">The container registry.</param>
        public void RegisterTypes(IContainerRegistry containerRegistry)
        {

        }
    }
}