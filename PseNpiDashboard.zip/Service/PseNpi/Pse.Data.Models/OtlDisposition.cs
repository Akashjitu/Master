﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class OtlDispositionDetails
    {
        [Columns("p_ID")]
        public string Id { get; set; }

        [Columns("p_PRODUCT_SBU")]
        public string ProductSbu { get; set; }

        [Columns("p_KEY_CODE")]
        public string HeatmapKc { get; set; }

        [Columns("p_PROGRAM_NAME")]
        public string ProgramName { get; set; }

        [Columns("p_OTL_BASELINE_DATE")]
        public DateTime OtlBaselineDate { get; set; }

        [Columns("p_OTL_FORECAST_DATE")]
        public DateTime OtlForecastDate { get; set; }

        [Columns("p_OTL_ACTUAL_DATE")]
        public DateTime OtlActualDate { get; set; }

        [Columns("p_MEETING_DATE_PLAN")]
        public string MeetingDatePlan { get; set; }

        [Columns("p_MEETING_DATE_ACTUAL")]
        public string MeetingDateActual { get; set; }

        [Columns("p_DATE_DATA_PULLED")]
        public string DateDataPulled { get; set; }

        [Columns("p_MONTH_PROGRAM_DISPOSITIONED")]
        public string MonthProgramDispositioned { get; set; }

        [Columns("p_SCOPE")]
        public string Scope { get; set; }

        [Columns("p_ACTIONS")]
        public string Actions { get; set; }

        [Columns("p_OTL_DISPOSITION")]
        public string OtlDisposition { get; set; }

        [Columns("p_REASONING")]
        public string Reasoning { get; set; }

        [Columns("p_OTL_DISPO_FNL_REVIEW")]
        public string OtlDispositionFinalReview { get; set; }

        [Columns("p_PRODUCTION_SITE")]
        public string ProductionSite { get; set; }

        [Columns("p_ENGINEERING_SITE")]
        public string EngineeringSite { get; set; }

        [Columns("p_GBE")]
        public string Gbe { get; set; }

        [Columns("p_IPDS")]
        public string Ipds { get; set; }

        [Columns("p_APQP_LEVEL")]
        public string ApqpLevel { get; set; }

        [Columns("p_PM")]
        public string Pm { get; set; }

        [Columns("p_PE")]
        public string Pe { get; set; }

        [Columns("p_AME")]
        public string Ame { get; set; }

        [Columns("p_PSE")]
        public string Pse { get; set; }

        [Columns("p_APQP_ENG")]
        public string ApqpEng { get; set; }

        [Columns("p_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("p_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("p_UPDATE_DATE")]
        public DateTime UpdateDate { get; set; }

        [Columns("p_ACTIVE")]
        public string Active { get; set; }
    }
}