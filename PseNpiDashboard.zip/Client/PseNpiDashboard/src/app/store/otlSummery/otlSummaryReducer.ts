import { Action } from '@ngrx/store';
import * as OtlSummaryActionGrid from './otlSummaryAction';
import { OtlSummery } from 'src/app/model/otlSummey';


export interface IAppState {
    readonly compliance: OtlSummery[];
}


export function otlGridSummaryReducer(state: OtlSummery[] = [], action: OtlSummaryActionGrid.Actions) {

    switch (action.type) {

        case OtlSummaryActionGrid.ADD_OTL_SUMMARY_GRID: {
            return [...state, action.payload]

        }

        case OtlSummaryActionGrid.LOAD_OTL_SUMMARY_GRID: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case OtlSummaryActionGrid.UPDATE_OTL_SUMMARY_GRID: {
            const otl = (action.payload as OtlSummery);
            const todo = state.find(t => t.id === otl.id);

            if (todo != undefined || todo != null) {


                todo.id                        =		otl.id;                         
                todo.keyCode                 =		otl.keyCode      ;            
                todo.programName       =		otl.programName ;       
                todo.productSbu                      =		otl.productSbu            ;           
                todo.hmrBaseline                    =		otl.hmrBaseline         ;            
                todo.rty        =		otl.rty  ;       
                todo.upc                  =		otl.upc          ;         
                todo.escapes             =		otl.escapes    ;          
                todo.prr                       =		otl.prr              ;          
                todo.ppap              =		otl.ppap     ;          
                todo.mra                =		otl.mra       ;          
                todo.otlHealth              =		otl.otlHealth     ;          
                todo.createdDate 					=		otl.createdDate ;
                todo.active                  =		otl.active         ;          
                todo.createdBy               =		otl.createdBy     ;           
                todo.updatedDate               =		otl.updatedDate              ;           
                todo.updatedByDashBoard         =		otl.updatedByDashBoard  ;        
               
                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            
            return state.slice();
        }



        default:
            return state;
    }
}