﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DataRepository.Migrations.ProjectDb
{
    public partial class Initial_Application : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Comments",
                columns: table => new
                {
                    CommentId = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CommentData = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Comments", x => x.CommentId);
                });

            migrationBuilder.CreateTable(
                name: "ContactTypes",
                columns: table => new
                {
                    ContactTypeID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContactTypes", x => x.ContactTypeID);
                });

            migrationBuilder.CreateTable(
                name: "Countries",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true),
                    Region = table.Column<string>(nullable: true),
                    Code = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Countries", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ExceptionLogs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Thread = table.Column<string>(maxLength: 500, nullable: true),
                    Level = table.Column<string>(maxLength: 100, nullable: true),
                    Logger = table.Column<string>(maxLength: 500, nullable: true),
                    Exception = table.Column<string>(maxLength: 4000, nullable: true),
                    Message = table.Column<string>(maxLength: 4000, nullable: true),
                    Date = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExceptionLogs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "IBComponenetTypes",
                columns: table => new
                {
                    ComponentTypeID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IBComponenetTypes", x => x.ComponentTypeID);
                });

            migrationBuilder.CreateTable(
                name: "Metadatas",
                columns: table => new
                {
                    MetadataID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Key = table.Column<string>(nullable: false),
                    Content = table.Column<byte[]>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Metadatas", x => x.MetadataID);
                });

            migrationBuilder.CreateTable(
                name: "Positions",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Positions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    CustomerID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedOn = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CompanyName = table.Column<string>(nullable: true),
                    BfoId = table.Column<int>(nullable: false),
                    Street = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    PostalCode = table.Column<string>(nullable: true),
                    Region = table.Column<string>(nullable: true),
                    CountryId = table.Column<int>(nullable: false),
                    ProjectName = table.Column<string>(nullable: false),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.CustomerID);
                    table.ForeignKey(
                        name: "FK_Customers_Countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Countries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Profiles",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    Street = table.Column<string>(nullable: true),
                    Town = table.Column<string>(nullable: true),
                    PostalCode = table.Column<string>(nullable: true),
                    Region = table.Column<string>(nullable: true),
                    Telephone = table.Column<string>(nullable: true),
                    MobileNumber = table.Column<string>(nullable: true),
                    Fax = table.Column<string>(nullable: true),
                    CountryId = table.Column<int>(nullable: false),
                    PositionId = table.Column<int>(nullable: false),
                    Created = table.Column<DateTime>(nullable: false),
                    Updated = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Profiles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Profiles_Countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Countries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Profiles_Positions_PositionId",
                        column: x => x.PositionId,
                        principalTable: "Positions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Projects",
                columns: table => new
                {
                    ProjectID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedOn = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CustomerID = table.Column<int>(nullable: true),
                    ProjectReferenceId = table.Column<string>(nullable: true),
                    LastSyncDate = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Projects", x => x.ProjectID);
                    table.ForeignKey(
                        name: "FK_Projects_Customers_CustomerID",
                        column: x => x.CustomerID,
                        principalTable: "Customers",
                        principalColumn: "CustomerID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    ContactID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedOn = table.Column<DateTime>(nullable: false, defaultValue: new DateTime(2020, 4, 14, 19, 50, 8, 117, DateTimeKind.Local).AddTicks(6497)),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false, defaultValue: false),
                    IsLinked = table.Column<bool>(type: "BOOLEAN", nullable: false, defaultValue: false),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Street = table.Column<string>(nullable: true),
                    City = table.Column<string>(nullable: true),
                    PostalCode = table.Column<string>(nullable: true),
                    PositionId = table.Column<int>(nullable: false),
                    CountryId = table.Column<int>(nullable: false),
                    Telephone = table.Column<string>(nullable: true),
                    Mobile = table.Column<string>(nullable: true),
                    Fax = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    ProjectID = table.Column<int>(nullable: false),
                    ContactTypeID = table.Column<int>(nullable: true),
                    Region = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.ContactID);
                    table.ForeignKey(
                        name: "FK_Contacts_ContactTypes_ContactTypeID",
                        column: x => x.ContactTypeID,
                        principalTable: "ContactTypes",
                        principalColumn: "ContactTypeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Contacts_Countries_CountryId",
                        column: x => x.CountryId,
                        principalTable: "Countries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Contacts_Positions_PositionId",
                        column: x => x.PositionId,
                        principalTable: "Positions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Contacts_Projects_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "Projects",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "IBProjectComponents",
                columns: table => new
                {
                    ComponentId = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    ModifiedOn = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    IsLinked = table.Column<bool>(nullable: false, defaultValue: true),
                    ComponentName = table.Column<string>(nullable: false),
                    ProjectID = table.Column<int>(nullable: true),
                    MetadataID = table.Column<int>(nullable: true),
                    CommentId = table.Column<int>(nullable: true),
                    ComponentTypeID = table.Column<int>(nullable: true),
                    NodeID = table.Column<int>(nullable: false),
                    ParentID = table.Column<int>(nullable: false),
                    IsTRNode = table.Column<bool>(nullable: false, defaultValue: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IBProjectComponents", x => x.ComponentId);
                    table.ForeignKey(
                        name: "FK_IBProjectComponents_Comments_CommentId",
                        column: x => x.CommentId,
                        principalTable: "Comments",
                        principalColumn: "CommentId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_IBProjectComponents_IBComponenetTypes_ComponentTypeID",
                        column: x => x.ComponentTypeID,
                        principalTable: "IBComponenetTypes",
                        principalColumn: "ComponentTypeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_IBProjectComponents_Metadatas_MetadataID",
                        column: x => x.MetadataID,
                        principalTable: "Metadatas",
                        principalColumn: "MetadataID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_IBProjectComponents_Projects_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "Projects",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "InventoryComments",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ProjectId = table.Column<int>(nullable: false),
                    NodeId = table.Column<int>(nullable: false),
                    Comments = table.Column<string>(nullable: true),
                    NodeType = table.Column<int>(nullable: false),
                    CustomerDocuments = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InventoryComments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InventoryComments_Projects_ProjectId",
                        column: x => x.ProjectId,
                        principalTable: "Projects",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProjectInventories",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ProjectId = table.Column<int>(nullable: false),
                    SubRangeId = table.Column<int>(nullable: false),
                    MaintenanceZone = table.Column<string>(nullable: true),
                    MaintenanceZoneId = table.Column<int>(nullable: false),
                    FactoryId = table.Column<int>(nullable: false),
                    Factory = table.Column<string>(nullable: true),
                    WorkshopId = table.Column<int>(nullable: false),
                    Workshop = table.Column<string>(nullable: true),
                    LineId = table.Column<int>(nullable: false),
                    Line = table.Column<string>(nullable: true),
                    MachineId = table.Column<int>(nullable: false),
                    Machine = table.Column<string>(nullable: true),
                    ConfigurationId = table.Column<int>(nullable: false),
                    Configuration = table.Column<string>(nullable: true),
                    DeviceType = table.Column<string>(nullable: true),
                    Range = table.Column<string>(nullable: true),
                    SubRange = table.Column<string>(nullable: true),
                    Reference = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    Quantity = table.Column<int>(nullable: false),
                    PvNumber = table.Column<string>(nullable: true),
                    SvNumber = table.Column<string>(nullable: true),
                    UnitPrice = table.Column<string>(nullable: true),
                    Strategic = table.Column<string>(nullable: true),
                    Brand = table.Column<string>(nullable: true),
                    Year = table.Column<string>(nullable: true),
                    Year1 = table.Column<string>(nullable: true),
                    Year2 = table.Column<string>(nullable: true),
                    Year3 = table.Column<string>(nullable: true),
                    Year4 = table.Column<string>(nullable: true),
                    Dosa = table.Column<string>(nullable: true),
                    DoS = table.Column<string>(nullable: true),
                    EoS = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    BrandId = table.Column<int>(nullable: false),
                    RangeId = table.Column<int>(nullable: false),
                    DeviceTypeId = table.Column<int>(nullable: false),
                    Criticality = table.Column<string>(nullable: true),
                    ConfigType = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectInventories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProjectInventories_Projects_ProjectId",
                        column: x => x.ProjectId,
                        principalTable: "Projects",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Criticalities",
                columns: table => new
                {
                    CriticalityID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    SafetyIssue = table.Column<string>(nullable: true),
                    QualityIssue = table.Column<string>(nullable: true),
                    LeadTimeIssue = table.Column<string>(nullable: true),
                    CostsIssue = table.Column<string>(nullable: true),
                    CriticalityValue = table.Column<string>(nullable: true),
                    Comments = table.Column<string>(nullable: true),
                    NodeID = table.Column<int>(nullable: false),
                    IBProjectComponentComponentId = table.Column<int>(nullable: true),
                    ProjectID = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Criticalities", x => x.CriticalityID);
                    table.ForeignKey(
                        name: "FK_Criticalities_IBProjectComponents_IBProjectComponentComponentId",
                        column: x => x.IBProjectComponentComponentId,
                        principalTable: "IBProjectComponents",
                        principalColumn: "ComponentId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Criticalities_Projects_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "Projects",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "OperationModes",
                columns: table => new
                {
                    OperationModeID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    OperatingMode = table.Column<string>(nullable: true),
                    HourlyProduction = table.Column<string>(nullable: true),
                    StartupDate = table.Column<string>(nullable: true),
                    Age = table.Column<string>(nullable: true),
                    EndOfLife = table.Column<string>(nullable: true),
                    Comments = table.Column<string>(nullable: true),
                    NodeID = table.Column<int>(nullable: false),
                    IBProjectComponentComponentId = table.Column<int>(nullable: true),
                    ProjectID = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OperationModes", x => x.OperationModeID);
                    table.ForeignKey(
                        name: "FK_OperationModes_IBProjectComponents_IBProjectComponentComponentId",
                        column: x => x.IBProjectComponentComponentId,
                        principalTable: "IBProjectComponents",
                        principalColumn: "ComponentId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_OperationModes_Projects_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "Projects",
                        principalColumn: "ProjectID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "xrefProducts",
                columns: table => new
                {
                    ProductID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    IBCatalogueID = table.Column<int>(nullable: false),
                    PVNumber = table.Column<string>(nullable: true),
                    SVNumber = table.Column<string>(nullable: true),
                    Quantity = table.Column<int>(nullable: false),
                    ComponentId = table.Column<int>(nullable: true),
                    CommentId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_xrefProducts", x => x.ProductID);
                    table.ForeignKey(
                        name: "FK_xrefProducts_Comments_CommentId",
                        column: x => x.CommentId,
                        principalTable: "Comments",
                        principalColumn: "CommentId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_xrefProducts_IBProjectComponents_ComponentId",
                        column: x => x.ComponentId,
                        principalTable: "IBProjectComponents",
                        principalColumn: "ComponentId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "ContactTypes",
                columns: new[] { "ContactTypeID", "Name" },
                values: new object[] { 2, "Schneider" });

            migrationBuilder.InsertData(
                table: "ContactTypes",
                columns: new[] { "ContactTypeID", "Name" },
                values: new object[] { 1, "Customer" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 3, "GB", "United Kingdom", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 142, "NA", "Namibia", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 143, "NR", "Nauru", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 144, "NP", "Nepal", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 145, "NL", "Netherlands", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 146, "AN", "Netherlands Antilles", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 147, "NC", "New Caledonia", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 148, "NZ", "New Zealand", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 149, "NI", "Nicaragua", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 150, "NE", "Niger", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 151, "NG", "Nigeria", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 152, "NO", "Norway", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 154, "PK", "Pakistan", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 141, "MM", "Myanmar", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 155, "PW", "Palau", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 156, "PA", "Panama", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 157, "PG", "Papua New Guinea", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 158, "PY", "Paraguay", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 159, "PE", "Peru", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 160, "PH", "Philippines", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 161, "PL", "Poland", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 162, "PT", "Portugal", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 163, "PR", "Puerto Rico", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 164, "QA", "Qatar", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 153, "OM", "Oman", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 140, "MZ", "Mozambique", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 138, "MS", "Montserrat", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 165, "RE", "Reunion", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 113, "LB", "Lebanon", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 114, "LS", "Lesotho", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 115, "LR", "Liberia", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 116, "LY", "Libya", "NORTHERN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 117, "LI", "Liechtenstein ", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 119, "LU", "Luxembourg", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 120, "MO", "Macau", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 121, "MK", "Macedonia", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 122, "MG", "Madagascar", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 123, "MW", "Malawi", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 124, "MY", "Malaysia", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 139, "MA", "Morocco", "NORTHERN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 125, "MV", "Maldives", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 127, "MT", "Malta", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 128, "MH", "Marshall Islands", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 129, "MQ", "Martinique", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 130, "MR", "Mauritania", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 131, "MU", "Mauritius", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 132, "YT", "Mayotte", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 133, "MX", "Mexico", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 134, "FM", "Micronesia Fed. St.", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 135, "MD", "Moldova", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 136, "MC", "Monaco", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 137, "MN", "Mongolia", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 126, "ML", "Mali", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 166, "RO", "Romania", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 168, "RW", "Rwanda", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 112, "LV", "Latvia", "BALTICS" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 197, "TZ", "Tanzania", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 198, "TH", "Thailand", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 199, "TG", "Togo", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 200, "TO", "Tonga", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 201, "TT", "Trinidad & Tobago", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 202, "TN", "Tunisia", "NORTHERN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 203, "TR", "Turkey", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 204, "TM", "Turkmenistan", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 205, "TC", "Turks & Caicos Is", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 206, "TV", "Tuvalu", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 207, "UG", "Uganda", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 196, "TJ", "Tajikistan", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 208, "UA", "Ukraine", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 212, "UY", "Uruguay", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 213, "UZ", "Uzbekistan", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 214, "VU", "Vanuatu", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 215, "VE", "Venezuela", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 216, "VN", "Vietnam", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 217, "VI", "Virgin Islands", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 218, "WF", "Wallis and Futuna", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 219, "EH", "Western Sahara", "NORTHERN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 220, "YE", "Yemen", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 221, "ZM", "Zambia", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 222, "ZW", "Zimbabwe", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 209, "AE", "United Arab Emirates", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 167, "RU", "Russia", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 195, "TW", "Taiwan", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 193, "CH", "Switzerland", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 169, "SH", "Saint Helena", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 170, "KN", "Saint Kitts & Nevis", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 171, "LC", "Saint Lucia", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 172, "VC", "Saint Vincent and the Grenadines", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 173, "WS", "Samoa", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 174, "SM", "San Marino", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 175, "ST", "Sao Tome & Principe", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 176, "SA", "Saudi Arabia", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 177, "SN", "Senegal", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 178, "CS", "Serbia", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 179, "SC", "Seychelles", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 194, "SY", "Syria", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 180, "SL", "Sierra Leone", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 182, "SK", "Slovakia", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 183, "SI", "Slovenia", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 184, "SB", "Solomon Islands", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 185, "SO", "Somalia", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 186, "ZA", "South Africa", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 187, "ES", "Spain", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 188, "LK", "Sri Lanka", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 189, "SD", "Sudan", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 190, "SR", "Suriname", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 191, "SZ", "Swaziland", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 192, "SE", "Sweden", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 181, "SG", "Singapore", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 111, "LA", "Laos", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 118, "LT", "Lithuania", "BALTICS" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 109, "KW", "Kuwait", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 27, "BW", "Botswana", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 28, "BR", "Brazil", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 29, "IO", "British Indian Ocean Territory", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 30, "BN", "Brunei Darussalam", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 31, "BG", "Bulgaria", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 32, "BF", "Burkina Faso", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 33, "BI", "Burundi", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 34, "KH", "Cambodia", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 35, "CM", "Cameroon", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 36, "CA", "Canada", "NORTHERN AMERICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 37, "CV", "Cape Verde", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 26, "BA", "Bosnia & Herzegovina", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 38, "KY", "Cayman Islands", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 40, "TD", "Chad", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 41, "CL", "Chile", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 42, "CN", "China", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 43, "CO", "Colombia", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 44, "KM", "Comoros", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 110, "KG", "Kyrgyzstan", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 46, "CD", "Congo Repub.", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 47, "CK", "Cook Islands", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 48, "CR", "Costa Rica", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 49, "CI", "Cote d'Ivoire", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 50, "HR", "Croatia", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 39, "CF", "Central African Republic", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 25, "BO", "Bolivia", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 24, "BT", "Bhutan", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 23, "BM", "Bermuda", "NORTHERN AMERICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 1, "US", "United States", "NORTHERN AMERICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 2, "FR", "France", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 4, "IN", "India", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 211, "AF", "Afghanistan", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 68, "AL", "Albania", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 210, "DZ", "Algeria", "NORTHERN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 92, "AS", "American Samoa", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 5, "AD", "Andorra", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 6, "AO", "Angola", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 7, "AI", "Anguilla", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 8, "AG", "Antigua & Barbuda", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 9, "AR", "Argentina", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 10, "AM", "Armenia", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 11, "AW", "Aruba", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 12, "AU", "Australia", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 13, "AT", "Austria", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 14, "AZ", "Azerbaijan", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 15, "BS", "Bahamas", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 16, "BH", "Bahrain", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 17, "BD", "Bangladesh", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 18, "BB", "Barbados", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 19, "BY", "Belarus", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 20, "BE", "Belgium", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 21, "BZ", "Belize", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 22, "BJ", "Benin", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 51, "CU", "Cuba", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 52, "CY", "Cyprus", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 45, "CG", "Congo Dem. Rep.", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 54, "DK", "Denmark", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 84, "GN", "Guinea", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 85, "GW", "Guinea-Bissau", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 86, "GY", "Guyana", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 87, "HT", "Haiti", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 88, "HN", "Honduras", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 53, "CZ", "Czech Republic", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 90, "HU", "Hungary", "EASTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 91, "IS", "Iceland", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 93, "ID", "Indonesia", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 94, "IR", "Iran", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 95, "IQ", "Iraq", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 83, "GG", "Guernsey", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 96, "IE", "Ireland", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 98, "IL", "Israel", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 99, "IT", "Italy", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 100, "JM", "Jamaica", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 101, "JP", "Japan", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 102, "JE", "Jersey", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 103, "JO", "Jordan", "NEAR EAST" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 104, "KZ", "Kazakhstan", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 105, "KE", "Kenya", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 106, "KI", "Kiribati", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 107, "KP", "Korea North", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 108, "KR", "Korea  South", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 97, "IM", "Isle of Man", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 82, "GT", "Guatemala", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 89, "HK", "Hong Kong", "ASIA (EX. NEAR EAST)" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 80, "GP", "Guadeloupe", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 55, "DJ", "Djibouti", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 56, "DM", "Dominica", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 57, "DO", "Dominican Republic", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 58, "EC", "Ecuador", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 59, "EG", "Egypt", "NORTHERN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 81, "GU", "Guam", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 60, "SV", "El Salvador", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 61, "GQ", "Equatorial Guinea", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 62, "ER", "Eritrea", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 64, "ET", "Ethiopia", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 65, "FO", "Faroe Islands", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 66, "FJ", "Fiji", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 63, "EE", "Estonia", "BALTICS" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 69, "GF", "French Guiana", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 79, "GD", "Grenada", "LATIN AMER. & CARIB" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 78, "GL", "Greenland", "NORTHERN AMERICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 67, "FI", "Finland", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 76, "GI", "Gibraltar", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 75, "GH", "Ghana", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 77, "GR", "Greece", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 73, "GE", "Georgia", "C.W. OF IND. STATES" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 72, "GM", "Gambia", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 71, "GA", "Gabon", "SUB-SAHARAN AFRICA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 70, "PF", "French Polynesia", "OCEANIA" });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "Id", "Code", "Name", "Region" },
                values: new object[] { 74, "DE", "Germany", "WESTERN EUROPE" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 11, "Maintenance Zone" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 10, "Technical Resource" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 9, "Open Configuration" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 6, "PLC Config" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 8, "Scada HMI Config" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 7, "Motion & Drive Config" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 5, "Machine" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 12, "Stock" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 3, "Workshop" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 2, "Factory" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 1, "Install Base" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 4, "Line" });

            migrationBuilder.InsertData(
                table: "IBComponenetTypes",
                columns: new[] { "ComponentTypeID", "Name" },
                values: new object[] { 13, "Competencies" });

            migrationBuilder.InsertData(
                table: "Positions",
                columns: new[] { "Id", "Name" },
                values: new object[] { 3, "Commercial Manager" });

            migrationBuilder.InsertData(
                table: "Positions",
                columns: new[] { "Id", "Name" },
                values: new object[] { 2, "Project Engineer" });

            migrationBuilder.InsertData(
                table: "Positions",
                columns: new[] { "Id", "Name" },
                values: new object[] { 1, "Project Manager" });

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_ContactTypeID",
                table: "Contacts",
                column: "ContactTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_CountryId",
                table: "Contacts",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_PositionId",
                table: "Contacts",
                column: "PositionId");

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_ProjectID",
                table: "Contacts",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "IX_Criticalities_IBProjectComponentComponentId",
                table: "Criticalities",
                column: "IBProjectComponentComponentId");

            migrationBuilder.CreateIndex(
                name: "IX_Criticalities_ProjectID",
                table: "Criticalities",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "INDX_bfoID",
                table: "Customers",
                column: "BfoId");

            migrationBuilder.CreateIndex(
                name: "IX_Customers_CountryId",
                table: "Customers",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_IBProjectComponents_CommentId",
                table: "IBProjectComponents",
                column: "CommentId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_IBProjectComponents_ComponentTypeID",
                table: "IBProjectComponents",
                column: "ComponentTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_IBProjectComponents_MetadataID",
                table: "IBProjectComponents",
                column: "MetadataID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_IBProjectComponents_ProjectID",
                table: "IBProjectComponents",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "IX_InventoryComments_ProjectId",
                table: "InventoryComments",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_OperationModes_IBProjectComponentComponentId",
                table: "OperationModes",
                column: "IBProjectComponentComponentId");

            migrationBuilder.CreateIndex(
                name: "IX_OperationModes_ProjectID",
                table: "OperationModes",
                column: "ProjectID");

            migrationBuilder.CreateIndex(
                name: "IX_Profiles_CountryId",
                table: "Profiles",
                column: "CountryId");

            migrationBuilder.CreateIndex(
                name: "IX_Profiles_PositionId",
                table: "Profiles",
                column: "PositionId");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectInventories_ProjectId",
                table: "ProjectInventories",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_Projects_CustomerID",
                table: "Projects",
                column: "CustomerID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_xrefProducts_CommentId",
                table: "xrefProducts",
                column: "CommentId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_xrefProducts_ComponentId",
                table: "xrefProducts",
                column: "ComponentId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Contacts");

            migrationBuilder.DropTable(
                name: "Criticalities");

            migrationBuilder.DropTable(
                name: "ExceptionLogs");

            migrationBuilder.DropTable(
                name: "InventoryComments");

            migrationBuilder.DropTable(
                name: "OperationModes");

            migrationBuilder.DropTable(
                name: "Profiles");

            migrationBuilder.DropTable(
                name: "ProjectInventories");

            migrationBuilder.DropTable(
                name: "xrefProducts");

            migrationBuilder.DropTable(
                name: "ContactTypes");

            migrationBuilder.DropTable(
                name: "Positions");

            migrationBuilder.DropTable(
                name: "IBProjectComponents");

            migrationBuilder.DropTable(
                name: "Comments");

            migrationBuilder.DropTable(
                name: "IBComponenetTypes");

            migrationBuilder.DropTable(
                name: "Metadatas");

            migrationBuilder.DropTable(
                name: "Projects");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "Countries");
        }
    }
}
