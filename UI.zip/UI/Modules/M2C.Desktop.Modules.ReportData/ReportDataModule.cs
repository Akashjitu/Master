﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.ReportData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReportDataModule.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Ioc;
using Prism.Modularity;

namespace M2C.Desktop.Modules.ReportData
{
    /// <summary>
    /// Class ReportDataModule.
    /// Implements the <see cref="Prism.Modularity.IModule" />
    /// </summary>
    /// <seealso cref="Prism.Modularity.IModule" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ReportDataModule : IModule
    {
        /// <summary>
        /// Notifies the module that it has been initialized.
        /// </summary>
        /// <param name="containerProvider">The container provider.</param>
        public void OnInitialized(IContainerProvider containerProvider)
        {

        }

        /// <summary>
        /// Registers the types.
        /// </summary>
        /// <param name="containerRegistry">The container registry.</param>
        public void RegisterTypes(IContainerRegistry containerRegistry)
        {

        }
    }
}