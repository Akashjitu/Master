export interface OtlGraduates {

    keyCode: string;
    otlBaselineDate:Date;
    partNumber:string;
    lru:string;
    productionSite:string;
    apqpLvl:string;
    plannedQty:string;
    erpSystemLoad:string;
    plan:string;
    actuals:string;
    forecast:string;
    upcIndex:string;
    ese:string;
    ece:string;
    ppap:string;
    prr:string;
    mra:string;
    updatedDate:Date;
    updatedBy:null;
    active: string;
    createdDate:Date;
    createBy: string;
    id: number
}