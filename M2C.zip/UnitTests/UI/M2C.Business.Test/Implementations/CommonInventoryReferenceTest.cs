﻿using DataRepository.DBContracts;
using M2C.Business.Mappers;
using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace M2C.Business.Implementations
{
    [TestClass]
    public class CommonInventoryReferenceTest
    {
        private IBrandModelMapper _brandModelMapper;
        private IRangeModelMapper _rangeModelMapper;
        private IDeviceTypeModelMapper _deviceTypeModelMapper;
        private IProductModelMapper _productModelMapper;

        private IProductQueries _productQueries;
        private IBrandQueries _brandQueries;
        private IRangeQueries _rangeQueries;
        private IDeviceTypeQueries _deviceTypeQueries;

        private CommonInventoryReference commonInventoryReference;

        [TestInitialize]
        public void Setup()
        {
            _brandModelMapper = new BrandModelMapper();
            _rangeModelMapper = new RangeModelMapper();
            _deviceTypeModelMapper = new DeviceTypeModelMapper();
            _productModelMapper = new ProductModelMapper();

            _productQueries = Substitute.For<IProductQueries>();
            _brandQueries = Substitute.For<IBrandQueries>();
            _rangeQueries = Substitute.For<IRangeQueries>();
            _deviceTypeQueries = Substitute.For<IDeviceTypeQueries>();

            _productQueries.GetProductsStartWithIdentifier(Arg.Any<string>()).Returns(MockProvider.GetProducts());
            _brandQueries.LoadBrands(Arg.Any<string>()).Returns(MockProvider.GetBrands());
            _rangeQueries.GetRangeByBrand(Arg.Any<int>()).Returns(MockProvider.GetRanges());
            _rangeQueries.GetRangeByBrandAndDeviceTypeIds(Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetRanges());
            _deviceTypeQueries.GetDeviceTypesByBrandAndRangeId(Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetDeviceTypes());
            _deviceTypeQueries.GetDeviceTypesByBrandId(Arg.Any<int>()).Returns(MockProvider.GetDeviceTypes());
            _productQueries.GetProductByIds(Arg.Any<int>(), Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetProducts());
            _deviceTypeQueries.LoadDeviceTypes(Arg.Any<string>()).Returns(MockProvider.GetDeviceTypes());
            _productQueries.GetProductsByDeviceIdAndRangeId(Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetProducts());
            _rangeQueries.GetRangeByDeviceId(Arg.Any<int>()).Returns(MockProvider.GetRanges());

            commonInventoryReference = new CommonInventoryReference(_brandModelMapper, _rangeModelMapper, _deviceTypeModelMapper, _productModelMapper,
                _productQueries, _brandQueries, _rangeQueries, _deviceTypeQueries);
        }

        [TestMethod]
        public void ShouldReturnProductsBasedOnText()
        {
            var products = commonInventoryReference.GetProductsStartWithIdentifier("s");

            Assert.IsNotNull(products);
            Assert.IsTrue(products.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnDatabaseProductsBasedOnText()
        {
            var products = commonInventoryReference.GetDbProducts("s");
            Assert.IsNotNull(products);
            Assert.IsTrue(products.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnBrandBasedonName()
        {
            var brands = commonInventoryReference.GetBrandModels("Se");
            Assert.IsNotNull(brands);
            Assert.IsTrue(brands.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnRangeBasedOnBrandId()
        {
            var ranges = commonInventoryReference.GetRangeByBrand(1);
            Assert.IsNotNull(ranges);
            Assert.IsTrue(ranges.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnRangeBasedOnDeviceTypeIdAndBrandId()
        {
            var ranges = commonInventoryReference.GetRangeByBrandAndDeviceTypeIds(1, 1);
            Assert.IsNotNull(ranges);
            Assert.IsTrue(ranges.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnDeviceTypesByBrandAndRangeId()
        {
            var deviceTypes = commonInventoryReference.GetDeviceTypesByBrandAndRangeId(1, 1);
            Assert.IsNotNull(deviceTypes);
            Assert.IsTrue(deviceTypes.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnDeviceTypesByBrandId()
        {
            var deviceTypes = commonInventoryReference.GetDeviceTypesByBrand(1);
            Assert.IsNotNull(deviceTypes);
            Assert.IsTrue(deviceTypes.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnProductsByBrandDeviceTypeIdAndRangeId()
        {
            var products = commonInventoryReference.GetProducts(1, 1, 1);
            Assert.IsNotNull(products);
            Assert.IsTrue(products.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnDeviceTypeBasedOnName()
        {
            var deviceTypes = commonInventoryReference.GetDeviceTypes("AE");
            Assert.IsNotNull(deviceTypes);
            Assert.IsTrue(deviceTypes.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnProductsByDeviceIdAndRangeId()
        {
            var products = commonInventoryReference.GetProductsByDeviceIdAndRangeId(1, 1);
            Assert.IsNotNull(products);
            Assert.IsTrue(products.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnRangeByDeviceTypeIds()
        {
            var ranges = commonInventoryReference.GetRangeByDeviceTypeIds(1);
            Assert.IsNotNull(ranges);
            Assert.IsTrue(ranges.Count > 0);
        }
    }
}