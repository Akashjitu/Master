﻿using Oracle.Data.Access;
using Oracle.ManagedDataAccess.Client;
using Pse.Data.Models;
using System;
using System.Data;

namespace Spea.Service.DataBaseAccessObject.Saver
{
    public class SeviceDataSave : ISeviceDataSave
    {
        public SeviceDataSave()
        {
        }

        public int AddCompliance(Compliance compliance)
        {
            using (var dao = new DataAccessObject<Compliance>())
            {
                var data = dao.Post(compliance, "PK_PSE_COMPLIANCE.SP_ADD_COMPLIANCE");
                return data;
            }
        }

        public int AddTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.Post(ttiPartAlignment, "PK_PSE_TTI.SP_ADD_TTI_INFO");
                return data;
            }

        }

        public int DeleteCompliance(Compliance compliance)
        {
           
            using (var dao = new DataAccessObject<Compliance>())
            {
                var data = dao.Delete(compliance, "PK_PSE_COMPLIANCE.SP_REMOVE_COMPLIANCE");
                return data;
            }
         
        }

        public int UpdateCompliance(Compliance compliance)
        {
          
            using (var dao = new DataAccessObject<Compliance>())
            {
                var data = dao.Put(compliance, "PK_PSE_COMPLIANCE.SP_UPDATE_COMPLIANCE");
                return data;
            }
        }

        public int UpdateTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.Post(ttiPartAlignment, "PK_PSE_TTI.SP_UPDATE_TTI_INFO");
                return data;
            }
        }

        public int AddEffectiveness(Effectiveness eft)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.Post(eft, "PK_PSE_EFFECTIVENESS.SP_INSERT_EFFECTIV_INFO");
                return data;
            }
        }


        public int UpdateEffectiveness(Effectiveness eft)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.Put(eft, "PK_PSE_EFFECTIVENESS.SP_UPDATE_EFFECTIV_INFO");
                return data;
            }
        }

    }
}