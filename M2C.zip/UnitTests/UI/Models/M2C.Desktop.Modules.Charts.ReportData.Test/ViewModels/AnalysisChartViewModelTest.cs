﻿//using System;
//using System.Collections.Generic;
//using System.Collections.ObjectModel;
//using System.Linq;
//using M2C.Business.Implementations;
//using M2C.Business.Models.CommonChartParameters;
//using M2C.Business.Models.Project;
//using M2C.Business.Models.Project.IBComponents;
//using M2C.Desktop.Modules.Charts.Events;
//using M2C.Desktop.Modules.Charts.ReportData.Test.Mock;
//using M2C.Desktop.Modules.Charts.ViewModels;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using Prism.Events;

//namespace M2C.Desktop.Modules.Charts.Test.ViewModels
//{
//    [TestClass]
//    public class AnalysisChartViewModelTest
//    {
//        private AnalysisChartViewModel _analysisChartViewModel = null;
//        private IEventAggregator _eventAggregator;
//        private IStatusColorProvider _colorProvider;

//        [TestInitialize]
//        public void Setup()
//        {
//            _eventAggregator = new EventAggregator();
//            _colorProvider = new StatusColorProvider();
//            _analysisChartViewModel = new AnalysisChartViewModel(_eventAggregator, _colorProvider);
//        }


//        [TestMethod]
//        public void ShouldSetTheDefaultValue()
//        {
//            Assert.IsTrue(_analysisChartViewModel.HeaderLabel == "Perimeter: Installed base");
//            Assert.IsTrue(_analysisChartViewModel.MappingChartHeight == 900);
//        }

//        [TestMethod]
//        public void ShouldCallShowChartWitMappingParameter()
//        {
//            var installbased = (InstalledBase)ChartMockProvide.GetInstalledBasedNodeTree();
//            var factories = installbased.Factories;
//            ChartParameter chartParameter = new ChartParameter();
//            chartParameter.SelectInventoryType = "Installed Base";
//            chartParameter.SelectChartMapping = "Mapping";
//            chartParameter.SelectedYear = 2020;
//            chartParameter.SelectedNode = factories[0];
//            chartParameter.SelectedParameterNode = new ChartParameterNode()
//            { NodeType = NodeType.FACTORY, NodeHeader = $"Factory (2)", Nodes = factories.Cast<INode>().ToList() };
//            chartParameter.AllParameterNodes = SetInstalledBasedTree(installbased);

//            _eventAggregator.GetEvent<ChartParameterEvent>().Publish(chartParameter);

//            Assert.IsNotNull(_analysisChartViewModel);
//            Assert.IsTrue(_analysisChartViewModel.ChartElements.Count == 2);
//            Assert.IsTrue(_analysisChartViewModel.ChartElements.Any(i => i.Name == "Factory1"));
//            Assert.IsTrue(_analysisChartViewModel.HeaderLabel == "Mapping Installed Base by FACTORY");
//            Assert.IsTrue(_analysisChartViewModel.ChartElements.Any(i => i.ConfigCount == 9));

//        }


//        [TestMethod]
//        public void ShouldCallShowChartWithObsolescenceParameter()
//        {
//            var installbased = (InstalledBase)ChartMockProvide.GetInstalledBasedNodeTree();
//            var factories = installbased.Factories;
//            ChartParameter chartParameter = new ChartParameter();
//            chartParameter.SelectInventoryType = "Installed Base";
//            chartParameter.SelectChartMapping = "Obsolescence";
//            chartParameter.SelectedYear = DateTime.Today.AddYears(7).Year;
//            chartParameter.SelectedNode = factories[0];
//            chartParameter.SelectedParameterNode = new ChartParameterNode()
//            { NodeType = NodeType.FACTORY, NodeHeader = $"Factory (2)", Nodes = factories.Cast<INode>().ToList() };
//            chartParameter.AllParameterNodes = SetInstalledBasedTree(installbased);

//            _eventAggregator.GetEvent<ChartParameterEvent>().Publish(chartParameter);

//            Assert.IsTrue(_analysisChartViewModel.XAxesLabel == "Configuration");
//            Assert.IsTrue(_analysisChartViewModel.ObsolescenceChartsHeight == 900);
//            Assert.IsTrue(_analysisChartViewModel.MappingChartHeight == 0);
//            Assert.IsTrue(_analysisChartViewModel.RedChartElements.Count > 0);
//            Assert.IsTrue(_analysisChartViewModel.GreenChartElements.Count > 0);
//            Assert.IsTrue(_analysisChartViewModel.YellowChartElements.Count > 0);

//            //Assert.IsTrue(_analysisChartViewModel.RedChartElements.Any(i => i.ConfigCount > 0));
//            //Assert.IsTrue(_analysisChartViewModel.GreenChartElements.Any(i => i.ConfigCount > 0));
//            //Assert.IsTrue(_analysisChartViewModel.YellowChartElements.Any(i => i.ConfigCount > 0));
//        }

//        [TestMethod]
//        public void ShouldCallShowChartWithCriticalityParameter()
//        {
//            var installbased = (InstalledBase)ChartMockProvide.GetInstalledBasedNodeTree();
//            var factories = installbased.Factories;
//            ChartParameter chartParameter = new ChartParameter();
//            chartParameter.SelectInventoryType = "Installed Base";
//            chartParameter.SelectChartMapping = "Machine Criticality";
//            chartParameter.SelectedYear = DateTime.Today.AddYears(7).Year;
//            chartParameter.SelectedNode = factories[0];
//            chartParameter.SelectedParameterNode = new ChartParameterNode()
//            { NodeType = NodeType.FACTORY, NodeHeader = $"Factory (2)", Nodes = factories.Cast<INode>().ToList() };
//            chartParameter.AllParameterNodes = SetInstalledBasedTree(installbased);

//            _eventAggregator.GetEvent<ChartParameterEvent>().Publish(chartParameter);

//            Assert.IsTrue(_analysisChartViewModel.XAxesLabel == "Machine");
//            Assert.IsTrue(_analysisChartViewModel.ObsolescenceChartsHeight == 0);
//            Assert.IsTrue(_analysisChartViewModel.MappingChartHeight == 900);

//            Assert.IsTrue(_analysisChartViewModel.ChartElements.Count == 2);
//            Assert.IsTrue(_analysisChartViewModel.ChartElements.Any(i => i.Name == "Machine1"));
//            Assert.IsTrue(_analysisChartViewModel.HeaderLabel == "Machine Criticality Installed Base by FACTORY");
//            Assert.IsTrue(_analysisChartViewModel.ChartElements.Any(i => i.ConfigCount == 3));
//        }

//        private ObservableCollection<ChartParameterNode> SetInstalledBasedTree(INode selectedInstalledBasedNode)
//        {
//            if (selectedInstalledBasedNode == null)
//                return null;

//            ObservableCollection<ChartParameterNode> chartParameterNodes = new ObservableCollection<ChartParameterNode>();
//            var machines = new List<MachineNode>();
//            if (!(selectedInstalledBasedNode is InstalledBase installedBaseNode)) return null;

//            var factories = installedBaseNode.Factories.Cast<INode>().ToList();
//            chartParameterNodes.Add(new ChartParameterNode() { NodeType = NodeType.FACTORY, NodeHeader = $"Factory ({factories.Count})", Nodes = factories });

//            var workshops = installedBaseNode.Factories.SelectMany(i => i.WorkShopNodes).ToList();
//            chartParameterNodes.Add(new ChartParameterNode() { NodeType = NodeType.WORKSHOP, NodeHeader = $"Workshop ({workshops.Count})", Nodes = workshops.Cast<INode>().ToList() });

//            var line = workshops.SelectMany(i => i.LineNodes).ToList();
//            chartParameterNodes.Add(new ChartParameterNode() { NodeType = NodeType.LINE, NodeHeader = $"Lines ({line.Count})", Nodes = line.Cast<INode>().ToList() });

//            var workshopsMachine = workshops.SelectMany(i => i.MachineNodes).ToList();
//            var lineMachine = line.SelectMany(i => i.MachineNodes).ToList();
//            var filterLineMachine = lineMachine.Where(i => workshopsMachine.All(k => k.Id != i.Id)).ToList();
//            machines.AddRange(filterLineMachine);
//            machines.AddRange(workshopsMachine);

//            chartParameterNodes.Add(new ChartParameterNode() { NodeType = NodeType.MACHINE, NodeHeader = $"Machine ({machines.Count})", Nodes = machines.Cast<INode>().ToList() });

//            var config = machines.SelectMany(i => i.ConfigNodes).ToList();
//            chartParameterNodes.Add(new ChartParameterNode() { NodeType = NodeType.OPEN_CONFIG, NodeHeader = $"Configuration ({config.Count})", Nodes = config.Cast<INode>().ToList() });

//            return chartParameterNodes;
//        }
//    }
//}