﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="TRSideBarTreeViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using Microsoft.Win32;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using M2C.Business.GlobalFields;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Technical Resource Side tree-view VM
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <summary>
    /// Class TRSideBarTreeViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="System.IDisposable" />
    public partial class TRSideBarTreeViewModel : BindableBase, IDisposable
    {
        /// <summary>
        /// The components command
        /// </summary>
        private IGlobalTRCommands _componentsCommand;

        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService _sharedContextService;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// The technical resources
        /// </summary>
        private TRNode _technicalResources;

        /// <summary>
        /// The add t rcomponents
        /// </summary>
        private DelegateCommand<string> _addTRcomponents;

        /// <summary>
        /// The selected node
        /// </summary>
        private dynamic _selectedNode;

        /// <summary>
        /// The save file dialog
        /// </summary>
        private readonly SaveFileDialog _saveFileDialog;

        /// <summary>
        /// Gets or sets the selected node.
        /// </summary>
        /// <value>The selected node.</value>
        public dynamic SelectedNode { get => _selectedNode; set => _selectedNode = value; }

        /// <summary>
        /// The project model
        /// </summary>
        private readonly ProjectContextModel _projectModel;

        /// <summary>
        /// The import tr component
        /// </summary>
        private readonly DelegateCommand _importTRComponent;

        /// <summary>
        /// export TR component
        /// </summary>
        private DelegateCommand _exportTRComponenet;

        /// <summary>
        /// Gets the excel import.
        /// </summary>
        /// <value>The excel import.</value>
        private IExcelImport ExcelImport { get; }

        /// <summary>
        /// The file open dialogue
        /// </summary>
        private readonly IFileOpenDialogue _fileOpenDialogue;

        /// <summary>
        /// The project change event
        /// </summary>
        private readonly ProjectChangeEvent _projectChangeEvent;

        /// <summary>
        /// The LST inventory
        /// </summary>
        private List<Inventory> _lstInventory;

        /// <summary>
        /// Gets the excel export.
        /// </summary>
        /// <value>The excel export.</value>
        private IExcelExport ExcelExport { get; }

        /// <summary>
        /// The inventory mapper
        /// </summary>
        private readonly IInventoryMapper _inventoryMapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="TRSideBarTreeViewModel" /> class.
        /// </summary>
        /// <param name="componentsCommand">The components command.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="excelImport">The excel import.</param>
        /// <param name="fileOpenDialogue">The file open dialogue.</param>
        /// <param name="excelExport">The excel export.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        public TRSideBarTreeViewModel(IGlobalTRCommands componentsCommand,
            ISharedContextService sharedContextService,
            IEventAggregator eventAggregator,
            IExcelImport excelImport,
            IFileOpenDialogue fileOpenDialogue,
            IExcelExport excelExport, IInventoryMapper inventoryMapper)
        {
            //Read-only variables
            ExcelImport = excelImport;
            _componentsCommand = componentsCommand;
            _sharedContextService = sharedContextService;
            _eventAggregator = eventAggregator;
            _fileOpenDialogue = fileOpenDialogue;
            ExcelExport = excelExport;
            _inventoryMapper = inventoryMapper;
            _plusMenu = new TRSMenuItem();
            //Delegate Commands
            SelectedItem = new DelegateCommand<object>(OnSelectedItem);
            _importTRComponent = new DelegateCommand(OnImportTrComponent);
            _exportTRComponenet = new DelegateCommand(OnExportTrCommand);
            RootNodeCommand = new DelegateCommand(OnRootNodeCommand);

            //Compound commands
            ComponentsCommand.AddTRNodeCommand.RegisterCommand(AddComponents);
            ComponentsCommand.ImportTRComponentCommand.RegisterCommand(_importTRComponent);
            ComponentsCommand.ExportTRComponenetCommand.RegisterCommand(_exportTRComponenet);

            //events
            _projectChangeEvent = _eventAggregator.GetEvent<ProjectChangeEvent>();

            //Models Initializations
            _projectModel = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);

            if (_projectModel != null && _projectModel?.TechnicalResources == null)
                _projectModel.TechnicalResources = new TRNode();

            TechnicalResources = _projectModel?.TechnicalResources;

            PlusMenu.MenuItems.Add(new TRSMenuItem(UIConstants.ADDMAINTENANCEZONE, UIConstants.CAP_MAINTENANCEZONE));
            OnRootNodeCommand();
            TRSideBarTreeViewModel_ContextMenu_init();
            _saveFileDialog = new SaveFileDialog();
        }

        /// <summary>
        /// Calling the export function for Excel export
        /// </summary>
        private void OnExportTrCommand()
        {
            try
            {
                string saveFilepath = string.Empty;
                if (!ShowSaveFileDialog(ref saveFilepath)) return;
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.VISIBLE });
                ExcelExport.TRExcelExport(_projectModel.TechnicalResources.Inventories, saveFilepath);
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });

                if (saveFilepath != null)
                {

                    if (MessageBox.Show("File generated successfully.\n Do want to open?", "File Generated",
                            MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        System.Diagnostics.Process.Start(saveFilepath);
                    }
                }
                else
                {
                    MessageBox.Show("Export Failed", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
                MessageBox.Show("Export failed", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
            }
        }

        /// <summary>
        /// save file dialog
        /// </summary>
        /// <param name="saveFilepath">The save filepath.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ShowSaveFileDialog(ref string saveFilepath)
        {
            _saveFileDialog.FileName = string.Empty;
            _saveFileDialog.Filter = "Excel Files| *.xls; *.xlsx; *.xlsm";
            if (_saveFileDialog.ShowDialog() == false) return false;
            saveFilepath = Path.ChangeExtension(_saveFileDialog.FileName, ".xlsx");
            return true;
        }

        /// <summary>
        /// Import file functionality for TR
        /// </summary>
        public void OnImportTrComponent()
        {
            _fileOpenDialogue.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            try
            {
                if (_fileOpenDialogue.ShowDialog() != true) return;
                var selectedFileName = _fileOpenDialogue.FileName.Trim();
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.VISIBLE });
                ExcelImport.TRBaseNodeImport(selectedFileName, TechnicalResources);

                _projectModel.TechnicalResources = TechnicalResources;

                var configNodes = new List<StockNode>();

                foreach (var maint in TechnicalResources.MaintenanceNodes)
                {
                    configNodes.AddRange(maint.StockNodes);
                }

                this._sharedContextService.Update<ProjectContextModel>(UIConstants.PROJECTCONTEXT, _projectModel);
                _projectChangeEvent.Publish(_projectModel);

                _lstInventory = ExcelImport.TrInventoryImport(selectedFileName, configNodes);
                OnRootNodeCommand();
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show("Import failed : Not able to import the file", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show($"Import failed : {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Import failed : Not able to import the file", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
            }
        }

        /// <summary>
        /// Gets or sets the technical resources.
        /// </summary>
        /// <value>The technical resources.</value>
        public TRNode TechnicalResources { get => _technicalResources; set => SetProperty(ref _technicalResources, value); }

        /// <summary>
        /// Gets the add components.
        /// </summary>
        /// <value>The add components.</value>
        public DelegateCommand<string> AddComponents => _addTRcomponents ?? (_addTRcomponents = new DelegateCommand<string>(OnAddComponents));

        /// <summary>
        /// Gets or sets the components command.
        /// </summary>
        /// <value>The components command.</value>
        public IGlobalTRCommands ComponentsCommand { get => _componentsCommand; set => SetProperty(ref _componentsCommand, value); }

        /// <summary>
        /// Ons the add components.
        /// </summary>
        /// <param name="addNodeType">The command.</param>
        private void OnAddComponents(string addNodeType)
        {
            try
            {
                Enum.TryParse(addNodeType.ToUpper(), out NodeType nodeType);
                switch (nodeType)
                {
                    case NodeType.MAINTENANCEZONE:
                        {
                            var tr = SelectedNode as TRNode ?? TechnicalResources;
                            tr.MaintenanceNodes.Add(new MaintenanceNode(GlobalFiled.GenerateRandomId(), UIConstants.MAINTENANCE_ZONE, tr));
                        }
                        break;

                    case NodeType.STOCK:
                        {
                            if (SelectedNode != null)
                            {
                                var mn = SelectedNode as MaintenanceNode;
                                mn?.StockNodes.Add(new StockNode(GlobalFiled.GenerateRandomId(), UIConstants.STOCK, mn));
                            }
                        }
                        break;
                }

                //Updating Project context
                _projectModel.TechnicalResources = TechnicalResources;
                this._sharedContextService.Update(UIConstants.PROJECTCONTEXT, _projectModel);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>The selected item.</value>
        public DelegateCommand<object> SelectedItem { get; set; }

        /// <summary>
        /// Ons the selected item.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void OnSelectedItem(object obj)
        {
            try
            {
                if (obj is RoutedPropertyChangedEventArgs<object> e)
                    SelectedNode = e.NewValue;

                if (SelectedNode == null) return;
                var node = SelectedNode as INode;
                _eventAggregator.GetEvent<TRTreeViewChangeEvent>().Publish(node);
                if (node != null) PlusMenu.SetMenu(node.NodeType);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// The plus menu
        /// </summary>
        private TRSMenuItem _plusMenu;

        /// <summary>
        /// Gets or sets the plus menu.
        /// </summary>
        /// <value>The plus menu.</value>
        public TRSMenuItem PlusMenu { get => _plusMenu; set => SetProperty(ref _plusMenu, value); }

        /// <summary>
        /// Gets or sets the root node command.
        /// </summary>
        /// <value>The root node command.</value>
        public DelegateCommand RootNodeCommand { get; set; }

        /// <summary>
        /// Ons the root node command.
        /// </summary>
        private void OnRootNodeCommand()
        {
            INode node = TechnicalResources;
            _eventAggregator.GetEvent<TRTreeViewChangeEvent>().Publish(node);
            PlusMenu.SetMenu(node.NodeType);
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            this.ComponentsCommand.AddTRNodeCommand.UnregisterCommand(AddComponents);
            this.ComponentsCommand.ImportTRComponentCommand.UnregisterCommand(_importTRComponent);
            this.ComponentsCommand.ExportTRComponenetCommand.UnregisterCommand(_exportTRComponenet);
        }
    }

    /// <summary>
    /// Dynamic menu item class
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class TRSMenuItem : BindableBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MenuItem" /> class.
        /// </summary>
        /// <param name="header">The header.</param>
        /// <param name="command">The command.</param>
        public TRSMenuItem(string header, string command)
        {
            this.Header = header;
            this.Command = command;
            MenuItems = new ObservableCollection<TRSMenuItem>();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuItem" /> class.
        /// </summary>
        public TRSMenuItem()
        {
            MenuItems = new ObservableCollection<TRSMenuItem>();
        }

        /// <summary>
        /// The header
        /// </summary>
        private string _header;

        /// <summary>
        /// The command
        /// </summary>
        private string _command;

        /// <summary>
        /// Gets or sets the header.
        /// </summary>
        /// <value>The header.</value>
        public string Header { get => _header; set => SetProperty(ref _header, value); }

        /// <summary>
        /// Gets or sets the command.
        /// </summary>
        /// <value>The command.</value>
        public string Command { get => _command; set => SetProperty(ref _command, value); }

        /// <summary>
        /// Gets or sets the menu items.
        /// </summary>
        /// <value>The menu items.</value>
        public ObservableCollection<TRSMenuItem> MenuItems { get; set; }

        /// <summary>
        /// Sets the menu.
        /// </summary>
        /// <param name="nodeType">Type of the node.</param>
        public void SetMenu(NodeType nodeType)
        {
            switch (nodeType)
            {
                case NodeType.TECHNICALRESOURCE:
                    {
                        this.MenuItems.Clear();
                        this.MenuItems.Add(new TRSMenuItem(UIConstants.ADDMAINTENANCEZONE, UIConstants.CAP_MAINTENANCEZONE));
                    }
                    break;

                case NodeType.MAINTENANCEZONE:
                    {
                        this.MenuItems.Clear();
                        this.MenuItems.Add(new TRSMenuItem(UIConstants.ADD_STOCK, UIConstants.STOCK));
                    }
                    break;

                default: { this.MenuItems.Clear(); } break;
            }
        }
    }
}