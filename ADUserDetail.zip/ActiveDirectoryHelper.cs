﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;

namespace Honeywell.ActiveDirectory
{
    public class ActiveDirectoryHelper : IActiveDirectoryHelper
    {
        private DirectoryEntry _directoryEntry = (DirectoryEntry)null;

        private DirectoryEntry SearchRoot
        {
            get
            {
                if (this._directoryEntry == null)
                    this._directoryEntry = new DirectoryEntry("GC://dc=ds,dc=honeywell,dc=com", (string)null, (string)null);
                return this._directoryEntry;
            }
        }

        private string LDAPPath
        {
            get
            {
                return ConfigurationManager.AppSettings[nameof(LDAPPath)];
            }
        }

        private string LDAPUser
        {
            get
            {
                return ConfigurationManager.AppSettings[nameof(LDAPUser)];
            }
        }

        private string LDAPPassword
        {
            get
            {
                return ConfigurationManager.AppSettings[nameof(LDAPPassword)];
            }
        }

        private string LDAPDomain
        {
            get
            {
                return ConfigurationManager.AppSettings[nameof(LDAPDomain)];
            }
        }

        internal ADUserDetail GetUserByFullName(string userName)
        {
            try
            {
                this._directoryEntry = (DirectoryEntry)null;
                SearchResult one = new DirectorySearcher(this.SearchRoot)
                {
                    SearchScope = SearchScope.Subtree,
                    Filter = ("(&(objectClass=user)(CN=DL -HTS_EGWD,OU=Distribution Lists,OU=Exchange,OU=US,DC=global,DC=ds,DC=honeywell,DC=com,cn=" + userName + "))")
                }.FindOne();
                if (one != null)
                    return ADUserDetail.GetUser(new DirectoryEntry(one.Path, this.LDAPUser, this.LDAPPassword));
                return (ADUserDetail)null;
            }
            catch (Exception ex)
            {
                return (ADUserDetail)null;
            }
        }

        public ADUserDetail GetUserByLoginName(string userName)
        {
            try
            {
                this._directoryEntry = (DirectoryEntry)null;
                SearchResult one = new DirectorySearcher(this.SearchRoot)
                {
                    SearchScope = SearchScope.Subtree,
                    Filter = ("(&(objectClass=user)(SAMAccountName=" + userName + "))")
                }.FindOne();
                if (one != null)
                    return ADUserDetail.GetUser(new DirectoryEntry(one.Path, this.LDAPUser, this.LDAPPassword));
                return (ADUserDetail)null;
            }
            catch (Exception ex)
            {
                return (ADUserDetail)null;
            }
        }

        public List<ADUserDetail> GetUserFromGroup(string groupName, string DomainName)
        {
            List<ADUserDetail> adUserDetailList = new List<ADUserDetail>();
            try
            {
                this._directoryEntry = (DirectoryEntry)null;
                DirectorySearcher directorySearcher = new DirectorySearcher(this.SearchRoot);
                directorySearcher.SearchScope = SearchScope.Subtree;
                directorySearcher.Filter = "(&(objectClass=group)(sAMAccountName=" + groupName + "))";
                SearchResultCollection all = directorySearcher.FindAll();
                Console.WriteLine("Members of the {0} Group in the {1} Domain", (object)groupName, (object)DomainName);
                foreach (SearchResult searchResult in all)
                {
                    foreach (string str in (ReadOnlyCollectionBase)searchResult.Properties["memberOf"])
                    {
                        if (str.Contains(groupName))
                            Console.WriteLine("    " + searchResult.Properties["name"][0].ToString());
                    }
                }
                SearchResult one = directorySearcher.FindOne();
                if (one != null)
                {
                    DirectoryEntry directoryEntry = new DirectoryEntry(one.Path, this.LDAPUser, this.LDAPPassword);
                    PropertyCollection properties = directoryEntry.Properties;
                    int count = properties["member"].Count;
                    foreach (string propertyName in (IEnumerable)directoryEntry.Properties.PropertyNames)
                        Console.WriteLine("{0}:{1}", (object)propertyName, directoryEntry.Properties[propertyName].Value);
                    for (int index = 0; index < count; ++index)
                    {
                        DirectoryEntry directoryUser = new DirectoryEntry(one.Path.Split("CN".ToCharArray())[0] + properties["member"][index].ToString(), this.LDAPUser, this.LDAPPassword);
                        ADUserDetail user = ADUserDetail.GetUser(directoryUser);
                        adUserDetailList.Add(user);
                        directoryUser.Close();
                    }
                }
                return adUserDetailList;
            }
            catch (Exception ex)
            {
                return adUserDetailList;
            }
        }

        public List<ADProfile> GetUsersByFirstName(string fName)
        {
            List<ADUserDetail> adUserDetailList = new List<ADUserDetail>();
            List<ADProfile> adProfileList = new List<ADProfile>();
            this._directoryEntry = (DirectoryEntry)null;
            DirectorySearcher directorySearcher = new DirectorySearcher(this.SearchRoot);
            directorySearcher.SearchScope = SearchScope.Subtree;
            directorySearcher.Asynchronous = false;
            directorySearcher.CacheResults = false;
            string str = "(&(objectClass=user)(objectCategory=person)(givenName=" + fName + "*)(!userAccountControl:1.2.840.113556.1.4.803:=2)(|(SAMAccountName=E*)(SAMAccountName=H*)))";
            directorySearcher.FindAll();
            directorySearcher.Filter = str;
            foreach (SearchResult searchResult in directorySearcher.FindAll())
            {
                ADUserDetail user = ADUserDetail.GetUser(new DirectoryEntry(searchResult.Path, this.LDAPUser, this.LDAPPassword));
                adProfileList.Add(new ADProfile()
                {
                    UserName = user.DisplayName.ToString(),
                    EID = user.LoginName
                });
            }
            return adProfileList;
        }

        public List<ADUserDetail> GetUsersByLoginName(string userName)
        {
            List<ADUserDetail> adUserDetailList = new List<ADUserDetail>();
            this._directoryEntry = (DirectoryEntry)null;
            DirectorySearcher directorySearcher = new DirectorySearcher(this.SearchRoot);
            directorySearcher.SearchScope = SearchScope.Subtree;
            directorySearcher.Asynchronous = true;
            directorySearcher.CacheResults = true;
            //  string str = "(&(objectClass=user)(SAMAccountName=" + userName + "*))";
            string str = "(&(objectClass=user)(mail=" + userName + "*))";
            directorySearcher.Filter = str;
            foreach (SearchResult searchResult in directorySearcher.FindAll())
            {
                ADUserDetail user = ADUserDetail.GetUser(new DirectoryEntry(searchResult.Path, this.LDAPUser, this.LDAPPassword));
                adUserDetailList.Add(user);
            }
            return adUserDetailList;
        }

        public List<ADUserDetail> GetUsersByFilte(string value, SearchType searchType)
        {
            List<ADUserDetail> adUserDetailList = new List<ADUserDetail>();
            this._directoryEntry = (DirectoryEntry)null;
            DirectorySearcher directorySearcher = new DirectorySearcher(this.SearchRoot);
            directorySearcher.SearchScope = SearchScope.Subtree;
            directorySearcher.Asynchronous = true;
            directorySearcher.CacheResults = true;
            //  string str = "(&(objectClass=user)(SAMAccountName=" + userName + "*))";
            string str = GetFilter(value, searchType); //"(&(objectClass=user)(mail=" + value + "*))";
            directorySearcher.Filter = str;
            foreach (SearchResult searchResult in directorySearcher.FindAll())
            {
                ADUserDetail user = ADUserDetail.GetUser(new DirectoryEntry(searchResult.Path, this.LDAPUser, this.LDAPPassword));
                adUserDetailList.Add(user);
            }
            return adUserDetailList;
        }


        private static string GetFilter(string value, SearchType searchType)
        {
            switch (searchType)
            {
                case SearchType.OBJECTCLASS:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.OBJECTCLASS, value);

                case SearchType.CONTAINERNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.CONTAINERNAME, value);

                case SearchType.LASTNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.LASTNAME, value);

                case SearchType.COUNTRYNOTATION:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.COUNTRYNOTATION, value);

                case SearchType.CITY:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.CITY, value);

                case SearchType.STATE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.STATE, value);

                case SearchType.TITLE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.TITLE, value);

                case SearchType.POSTALCODE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.POSTALCODE, value);

                case SearchType.PHYSICALDELIVERYOFFICENAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.PHYSICALDELIVERYOFFICENAME, value);

                case SearchType.FIRSTNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.FIRSTNAME, value);

                case SearchType.MIDDLENAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MIDDLENAME, value);

                case SearchType.DISTINGUISHEDNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.DISTINGUISHEDNAME, value);

                case SearchType.INSTANCETYPE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.INSTANCETYPE, value);

                case SearchType.WHENCREATED:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.WHENCREATED, value);

                case SearchType.WHENCHANGED:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.WHENCHANGED, value);

                case SearchType.DISPLAYNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.DISPLAYNAME, value);

                case SearchType.USNCREATED:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.USNCREATED, value);

                case SearchType.MEMBEROF:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MEMBEROF, value);

                case SearchType.USNCHANGED:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.USNCHANGED, value);

                case SearchType.COUNTRY:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.COUNTRY, value);

                case SearchType.DEPARTMENT:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.DEPARTMENT, value);

                case SearchType.COMPANY:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.COMPANY, value);

                case SearchType.PROXYADDRESSES:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.PROXYADDRESSES, value);

                case SearchType.STREETADDRESS:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.STREETADDRESS, value);

                case SearchType.DIRECTREPORTS:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.DIRECTREPORTS, value);

                case SearchType.NAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.NAME, value);

                case SearchType.OBJECTGUID:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.OBJECTGUID, value);

                case SearchType.USERACCOUNTCONTROL:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.USERACCOUNTCONTROL, value);

                case SearchType.BADPWDCOUNT:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.BADPWDCOUNT, value);

                case SearchType.CODEPAGE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.CODEPAGE, value);
                case SearchType.COUNTRYCODE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.COUNTRYCODE, value);
                case SearchType.BADPASSWORDTIME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.BADPASSWORDTIME, value);
                case SearchType.LASTLOGOFF:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.LASTLOGOFF, value);
                case SearchType.LASTLOGON:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.LASTLOGON, value);
                case SearchType.PWDLASTSET:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.PWDLASTSET, value);
                case SearchType.PRIMARYGROUPID:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.PRIMARYGROUPID, value);
                case SearchType.OBJECTSID:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.OBJECTSID, value);
                case SearchType.ADMINCOUNT:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.ADMINCOUNT, value);
                case SearchType.ACCOUNTEXPIRES:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.ACCOUNTEXPIRES, value);
                case SearchType.LOGONCOUNT:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.LOGONCOUNT, value);
                case SearchType.LOGINNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.LOGINNAME, value);
                case SearchType.SAMACCOUNTTYPE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.SAMACCOUNTTYPE, value);
                case SearchType.SHOWINADDRESSBOOK:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.SHOWINADDRESSBOOK, value);
                case SearchType.LEGACYEXCHANGEDN:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.LEGACYEXCHANGEDN, value);
                case SearchType.USERPRINCIPALNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.USERPRINCIPALNAME, value);
                case SearchType.EXTENSION:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.EXTENSION, value);
                case SearchType.SERVICEPRINCIPALNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.SERVICEPRINCIPALNAME, value);
                case SearchType.OBJECTCATEGORY:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.OBJECTCATEGORY, value);
                case SearchType.DSCOREPROPAGATIONDATA:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.DSCOREPROPAGATIONDATA, value);
                case SearchType.LASTLOGONTIMESTAMP:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.LASTLOGONTIMESTAMP, value);
                case SearchType.EMAILADDRESS:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.EMAILADDRESS, value);
                case SearchType.MANAGER:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MANAGER, value);
                case SearchType.MOBILE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MOBILE, value);
                case SearchType.PAGER:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.PAGER, value);
                case SearchType.FAX:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.FAX, value);
                case SearchType.HOMEPHONE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.HOMEPHONE, value);
                case SearchType.MSEXCHUSERACCOUNTCONTROL:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHUSERACCOUNTCONTROL, value);
                case SearchType.MDBUSEDEFAULTS:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MDBUSEDEFAULTS, value);
                case SearchType.MSEXCHMAILBOXSECURITYDESCRIPTOR:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHMAILBOXSECURITYDESCRIPTOR, value);
                case SearchType.HOMEMDB:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.HOMEMDB, value);
                case SearchType.MSEXCHPOLICIESINCLUDED:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHPOLICIESINCLUDED, value);
                case SearchType.HOMEMTA:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.HOMEMTA, value);
                case SearchType.MSEXCHRECIPIENTTYPEDETAILS:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHRECIPIENTTYPEDETAILS, value);
                case SearchType.MAILNICKNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MAILNICKNAME, value);
                case SearchType.MSEXCHHOMESERVERNAME:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHHOMESERVERNAME, value);
                case SearchType.MSEXCHVERSION:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHVERSION, value);
                case SearchType.MSEXCHRECIPIENTDISPLAYTYPE:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHRECIPIENTDISPLAYTYPE, value);
                case SearchType.MSEXCHMAILBOXGUID:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.MSEXCHMAILBOXGUID, value);
                case SearchType.NTSECURITYDESCRIPTOR:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.NTSECURITYDESCRIPTOR, value);
                default:
                    return string.Format("(&(objectClass=user)({0}={1}*))", ADProperties.DISPLAYNAME, value);
            }

        }



    }

    public enum SearchType
    {
        OBJECTCLASS,
        CONTAINERNAME,
        LASTNAME,
        COUNTRYNOTATION,
        CITY,
        STATE,
        TITLE,
        POSTALCODE,
        PHYSICALDELIVERYOFFICENAME,
        FIRSTNAME,
        MIDDLENAME,
        DISTINGUISHEDNAME,
        INSTANCETYPE,
        WHENCREATED,
        WHENCHANGED,
        DISPLAYNAME,
        USNCREATED,
        MEMBEROF,
        USNCHANGED,
        COUNTRY,
        DEPARTMENT,
        COMPANY,
        PROXYADDRESSES,
        STREETADDRESS,
        DIRECTREPORTS,
        NAME,
        OBJECTGUID,
        USERACCOUNTCONTROL,
        BADPWDCOUNT,
        CODEPAGE,
        COUNTRYCODE,
        BADPASSWORDTIME,
        LASTLOGOFF,
        LASTLOGON,
        PWDLASTSET,
        PRIMARYGROUPID,
        OBJECTSID,
        ADMINCOUNT,
        ACCOUNTEXPIRES,
        LOGONCOUNT,
        LOGINNAME,
        SAMACCOUNTTYPE,
        SHOWINADDRESSBOOK,
        LEGACYEXCHANGEDN,
        USERPRINCIPALNAME,
        EXTENSION,
        SERVICEPRINCIPALNAME,
        OBJECTCATEGORY,
        DSCOREPROPAGATIONDATA,
        LASTLOGONTIMESTAMP,
        EMAILADDRESS,
        MANAGER,
        MOBILE,
        PAGER,
        FAX,
        HOMEPHONE,
        MSEXCHUSERACCOUNTCONTROL,
        MDBUSEDEFAULTS,
        MSEXCHMAILBOXSECURITYDESCRIPTOR,
        HOMEMDB,
        MSEXCHPOLICIESINCLUDED,
        HOMEMTA,
        MSEXCHRECIPIENTTYPEDETAILS,
        MAILNICKNAME,
        MSEXCHHOMESERVERNAME,
        MSEXCHVERSION,
        MSEXCHRECIPIENTDISPLAYTYPE,
        MSEXCHMAILBOXGUID,
        NTSECURITYDESCRIPTOR,
    }
}
