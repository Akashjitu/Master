﻿using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace M2C.Business.Mappers
{
    [TestClass]
    public class RangeModelMapperTest
    {
        private RangeModelMapper rangeModelMapper;

        [TestInitialize]
        public void Setup()
        {
            rangeModelMapper = new RangeModelMapper();
        }

        [TestMethod]
        public void ShouldReturnRangeModels()
        {
            var rangeModels = rangeModelMapper.Map(MockProvider.GetRanges());
            Assert.IsNotNull(rangeModels);
            Assert.IsTrue(rangeModels.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnRangeModel()
        {
            var rangeModel = rangeModelMapper.Map(MockProvider.GetRanges()[0]);
            Assert.IsNotNull(rangeModel);
        }
    }
}