﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SyncHistoryMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using System;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Class SyncHistoryMapper.
    /// Implements the <see cref="M2C.Business.Mappers.ISyncHistoryMapper" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.ISyncHistoryMapper" />
    public class SyncHistoryMapper : ISyncHistoryMapper
    {
        /// <summary>
        /// Maps the specified attempt.
        /// </summary>
        /// <param name="attempt">The attempt.</param>
        /// <param name="status">The status.</param>
        /// <param name="version">The version.</param>
        /// <returns>SyncHistory.</returns>
        public SyncHistory Map(int attempt, int status, int version)
        {
            return new SyncHistory()
            {
                SyncId = Guid.NewGuid().ToString(),
                RetryCount = attempt,
                Status = status,
                Version = version,
                SyncDate = DateTime.Now,
                //ID=2
            };
        }
    }
}