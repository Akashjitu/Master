//using Oracle.Data.Access;

//namespace Pse.Data.Models
//{
//    public class Heatmap
//    {
//        [Columns("Waterline")]
//        public string Waterline { get; set; }

//        [Columns("AME_Indicator")]
//        public string AME_Indicator { get; set; }

//        [Columns("Authorized_to_Spend")]
//        public string Authorized_to_Spend { get; set; }

//        [Columns("TotalMeasures")]
//        public string TotalMeasures { get; set; }

//        [Columns("Calculation2")]
//        public string Calculation2 { get; set; }

//        [Columns("Calculation1")]
//        public string Calculation1 { get; set; }

//        [Columns("KPI")]
//        public string KPI { get; set; }

//        [Columns("Metric_Health_Identity")]
//        public string Metric_Health_Identity { get; set; }

//        [Columns("Green_Label")]
//        public string Green_Label { get; set; }

//        [Columns("blank")]
//        public string blank { get; set; }

//        [Columns("DATE_LAST_REFRESH")]
//        public string DATE_LAST_REFRESH { get; set; }

//        [Columns("Finance_Category")]
//        public string Finance_Category { get; set; }

//        [Columns("GBE")]
//        public string GBE { get; set; }

//        [Columns("Yellow_Label")]
//        public string Yellow_Label { get; set; }

//        [Columns("Hardware_Development_Scope")]
//        public string Hardware_Development_Scope { get; set; }

//        [Columns("IPDS_Phase")]
//        public string IPDS_Phase { get; set; }

//        [Columns("Key_Code")]
//        public string Key_Code { get; set; }

//        [Columns("Key_Code_copy_")]
//        public string Key_Code_copy { get; set; }

//        [Columns("Metric_Group")]
//        public string Metric_Group { get; set; }

//        [Columns("METRIC_HEALTH")]
//        public string METRIC_HEALTH { get; set; }

//        [Columns("Metric_Name")]
//        public string Metric_Name { get; set; }

//        [Columns("METRIC_VALUE")]
//        public string METRIC_VALUE { get; set; }

//        [Columns("Metric_Health_Identity_copy")]
//        public string Metric_Health_Identity_copy { get; set; }

//        [Columns("Number_of_Records")]
//        public string Number_of_Records { get; set; }

//        [Columns("PAC")]
//        public string PAC { get; set; }

//        [Columns("PM_Focal")]
//        public string PM_Focal { get; set; }

//        [Columns("PP_C_FOCAL")]
//        public string PP_C_FOCAL { get; set; }

//        [Columns("Product_Line")]
//        public string Product_Line { get; set; }

//        [Columns("Product_SBU")]
//        public string Product_SBU { get; set; }

//        [Columns("Product_Type")]
//        public string Product_Type { get; set; }

//        [Columns("Program_Name")]
//        public string Program_Name { get; set; }

//        [Columns("REFRESH_STATUS")]
//        public string REFRESH_STATUS { get; set; }

//        [Columns("REPORT_DATE")]
//        public string REPORT_DATE { get; set; }

//        [Columns("Red_Label")]
//        public string Red_Label { get; set; }
//    }
//}