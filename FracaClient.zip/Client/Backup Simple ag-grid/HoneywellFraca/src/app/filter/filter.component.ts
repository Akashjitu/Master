import { Component, OnInit, TemplateRef, Input } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import * as FracaAction from './../store/fracaAction';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/fracaReducer';
import { FracaInfo } from '../Models/fraca-info';
import { formatDate } from '@angular/common';
import { ShareDataService } from '../service/share-data.service';
import { FracaService } from '../service/fraca-service.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
  fracaNumber ='';
  partNumber  ='';
  message;

  ngOnInit(): void {
    this.shareDataService.currentMessage.subscribe( message=> this.message = message);
  }
  
  modalRef: BsModalRef;
  constructor(private modalService: BsModalService, private shareDataService: ShareDataService,  private service: FracaService) {
}

config = {
  animated: true,
  keyboard: true,
  backdrop: true,
  ignoreBackdropClick: false,
};

search(e){
  // public DateTime FromDate { get; set; }
  // public DateTime ToDate { get; set; }
  // public string FracaNo { get; set; }
  // public string PartNo { get; set; }
  this.service.SearchByFilter({ 
  'FracaNo': this.fracaNumber ,
 'PartNo': this.partNumber,
 'FromDate': new Date(),
 'ToDate':new Date()})
}

  openModal(template: TemplateRef<any>) {
    this.shareDataService.changeMessage( {
      FracaNo : ' ',
      PartNo : ' ',
      OpenDate : new Date(),
      CloseDate :new Date(),
      FailedDate :new Date(),
      Product : ' ',
      Program : ' ',
      Customer : ' ',
      TestEnv : ' ',
      Originator : ' ',
      RespEng : ' ',
      System : ' ',
      Electrical : ' ',
      Emi : ' ',
      ClosedBy : ' ',
      TestDoc : ' ',
      Paragraph : ' ',
      TestType : ' ',
      FailureCode : ' ',
      EndUnit : ' ',
      Level1 : ' ',
      Level2 : ' ',
      Nomenclature : ' ',
      SerialNumber : ' ',
      Designator : ' ',
      InflightShutdown : ' ',
      InflightPowerLoss : ' ',
      Chargeability : ' ',
      SafetyAffected : ' ',
      FailureToStart : ' ',
      ProblemDescription : ' ',
      Finding : ' ',
      Analysis : ' '
    } );
    this.modalRef = this.modalService.show(template, {class: "my-modal"});
   
  }
}
