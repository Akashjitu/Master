﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="IProductSyncService.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace RestClientServices.Contracts
{
    /// <summary>
    /// Product Sync service Interface
    /// </summary>
    public interface IProductSyncService : IRestClientService
    {
        /// <summary>
        /// Gets the product update by date.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="LastSyncDate">The last synchronize date.</param>
        /// <returns>T.</returns>
        T getProductUpdateByDate<T>(string LastSyncDate);
    }
}