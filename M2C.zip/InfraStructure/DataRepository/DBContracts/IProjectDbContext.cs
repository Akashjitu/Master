﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProjectDbContext.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels;
using DomainModels.Common;
using DomainModels.ErrorLogs;
using DomainModels.ProjectModels;
using Microsoft.EntityFrameworkCore;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IProjectDbContext
    /// Implements the <see cref="DataRepository.DBContracts.IDbContext" />
    /// </summary>
    /// <seealso cref="DataRepository.DBContracts.IDbContext" />
    public interface IProjectDbContext : IDbContext
    {
        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>The comments.</value>
        DbSet<Comment> Comments { get; set; }

        /// <summary>
        /// Gets or sets the contacts.
        /// </summary>
        /// <value>The contacts.</value>
        DbSet<Contact> Contacts { get; set; }

        /// <summary>
        /// Gets or sets the contact types.
        /// </summary>
        /// <value>The contact types.</value>
        DbSet<ContactType> ContactTypes { get; set; }

        /// <summary>
        /// Gets or sets the customers.
        /// </summary>
        /// <value>The customers.</value>
        DbSet<Customer> Customers { get; set; }

        /// <summary>
        /// Gets or sets the ib componenet types.
        /// </summary>
        /// <value>The ib componenet types.</value>
        DbSet<IBComponenetType> IBComponenetTypes { get; set; }

        /// <summary>
        /// Gets or sets the ib project components.
        /// </summary>
        /// <value>The ib project components.</value>
        DbSet<IBProjectComponent> IBProjectComponents { get; set; }

        /// <summary>
        /// Gets or sets the metadatas.
        /// </summary>
        /// <value>The metadatas.</value>
        DbSet<Metadata> Metadatas { get; set; }

        /// <summary>
        /// Gets or sets the projects.
        /// </summary>
        /// <value>The projects.</value>
        DbSet<Project> Projects { get; set; }

        /// <summary>
        /// Gets or sets the xref products.
        /// </summary>
        /// <value>The xref products.</value>
        DbSet<XrefProduct> xrefProducts { get; set; }

        /// <summary>
        /// Gets or sets the Operation Modes.
        /// </summary>
        /// <value>The OperationModes.</value>
        DbSet<OperationMode> OperationModes { get; set; }

        /// <summary>
        /// Collection of Project Inventories
        /// </summary>
        /// <value>The project inventories.</value>
        DbSet<ProjectInventory> ProjectInventories { get; set; }

        /// <summary>
        /// Gets or sets the Criticality
        /// </summary>
        /// <value>The criticalities.</value>
        DbSet<Criticality> Criticalities { get; set; }

        /// <summary>
        /// Collection of node Comments
        /// </summary>
        /// <value>The inventory comments.</value>
        DbSet<InventoryComments> InventoryComments { get; set; }

        /// <summary>
        /// Gets or sets the countries.
        /// </summary>
        /// <value>The countries.</value>
        DbSet<Country> Countries { get; set; }

        /// <summary>
        /// Gets or sets the positions.
        /// </summary>
        /// <value>The positions.</value>
        DbSet<Position> Positions { get; set; }

        /// <summary>
        /// Gets or sets the profiles.
        /// </summary>
        /// <value>The profiles.</value>
        DbSet<Profile> Profiles { get; set; }

        /// <summary>
        /// Gets or sets the exception logs.
        /// </summary>
        /// <value>The exception logs.</value>
        DbSet<ExceptionLog> ExceptionLogs { get; set; }
    }
}