﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ModelBuilderExtensions.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Microsoft.EntityFrameworkCore;

namespace DataRepository.Seeds
{
    /// <summary>
    /// Class ModelBuilderExtensions.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class ModelBuilderExtensions
    {
        /// <summary>
        /// Seeds the specified model builder.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public static void Seed(this ModelBuilder modelBuilder)
        {
            new ContactTypeSeed().Seed(modelBuilder);
            new IBComponenetTypeSeed().Seed(modelBuilder);
            new CountrySeed().Seed(modelBuilder);
            new PositionSeed().Seed(modelBuilder);            
        }
    }
}