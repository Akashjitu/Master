﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="INode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project.IBComponents;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace M2C.Business.Models.Project
{
    /// <summary>
    /// Provide node object
    /// </summary>
    public interface INode
    {
        /// <summary>
        /// Get or Set Node ID
        /// </summary>
        /// <value>The identifier.</value>
        int? Id { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        string Name { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        string NullableName { get; set; }

        /// <summary>
        /// Gets or sets the type of the node.
        /// </summary>
        /// <value>The type of the node.</value>
        NodeType NodeType { get; set; }

        /// <summary>
        /// Gets or sets the parent node.
        /// </summary>
        /// <value>The parent node.</value>
        INode ParentNode { get; set; }

        /// <summary>
        /// Gets or sets the criticality.
        /// </summary>
        /// <value>The criticality.</value>
        string Criticality { get; set; }

        /// <summary>
        /// Provide Node Level Comments
        /// </summary>
        /// <value>The comment.</value>
        string Comment { get; set; }

        /// <summary>
        /// Get or set All Inventories
        /// </summary>
        /// <value>The master inventories.</value>
        ObservableCollection<Inventory> MasterInventories { get; set; }

        /// <summary>
        /// Get  node level Inventories
        /// </summary>
        /// <value>The inventories.</value>
        ObservableCollection<Inventory> Inventories { get; }

        /// <summary>
        /// Get Parent node Names And NodeTypes
        /// </summary>
        /// <returns>Dictionary&lt;NodeType, System.String&gt;.</returns>
        Dictionary<NodeType, string> GetNodeParentNameAndNodeType();

        /// <summary>
        /// Get Parent node Names And NodeTypes
        /// </summary>
        /// <value>The type of the node parent name and node.</value>
        Dictionary<NodeType, string> NodeParentNameAndNodeType { get; }

        /// <summary>
        /// Get Parent node Names And NodeTypes
        /// </summary>
        /// <value>The type of the parent node and node.</value>
        Dictionary<NodeType, INode> ParentNodeAndNodeType { get; }

        /// <summary>
        /// Customer Documents
        /// </summary>
        /// <value>The customer documents.</value>
        ObservableCollection<CustomerDocument> CustomerDocuments { get; set; }

        /// <summary>
        /// Get Copy of Current node Inventories
        /// </summary>
        /// <returns>List&lt;Inventory&gt;.</returns>
        List<Inventory> GetCopyOfNodeInventories();

        /// <summary>
        /// Get Copy of Current node Inventories
        /// </summary>
        /// <value>The copy of node inventories.</value>
        List<Inventory> CopyOfNodeInventories { get; set; }

    }
}