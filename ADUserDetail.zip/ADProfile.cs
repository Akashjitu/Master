﻿
namespace Honeywell.ActiveDirectory
{
    public class ADProfile
    {
        public string UserName { get; set; }

        public string EID { get; set; }
    }
}
