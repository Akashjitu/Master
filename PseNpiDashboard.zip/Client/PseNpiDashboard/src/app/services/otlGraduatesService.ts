


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Store } from '@ngrx/store';

import { saveAs } from 'file-saver';

import { NgxSpinnerService } from 'ngx-spinner';
import {environment } from '../../environments/environment'
import { IAppState } from '../store/otlGraduates/otlGraduatesReducer';
import * as OtlGraduatesAction from './../store/otlGraduates/otlGraduatesAction';
//import { IAppState } from '../store/otlScoreCard/otlScoreCardReducer';
@Injectable({
  providedIn: 'root'
})
export class OtlGraduatesService {

  headers: any;
  url = environment.apiBaseUrl;
  fileBaseUrl = environment.fileBaseUrl;

  constructor(private http: HttpClient, private store: Store<IAppState>, private spinner: NgxSpinnerService) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
     'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
     withCredentials: 'true',
  });
   }


   reportDownload(date) {
    console.log(date);
   
    this.http.get(this.fileBaseUrl+'OtlGraduates?date=' + date , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'OtlGraduates' + date + '.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }

  getAllOtlGraduates() {
    this.spinner.show();
    this.http.get<any>(this.url+'OtlGraduates')
    .subscribe(res => {
      this.spinner.hide()
      this.store.dispatch(new OtlGraduatesAction.LoadOtlGraduates(res)
      )}, err => {
            this.spinner.hide();
          });
  }


  
  loadPliByFilter(criteria) {
    this.spinner.show();
    console.log('Load By  criteria ' + criteria)
    return this.http.post(this.url + 'OtlGraduates/loadbycriteria', criteria, { headers: this.headers })
    .subscribe(res => {
      this.spinner.hide()
      this.store.dispatch(new OtlGraduatesAction.LoadOtlGraduates(res)
      )}, err => {
            this.spinner.hide();
          });
  }


  reportDownloadByFilter(data) {
    this.http.post(this.fileBaseUrl+'OtlGraduatesfilterreport', data , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'OtlGraduates.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }
  
  reportDownloadAll() {
    this.http.get(this.fileBaseUrl+'OtlGraduatesreport' , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'PliSummary.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }

}
