﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="WorkShopNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using DomainModels.ProjectModels;
using M2C.Business.Contracts;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Data;
using M2C.Business.GlobalFields;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Class WorkShopNode.
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class WorkShopNode : Node, IChildNode, ICloneable, IDelete
    {
        /// <summary>
        /// The line nodes
        /// </summary>
        private ObservableCollection<LineNode> _lineNodes;

        /// <summary>
        /// The machine nodes
        /// </summary>
        private ObservableCollection<MachineNode> _machineNodes;

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkShopNode" /> class.
        /// </summary>
        public WorkShopNode()
        {
            this.NodeType = NodeType.WORKSHOP;
            _lineNodes = new ObservableCollection<LineNode>();
            _machineNodes = new ObservableCollection<MachineNode>();
            LineNodes.CollectionChanged += LineNodes_CollectionChanged;
            MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;
        }

        /// <summary>
        /// Handles the CollectionChanged event of the MachineNodes control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void MachineNodes_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Handles the CollectionChanged event of the LineNodes control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void LineNodes_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkShopNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public WorkShopNode(string name)
        {
            NodeType = NodeType.WORKSHOP;
            Name = name;
            _lineNodes = new ObservableCollection<LineNode>();
            _machineNodes = new ObservableCollection<MachineNode>();
            LineNodes.CollectionChanged += LineNodes_CollectionChanged;
            MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="WorkShopNode" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="parentNode">The parent node.</param>
        public WorkShopNode(int id, string name, INode parentNode)
        {
            Id = id;
            Name = name;
            ParentNode = parentNode;
            this.NodeType = NodeType.WORKSHOP;
            this.Name = name;
            _lineNodes = new ObservableCollection<LineNode>();
            _machineNodes = new ObservableCollection<MachineNode>();
            LineNodes.CollectionChanged += LineNodes_CollectionChanged;
            MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;
        }

        /// <summary>
        /// Adds the child.
        /// </summary>
        /// <param name="components">The components.</param>
        internal void AddChild(List<IBProjectComponent> components)
        {
            var lineMachineComponents = components.Where(x => (x.IBComponenetType.ComponentTypeID == 4 || x.IBComponenetType.ComponentTypeID == 5) && x.ParentID == this.Id).ToList();

            foreach (var c in lineMachineComponents)
            {
                if (c.IBComponenetType.ComponentTypeID == 4)
                {
                    var lineNode = new LineNode(c.NodeID, c.ComponentName, this);
                    lineNode.AddChild(components);
                    LineNodes.Add(lineNode);
                }
                else
                {
                    var machineNode = new MachineNode(c.NodeID, c.ComponentName, this);
                    machineNode.AddChild(components);
                    MachineNodes.Add(machineNode);
                }
            }
        }

        /// <summary>
        /// Creates a new object that is a copy of the current instance.
        /// </summary>
        /// <returns>A new object that is a copy of this instance.</returns>
        public object Clone()
        {
            WorkShopNode cloneNode = this.MemberwiseClone() as WorkShopNode;
            if (cloneNode != null)
            {
                cloneNode.ParentNode = null;
                cloneNode.Id = null;

                cloneNode.MachineNodes = new ObservableCollection<MachineNode>();
                cloneNode.LineNodes = new ObservableCollection<LineNode>();
                cloneNode.LineNodes.CollectionChanged += LineNodes_CollectionChanged;
                cloneNode.MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;

                foreach (ICloneable c in this.MachineNodes)
                {
                    var machine = c.Clone() as MachineNode;
                    machine.Id = GlobalFiled.GenerateRandomId();
                    cloneNode.MachineNodes.Add(machine);
                    if (machine != null) machine.ParentNode = cloneNode;
                }

                foreach (ICloneable c in this.LineNodes)
                {
                    var line = c.Clone() as LineNode;
                    line.Id = GlobalFiled.GenerateRandomId();
                    cloneNode.LineNodes.Add(line);
                    if (line != null) line.ParentNode = cloneNode;
                }

                return cloneNode;
            }
            return cloneNode;
        }

        /// <summary>
        /// Deletes this instance.
        /// </summary>
        public void Delete()
        {
            (this.ParentNode as FactoryNode)?.WorkShopNodes.Remove(this);
        }

        /// <summary>
        /// Gets or sets the line nodes.
        /// </summary>
        /// <value>The line nodes.</value>
        public ObservableCollection<LineNode> LineNodes { get => _lineNodes; set => SetProperty(ref _lineNodes, value); }

        /// <summary>
        /// Gets or sets the machine nodes.
        /// </summary>
        /// <value>The machine nodes.</value>
        public ObservableCollection<MachineNode> MachineNodes { get => _machineNodes; set => SetProperty(ref _machineNodes, value); }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        public CompositeCollection ChildNodes
        {
            get
            {
                return new CompositeCollection()
                    {
                        new CollectionContainer() { Collection = LineNodes },
                        new CollectionContainer() { Collection = MachineNodes }
                    };
            }
        }
    }

    /// <summary>
    /// extension class for workshop for adding nodes for lines and machines
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class WorkshopExt
    {
        /// <summary>
        /// importing function for lines
        /// </summary>
        /// <param name="workshop">The workshop.</param>
        /// <param name="ibComponenets">The ib componenets.</param>
        public static void ImportLine(this WorkShopNode workshop, List<IBImportModel> ibComponenets)
        {
            var row = ibComponenets.Where(x => x.Workshop == workshop.Name && x.Line != null);
            var lines = row.Select(x => x.Line).Distinct();
            foreach (var line in lines)
            {
                if (!line.Equals("N/A"))
                {
                    var lineObj = new LineNode(GlobalFiled.GenerateRandomId(), line, workshop);
                    //lineObj.ParentNode = workshop;
                    var ibComponents = ibComponenets.Where(i =>
                        string.Compare(i.Line, line, StringComparison.OrdinalIgnoreCase) == 0).ToList();
                    //Import should be done to attached node only, Node ID is mandatory for filtering
                    workshop.LineNodes.Add(lineObj);

                    lineObj.ImportMachine(ibComponents);
                }
            }
        }

        /// <summary>
        /// importing function for machines
        /// </summary>
        /// <param name="workshop">The workshop.</param>
        /// <param name="IBComponenets">The ib componenets.</param>
        public static void ImportMachine(this WorkShopNode workshop, List<IBImportModel> IBComponenets)
        {
            var machineRow = IBComponenets.Where(x => x.Workshop == workshop.Name && (x.Line == null || x.Line == "N/A"));

            var machineInfo = machineRow.
           Select(i => new
           {
               Machine = i.Machine,
               Criticality = i.MachineCriticity,
           }).Distinct().ToList();

            foreach (var machines in machineInfo)
            {
                var machineNod = new MachineNode(GlobalFiled.GenerateRandomId(), machines.Machine, workshop);
                var machinesCriticality = machines.Criticality;
                if (!String.IsNullOrEmpty(machinesCriticality) && machinesCriticality.Any(char.IsDigit))
                {
                    machinesCriticality = machines.Criticality.Remove(0, 3);
                }
                if (!String.IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Not defined")
                {
                    machinesCriticality = CriticalitystringValues.NotCritical;
                }
                //Update Criticality values if file will open from old tool. 
                if (!String.IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Not critical")
                {
                    machinesCriticality = CriticalitystringValues.NotCritical;
                }
                if (!String.IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Somewhat critical")
                {
                    machinesCriticality = CriticalitystringValues.SomewhatCritical;
                }
                if (!String.IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Very critical")
                {
                    machinesCriticality = CriticalitystringValues.VeryCritical;
                }
                if (String.IsNullOrEmpty(machinesCriticality))
                {
                    machinesCriticality = CriticalitystringValues.NotCritical;
                }
                //var criticality = new CriticalityModel() { SelectedValue = machines.Criticality };
                var criticality = new CriticalityModel()
                {
                    SafetyIssue = CriticalitystringValues.LOW_RISK,
                    QualityIssue = CriticalitystringValues.LOW_IMPACT,
                    LeadTimeIssue = CriticalitystringValues.LOW_IMPACT,
                    CostsIssue = CriticalitystringValues.LOW_IMPACT,
                    SelectedValue = machinesCriticality
                };

                machineNod.ParentNode = workshop;
                machineNod.CriticalityParams = criticality;
                machineNod.CriticalityParameters = criticality;
                machineNod.Inventories.SelectMany(x => x.Criticality = criticality.SelectedValue);
                var ibComponents = machineRow.Where(i =>
                    string.Compare(i.Machine, machines.Machine, StringComparison.OrdinalIgnoreCase) == 0).ToList();
                //Import should be done to attached node only, Node ID is mandatory for filtering
                workshop.MachineNodes.Add(machineNod);
                //Update Criticality values of all Machine Node if file will open from old tool. 
                foreach (var ibComponent in ibComponents)
                {
                    ibComponent.MachineCriticity = FindCriticalString(ibComponent.MachineCriticity);
                }
                machineNod.ImportConfig(ibComponents);
            }
        }
        /// <summary>
        /// Finds the critical string.
        /// </summary>
        /// <param name="criticalData">The critical data.</param>
        /// <returns>System.String.</returns>
        private static string FindCriticalString(string criticalData)
        {
            if (string.IsNullOrEmpty(criticalData))
                return CriticalitystringValues.NotCritical;

            switch (criticalData.Trim().ToUpper())
            {
                case "0. NOT DEFINED":
                    return CriticalitystringValues.NotCritical;
                case "1. NOT CRITICAL":
                case "NOT CRITICAL":
                    return CriticalitystringValues.NotCritical;
                case "2. SOMEWHAT CRITICAL":
                case "SOMEWHAT CRITICAL":
                    return CriticalitystringValues.SomewhatCritical;
                case "3. CRITICAL":
                case "CRITICAL":
                    return CriticalitystringValues.Critical;
                case "4. VERY CRITICAL":
                case "VERY CRITICAL":
                    return CriticalitystringValues.VeryCritical;
                default: return CriticalitystringValues.NotCritical;
            }
        }
        /// <summary>
        /// Gets all nodes.
        /// </summary>
        /// <param name="workshop">The workshop.</param>
        /// <returns>List&lt;Node&gt;.</returns>
        public static List<Node> getAllNodes(this WorkShopNode workshop)
        {
            List<Node> nodes = new List<Node>();

            foreach (var n in workshop.LineNodes)
            {
                nodes.Add(n);
                nodes.AddRange(n.GetAllNodes());
            }

            foreach (var n in workshop.MachineNodes)
            {
                nodes.Add(n);
                nodes.AddRange(n.GetAllNodes());
            }

            return nodes;
        }
    }
}