﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IPliDataAccess
    {
        List<Pli> LoadPli();

        List<Pli> LoadByDate(Pli pli);

        List<Pli> LoadById(Pli pli);

        List<Pli> LoadByKeyCode(Pli pli);
    }
}