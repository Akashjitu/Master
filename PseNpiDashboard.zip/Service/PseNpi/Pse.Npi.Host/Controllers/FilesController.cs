﻿using Pse.Data.Models;
using Pse.Services.Service;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class FilesController : ApiController
    {
        private ISpeService _service;

        public FilesController(ISpeService service)
        {
            _service = service;
        }

        [HttpGet]
        [Route("tti")]
        public HttpResponseMessage GetTtiReport(string date)
        {
            DateTime dt;
            if (!DateTime.TryParse(date, out dt))
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);

            var ttiData = _service.ExportTti(new Data.Models.TtiPartAlignment() { InfoCreatedDate = dt });
            var dataStream = new MemoryStream(ttiData);

            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");

            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "Tti" + date + ".xlsx";
            return response;
        }


        [HttpGet]
        [Route("effectivene")]
        public HttpResponseMessage GetEffectiveneReport(string date)
        {
            DateTime dt;
            if (!DateTime.TryParse(date, out dt))
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);

            var ttiData = _service.ExportEffectivene(new Data.Models.Effectiveness() { CreatedDate = dt });
            var dataStream = new MemoryStream(ttiData);

            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");

            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "Effectiveness" + date + ".xlsx";
            return response;
        }


        [HttpGet]
        [Route("effectivenesanalysis")]
        public HttpResponseMessage GetEffectivenesAnalysisReport(string date)
        {
            DateTime dt;
            if (!DateTime.TryParse(date, out dt))
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);

            var ttiData = _service.ExportEffectivenesAnalysis(new Data.Models.EffectivenessAnalysis() { CREATED = dt });
            var dataStream = new MemoryStream(ttiData);

            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");

            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "EffectivenessAnalysis" + date + ".xlsx";
            return response;
        }


        [HttpGet]
        [Route("compliance")]
        public HttpResponseMessage GetComplianceReport(string date)
        {
            DateTime dt;
            if (!DateTime.TryParse(date, out dt))
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);

            var ttiData = _service.ExportCompliance(new Data.Models.Compliance() { CreateDon = dt });
            var dataStream = new MemoryStream(ttiData);

            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");

            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "Compliance" + date + ".xlsx";
            return response;
        }


        [HttpGet]
        [Route("otldisposition")]
        public HttpResponseMessage GetOtlDispositionReport(string date)
        {
            DateTime dt;
            if (!DateTime.TryParse(date, out dt))
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);

            var ttiData = _service.ExportOtlDisposition(new Data.Models.OtlDispositionDetails() { CreatedDate = dt });
            var dataStream = new MemoryStream(ttiData);

            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");

            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "OtlDisposition" + date + ".xlsx";
            return response;
        }

        [HttpGet]
        [Route("plisummaryreport")]
        public HttpResponseMessage GetPliSummaryReport()
        {
          
            var ttiData = _service.ExportAllPli();
            var dataStream = new MemoryStream(ttiData);

            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");

            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "F_Pli_" + DateTime.Today + ".xlsx";
            return response;
        }

        [HttpPost]
        [Route("plifilterreport")]
        public HttpResponseMessage GetPliSummaryReport(Pli filter)
        {

            var pli = _service.ExportPliByFilter(filter);
            var dataStream = new MemoryStream(pli);

            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");

            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "F_Pli_" + DateTime.Today + ".xlsx";
            return response;
        }
    }
}