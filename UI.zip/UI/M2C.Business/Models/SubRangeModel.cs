﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SubRangeModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;
using System;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class SubRangeModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class SubRangeModel : BindableBase
    {
        /// <summary>
        /// The identifier
        /// </summary>
        private int _id;
        /// <summary>
        /// The name
        /// </summary>
        private string _name;
        /// <summary>
        /// The SDH code
        /// </summary>
        private string _sdhCode;
        /// <summary>
        /// The SDH description
        /// </summary>
        private string _sdhDescription;
        /// <summary>
        /// The range identifier
        /// </summary>
        private int _rangeId;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get => _id; set => SetProperty(ref _id, value); }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get => _name; set => SetProperty(ref _name, value); }
        /// <summary>
        /// Gets or sets the SDH code.
        /// </summary>
        /// <value>The SDH code.</value>
        public string SdhCode { get => _sdhCode; set => SetProperty(ref _sdhCode, value); }
        /// <summary>
        /// Gets or sets the SDH description.
        /// </summary>
        /// <value>The SDH description.</value>
        public string SdhDescription { get => _sdhDescription; set => SetProperty(ref _sdhDescription, value); }
        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>The created date.</value>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the updated date.
        /// </summary>
        /// <value>The updated date.</value>
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Gets or sets the range identifier.
        /// </summary>
        /// <value>The range identifier.</value>
        public int RangeId { get => _rangeId; set => SetProperty(ref _rangeId, value); }
        /// <summary>
        /// Gets or sets the range.
        /// </summary>
        /// <value>The range.</value>
        public virtual RangeModel Range { get; set; }
    }
}