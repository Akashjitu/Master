﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 04-15-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="GlobalFiled.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using M2C.Business.Models.Project;

namespace M2C.Business.GlobalFields
{
    /// <summary>
    /// Class GlobalFiled.
    /// </summary>
    public static class GlobalFiled
    {
        /// <summary>
        /// The random
        /// </summary>
        static Random _random = new Random();
        /// <summary>
        /// Gets or sets the type of the selected node.
        /// </summary>
        /// <value>The type of the selected node.</value>
        public static string SelectedNodeType { get; set; }

        /// <summary>
        /// Gets or sets the current selected node.
        /// </summary>
        /// <value>The current selected node.</value>
        public static INode CurrentSelectedNode { get; set; }

        /// <summary>
        /// Generates the random identifier.
        /// </summary>
        /// <returns>System.Int32.</returns>
        public static int GenerateRandomId()
        {
            return _random.Next(1000, 9999);
        }

    }
}