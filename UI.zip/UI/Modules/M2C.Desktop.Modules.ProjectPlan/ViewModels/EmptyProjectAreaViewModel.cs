﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.ProjectPlan
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="EmptyProjectAreaViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System;

namespace M2C.Desktop.Modules.ProjectPane.ViewModels
{
    /// <summary>
    /// Class EmptyProjectAreaViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class EmptyProjectAreaViewModel : BindableBase, IDisposable
    {
        /// <summary>
        /// The global menu comands
        /// </summary>
        private IGlobalMenuComands _globalMenuComands;

        /// <summary>
        /// My profile
        /// </summary>
        private readonly IMyProfileLogic myProfile;

        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService sharedContextService;

        /// <summary>
        /// Gets the region manager.
        /// </summary>
        /// <value>The region manager.</value>
        public IRegionManager _regionManager { get; }

        /// <summary>
        /// Gets the dialog service.
        /// </summary>
        /// <value>The dialog service.</value>
        public IDialogService DialogService { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="EmptyProjectAreaViewModel" /> class.
        /// </summary>
        /// <param name="regionManager">The region manager.</param>
        /// <param name="globalMenuComands">The global menu comands.</param>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="myProfile">My profile.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        public EmptyProjectAreaViewModel(IRegionManager regionManager, IGlobalMenuComands globalMenuComands,
            IDialogService dialogService, IMyProfileLogic myProfile, ISharedContextService sharedContextService)
        {
            this._regionManager = regionManager;
            this._globalMenuComands = globalMenuComands;
            DialogService = dialogService;
            this.myProfile = myProfile;
            this.sharedContextService = sharedContextService;
        }

        /// <summary>
        /// Gets or sets the global menu comands.
        /// </summary>
        /// <value>The global menu comands.</value>
        public IGlobalMenuComands GlobalMenuComands
        {
            get => _globalMenuComands;
            set => SetProperty(ref _globalMenuComands, value);
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
        }
    }
}