﻿using Data.Management.Data.Models;
using Data.Management.Services.MemoryCachers;
using DataManagement.Data.Models;
using Oracle.Data.Access;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Data.Management.Services.DataBaseAccessObject
{
    public class DataManagementDbAccess : IDataManagementDbAccess
    {
        private void UpdateCacher()
        {
            MemoryCacher.Delete("programs");
            MemoryCacher.Delete("customers");

            MemoryCacher.Add("programs", LoadPrograms(), DateTimeOffset.Now.AddHours(5));
            MemoryCacher.Add("customers", LoadCustomers(), DateTimeOffset.Now.AddHours(5));
        }

        public DataManagementTrack AddNew(DataManagementTrack dataManagement)
        {
            if (dataManagement.CustomerId == 5)
            {
                var customer = AddCustomerName(dataManagement.CustomerName);
                var program = AddProgramName(dataManagement.ProgramNames, customer.ID);

                dataManagement.ProgramNames = program.ID.ToString();
                dataManagement.CustomerName = customer.ID.ToString();
                UpdateCacher();
            }
            else
            {
                dataManagement.ProgramNames = dataManagement.Programid.ToString();
                dataManagement.CustomerName = dataManagement.CustomerId.ToString();
            }
            dataManagement.Site = dataManagement.SiteId.ToString();

            using (var dao = new DataAccessObject<DataManagementTrack>())
            {
                var count = dao.Post(dataManagement, "PK_DATA_MANAGEMENT.SP_ADD_NEW");
                var data = dao.Load("PK_DATA_MANAGEMENT.SP_LOAD_LAST");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public List<DataManagementTrack> LoadAllDataManagements()
        {
            using (var dao = new DataAccessObject<DataManagementTrack>())
            {
                var data = dao.Load("PK_DATA_MANAGEMENT.SP_LOAD_ALL");
                var returndata = new List<DataManagementTrack>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<DataManagementTrack> LoadByDate(DateTime created)
        {
            using (var dao = new DataAccessObject<DataManagementTrack>())
            {
                var data = dao.LoadByInput(new DataManagementTrack() { CreatedDate = created }, "PK_DATA_MANAGEMENT.SP_LOAD_BY_DATE");
                var returndata = new List<DataManagementTrack>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<DataManagementTrack> LoadById(int id)
        {
            using (var dao = new DataAccessObject<DataManagementTrack>())
            {
                var data = dao.LoadByInput(new DataManagementTrack() { Id = id }, "PK_DATA_MANAGEMENT.SP_LOAD_BY_ID");
                var returndata = new List<DataManagementTrack>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<DataManagementTrack> LoadMaxRequestorId(string requestorId)
        {
            using (var dao = new DataAccessObject<DataManagementTrack>())
            {
                var data = dao.LoadByInput(new DataManagementTrack() { RequestorId = requestorId }, "PK_DATA_MANAGEMENT.SP_LOAD_MAX_REQUESTOR_ID");
                var returndata = new List<DataManagementTrack>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Customer> LoadCustomers()
        {
            using (var dao = new DataAccessObject<Customer>())
            {
                var data = dao.Load("PK_DATA_MANAGEMENT_REFERENCE.SP_LOAD_CUSTOMERS");
                var returndata = new List<Customer>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Program> LoadPrograms()
        {
            using (var dao = new DataAccessObject<Program>())
            {
                var data = dao.Load("PK_DATA_MANAGEMENT_REFERENCE.SP_LOAD_PROGRAMS");
                var returndata = new List<Program>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Site> LoadSites()
        {
            using (var dao = new DataAccessObject<Site>())
            {
                var data = dao.Load("PK_DATA_MANAGEMENT_REFERENCE.SP_LOAD_SITES");
                var returndata = new List<Site>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public DataManagementTrack UpdateData(DataManagementTrack dataManagement)
        {
            dataManagement.ProgramNames = dataManagement.Programid.ToString();
            dataManagement.CustomerName = dataManagement.CustomerId.ToString();
            dataManagement.Site = dataManagement.SiteId.ToString();
            using (var dao = new DataAccessObject<DataManagementTrack>())
            {
                var count = dao.Put(dataManagement, "PK_DATA_MANAGEMENT.SP_UPDATE_DATA");
                var data = dao.LoadByInput(dataManagement, "PK_DATA_MANAGEMENT.SP_LOAD_BY_ID");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public Customer AddCustomerName(string name)
        {
            using (var dao = new DataAccessObject<Customer>())
            {
                var count = dao.Post(new Customer() { Name = name }, "PK_DATA_MANAGEMENT.SP_ADD_CUSTOMER");

                var data = dao.Load("PK_DATA_MANAGEMENT_REFERENCE.SP_LOAD_LAST_CUSTOMERS");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public Program AddProgramName(string name, int customerID)
        {
            using (var dao = new DataAccessObject<Program>())
            {
                var count = dao.Post(new Program() { Name = name, CustomerId = customerID }, "PK_DATA_MANAGEMENT.SP_ADD_PROGRAM");

                var data = dao.Load("PK_DATA_MANAGEMENT_REFERENCE.SP_LOAD_LAST_PROGRAMS");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public List<EmployeeInfo> GetUserDbAccess(string eid)
        {
            using (var dao = new DataAccessObject<EmployeeInfo>())
            {
                var data = dao.LoadByInput(new EmployeeInfo() { EID = eid }, "PK_DATA_MANAGEMENT.LOAD_ACCESS");
                if (data == null)
                    return null;

                return data.ToList();
            }
        }

        public int AddUserDbAccess(string eid, int access)
        {
            using (var dao = new DataAccessObject<EmployeeInfo>())
            {
                return dao.Post(new EmployeeInfo() { EID = eid, AccessType = access }, "PK_DATA_MANAGEMENT.LOAD_ACCESS");
            }
        }

        public List<EmployeeInfo> GetAllEmployeeAccess()
        {
            using (var dao = new DataAccessObject<EmployeeInfo>())
            {
                var data = dao.Load("PK_DATA_MANAGEMENT_ACCESS.SP_LOAD_ALL_ACCESS");
                var returndata = new List<EmployeeInfo>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public EmployeeInfo AddEmployeeAccess(EmployeeInfo employeeInfo)
        {
            using (var dao = new DataAccessObject<EmployeeInfo>())
            {
                var count = dao.Put(employeeInfo, "PK_DATA_MANAGEMENT_ACCESS.SP_ADD_ACCESS");
                var returndata = new List<EmployeeInfo>();
                var data = dao.Load("PK_DATA_MANAGEMENT_ACCESS.SP_LOAD_LATEST");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public EmployeeInfo UpdateEmployeeAccess(EmployeeInfo employeeInfo)
        {
            using (var dao = new DataAccessObject<EmployeeInfo>())
            {
                var count = dao.Put(employeeInfo, "PK_DATA_MANAGEMENT_ACCESS.SP_UPDATE_ACCESS");
                var data = dao.LoadByInput(employeeInfo, "PK_DATA_MANAGEMENT_ACCESS.SP_LOAD_BY_ID");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public EmployeeInfo GetEmployeeAccessByEid(EmployeeInfo employeeInfo)
        {
            using (var dao = new DataAccessObject<EmployeeInfo>())
            {
                var data = dao.LoadByInput(employeeInfo, "PK_DATA_MANAGEMENT_ACCESS.SP_LOAD_BY_E_ID");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }
    }
}