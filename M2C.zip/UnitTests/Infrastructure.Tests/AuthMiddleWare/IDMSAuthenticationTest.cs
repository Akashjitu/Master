﻿// ***********************************************************************
// Assembly         : Infrastructure.Tests
// Author           : SESA56024
// Created          : 03-27-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-06-2020
// ***********************************************************************
// <copyright file="IDMSAuthenticationTest.cs" company="Infrastructure.Tests">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using AuthMiddleWare.Contracts;
using AuthMiddleWare.Implementations;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RestClientServices.Contracts;
using RestSharp;
using System;

namespace Infrastructure.Tests.AuthMiddleWare
{
    /// <summary>
    /// Defines test class IDMSAuthenticationTest.
    /// </summary>
    [TestClass]
    public class IDMSAuthenticationTest
    {
        /// <summary>
        /// Gets or sets the mock repo.
        /// </summary>
        /// <value>The mock repo.</value>
        private MockRepository MockRepo { get; set; }
        /// <summary>
        /// Gets or sets the i application configurations mock.
        /// </summary>
        /// <value>The i application configurations mock.</value>
        private Mock<IAppConfigurations> IAppConfigurationsMock { get; set; }
        /// <summary>
        /// Gets or sets the i rest client mock.
        /// </summary>
        /// <value>The i rest client mock.</value>
        private Mock<IRestClient> IRestClientMock { get; set; }
        /// <summary>
        /// Gets or sets the i rest services factory mock.
        /// </summary>
        /// <value>The i rest services factory mock.</value>
        private Mock<IRestServicesFactory> IRestServicesFactoryMock { get; set; }
        /// <summary>
        /// Gets or sets the i rest client service mock.
        /// </summary>
        /// <value>The i rest client service mock.</value>
        private Mock<IAuthService> IRestClientServiceMock { get; set; }

        /// <summary>
        /// Tests the ini tialize.
        /// </summary>
        [TestInitialize]
        public void TestIniTialize()
        {
            MockRepo = new MockRepository(MockBehavior.Loose);

            IAppConfigurationsMock = MockRepo.Create<IAppConfigurations>();
            IAppConfigurationsMock.Setup(x => x.AuthServicePath).Returns("https://schneider-m2c-apis-dev.azurewebsites.net/m2cdesktop");

            IRestClientMock = MockRepo.Create<IRestClient>();

            IRestClientServiceMock = MockRepo.Create<IAuthService>();

            IRestServicesFactoryMock = MockRepo.Create<IRestServicesFactory>();
            IRestServicesFactoryMock.Setup(x => x.GetRestClientService<IAuthService>(It.IsAny<RestServiceTypes>())).Returns(IRestClientServiceMock.Object);
        }

        /// <summary>
        /// Defines the test method IDMSAuthenticationObject.
        /// </summary>
        [TestMethod]
        public void IDMSAuthenticationObject()
        {
            IAuthentication authobj = null;

            Action action = () =>
            {
                authobj = new IDMSAuthentication(IRestServicesFactoryMock.Object);
            };

            action.Should().NotThrow();
            authobj.Should().NotBeNull();
        }

        /// <summary>
        /// Defines the test method getAccessTokenValidToken.
        /// </summary>
        [TestMethod]
        public void getAccessTokenValidToken()
        {
            IAuthentication authobj = new IDMSAuthentication(IRestServicesFactoryMock.Object);

            IRestClientServiceMock.Setup(x => x.Execute<string>(It.IsAny<IRestServiceRequest>())).Returns("00Dg0000006I0pD!AR4AQARVfZzO6hsy5J3QOj1DBj3gutbEh9gTGTS4dz3RfDJlp4yvpysRyxwPSK4Sl5VwWtdSPYlu5n8y2jqO4lKUoLQ3lhlC");

            string token = authobj.getAccessToken("dummy_auth_code");
            token.Should().NotBeNullOrEmpty();
        }

        /// <summary>
        /// Defines the test method getAccessTokenInvalidValidToken.
        /// </summary>
        [TestMethod]
        public void getAccessTokenInvalidValidToken()
        {
            IAuthentication authobj = new IDMSAuthentication(IRestServicesFactoryMock.Object);

            IRestClientServiceMock.Setup(x => x.Execute<string>(It.IsAny<IRestServiceRequest>())).Returns(string.Empty);

            string token = authobj.getAccessToken("dummy_auth_code");
            token.Should().BeNull();
        }

        /// <summary>
        /// Defines the test method getLoginUrlTest.
        /// </summary>
        [TestMethod]
        public void getLoginUrlTest()
        {
            IAuthentication authobj = new IDMSAuthentication(IRestServicesFactoryMock.Object);

            IRestClientServiceMock.Setup(x => x.Execute<string>(It.IsAny<IRestServiceRequest>())).Returns("http://www.idms.com");

            string token = authobj.GetLoginPath();
            token.Should().NotBeNull();
        }
    }
}