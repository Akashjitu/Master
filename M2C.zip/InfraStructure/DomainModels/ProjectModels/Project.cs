﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="Project.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using DomainModels.Common;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class Project.
    /// Implements the <see cref="DomainModels.Common.ChangeTrack" />
    /// </summary>
    /// <seealso cref="DomainModels.Common.ChangeTrack" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [Table("Projects")]
    public class Project : ChangeTrack
    {
        /// <summary>
        /// Gets or sets the project identifier.
        /// </summary>
        /// <value>The project identifier.</value>
        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProjectID { get; set; }

        /// <summary>
        /// Gets or sets the customer.
        /// </summary>
        /// <value>The customer.</value>
        [ForeignKey("CustomerID")]
        public virtual Customer Customer { get; set; }

        /// <summary>
        /// Gets or sets the contacts.
        /// </summary>
        /// <value>The contacts.</value>
        public ICollection<Contact> Contacts { get; set; }

        /// <summary>
        /// Gets or sets the ib project components.
        /// </summary>
        /// <value>The ib project components.</value>
        public ICollection<IBProjectComponent> IBProjectComponents { get; set; }

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="builder">The builder.</param>
        public static void OnModelCreating(ModelBuilder builder)
        {
            //Base class Modeling
            OnModelCreating<Contact>(builder);

            builder.Entity<Project>().HasMany(s => s.ProjectInventories).WithOne(i => i.Project).HasForeignKey(oi => oi.ProjectId);
            builder.Entity<Project>().HasMany(s => s.InventoryComments).WithOne(i => i.Project).HasForeignKey(oi => oi.ProjectId);
            builder.Entity<ProjectInventory>().Property(a => a.Id).ValueGeneratedOnAdd();
        }

        /// <summary>
        /// Gets or sets the operation modes.
        /// </summary>
        /// <value>The operation modes.</value>
        public ICollection<OperationMode> OperationModes { get; set; }

        /// <summary>
        /// Get set Collection of ProjectInventories
        /// </summary>
        /// <value>The project inventories.</value>
        public ICollection<ProjectInventory> ProjectInventories { get; set; }

        /// <summary>
        /// Get set Collection of ProjectInventories
        /// </summary>
        /// <value>The inventory comments.</value>
        public ICollection<InventoryComments> InventoryComments { get; set; }

        /// <summary>
        /// Get set Collection of criticalities
        /// </summary>
        /// <value>The criticalities.</value>
        public ICollection<Criticality> Criticalities { get; set; }

        /// <summary>
        /// Gets or sets the project reference identifier.
        /// </summary>
        /// <value>The project reference identifier.</value>
        public string ProjectReferenceId { get; set; }

        /// <summary>
        /// Gets or sets the last synchronize date.
        /// </summary>
        /// <value>The last synchronize date.</value>
        public DateTime? LastSyncDate { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public int Version { get; set; }
    }
}