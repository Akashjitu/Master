﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class OtlScoreCard
    {
        [Columns("P_KEY_CODE")]
        public string KeyCode { get; set; }

        [Columns("P_OTL_BASELINE_DATE")]
        public DateTime OTLBaselineDate { get; set; }

        [Columns("P_PART_NUMBER")]
        public string PartNumber { get; set; }

        [Columns("P_LRU")]
        public string Lru { get; set; }

        [Columns("P_PRODUCTION_SITE")]
        public string ProductionSite { get; set; }

        [Columns("P_APQP_LVL")]
        public string ApqpLvl { get; set; }

        [Columns("P_PLANNED_QTY")]
        public string PlannedQty { get; set; }

        [Columns("P_ERP_SYSTEM_LOAD")]
        public string ERPSystemLoad { get; set; }

        [Columns("P_PLAN")]
        public string Plan { get; set; }

        [Columns("P_ACTUALS")]
        public string Actuals { get; set; }

        [Columns("P_FORECAST")]
        public string Forecast { get; set; }

        [Columns("P_UPC_INDEX")]
        public string UpcIndex { get; set; }

        [Columns("P_ESE")]
        public string Ese { get; set; }

        [Columns("P_ECE")]
        public string Ece { get; set; }

        [Columns("P_PPAP")]
        public string Ppap { get; set; }

        [Columns("P_PRR")]
        public string Prr { get; set; }

        [Columns("P_MRA")]
        public string Mra { get; set; }

        [Columns("P_UPDATED_DATE")]
        public DateTime UpdatedDate { get; set; }

        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("P_ACTIVE")]
        public string active { get; set; }

        [Columns("P_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("P_CREATE_BY")]
        public string CreateBy { get; set; }

        [Columns("P_ID")]
        public int Id { get; set; }
    }
}