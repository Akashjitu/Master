
// Section 1
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { FracaInfo } from '../models/fraca-info';
import { FracaData } from '../models/fraca-data';

export const ADD_FRACA ='ADD_FRACA';
export const LOAD_FRACA ='LOAD_FRACA';
export const REMOVE_FRACA ='REMOVE_FRACA';
//export const REMOVE_ALL_FRACA ='REMOVE_ALL_FRACA';
export const UPDATE_FRACA:string ='UPDATE_FRACA';

export class LoadFraca implements Action {
    readonly type = LOAD_FRACA

    constructor(public payload: FracaData) {
       
    }
}

export class AddFraca implements Action {
    readonly type = ADD_FRACA

    constructor(public payload: FracaInfo) {}
}

export class UpdateFraca implements Action {
    readonly type = UPDATE_FRACA

    constructor(public payload: FracaInfo) {}
}

export class RemoveFraca implements Action {
    readonly type = REMOVE_FRACA

    constructor(public payload: number) {}
}


export type Actions = AddFraca | RemoveFraca|LoadFraca