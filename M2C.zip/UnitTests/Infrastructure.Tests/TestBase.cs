﻿using DataRepository.DBContracts;
using Moq;

namespace Infrastructure.Tests
{
    public class TestBase
    {
        protected MockRepository MockRepo { get; set; }
        protected Mock<IDbContextFactory> IDbContextFactoryMock { get; set; }
        protected Mock<IProductDbContext> IProductDbContextMock { get; set; }
        protected Mock<IProjectDbContext> IProjectDbContextMock { get; set; }

        public TestBase()
        {
            MockRepo = new MockRepository(MockBehavior.Loose);
            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();
            IProjectDbContextMock = MockRepo.Create<IProjectDbContext>();
        }
    }
}