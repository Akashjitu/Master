﻿namespace NuGetPackageExplorer.Types
{
    public enum PackageIssueLevel
    {
        Error = 0,
        Warning = 1
    }
}