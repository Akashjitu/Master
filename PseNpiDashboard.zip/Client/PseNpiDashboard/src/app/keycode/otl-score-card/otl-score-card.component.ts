import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otl-score-card',
  templateUrl: './otl-score-card.component.html',
  styleUrls: ['./otl-score-card.component.css']
})
export class OtlScoreCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
