﻿using System.Windows.Controls;

namespace PackageExplorer
{
    /// <summary>
    /// Interaction logic for PackageListItem.xaml
    /// </summary>
    public partial class PackageListItem : UserControl
    {
        public PackageListItem()
        {
            InitializeComponent();
        }
    }
}
