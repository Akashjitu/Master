﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ReferenceControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using M2C.Business.GlobalFields;

namespace M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls
{
    /// <summary>
    /// ViewModel for ReferenceControl.
    /// Provide Binding Data and Event
    /// </summary>
    public class ReferenceControlViewModel : BindableBase, ICommonInventory
    {
        #region Class fields

        /// <summary>
        /// The common inventory reference
        /// </summary>
        private readonly ICommonInventoryReference _commonInventoryReference;
        /// <summary>
        /// The products
        /// </summary>
        private List<ProductModel> _products;
        /// <summary>
        /// The selected product
        /// </summary>
        private ProductModel _selectedProduct;

        #endregion Class fields

        #region Properties

        /// <summary>
        /// Collection of Product.
        /// This Bind with reference Drop-down box
        /// </summary>
        /// <value>The products.</value>
        public List<ProductModel> Products
        {
            get => _products;
            set => SetProperty(ref _products, value);
        }

        /// <summary>
        /// Selected Product Bind with reference Drop-down box.
        /// and it will set after the selection.
        /// </summary>
        /// <value>The selected product.</value>
        public ProductModel SelectedProduct
        {
            get => _selectedProduct;
            set => SetProperty(ref _selectedProduct, value);
        }

        /// <summary>
        /// Get the Products if multiple selected
        /// </summary>
        /// <value>The selected products.</value>
        public List<ProductModel> SelectedProducts => SelectedProduct != null
            ? new List<ProductModel> { SelectedProduct }
            : new List<ProductModel>();

        #endregion Properties

        #region Event and Commend

        /// <summary>
        /// Event when  reference Drop-down selection change
        /// </summary>
        /// <value>The on reference change command.</value>
        public DelegateCommand<string> OnReferenceChangeCommand { get; set; }

        /// <summary>
        /// event while user start typing.
        /// </summary>
        /// <value>The on key up p change command.</value>
        public DelegateCommand<RoutedEventArgs> OnKeyUpPChangeCommand { get; set; }

        /// <summary>
        /// Event for Send data to handler
        /// </summary>
        /// <value>The event aggregator.</value>
        private IEventAggregator EventAggregator { get; }

        #endregion Event and Commend

        /// <summary>
        /// Initialize class fields
        /// </summary>
        /// <param name="commonInventoryReference">The common inventory reference.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        public ReferenceControlViewModel(ICommonInventoryReference commonInventoryReference,
            IEventAggregator eventAggregator)
        {
            _commonInventoryReference = commonInventoryReference;
            EventAggregator = eventAggregator;
            SelectedProduct = new ProductModel();
            OnKeyUpPChangeCommand = new DelegateCommand<RoutedEventArgs>(OnKeyUpPChange);
            OnReferenceChangeCommand = new DelegateCommand<string>(OnReferenceChange);
        }


        /// <summary>
        /// Handler when user Start Typing on reference Drop-down box
        /// </summary>
        /// <param name="identifier">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void OnKeyUpPChange(RoutedEventArgs identifier)
        {
            var searchText = (identifier.OriginalSource as TextBox)?.Text;
            if (string.IsNullOrEmpty(searchText))
            {
                identifier.Handled = true;
                return;
            }

            if (string.IsNullOrEmpty(searchText.Trim()))
                return;
            var databaseProduct = _commonInventoryReference.GetProductsStartWithIdentifierByNode(GetProductIdentifier(searchText), GlobalFiled.SelectedNodeType);
            if (!IsAlreadySelected(databaseProduct))
                Products = databaseProduct;
        }

        /// <summary>
        /// Handler when reference selection Change
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        private void OnReferenceChange(string identifier)
        {
        }

        /// <summary>
        /// Get the Product Identifier from full Name
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.String.</returns>
        private static string GetProductIdentifier(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            var identifier = value.Contains("(")
                ? value.Remove(value.IndexOf('('), value.Length - value.IndexOf('('))
                : value;
            return identifier.Trim();
        }

        /// <summary>
        /// Check Product already Selected
        /// </summary>
        /// <param name="productModels">The product models.</param>
        /// <returns><c>true</c> if [is already selected] [the specified product models]; otherwise, <c>false</c>.</returns>
        private bool IsAlreadySelected(IReadOnlyCollection<ProductModel> productModels)
        {
            if (productModels.Count == 1 && SelectedProduct != null)
                return productModels.Any(i => i.FullName == SelectedProduct.FullName);
            return false;
        }
    }
}