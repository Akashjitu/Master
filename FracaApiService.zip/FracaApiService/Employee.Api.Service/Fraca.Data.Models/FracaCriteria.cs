﻿using System;

namespace Fraca.Data.Models
{
    public class FracaCriteria
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }

        public string FracaNo { get; set; }


        public string PartNo { get; set; }
    }
}