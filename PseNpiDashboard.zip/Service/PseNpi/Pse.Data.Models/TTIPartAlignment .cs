using Oracle.Data.Access;
using Pse.Data.Models.Attributes;
using System;

namespace Pse.Data.Models
{
    public class TtiPartAlignment
    {
        [Columns("p_ACCOLADE_KC")]
        public string Accolade_KC { get; set; }

        [Columns("p_KEY_CODE")]
        public string Heatmap_KC { get; set; }

        [Columns("p_PROGRAM_NAME")]
        public string Program_Name { get; set; }

        [Columns("p_IPDS_PHASE")]
        public string IPDS_Current_Phase { get; set; }

        [Columns("p_SBU")]
        public string Prod_SBU { get; set; }

        [Columns("p_GBE")]
        public string GBE { get; set; }

        [Columns("p_PAC")]
        public string PAC { get; set; }

        [Columns("p_HONEYWELL_PART_NUMBER")]
        public string Honeywell_Part_Number { get; set; }

        [Columns("p_BASELINE_DATE")]
        public string OTL_Baseline_Date { get; set; }

        [Columns("p_FORECAST_DATE")]
        public string OTL_Forecast_Date { get; set; }

        [Columns("p_OTL_Baseline_Date_refresh")]
        public string OTL_Baseline_Date_refresh { get; set; }

        [Columns("p_OTL_Forecast_Data_refresh")]
        public string OTL_Forecast_Data_refresh { get; set; }

        [Columns("p_PART_DESCRIPTION")]
        public string Part_Description { get; set; }

        [Columns("p_END_ITEM_LUR")]
        public string End_Item_LRU { get; set; }

        [Columns("p_MAKE_BUY")]
        public string Make_Buy { get; set; }

        [Columns("p_PRODUCTION_SITE")]
        public string Production_Site { get; set; }

        [Columns("p_PROGRAM_MANAGER")]
        public string PM { get; set; }

        [Columns("p_PROJECT_ENGINEER")]
        public string PE { get; set; }

        [Columns("p_QTYPER_SHIPSET")]
        public string Qty_Per_Shipset { get; set; }

        [Columns("p_AME")]
        public string AME_NPD_Engineer { get; set; }

        [Columns("p_PM_CHIEF")]
        public string Eng_Chief { get; set; }

        [Columns("p_APQP_LEVEL")]
        public string APQP_Level { get; set; }

        [Columns("P_RTY_VALIDATION_METHOD")]
        public string RTY_Validation_Method { get; set; }

        [Columns("p_PART_OF_OTL_TTI")]
        public string Part_of_OTL_TTI { get; set; }

        [Columns("p_ADDED_REMOVED_FROM_OTL_TTI")]
        public DateTime? Added_Removed_from_OTL_TTI { get; set; }

        [Columns("p_PART_OF_RTY_TTI")]
        public string Part_of_RTY_TTI { get; set; }

        [Columns("p_ADD_REMOVE_RTY_TTI")]
        public DateTime? Added_Removed_from_RTY_TTI { get; set; }

        [Columns("p_PART_OF_PPM_TTI")]
        public string Part_of_PPM_TTI { get; set; }

        [Columns("p_ADDED_PPM_TTI")]
        public DateTime? Added_to_PPM_TTI { get; set; }

        [Columns("p_NOTES")]
        public string NOTES { get; set; }

        [Columns("p_Record_Number")]
        public string Record_Number { get; set; }

        [Columns("p_INDEX_RECORD_ID")]
        public string Index_Record_ID { get; set; }

        [Columns("p_ESE_BASELINE")]
        public DateTime? EseBaseLine { get; set; }

        [Columns("p_ESE_FORECAST")]
        public DateTime? EseForecast { get; set; }

        [Columns("p_SUCCESSFUL_ESE")]
        public string SuccessfulEse { get; set; }

        [Columns("p_SOURCING")]
        public string Sourcing { get; set; }

        [Columns("p_PG_EXIT")]
        public DateTime? PgExit { get; set; }

     

        [Columns("p_SUCCESSFUL_RTY")]
        public string SuccessfulRty { get; set; }

        [Columns("p_SUCCESSFUL_UPC")]
        public string SuccessfulUpc { get; set; }

        [Columns("p_SUCCESSFUL_PPM")]
        public string SuccessfulPpm { get; set; }

        [Columns("p_SUCCESSFUL_OTL")]
        public string SuccessfulOtl { get; set; }

        [Columns("p_PART_OF_BASELINE")]
        public string PartOfBaseline { get; set; }

        [ExportColumn(true)]
        [Columns("p_ACTIVE")]
        public string Actibe { get; set; }

        [ExportColumn(true)]
        [Columns("p_CREATED_DATE")]
        public DateTime? InfoCreatedDate { get; set; }


        [ExportColumn(true)]
        [Columns("p_UPDATED_DATE")]
        public DateTime? InfoUpdateDate { get; set; }

        [ExportColumn(true)]
        [Columns("p_UPDATED_BY")]
        public string UpdateBy { get; set; }

        [ExportColumn(false, true)]
        [Columns("p_ID")]
        public int Id { get; set; }
    }
}