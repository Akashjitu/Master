﻿using Oracle.Data.Access;

namespace Data.Management.Data.Models
{
    public class Program
    {
        [Columns("P_PROGRAM_ID")]
        public int ID { get; set; }

        [Columns("P_PROGRAM_NAME")]
        public string Name { get; set; }

        [Columns("P_CUSTOMER_ID")]
        public int CustomerId { get; set; }
    }
}