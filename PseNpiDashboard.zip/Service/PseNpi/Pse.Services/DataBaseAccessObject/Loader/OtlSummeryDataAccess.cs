﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pse.Data.Models;
using Oracle.Data.Access;

namespace Pse.Services.DataBaseAccessObject.Loader
{

    
    public class OtlSummeryDataAccess : IOtlSummeryDataAccess
    {
        public List<OtlSummery> AddOtlSummeryByID(OtlSummery otlSummery)
        {
            throw new NotImplementedException();
        }

        public OtlSummery AddOtlSummery(OtlSummery otlSummery)
        {
            using (var dao = new DataAccessObject<OtlSummery>())
            {
                var count = dao.Put(otlSummery, "PK_OTL_SUMMERY.SP_ADD_OTL_SUMMERY");
                var data = dao.Load("PK_OTL_SCORE_CARD.SP_LOAD_LATEST_OTL_SUMMERY");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public List<OtlSummery> LoadAllOtlSummery()
        {
            using (var dao = new DataAccessObject<OtlSummery>())
            {
                var data = dao.Load("PK_OTL_SUMMERY.SP_LOAD_OTL_SUMMERY");
                var returndata = new List<OtlSummery>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlSummery> LoadOtlSummeryByCreatedDate(DateTime created)
        {
            using (var dao = new DataAccessObject<OtlSummery>())
            {
                var data = dao.LoadByInput(new OtlSummery {CreatedDate = created }, "PK_OTL_SUMMERY.SP_LOAD_BY_MO_YY");
                var returndata = new List<OtlSummery>();
                returndata.AddRange(data);
                return returndata;
            }
        }


        public List<OtlSummery> LoadOtlSummeryByBaseLine(DateTime baseLine)
        {
            using (var dao = new DataAccessObject<OtlSummery>())
            {
                var data = dao.LoadByInput(new OtlSummery { HmrBaseline = baseLine }, "PK_OTL_SUMMERY.SP_LOAD_BASE_LINE");
                var returndata = new List<OtlSummery>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlSummery> LoadOtlSummeryByID(int id)
        {
            using (var dao = new DataAccessObject<OtlSummery>())
            {
                var data = dao.LoadByInput( new OtlSummery() { Id = id}, "PK_OTL_SUMMERY.SP_LOAD_BY_ID");
                var returndata = new List<OtlSummery>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlSummery> LoadOtlSummeryByKeyCode(string keycode)
        {
            using (var dao = new DataAccessObject<OtlSummery>())
            {
                var data = dao.LoadByInput(new OtlSummery() { KeyCode = keycode }, "PK_OTL_SUMMERY.SP_LOAD_BY_KEY_CODE");
                var returndata = new List<OtlSummery>();
                returndata.AddRange(data);
                return returndata;
            }

        }

        public OtlSummery UpdateOtlSummery(OtlSummery otlSummery) 
        {
            using (var dao = new DataAccessObject<OtlSummery>())
            {
                var count = dao.Put(otlSummery, "PK_OTL_SUMMERY.SP_UPDATE_OTL_SUMMERY");
                var data = dao.LoadByInput(otlSummery, "PK_OTL_SUMMERY.SP_LOAD_BY_ID");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }
    }
}
