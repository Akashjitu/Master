﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-21-2020
// ***********************************************************************
// <copyright file="ExcelExportObsolescence.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using DevExpress.Spreadsheet;
using M2C.Business.Implementations;
using M2C.Business.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Media;
using User.Digital.Sign;

namespace M2C.Desktop.Modules.Charts.ReportData.ChartExports
{
    /// <summary>
    /// Class ExcelExportObsolescence.
    /// Implements the <see cref="M2C.Desktop.Modules.Charts.ReportData.ChartExports.IExcelExportObsolescence" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.Charts.ReportData.ChartExports.IExcelExportObsolescence" />
    public class ExcelExportObsolescence : IExcelExportObsolescence
    {
        /// <summary>
        /// The color provider
        /// </summary>
        private IStatusColorProvider _colorProvider;
        /// <summary>
        /// The reference ib data
        /// </summary>
        private Dictionary<string, int> refIbData = new Dictionary<string, int>();
        /// <summary>
        /// The reference tr data
        /// </summary>
        private Dictionary<string, int> refTrData = new Dictionary<string, int>();
        /// <summary>
        /// The reference list
        /// </summary>
        private List<string> refList = new List<string>();

        /// <summary>
        /// Initializes a new instance of the <see cref="ExcelExportObsolescence" /> class.
        /// </summary>
        /// <param name="colorProvider">The color provider.</param>
        public ExcelExportObsolescence(IStatusColorProvider colorProvider)
        {
            _colorProvider = colorProvider;
        }

        /// <summary>
        /// Exports the specified path.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <param name="IbSheetName">Name of the sheet.</param>
        /// <param name="IbInventories">The inventories.</param>
        /// <param name="TrSheetName">Name of the tr sheet.</param>
        /// <param name="TrInventories">The tr inventories.</param>
        public void Export(string path, string IbSheetName, List<Inventory> IbInventories, string TrSheetName, List<Inventory> TrInventories)
        {
            using (var workbook = new Workbook())
            {
                var IbWorksheet = workbook.Worksheets[0];
                IbWorksheet.Name = IbSheetName;                                
                var TrWorksheet = workbook.Worksheets.Add(TrSheetName);
                var AnalysisWorksheet = workbook.Worksheets.Add("Analysis");
                workbook.Unit = DevExpress.Office.DocumentUnit.Point;
                try
                {
                    if (File.Exists(path))
                        File.Delete(path);

                    workbook.BeginUpdate();
                    FillIbData(IbInventories, IbWorksheet);
                    FillTrData(TrInventories, TrWorksheet);
                    FillAnalysisData(AnalysisWorksheet, IbInventories);

                    workbook.Worksheets.ActiveWorksheet = workbook.Worksheets[0];
                    workbook.SaveDocument(path, DevExpress.Spreadsheet.DocumentFormat.OpenXml);
                    EncryptionDigitalSignature.SignOfficeFile(path);
                }
                finally
                {
                    workbook.EndUpdate();
                }
            }
        }

        /// <summary>
        /// Fills the analysis data.
        /// </summary>
        /// <param name="AnalysisWorksheet">The analysis worksheet.</param>
        /// <param name="IbInventories">The ib inventories.</param>
        private void FillAnalysisData(Worksheet AnalysisWorksheet, List<Inventory> IbInventories)
        {
            AnalysisWorksheet.Cells["A1"].Value = "Reference";
            AnalysisWorksheet.Cells["B1"].Value = "Description";
            AnalysisWorksheet.Cells["C1"].Value = "Installed Base Quantity";
            AnalysisWorksheet.Cells["D1"].Value = "Technical Resources Quantity";           
            AnalysisWorksheet.Cells["E1"].Value = DateTime.Today.Year;
            AnalysisWorksheet.Cells["F1"].Value = DateTime.Today.AddYears(1).Year;
            AnalysisWorksheet.Cells["G1"].Value = DateTime.Today.AddYears(2).Year;
            AnalysisWorksheet.Cells["H1"].Value = DateTime.Today.AddYears(3).Year;
            AnalysisWorksheet.Cells["I1"].Value = DateTime.Today.AddYears(4).Year;
            AnalysisWorksheet.Cells["J1"].Value = DateTime.Today.AddYears(5).Year;
            AnalysisWorksheet.Cells["K1"].Value = DateTime.Today.AddYears(6).Year;
            AnalysisWorksheet.Cells["L1"].Value = DateTime.Today.AddYears(7).Year;
            AnalysisWorksheet.Cells["M1"].Value = DateTime.Today.AddYears(8).Year;
            AnalysisWorksheet.Cells["N1"].Value = DateTime.Today.AddYears(9).Year;

            AnalysisWorksheet.Range["A1:N1"].Font.Color = System.Drawing.Color.DodgerBlue;
            AnalysisWorksheet.Range["A1:N1"].Font.Bold = true;

            for(int i=0; i< refList.Count;i++)
            {
                foreach (var inventory in IbInventories)
                {
                    if (refList[i] == inventory.Reference)
                    {
                        var yearColor = (Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.Year,
                       int.TryParse(inventory.Dosa, out var dosaYear) ? dosaYear : (int?)null,
                       int.TryParse(inventory.DoS, out var dosYear) ? dosYear : (int?)null,
                       int.TryParse(inventory.EoS, out var eosYear) ? eosYear : (int?)null));

                        var year1Color = (Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(1).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear1) ? dosaYear1 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear1) ? dosYear1 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear1) ? eosYear1 : (int?)null));

                        var year2Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(2).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear2) ? dosaYear2 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear2) ? dosYear2 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear2) ? eosYear2 : (int?)null));

                        var year3Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(3).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear3) ? dosaYear3 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear3) ? dosYear3 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear3) ? eosYear3 : (int?)null));

                        var year4Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(4).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear4) ? dosaYear4 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear4) ? dosYear4 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear4) ? eosYear4 : (int?)null));

                        var year5Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(5).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear5) ? dosaYear5 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear5) ? dosYear5 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear5) ? eosYear5 : (int?)null));

                        var year6Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(6).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear6) ? dosaYear6 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear6) ? dosYear6 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear6) ? eosYear6 : (int?)null));

                        var year7Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(7).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear7) ? dosaYear7 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear7) ? dosYear7 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear7) ? eosYear7 : (int?)null));

                        var year8Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(8).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear8) ? dosaYear8 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear8) ? dosYear8 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear8) ? eosYear8 : (int?)null));

                        var year9Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(9).Year,
                            int.TryParse(inventory.Dosa, out var dosaYear9) ? dosaYear9 : (int?)null,
                            int.TryParse(inventory.DoS, out var dosYear9) ? dosYear9 : (int?)null,
                            int.TryParse(inventory.EoS, out var eosYear9) ? eosYear9 : (int?)null));

                        AnalysisWorksheet.Cells[$"A{i + 2}"].Value = refList[i];
                        AnalysisWorksheet.Cells[$"B{i + 2}"].Value = inventory.Name;
                        AnalysisWorksheet.Cells[$"C{i + 2}"].Value = refIbData[refList[i]];
                        AnalysisWorksheet.Cells[$"D{i + 2}"].Value = refTrData[refList[i]];

                        AnalysisWorksheet.Cells[$"E{i + 2}"].FillColor = System.Drawing.Color.FromArgb(yearColor.A, yearColor.R, yearColor.G, yearColor.B);
                        AnalysisWorksheet.Cells[$"F{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year1Color.A, year1Color.R, year1Color.G, year1Color.B);
                        AnalysisWorksheet.Cells[$"G{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year2Color.A, year2Color.R, year2Color.G, year2Color.B);
                        AnalysisWorksheet.Cells[$"H{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year3Color.A, year3Color.R, year3Color.G, year3Color.B);
                        AnalysisWorksheet.Cells[$"I{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year4Color.A, year4Color.R, year4Color.G, year4Color.B);
                        AnalysisWorksheet.Cells[$"J{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year5Color.A, year5Color.R, year5Color.G, year5Color.B);
                        AnalysisWorksheet.Cells[$"K{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year6Color.A, year6Color.R, year6Color.G, year6Color.B);
                        AnalysisWorksheet.Cells[$"L{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year7Color.A, year7Color.R, year7Color.G, year7Color.B);
                        AnalysisWorksheet.Cells[$"M{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year8Color.A, year8Color.R, year8Color.G, year8Color.B);
                        AnalysisWorksheet.Cells[$"N{i + 2}"].FillColor = System.Drawing.Color.FromArgb(year9Color.A, year9Color.R, year9Color.G, year9Color.B);
                        break;
                    }
                }
            }
                       
            var trRange = AnalysisWorksheet.Range[$"A1:N{refList.Count + 1}"];
            trRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Medium);
            AnalysisWorksheet.Columns.AutoFit(0, AnalysisWorksheet.Columns.LastUsedIndex);
        }

        /// <summary>
        /// Fills the tr data.
        /// </summary>
        /// <param name="TrInventories">The tr inventories.</param>
        /// <param name="TrWorksheet">The tr worksheet.</param>
        private void FillTrData(List<Inventory> TrInventories, Worksheet TrWorksheet)
        {
            CreateTrReferenceData(TrInventories);
            CreateTrHeader(TrWorksheet);
            var trRowIndex = 1;
            foreach (var inventory in TrInventories)
            {
                trRowIndex++;

                var yearColor = (Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.Year,
                    int.TryParse(inventory.Dosa, out var dosaYear) ? dosaYear : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear) ? dosYear : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear) ? eosYear : (int?)null));

                var year1Color = (Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(1).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear1) ? dosaYear1 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear1) ? dosYear1 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear1) ? eosYear1 : (int?)null));

                var year2Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(2).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear2) ? dosaYear2 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear2) ? dosYear2 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear2) ? eosYear2 : (int?)null));

                var year3Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(3).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear3) ? dosaYear3 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear3) ? dosYear3 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear3) ? eosYear3 : (int?)null));

                var year4Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(4).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear4) ? dosaYear4 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear4) ? dosYear4 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear4) ? eosYear4 : (int?)null));

                var year5Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(5).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear5) ? dosaYear5 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear5) ? dosYear5 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear5) ? eosYear5 : (int?)null));

                var year6Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(6).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear6) ? dosaYear6 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear6) ? dosYear6 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear6) ? eosYear6 : (int?)null));

                var year7Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(7).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear7) ? dosaYear7 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear7) ? dosYear7 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear7) ? eosYear7 : (int?)null));

                var year8Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(8).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear8) ? dosaYear8 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear8) ? dosYear8 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear8) ? eosYear8 : (int?)null));

                var year9Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(9).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear9) ? dosaYear9 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear9) ? dosYear9 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear9) ? eosYear9 : (int?)null));

                TrWorksheet.Cells[$"A{trRowIndex}"].Value = inventory.MaintenanceZone;
                TrWorksheet.Cells[$"B{trRowIndex}"].Value = inventory.Configuration;
                TrWorksheet.Cells[$"C{trRowIndex}"].Value = inventory.Reference;
                TrWorksheet.Cells[$"D{trRowIndex}"].Value = inventory.Name;
                TrWorksheet.Cells[$"E{trRowIndex}"].Value = inventory.DeviceType;
                TrWorksheet.Cells[$"F{trRowIndex}"].Value = inventory.Range;
                TrWorksheet.Cells[$"G{trRowIndex}"].Value = inventory.Quantity;

                TrWorksheet.Cells[$"H{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(yearColor.A, yearColor.R, yearColor.G, yearColor.B);
                TrWorksheet.Cells[$"I{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year1Color.A, year1Color.R, year1Color.G, year1Color.B);
                TrWorksheet.Cells[$"J{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year2Color.A, year2Color.R, year2Color.G, year2Color.B);
                TrWorksheet.Cells[$"K{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year3Color.A, year3Color.R, year3Color.G, year3Color.B);
                TrWorksheet.Cells[$"L{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year4Color.A, year4Color.R, year4Color.G, year4Color.B);
                TrWorksheet.Cells[$"M{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year5Color.A, year5Color.R, year5Color.G, year5Color.B);
                TrWorksheet.Cells[$"N{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year6Color.A, year6Color.R, year6Color.G, year6Color.B);
                TrWorksheet.Cells[$"O{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year7Color.A, year7Color.R, year7Color.G, year7Color.B);
                TrWorksheet.Cells[$"P{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year8Color.A, year8Color.R, year8Color.G, year8Color.B);
                TrWorksheet.Cells[$"Q{trRowIndex}"].FillColor = System.Drawing.Color.FromArgb(year9Color.A, year9Color.R, year9Color.G, year9Color.B);
            }

            var trRange = TrWorksheet.Range[$"A1:Q{TrInventories.Count + 1}"];
            trRange.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Medium);
            TrWorksheet.Columns.AutoFit(0, TrWorksheet.Columns.LastUsedIndex);
        }

        /// <summary>
        /// Creates the tr reference data.
        /// </summary>
        /// <param name="TrInventories">The tr inventories.</param>
        private void CreateTrReferenceData(List<Inventory> TrInventories)
        {
            for (int i = 0; i < refList.Count; i++)
            {
                var count = 0;
                var tempRef = refList[i];
                foreach (var inventory in TrInventories)
                {

                    if (tempRef == inventory.Reference)
                    {
                        count += inventory.Quantity;
                    }
                }
                if (refTrData.ContainsKey(tempRef))
                {
                    continue;
                }
                refTrData.Add(tempRef, count);
            }
        }

        /// <summary>
        /// Fills the ib data.
        /// </summary>
        /// <param name="IbInventories">The ib inventories.</param>
        /// <param name="IbWorksheet">The ib worksheet.</param>
        private void FillIbData(List<Inventory> IbInventories, Worksheet IbWorksheet)
        {
            CreateIbReferenceData(IbInventories);
            CreateIbHeader(IbWorksheet);
            var rowIndex = 1;
            foreach (var inventory in IbInventories)
            {
                rowIndex++;

                var yearColor = (Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.Year,
                    int.TryParse(inventory.Dosa, out var dosaYear) ? dosaYear : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear) ? dosYear : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear) ? eosYear : (int?)null));

                var year1Color = (Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(1).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear1) ? dosaYear1 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear1) ? dosYear1 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear1) ? eosYear1 : (int?)null));

                var year2Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(2).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear2) ? dosaYear2 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear2) ? dosYear2 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear2) ? eosYear2 : (int?)null));

                var year3Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(3).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear3) ? dosaYear3 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear3) ? dosYear3 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear3) ? eosYear3 : (int?)null));

                var year4Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(4).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear4) ? dosaYear4 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear4) ? dosYear4 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear4) ? eosYear4 : (int?)null));

                var year5Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(5).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear5) ? dosaYear5 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear5) ? dosYear5 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear5) ? eosYear5 : (int?)null));

                var year6Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(6).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear6) ? dosaYear6 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear6) ? dosYear6 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear6) ? eosYear6 : (int?)null));

                var year7Color = (System.Windows.Media.Color)ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(7).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear7) ? dosaYear7 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear7) ? dosYear7 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear7) ? eosYear7 : (int?)null));

                var year8Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(8).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear8) ? dosaYear8 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear8) ? dosYear8 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear8) ? eosYear8 : (int?)null));

                var year9Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(9).Year,
                    int.TryParse(inventory.Dosa, out var dosaYear9) ? dosaYear9 : (int?)null,
                    int.TryParse(inventory.DoS, out var dosYear9) ? dosYear9 : (int?)null,
                    int.TryParse(inventory.EoS, out var eosYear9) ? eosYear9 : (int?)null));

                IbWorksheet.Cells[$"A{rowIndex}"].Value = inventory.Factory;
                IbWorksheet.Cells[$"B{rowIndex}"].Value = inventory.Workshop;
                IbWorksheet.Cells[$"C{rowIndex}"].Value = inventory.Line;
                IbWorksheet.Cells[$"D{rowIndex}"].Value = inventory.Machine;
                IbWorksheet.Cells[$"E{rowIndex}"].Value = inventory.Criticality ?? CriticalitystringValues.NotCritical;
                IbWorksheet.Cells[$"F{rowIndex}"].Value = inventory.Configuration;
                IbWorksheet.Cells[$"G{rowIndex}"].Value = inventory.ConfigType;
                IbWorksheet.Cells[$"H{rowIndex}"].Value = inventory.Reference;
                IbWorksheet.Cells[$"I{rowIndex}"].Value = inventory.Name;
                IbWorksheet.Cells[$"J{rowIndex}"].Value = inventory.DeviceType;
                IbWorksheet.Cells[$"K{rowIndex}"].Value = inventory.Range;
                IbWorksheet.Cells[$"L{rowIndex}"].Value = inventory.Quantity;

                IbWorksheet.Cells[$"M{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(yearColor.A, yearColor.R, yearColor.G, yearColor.B);
                IbWorksheet.Cells[$"N{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year1Color.A, year1Color.R, year1Color.G, year1Color.B);
                IbWorksheet.Cells[$"O{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year2Color.A, year2Color.R, year2Color.G, year2Color.B);
                IbWorksheet.Cells[$"P{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year3Color.A, year3Color.R, year3Color.G, year3Color.B);
                IbWorksheet.Cells[$"Q{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year4Color.A, year4Color.R, year4Color.G, year4Color.B);
                IbWorksheet.Cells[$"R{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year5Color.A, year5Color.R, year5Color.G, year5Color.B);
                IbWorksheet.Cells[$"S{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year6Color.A, year6Color.R, year6Color.G, year6Color.B);
                IbWorksheet.Cells[$"T{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year7Color.A, year7Color.R, year7Color.G, year7Color.B);
                IbWorksheet.Cells[$"U{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year8Color.A, year8Color.R, year8Color.G, year8Color.B);
                IbWorksheet.Cells[$"V{rowIndex}"].FillColor = System.Drawing.Color.FromArgb(year9Color.A, year9Color.R, year9Color.G, year9Color.B);
            }
            var range = IbWorksheet.Range[$"A1:V{IbInventories.Count + 1}"];
            range.Borders.SetAllBorders(System.Drawing.Color.Black, BorderLineStyle.Medium);
            IbWorksheet.Columns.AutoFit(0, IbWorksheet.Columns.LastUsedIndex);
        }

        /// <summary>
        /// Creates the ib reference data.
        /// </summary>
        /// <param name="IbInventories">The ib inventories.</param>
        private void CreateIbReferenceData(List<Inventory> IbInventories)
        {
            for (int i = 0; i < IbInventories.Count; i++)
            {
                var count = 0;
                var tempRef = IbInventories[i].Reference;
                foreach (var inventory in IbInventories)
                {

                    if (tempRef == inventory.Reference)
                    {
                        count += inventory.Quantity;
                    }
                }
                if (refIbData.ContainsKey(tempRef))
                {
                    continue;
                }
                refIbData.Add(tempRef, count);
            }
            refList = refIbData.Keys.ToList();
        }

        /// <summary>
        /// Creates the header.
        /// </summary>
        /// <param name="worksheet">The worksheet.</param>
        private static void CreateIbHeader(Worksheet worksheet)
        {            
            worksheet.Cells["A1"].Value = "Factory";
            worksheet.Cells["B1"].Value = "Workshop";
            worksheet.Cells["C1"].Value = "Line";
            worksheet.Cells["D1"].Value = "Machine";
            worksheet.Cells["E1"].Value = "Machine Criticality";
            worksheet.Cells["F1"].Value = "Configuration";
            worksheet.Cells["G1"].Value = "Config. type";
            worksheet.Cells["H1"].Value = "Reference";
            worksheet.Cells["I1"].Value = "Description";
            worksheet.Cells["J1"].Value = "Device-Type";
            worksheet.Cells["K1"].Value = "Range";
            worksheet.Cells["L1"].Value = "Quantity";
            worksheet.Cells["M1"].Value = DateTime.Today.Year;
            worksheet.Cells["N1"].Value = DateTime.Today.AddYears(1).Year;
            worksheet.Cells["O1"].Value = DateTime.Today.AddYears(2).Year;
            worksheet.Cells["P1"].Value = DateTime.Today.AddYears(3).Year;
            worksheet.Cells["Q1"].Value = DateTime.Today.AddYears(4).Year;
            worksheet.Cells["R1"].Value = DateTime.Today.AddYears(5).Year;
            worksheet.Cells["S1"].Value = DateTime.Today.AddYears(6).Year;
            worksheet.Cells["T1"].Value = DateTime.Today.AddYears(7).Year;
            worksheet.Cells["U1"].Value = DateTime.Today.AddYears(8).Year;
            worksheet.Cells["V1"].Value = DateTime.Today.AddYears(9).Year;

            worksheet.Range["A1:V1"].Font.Color = System.Drawing.Color.DodgerBlue;
            worksheet.Range["A1:V1"].Font.Bold = true;
        }
        /// <summary>
        /// Creates the tr header.
        /// </summary>
        /// <param name="worksheet">The worksheet.</param>
        private static void CreateTrHeader(Worksheet worksheet)
        {
            worksheet.Cells["A1"].Value = "Maintenance zone";
            worksheet.Cells["B1"].Value = "Configuration";            
            worksheet.Cells["C1"].Value = "Reference";
            worksheet.Cells["D1"].Value = "Description";
            worksheet.Cells["E1"].Value = "Device-Type";
            worksheet.Cells["F1"].Value = "Range";
            worksheet.Cells["G1"].Value = "Quantity";
            worksheet.Cells["H1"].Value = DateTime.Today.Year;
            worksheet.Cells["I1"].Value = DateTime.Today.AddYears(1).Year;
            worksheet.Cells["J1"].Value = DateTime.Today.AddYears(2).Year;
            worksheet.Cells["K1"].Value = DateTime.Today.AddYears(3).Year;
            worksheet.Cells["L1"].Value = DateTime.Today.AddYears(4).Year;
            worksheet.Cells["M1"].Value = DateTime.Today.AddYears(5).Year;
            worksheet.Cells["N1"].Value = DateTime.Today.AddYears(6).Year;
            worksheet.Cells["O1"].Value = DateTime.Today.AddYears(7).Year;
            worksheet.Cells["P1"].Value = DateTime.Today.AddYears(8).Year;
            worksheet.Cells["Q1"].Value = DateTime.Today.AddYears(9).Year;

            worksheet.Range["A1:Q1"].Font.Color = System.Drawing.Color.DodgerBlue;
            worksheet.Range["A1:Q1"].Font.Bold = true;
        }
    }
}