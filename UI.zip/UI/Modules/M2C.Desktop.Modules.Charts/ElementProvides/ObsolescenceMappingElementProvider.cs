﻿using DevExpress.Mvvm.Native;
using M2C.Business.Implementations;
using M2C.Business.Models;
using M2C.Business.Models.Chart;
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    public class ObsolescenceMappingElementProvider : IObsolescenceMappingElementProvider
    {
        /// <summary>
        /// Provide Colors
        /// </summary>
        private readonly IStatusColorProvider _colorProvider;

        public ObsolescenceMappingElementProvider(IStatusColorProvider colorProvider)
        {
            _colorProvider = colorProvider;
        }

        /// <summary>
        /// Creates the obsolescence mapping.
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetObsolescenceMapping(ChartParameter chartParameter, NodeType type = NodeType.OPEN_CONFIG)
        {
            var elements = new ChartBarElements();
            elements.GreenChartElements.Clear();
            elements.RedChartElements.Clear();
            elements.YellowChartElements.Clear();
            var nodeType = chartParameter.SelectedParameterNode.NodeType;
            var selectedNodes = chartParameter.SelectedParameterNode.Nodes;
            var allConfigurationNodes = chartParameter.AllParameterNodes
                .Where(conf => conf.NodeType == type).SelectMany(i => i.Nodes).ToList();

            // "#FFDC0A0A" //Red
            //"#FFFFD100" //Yellow
            //"#FF3DCD58" //Green

            var numberString = chartParameter.SelectedElementNumber; // total number selected by user...
            if (numberString == "All")// show all data
            {
                if (nodeType == type)
                {
                    foreach (var node in allConfigurationNodes)
                    {
                        BindObsolescenceMapping(node.Name, node.Inventories, elements, chartParameter);
                    }
                }
                else
                {
                    foreach (var node in selectedNodes)
                    {
                        var inventories = allConfigurationNodes.Where(i =>
                            i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                            i.ParentNodeAndNodeType[nodeType].Id == node.Id).SelectMany(i => i.Inventories).ToList();
                        BindObsolescenceMapping(node.Name, inventories, elements, chartParameter);
                    }
                }
            }
            else // find the user selection and loop till selection & rest added on Others
            {
                int.TryParse(numberString, out var num);
                int tempNum = 1;
                if (nodeType == type)
                {
                    foreach (var node in allConfigurationNodes)
                    {
                        BindObsolescenceMapping(tempNum < num ? node.Name : "Others", node.Inventories, elements, chartParameter);
                        tempNum++;
                    }
                }
                else
                {
                    foreach (var node in selectedNodes)
                    {
                        var inventories = allConfigurationNodes.Where(i =>
                            i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                            i.ParentNodeAndNodeType[nodeType].Id == node.Id).SelectMany(i => i.Inventories).ToList();
                        BindObsolescenceMapping(tempNum < num ? node.Name : "Others", inventories, elements, chartParameter);
                        tempNum++;
                    }
                }
            }

            return elements;
        }

        /// <summary>
        /// Binds the obsolescence mapping.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="inventories">The inventories.</param>
        /// <param name="chartBarElements"></param>
        /// <param name="chartParameter"></param>
        private void BindObsolescenceMapping(string name, ICollection<Inventory> inventories, ChartBarElements chartBarElements, ChartParameter chartParameter)
        {
            // added functionality in Obsolescence mapping , User can select Year
            var selectedYear = chartParameter.SelectedYear;
            // update all inventories data wrt to selectedYear
            inventories.ForEach(i => i.Year = _colorProvider.GetYearColor(selectedYear,
                int.TryParse(i.Dosa, out var dosa) ? dosa : (int?)null,
                int.TryParse(i.DoS, out var dos) ? dos : (int?)null,
                int.TryParse(i.EoS, out var eos) ? eos : (int?)null));

            var redChartBarElement = new ChartBarElement()
            {
                ConfigCount = inventories.Where(i => i.Year == "#FFDC0A0A").Sum(i => i.Quantity),
                Name = name
            };
            var yellowChartBarElement = new ChartBarElement()
            {
                ConfigCount = inventories.Where(i => i.Year == "#FFFFD100").Sum(i => i.Quantity),
                Name = name
            };
            var greenChartBarElement = new ChartBarElement()
            {
                ConfigCount = inventories.Where(i => i.Year == "#FF3DCD58").Sum(i => i.Quantity),
                Name = name
            };
            var redElement = chartBarElements.RedChartElements.FirstOrDefault(i => i.Name == redChartBarElement.Name);
            var yellowElement = chartBarElements.YellowChartElements.FirstOrDefault(i => i.Name == yellowChartBarElement.Name);
            var greenElement = chartBarElements.GreenChartElements.FirstOrDefault(i => i.Name == greenChartBarElement.Name);

            if (redElement == null)
                chartBarElements.RedChartElements.Add(redChartBarElement);
            else
                redElement.ConfigCount += redChartBarElement.ConfigCount;

            if (yellowElement == null)
                chartBarElements.YellowChartElements.Add(yellowChartBarElement);
            else
                yellowElement.ConfigCount += yellowChartBarElement.ConfigCount;

            if (greenElement == null)
                chartBarElements.GreenChartElements.Add(greenChartBarElement);
            else
                greenElement.ConfigCount += greenChartBarElement.ConfigCount;
        }
    }
}