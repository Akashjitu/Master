﻿using System;
using System.IO;
using M2C.Business;
using M2C.Business.Implementations;

namespace OneIBCatalogMigration
{
    internal class Program
    {
        private static void Main(string[] args)
        {
        var filePath =  Path.Combine(Environment.CurrentDirectory, @"Data\One IB Catalog_Mar_2020_V1.0.xlsx");
            BusinessService.Migrate();
            new ProductSync(null, null, null, null, null)
               .SyncProductDataAsync(filePath);
        }
    }
}