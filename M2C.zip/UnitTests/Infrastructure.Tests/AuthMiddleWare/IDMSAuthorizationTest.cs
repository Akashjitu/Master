﻿using AuthMiddleWare.Contracts;
using AuthMiddleWare.Implementations;
using AuthMiddleWare.Models;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RestClientServices.Contracts;
using System;

namespace Infrastructure.Tests.AuthMiddleWare
{
    [TestClass]
    public class IDMSAuthorizationTest
    {
        private MockRepository MockRepo { get; set; }
        private Mock<IRestServicesFactory> IRestServicesFactoryMock { get; set; }
        private Mock<IAuthService> IRestClientServiceMock { get; set; }

        [TestInitialize]
        public void TestIniTialize()
        {
            MockRepo = new MockRepository(MockBehavior.Loose);
            IRestClientServiceMock = MockRepo.Create<IAuthService>();

            IRestServicesFactoryMock = MockRepo.Create<IRestServicesFactory>();
            IRestServicesFactoryMock.Setup(x => x.GetRestClientService<IAuthService>(It.IsAny<RestServiceTypes>())).Returns(IRestClientServiceMock.Object);
        }

        [TestMethod]
        public void IDMSAuthorizationObject()
        {
            IAuthorization authobj = null;

            Action action = () =>
            {
                authobj = new IDMSAuthorization(IRestServicesFactoryMock.Object);
            };

            action.Should().NotThrow();
            authobj.Should().NotBeNull();
        }

        [TestMethod]
        public void GetDecodedTokenwithValidToken()
        {
            IAuthorization authobj = new IDMSAuthorization(IRestServicesFactoryMock.Object);

            TokenJsonModel tokenObj = authobj.GetDecodedToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InN1aml0aC50ZXN0MDAxQGdtYWlsLmNvbSIsImZlZGVyYXRlZElkIjoiZ2IwMDViYjEtNzcyMy0xZmQ1LWVkYzEtOWM2ZmQ4Y2UzMTlmIiwiZmlyc3ROYW1lIjoiU3VqaXRoIiwibGFzdE5hbWUiOiJTdXJlbmRyYW4iLCJndWlkIjoiNDVjMTFlNDctNzNkNy00NWFmLTllYmQtMDBlYTViZTU5YTMzIiwibmJmIjoxNTg1NjQ2Nzg0LCJleHAiOjE1ODYxNjUxODQsImlhdCI6MTU4NTY0Njc4NCwiaXNzIjoiaHR0cHM6Ly9zY2huZWlkZXItbTJjLWFwaXMtZGV2LmF6dXJld2Vic2l0ZXMubmV0L0F1dGgvVG9rZW4iLCJhdWQiOiJNMkMtUmVuZXdhbCJ9.u7UibUFHDsRMX9XU3US0Tedvcbls-XM1nA-n57-qoDE");

            tokenObj.Should().NotBeNull();
            tokenObj.Name.Should().NotBeNullOrEmpty();
            tokenObj.Email.Should().NotBeNullOrEmpty();
        }

        [TestMethod]
        public void GetDecodedTokenwithInValidToken()
        {
            IAuthorization authobj = new IDMSAuthorization(IRestServicesFactoryMock.Object);

            TokenJsonModel tokenObj = authobj.GetDecodedToken("mWzpE8d27c5eoOGzTvU-LFVz4k1dvpAgNT6EiKV1ifzBKOchoZ1ECozayyLQ8E9du8aMszX0JV4V5Ykr4Su_D-842uXDg");

            tokenObj.Should().NotBeNull();
            tokenObj.Name.Should().BeNullOrEmpty();
            tokenObj.Email.Should().BeNullOrEmpty();

            tokenObj = authobj.GetDecodedToken(string.Empty);

            tokenObj.Should().NotBeNull();
            tokenObj.Name.Should().BeNullOrEmpty();
            tokenObj.Email.Should().BeNullOrEmpty();

            tokenObj = authobj.GetDecodedToken("eyJraWQiOiIyMjIiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.emp.VxzoV9Sp_59aCsKvD269MvEoX53_ujqWxlb_PEITA3vUkBfWLz6L4Uel-7qg8ALz24yGxRWRi_kWgBv36yBSS8EGAZcpKixnsbLUtaffFvo1tAsDAGj6IyOfahnWAVWA6X5OET6xvMevJQMFWABosdvjLnmn8qDAlSajo9o-lWGNkhaDqEa71HQgPSZI7cB_ucQ0Uo6vaMSJKOTZxJB7_qbKAE3vIvr0epM6_lQmDqGW3EZ1C0J-RXxvQYrYgzCO3nhV2TfPtk8areK-G0jL-ZUU27FkGhEivSS-QknWxcouNku8YeRA8j3D76nob0eP7tANwaFs-a5z0sBx9kJ8YTbvm2DCWzJ1Pv2SRnIyhy3Vy8H1np937sIeYmctNU5bEdqfueIPTsp-HIlYe4gEpdmKNgIzcXoTsy7oKGPX6mbv9qbyIVK3ko1EEYz-aMftNplcOOJH71PSnNKs4lE0m7rIPNMvL-ViVyLs5XRJPlhdouWqsejeEYoQSpQjd6zhPYxUb9i5pK4865XTKy2TF2rxI807-8D-IrXRgdsrUHW_e9_pJlIUESAudwfnen-Y50igYs5qa2kdE-mWzpE8d27c5eoOGzTvU-LFVz4k1dvpAgNT6EiKV1ifzBKOchoZ1ECozayyLQ8E9du8aMszX0JV4V5Ykr4Su_D-842uXDg");

            tokenObj.Should().NotBeNull();
            tokenObj.Name.Should().BeNullOrEmpty();
            tokenObj.Email.Should().BeNullOrEmpty();
        }

        [TestMethod]
        public void validateTokenwithValidToken()
        {
            IAuthorization authobj = new IDMSAuthorization(IRestServicesFactoryMock.Object);
            IRestClientServiceMock.Setup(x => x.Execute<bool>(It.IsAny<IRestServiceRequest>())).Returns(true);

            bool result = authobj.ValidateToken("eyJraWQiOiIyMjIiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdF9oYXNoIjoiSDRmeWI5LURJRlNkRkE1WG5nUzlZQSIsInN1YiI6Imh0dHBzOi8vdGVzdC5zYWxlc2ZvcmNlLmNvbS9pZC8wMERnMDAwMDAwNkkwcERFQVMvMDA1ZzAwMDAwMDdBemFuQUFDIiwiem9uZWluZm8iOiJBbWVyaWNhL05ld19Zb3JrIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJhZGRyZXNzIjp7ImNvdW50cnkiOiJJTiJ9LCJwcm9maWxlIjoiaHR0cHM6Ly9zZS0tU0lUYkZPMTkuY3MxNy5teS5zYWxlc2ZvcmNlLmNvbS8wMDVnMDAwMDAwN0F6YW5BQUMiLCJpc3MiOiJodHRwczovL3NpdGJmbzE5LXNlY29tbXVuaXRpZXMuY3MxNy5mb3JjZS5jb20vaWRlbnRpdHkiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJzdWppdGgudGVzdDAwMUBnbWFpbC5jb20uYmZvLXBvcnRhbC5jb20uc2l0YmZvMTkiLCJnaXZlbl9uYW1lIjoiU3VqaXRoIiwibG9jYWxlIjoiZW5fSU4iLCJwaWN0dXJlIjoiaHR0cHM6Ly9zaXRiZm8xOS1zZWNvbW11bml0aWVzLmNzMTcuZm9yY2UuY29tL2ltZy91c2VycHJvZmlsZS9kZWZhdWx0X3Byb2ZpbGVfMjAwX3YyLnBuZyIsImN1c3RvbV9hdHRyaWJ1dGVzIjp7ImNvbnRhY3RHb2xkZW5JRCI6bnVsbCwiemlwQ29kZSI6bnVsbCwiYnVzaW5lc3NVbml0IjpudWxsLCJhaWxQcm9ncmFtcyI6bnVsbCwiY29tcGFueU5hbWUiOm51bGwsImpvYlRpdGxlIjpudWxsLCJjb3VudHkiOm51bGwsIm1hcmtldFN1YlNlZ21lbnQiOm51bGwsImFpbEZlYXR1cmVzIjpudWxsLCJzdWZmaXgiOm51bGwsImFpbEFwcGxpY2F0aW9ucyI6bnVsbCwiY29tcGFueVN0cmVldCI6bnVsbCwiZGl2aXNpb24iOm51bGwsImlkbXNGZWRlcmF0ZWRJZCI6ImdiMDA1YmIxLTc3MjMtMWZkNS1lZGMxLTljNmZkOGNlMzE5ZiIsImNvbXBhbnlQaG9uZSI6bnVsbCwiZmF4IjpudWxsLCJJc0VtYWlsVmVyaWZpZWQiOiJ0cnVlIiwiY2xhc3NMZXZlbDEiOm51bGwsImNvbXBhbnlDaXR5IjpudWxsLCJ0cnVzdFN0YXR1cyI6bnVsbCwiY2xhc3NMZXZlbDIiOm51bGwsInBPQm94IjpudWxsLCJjb250YWN0SWQiOm51bGwsImNvbXBhbnlaaXBDb2RlIjpudWxsLCJzdGF0ZU9yUHJvdmluY2VDb2RlIjpudWxsLCJsYW5ndWFnZUNvZGUiOiJFTiIsImlzSW50ZXJuYWwiOiJGQUxTRSIsImFjY291bnRJZCI6bnVsbCwiZmlyc3ROYW1lIjoiU3VqaXRoIiwibW9iaWxlUGhvbmUiOm51bGwsImVtcGxveWVlU2l6ZSI6bnVsbCwiY29tcGFueVBPQm94IjpudWxsLCJqb2JEZXNjcmlwdGlvbiI6bnVsbCwic2FsdXRhdGlvbiI6bnVsbCwibWFya2V0U2VydmVkIjpudWxsLCJyZWplY3Rpb25SZWFzb24iOm51bGwsImNvbXBhbnlBZGRpdGlvbmFsQWRkcmVzcyI6bnVsbCwiYW5udWFsUmV2ZW51ZSI6IjAiLCJjb21wYW55Q291bnRyeUNvZGUiOm51bGwsImxhc3ROYW1lIjoiU3VyZW5kcmFuIiwiYWNjb3VudEdvbGRlbklEIjpudWxsLCJhaWwiOm51bGwsImNpdHkiOm51bGwsImVtYWlsT3B0SW4iOiJVIiwidGl0bGUiOm51bGwsImNvbXBhbnlGZWRlcmF0aW9uSWQiOm51bGwsImFib3V0TWUiOm51bGwsImpvYkZ1bmN0aW9uIjpudWxsLCJpZGVudGl0eVR5cGUiOiJFbWFpbCIsImhlYWRxdWFydGVyIjoiZmFsc2UiLCJjb3VudHJ5Q29kZSI6IklOIiwic3RyZWV0IjpudWxsLCJjdXJyZW5jeSI6IkFSUyIsInJlamVjdGlvbkNvbW1lbnQiOm51bGwsImRlcGFydG1lbnQiOm51bGwsInVzZXJDb250ZXh0IjoiV29yayIsImVtYWlsIjoic3VqaXRoLnRlc3QwMDFAZ21haWwuY29tIiwibWFya2V0U2VnbWVudCI6bnVsbCwiaGFzaGVkUGluIjpudWxsLCJ0cnVzdExldmVsIjoiSXNQcml2YXRlIiwidXNlcklkIjoiMDA1ZzAwMDAwMDdBemFuQUFDIiwidGF4SWRlbnRpZmljYXRpb25OdW1iZXIiOm51bGwsImZlZGVyYXRlZElkIjoiZ2IwMDViYjEtNzcyMy0xZmQ1LWVkYzEtOWM2ZmQ4Y2UzMTlmIiwiY29tcGFueVN0YXRlT3JQcm92aW5jZUNvZGUiOm51bGwsIndvcmtQaG9uZSI6bnVsbCwibWlkZGxlTmFtZSI6bnVsbCwiYWRkaXRpb25hbEFkZHJlc3MiOm51bGwsImNvbXBhbnlDb3VudHkiOm51bGwsImNvbXBhbnlXZWJzaXRlIjpudWxsfSwiYXVkIjoiM01WRzlhaEdIcXAuazJfeFdvS1paS3pmcTNoR2RyV0hSUDBNWW9ZdzZFQ3FGV3NaQlhiRVJjQXpOZnIuSUlTM2xpZ3Fma0p4NVFXa1hjOU53VUZvMSIsInVwZGF0ZWRfYXQiOiIyMDIwLTAzLTIwVDA0OjIxOjUyWiIsIm5pY2tuYW1lIjoic3VqaXRoLnRlc3QwMDFAZ21haWwuY29tLmJmby1wb3J0YWwxNzQxOCIsIm5hbWUiOiJTdWppdGggU3VyZW5kcmFuIiwicGhvbmVfbnVtYmVyIjpudWxsLCJleHAiOjE1ODQ3MjY5ODMsImlhdCI6MTU4NDcyNjg2MywiZmFtaWx5X25hbWUiOiJTdXJlbmRyYW4iLCJlbWFpbCI6InN1aml0aC50ZXN0MDAxQGdtYWlsLmNvbSJ9.VxzoV9Sp_59aCsKvD269MvEoX53_ujqWxlb_PEITA3vUkBfWLz6L4Uel-7qg8ALz24yGxRWRi_kWgBv36yBSS8EGAZcpKixnsbLUtaffFvo1tAsDAGj6IyOfahnWAVWA6X5OET6xvMevJQMFWABosdvjLnmn8qDAlSajo9o-lWGNkhaDqEa71HQgPSZI7cB_ucQ0Uo6vaMSJKOTZxJB7_qbKAE3vIvr0epM6_lQmDqGW3EZ1C0J-RXxvQYrYgzCO3nhV2TfPtk8areK-G0jL-ZUU27FkGhEivSS-QknWxcouNku8YeRA8j3D76nob0eP7tANwaFs-a5z0sBx9kJ8YTbvm2DCWzJ1Pv2SRnIyhy3Vy8H1np937sIeYmctNU5bEdqfueIPTsp-HIlYe4gEpdmKNgIzcXoTsy7oKGPX6mbv9qbyIVK3ko1EEYz-aMftNplcOOJH71PSnNKs4lE0m7rIPNMvL-ViVyLs5XRJPlhdouWqsejeEYoQSpQjd6zhPYxUb9i5pK4865XTKy2TF2rxI807-8D-IrXRgdsrUHW_e9_pJlIUESAudwfnen-Y50igYs5qa2kdE-mWzpE8d27c5eoOGzTvU-LFVz4k1dvpAgNT6EiKV1ifzBKOchoZ1ECozayyLQ8E9du8aMszX0JV4V5Ykr4Su_D-842uXDg");

            result.Should().BeFalse();
        }

        [TestMethod]
        public void validateTokenwithinValidToken()
        {
            IAuthorization authobj = new IDMSAuthorization(IRestServicesFactoryMock.Object);
            IRestClientServiceMock.Setup(x => x.Execute<bool>(It.IsAny<IRestServiceRequest>())).Returns(true);

            bool result = authobj.ValidateToken("szX0JV4V5Ykr4Su_D-842uXDg");

            result.Should().BeFalse();
        }
    }
}