﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="OpenProjectDialogViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.Utils;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// OpenProjectDialog ViewModel
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    public class OpenProjectDialogViewModel : BindableBase, IDialogAware
    {
        #region PRIVATE FIELDS

        /// <summary>
        /// The projects
        /// </summary>
        private ObservableCollection<ProjectContextModel> _projects;

        /// <summary>
        /// The selected project
        /// </summary>
        private ProjectContextModel _selectedProject = null;

        /// <summary>
        /// The project logic
        /// </summary>
        private readonly IProjectLogic _projectLogic;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator eventAggregator;

        private readonly IDialogService _dialogService;

        private readonly InventoryDialogHelper inventoryDialogHelper;

        #endregion PRIVATE FIELDS

        #region PUBLIC FIELDS

        /// <summary>
        /// Gets or sets the projects.
        /// </summary>
        /// <value>The projects.</value>
        public ObservableCollection<ProjectContextModel> Projects
        {
            get => _projects;
            set => _projects = value;
        }

        /// <summary>
        /// Gets or sets the selected project.
        /// </summary>
        /// <value>The selected project.</value>
        public ProjectContextModel SelectedProject
        {
            get { return _selectedProject; }
            set { SetProperty(ref _selectedProject, value); }
        }

        /// <summary>
        /// Gets or sets the open command.
        /// </summary>
        /// <value>The open command.</value>
        public DelegateCommand OpenCommand { get; set; }

        #endregion PUBLIC FIELDS

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenProjectDialogViewModel" /> class.
        /// </summary>
        /// <param name="projectLogic">The project logic.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        public OpenProjectDialogViewModel(IProjectLogic projectLogic, IEventAggregator eventAggregator, IDialogService dialogService)
        {
            Projects = new ObservableCollection<ProjectContextModel>();
            inventoryDialogHelper = new InventoryDialogHelper(dialogService);
            //Read-only variables
            _projectLogic = projectLogic;
            this.eventAggregator = eventAggregator;
            this._dialogService = dialogService;
            OpenCommand = new DelegateCommand(OnOpenCommand, CanOpenCommand).ObservesProperty(() => SelectedProject);
        }

        /// <summary>
        /// Determines whether this instance [can open command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can open command]; otherwise, <c>false</c>.</returns>
        private bool CanOpenCommand()
        {
            return (SelectedProject != null);
        }

        /// <summary>
        /// Ons the open command.
        /// </summary>
        private void OnOpenCommand()
        {
            IDialogParameters dialogParameters = new DialogParameters();
            bool IsUpdateNeeded = false;

            if (SelectedProject.ProjectId == null) return;

            if (!_projectLogic.CheckProjectIsUpdated(SelectedProject))
            {
                if (MessageBox.Show("New Product updates are available. Do you want to Proceed ? ", "Project Update",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    //Modal pop-up call back from Business layer
                    _projectLogic.UpdateInventoryCallback = (IReadOnlyCollection<string> messages) =>
                    {
                        IsUpdateNeeded = inventoryDialogHelper.ShowMessages(messages);
                        return IsUpdateNeeded;
                    };
                    IsUpdateNeeded = true;
                }
                else
                {
                    _projectLogic.UpdateInventoryCallback = null;
                    IsUpdateNeeded = false;
                }
            }
            else
            {
                _projectLogic.UpdateInventoryCallback = null;
            }

            var inventoryProject = _projectLogic.GetProject(SelectedProject.ProjectId.Value);

            if (inventoryProject == null)
            {
                MessageBox.Show("Project not Found.", "Information", MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }
            //Need to get a feed back from UpdateInventoryCallback
            if (IsUpdateNeeded)
            {
                inventoryProject.Version = _projectLogic.getSyncHistoryLatestVersion();
            }
            dialogParameters.Add("data", inventoryProject);
            _projectLogic.UpdateInventoryCallback = null; //reset handler
            RaiseRequestClose(new DialogResult(ButtonResult.OK, dialogParameters));
        }

        #region DIALOG METHODS

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => "Open Project";

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
        }

        /// <summary>
        /// Called when the dialog is opened.
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            try
            {
                Projects.AddRange(_projectLogic.GetProjectsWithCustomers());
            }
            catch (Exception Ex)
            {
                var data = Ex.ToString();
            }
            finally
            {
            }
        }

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }

        #endregion DIALOG METHODS
    }

    /// <summary>
    /// Project Open Mode
    /// </summary>
    public enum ProjectOpenMode
    {
        /// <summary>
        /// The localstore
        /// </summary>
        LOCALSTORE,

        /// <summary>
        /// The file
        /// </summary>
        FILE
    }
}