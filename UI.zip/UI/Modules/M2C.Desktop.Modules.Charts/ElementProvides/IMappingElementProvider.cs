﻿using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    public interface IMappingElementProvider
    {
        /// <summary>
        /// Get Mapping Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        ChartBarElements GetMappingBarElements(ChartParameter chartParameter, NodeType type = NodeType.OPEN_CONFIG);
    }
}