﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="CriticalityControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class CriticalityControlViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    internal class CriticalityControlViewModel : BindableBase
    {
        /// <summary>
        /// Gets the dialog service.
        /// </summary>
        /// <value>The dialog service.</value>
        public IDialogService DialogService { get; }
        /// <summary>
        /// The selected node
        /// </summary>
        private static INode _selectedNode;
        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService _sharedContextService;
        /// <summary>
        /// The criticality
        /// </summary>
        private ObservableCollection<CriticalityModel> _criticality;

        /// <summary>
        /// Open Add criticality dialog box
        /// </summary>
        /// <value>The add criticality command.</value>
        public DelegateCommand AddCriticalityCommand { get; set; }

        /// <summary>
        /// Gets or sets the criticality.
        /// </summary>
        /// <value>The criticality.</value>
        public ObservableCollection<CriticalityModel> Criticality
        {
            get => _criticality;
            set => SetProperty(ref _criticality, value);
        }

        /// <summary>
        /// The context model
        /// </summary>
        private ProjectContextModel ContextModel;

        /// <summary>
        /// Initializes a new instance of the <see cref="CriticalityControlViewModel" /> class.
        /// </summary>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        public CriticalityControlViewModel(IDialogService dialogService, IEventAggregator eventAggregator, ISharedContextService sharedContextService)
        {
            DialogService = dialogService;
            eventAggregator.GetEvent<IBTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            AddCriticalityCommand = new DelegateCommand(AddCriticality);
            Criticality = new ObservableCollection<CriticalityModel>();
            this._sharedContextService = sharedContextService;
            ContextModel = this._sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
        }
        /// <summary>
        /// Add criticality function
        /// </summary>
        private void AddCriticality()
        {
            //Nitin / Rick point - 11 - Removed "Alert - Criticality - Inventory is missing" message box
            //if (_selectedNode.Inventories == null || !_selectedNode.Inventories.Any())
            //{
            //    MessageBox.Show($"Inventory is missing.", "Alert - Criticality", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            //}
            //else
            {
                var param = new DialogParameters { { "Criticality", Criticality } };
                DialogService.ShowDialog(CollectionConstant.CriticalityDialog, param, CloseCriticalityDialogCallback);
            }
        }
        /// <summary>
        /// node selection event handler
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnNodeSelectionChanged(INode node)
        {
            _selectedNode = node;

            if (_selectedNode is ICriticality)
            {
                if ((_selectedNode as ICriticality)?.CriticalityParameters == null)

                {
                    ((ICriticality) _selectedNode).CriticalityParameters = new CriticalityModel()
                    {
                        SafetyIssue = CriticalitystringValues.LOW_RISK,
                        QualityIssue = CriticalitystringValues.LOW_IMPACT,
                        LeadTimeIssue = CriticalitystringValues.LOW_IMPACT,
                        CostsIssue = CriticalitystringValues.LOW_IMPACT,
                        SelectedValue = CriticalitystringValues.NotCritical
                    };

                    Criticality.Clear();
                    Criticality.Add((_selectedNode as ICriticality)?.CriticalityParameters);

                    foreach (var machine in ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.MachineNodes))
                    {
                        if (machine.Id == ((MachineNode)_selectedNode).Id)
                        {
                            machine.CriticalityParameters = (_selectedNode as ICriticality)?.CriticalityParameters;
                        }
                    }

                    foreach (var machine in ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.LineNodes).SelectMany(x => x.MachineNodes))
                    {
                        if (machine.Id == ((MachineNode)_selectedNode).Id)
                        {
                            machine.CriticalityParameters = (_selectedNode as ICriticality)?.CriticalityParameters;
                        }
                    }
                    if (_selectedNode.Inventories != null && _selectedNode.Inventories.Any() && Criticality != null)
                        _selectedNode.Inventories.ToList().ForEach(inventorie => inventorie.Criticality = (Criticality.Select(i => i.SelectedValue).FirstOrDefault()));
                }
                else
                {
                    Criticality.Clear();
                    Criticality.Add((_selectedNode as ICriticality)?.CriticalityParameters);
                    if (_selectedNode.Inventories != null && _selectedNode.Inventories.Any() && Criticality != null)
                        _selectedNode.Inventories.ToList().ForEach(inventorie => inventorie.Criticality = (Criticality.Select(i => i.SelectedValue).FirstOrDefault()));
                }
            }
        }
        /// <summary>
        /// call back function
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        private void CloseCriticalityDialogCallback(IDialogResult dialogResult)
        {
            if (dialogResult.Result != ButtonResult.OK)
                return;

            if (dialogResult.Parameters.TryGetValue(CollectionConstant.Add, out CriticalityModel criticality))
            {
                if (criticality != null)
                {
                    Criticality.Clear();
                    Criticality.Add(criticality);

                    ((ICriticality) _selectedNode).CriticalityParameters = criticality;

                   
                    foreach (var machine in ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.MachineNodes))
                    {
                        if (machine.Id == ((MachineNode)_selectedNode).Id)
                        {
                            machine.CriticalityParameters = criticality;
                        }
                    }

                    foreach (var machine in ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.LineNodes).SelectMany(x => x.MachineNodes))
                    {
                        if (machine.Id == ((MachineNode)_selectedNode).Id)
                        {
                            machine.CriticalityParameters = criticality;
                        }
                    }
                   
                    if (_selectedNode.Inventories != null && _selectedNode.Inventories.Any() && criticality != null)
                        _selectedNode.Inventories.ToList().ForEach(inventorie => inventorie.Criticality = criticality.SelectedValue);
                }
            }
        }
    }
}