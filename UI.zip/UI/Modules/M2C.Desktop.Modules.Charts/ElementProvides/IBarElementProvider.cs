﻿using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    public interface IBarElementProvider
    {
        /// <summary>
        /// Get Configuration Mapping Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        ChartBarElements GetConfigurationMappingElements(ChartParameter chartParameter, NodeType type = NodeType.OPEN_CONFIG);

        /// <summary>
        /// Get Mapping Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        ChartBarElements GetMappingBarElements(ChartParameter chartParameter,
            NodeType type = NodeType.OPEN_CONFIG);

        /// <summary>
        /// Get Obsolescence Chart Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        ChartBarElements GetObsolescenceChartElements(ChartParameter chartParameter,
            NodeType type = NodeType.OPEN_CONFIG);

        /// <summary>
        /// Get Obsolescence Chart Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        ChartBarElements GetbsolescenceMapping(ChartParameter chartParameter,
            NodeType type = NodeType.OPEN_CONFIG);

        /// <summary>
        /// Get Criticality Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        ChartBarElements GetCriticalityBarElements(ChartParameter chartParameter);
    }
}