﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="MainWindow.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************

using M2C.Desktop.App.ViewModels;
using System;
using System.Threading;
using System.Windows;
using DocumentFormat.OpenXml.Drawing.Charts;

namespace M2C.Desktop.App.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// The new window thread
        /// </summary>
        private Thread newWindowThread = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindow" /> class.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
        }

        /// <summary>
        /// Handles the <see cref="E:UnhandledException" /> event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="args">The <see cref="UnhandledExceptionEventArgs" /> instance containing the event data.</param>
        private static void OnUnhandledException(object sender, UnhandledExceptionEventArgs args)
        {
            var e = (Exception)args?.ExceptionObject;
            if (e != null)
                MessageBox.Show(e.Message, "Unhandled Exception", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        /// <summary>
        /// Handles the Loaded event of the Window control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ((MainWindowViewModel) this.DataContext).LoadingWindowStateChange += MainWindow_LoadingWindowStateChange;
        }

        /// <summary>
        /// Mains the window loading window state change.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="eventValue">if set to <c>true</c> [event value].</param>
        private void MainWindow_LoadingWindowStateChange(object sender, bool eventValue)
        {
            try
            {
                if (eventValue)
                {
                    newWindowThread = new Thread(new ThreadStart(() => { ThreadStartingPoint(this); }));
                    newWindowThread.SetApartmentState(ApartmentState.STA);
                    newWindowThread.IsBackground = true;

                    newWindowThread.Start();
                }
                else
                {
                    //needed wait for thread grooming
                    Thread.Sleep(2000);
                    if (newWindowThread.ThreadState == ThreadState.Background)
                    {
                        _tempWindow.Dispatcher.BeginInvoke((Action)_tempWindow.Close);
                    }
                }
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// The temporary window
        /// </summary>
        private LoadingWindow _tempWindow = null;

        /// <summary>
        /// Threads the starting point.
        /// </summary>
        /// <param name="parent">The parent.</param>
        private void ThreadStartingPoint(Window parent)
        {
            try
            {
                _tempWindow = new LoadingWindow(parent);
                _tempWindow.Closed += OnTempClosed;

                _tempWindow.Show();
                System.Windows.Threading.Dispatcher.Run();
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// Handles the <see cref="E:TempClosed" /> event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void OnTempClosed(object sender, EventArgs e)
        {
            try
            {
                System.Windows.Threading.Dispatcher.FromThread(newWindowThread)?.InvokeShutdown();
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// Handles the SizeChanged event of the Window control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs" /> instance containing the event data.</param>
        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
        }
    }
}