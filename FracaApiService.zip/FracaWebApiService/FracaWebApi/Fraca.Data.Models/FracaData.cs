﻿using System.Collections.Generic;


namespace Fraca.Data.Models
{
    public class FracaData
    {
        public List<FracaInfo> FracaInfo { get; set; }
        public string UserName { get; set; }
}
}
