﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IChildNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using Newtonsoft.Json;
using System.Windows.Data;

namespace M2C.Business.Models.Project.IBComponents
{

    /// <summary>
    /// Interface for having heterogeneous Child node
    /// </summary>
    public interface IChildNode
    {
        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        CompositeCollection ChildNodes
        {
            get;
        }
    }
}