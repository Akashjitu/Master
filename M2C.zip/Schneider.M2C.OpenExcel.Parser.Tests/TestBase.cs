﻿using Moq;
using System;
using System.Collections.Generic;
using System.Text;

namespace Schneider.M2C.OpenExcel.Parser.Tests
{
    public class TestBase
    {
        protected MockRepository MockRepo;

        public TestBase()
        {
            MockRepo = new MockRepository(MockBehavior.Loose);
        }
    }
}
