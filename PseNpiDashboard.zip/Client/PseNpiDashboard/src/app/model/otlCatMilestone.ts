export interface OtlCatMilestone {
    id:            number;
    keyCode:       string;
    programName:   string;
    sbu:          string;
    gbe:           string;
    EseBaseLine:   Date;
    EseActual:     Date;
    updatedDate:   Date;
    updatedBy:    string;
    active:        string;
    createdDate: Date;   
    createBy: string;   
   
}