
import { DatePipe } from '@angular/common';

export class EffectivenessPartsListColumns {
constructor(private datePipe: DatePipe){}

       

    static  columns =
     [
        { field: 'id',                              colId: 	    'id',	                   		hide: true,	    headerName: 	'Id',	},
        { field: 'keyCode',                        colId: 	'keyCode',	               	hide: false,	headerName: 	'Key Code',	},
        { field: 'programName',                      colId: 	'programName',	       			hide: false,	headerName: 	'Program Name',	},
        { field: 'partIndex',                     colId: 	    'partIndex',			        hide: false,	headerName: 	'Part Index',	},
        { field: 'partNumber',                        colId: 	'partNumber',	               	hide: false,	    headerName: 	'Part Number',	},
        { field: 'updatedpartNumber',                             colId: 	'updatedpartNumber',			                hide: false,	headerName: 	'Updated Part Number',	},
        { field: 'partNumberDescription',             colId: 	 'partNumberDescription',	       			        hide: true,	headerName: 	'Part Number Description',	},
        { field: 'otlGraduation',                               colId: 	'otlGraduation',	   			            hide: true,	headerName: 	'Otl Graduation',	},

        { field: 'makeBuy',                    colId: 	'makeBuy',	            hide: false,	headerName: 	'Make/Buy',	},
        { field: 'productionSite',                             colId: 	'productionSite',		 hide: false,	headerName: 	'Production Site',	},
        { field: 'sbu',                    colId: 	 'sbu',	       			        hide: false,	headerName: 	'SBU',	},
        { field: 'gbe',                           colId: 	'gbe',	   			            hide: false,	headerName: 	'GBE',	},
        { field: 'notes',                    colId: 	'notes',	            hide: false,	headerName: 	'Notes',	
         cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }},
        { field: 'updatedDate',                    colId: 	'updatedDate',	            hide: true,	headerName: 	'Updated Date',	},
        { field: 'updatedBy',                    colId: 	'updatedBy',	            hide: true,	headerName: 	'Updated By',	},
        { field: 'active',                    colId: 	'active',	            hide: true,	headerName: 	'Active',	},
        { field: 'createdDate',                    colId: 	'createdDate',	            hide: true,	headerName: 	'Created Date',	},
        { field: 'createBy',                    colId: 	'createBy',	            hide: true,	headerName: 	'Create By',	},
    ];

}

      	
