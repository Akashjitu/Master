using AppConfiguration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RestClientServices;
using RestClientServices.Contracts;
using RestClientServices.Services;
using RestSharp;
using SyncServiceLibrary.Model;
using System.Collections.Generic;
using System.Linq;

namespace SyncServiceLibrary.Tests
{
    [TestClass]
    public class RestServiceTest : TestBase
    {
        
    }
}