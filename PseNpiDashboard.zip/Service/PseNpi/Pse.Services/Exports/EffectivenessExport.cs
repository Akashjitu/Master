﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;
using System;

namespace Pse.Services.ExcelExports
{
    public class EffectivenessDataAccess : IEffectivenessExports
    {
        public byte[] Export(List<Effectiveness> effectiveness)
        {
            throw new NotImplementedException();
        }
    }
}