﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProductDbContext.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DataRepository.Seeds;
using DomainModels.Common;
using DomainModels.IbCatalogFilter;
using DomainModels.IbCatalogModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;

namespace DataRepository
{
    /// <summary>
    /// Product database context class
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ProductDbContext : DbContext, IProductDbContext
    {
        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public DbSet<Product> Products { get; set; }

        /// <summary>
        /// Gets or sets the filter ib catalog bus.
        /// </summary>
        /// <value>The filter ib catalog bus.</value>
        public DbSet<FilterIbCatalogBu> FilterIbCatalogBus { get; set; }

        /// <summary>
        /// Gets or sets the filter ib catalog product categories.
        /// </summary>
        /// <value>The filter ib catalog product categories.</value>
        public DbSet<FilterIbCatalogProductCategory> FilterIbCatalogProductCategories { get; set; }

        /// <summary>
        /// Gets or sets the filter ib catalog status ip creations.
        /// </summary>
        /// <value>The filter ib catalog status ip creations.</value>
        public DbSet<FilterIbCatalogStatusIpCreation> FilterIbCatalogStatusIpCreations { get; set; }

        /// <summary>
        /// Gets or sets the brands.
        /// </summary>
        /// <value>The brands.</value>
        public DbSet<Brand> Brands { get; set; }

        /// <summary>
        /// Gets or sets the device types.
        /// </summary>
        /// <value>The device types.</value>
        public DbSet<DeviceType> DeviceTypes { get; set; }

        /// <summary>
        /// Gets or sets the ranges.
        /// </summary>
        /// <value>The ranges.</value>
        public DbSet<Range> Ranges { get; set; }

        /// <summary>
        /// Gets or sets the sub ranges.
        /// </summary>
        /// <value>The sub ranges.</value>
        public DbSet<SubRange> SubRanges { get; set; }

        /// <summary>
        /// Gets or sets the product entries.
        /// </summary>
        /// <value>The product entries.</value>
        public DbSet<ProductEntry> ProductEntries { get; set; }

        /// <summary>
        /// Gets or sets the SyncHistories.
        /// </summary>
        /// <value>The SyncHistories.</value>
        public DbSet<SyncHistory> SyncHistories { get; set; }

        /// <summary>
        /// Migrates this instance.
        /// </summary>
        public void Migrate()
        {
            string sourcepath = $"{System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly()?.Location)}\\Data\\M2CRenewalProduct.db";

            string targetPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\schneider electric\\m2c Renewal\\";
            if (!Directory.Exists(targetPath))
            { Directory.CreateDirectory(targetPath); }

            if (!File.Exists(targetPath + "\\M2CRenewalProduct.db") && File.Exists(sourcepath))
            {
                File.Copy(sourcepath, targetPath + "\\M2CRenewalProduct.db", true);
            }

            if (Database.GetPendingMigrations().Count() > 0)
            {
                Database.Migrate();
            }
        }

        /// <summary>
        /// <para>
        /// Saves all changes made in this context to the database.
        /// </para>
        /// <para>
        /// This method will automatically call <see cref="M:Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.DetectChanges" /> to discover any
        /// changes to entity instances before saving to the underlying database. This can be disabled via
        /// <see cref="P:Microsoft.EntityFrameworkCore.ChangeTracking.ChangeTracker.AutoDetectChangesEnabled" />.
        /// </para>
        /// </summary>
        /// <returns>The number of state entries written to the database.</returns>
        int IDbContext.SaveChanges()
        {
            var entries = ChangeTracker
                .Entries()
                .Where(e => e.Entity is ChangeTrack && (
                                e.State == EntityState.Added
                                || e.State == EntityState.Modified));

            foreach (var entityEntry in entries)
            {
                if (entityEntry.State == EntityState.Added) ((ChangeTrack)entityEntry.Entity).CreatedOn = DateTime.Now;

                ((ChangeTrack)entityEntry.Entity).ModifiedOn = DateTime.Now;
            }

            return SaveChanges();
        }

        /// <summary>
        /// <para>
        /// Override this method to configure the database (and other options) to be used for this context.
        /// This method is called for each instance of the context that is created.
        /// The base implementation does nothing.
        /// </para>
        /// <para>
        /// In situations where an instance of <see cref="T:Microsoft.EntityFrameworkCore.DbContextOptions" /> may or may not have been passed
        /// to the constructor, you can use <see cref="P:Microsoft.EntityFrameworkCore.DbContextOptionsBuilder.IsConfigured" /> to determine if
        /// the options have already been set, and skip some or all of the logic in
        /// <see cref="M:Microsoft.EntityFrameworkCore.DbContext.OnConfiguring(Microsoft.EntityFrameworkCore.DbContextOptionsBuilder)" />.
        /// </para>
        /// </summary>
        /// <param name="optionsBuilder">A builder used to create or modify options for this context. Databases (and other extensions)
        /// typically define extension methods on this object that allow you to configure the context.</param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var dbpath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\schneider electric\\m2c Renewal\\";
            if (!Directory.Exists(dbpath)) Directory.CreateDirectory(dbpath);
            optionsBuilder.UseSqlite("Data Source = " + dbpath + "\\M2CRenewalProduct.db");
            base.OnConfiguring(optionsBuilder);
        }

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="builder">The builder.</param>
        protected override void OnModelCreating(ModelBuilder builder)
        {
            Range.OnModelCreating(builder);
            Brand.OnModelCreating(builder);
            DeviceType.OnModelCreating(builder);
            Product.OnModelCreating(builder);
            ProductEntry.OnModelCreating(builder);
            SubRange.OnModelCreating(builder);
            FilterIbCatalogBu.OnModelCreating(builder);
            FilterIbCatalogStatusIpCreation.OnModelCreating(builder);
            FilterIbCatalogProductCategory.OnModelCreating(builder);
            new FilterIbCatalogStatusIpCreationSeed().Seed(builder);
            new FilterIbCatalogBuSeed().Seed(builder);
            new FilterIbCatalogProductCategorySeed().Seed(builder);
            new SyncHistorySeed().Seed(builder);
            base.OnModelCreating(builder);
        }
    }
}