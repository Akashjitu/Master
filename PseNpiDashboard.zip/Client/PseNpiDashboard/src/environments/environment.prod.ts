export const environment = {
  production: true,
  apiBaseUrl: 'http://approvalworkflowtool.honeywell.com/PseNpdDashBoardService/api/',
  fileBaseUrl: 'http://approvalworkflowtool.honeywell.com/PseNpdDashBoardService/'
};
