﻿using System;

namespace Data.Management.Data.Models.Attributes
{
    public class ExportColumn : Attribute
    {
        public string ColumnCaption;
        public bool IsColumnHide = false;
        public bool IsColumnRemoved = false;

        /// <summary>
        /// Set Functionality for Export
        /// </summary>
        /// <param name="columnCaption"> Empty Caption will set default Caption </param>
        /// <param name="isHidden">Option for Hide Column </param>
        public ExportColumn(bool isColumnRemoved = false, bool isHidden =false, string columnCaption = "")
        {
            IsColumnHide = isHidden;
            ColumnCaption = columnCaption;
            IsColumnRemoved = isColumnRemoved;
        }
    }
}