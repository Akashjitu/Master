﻿using Pse.Data.Models;
using Pse.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class ComplianceController : ApiController
    {

        ISpeService _service;
        public ComplianceController(ISpeService service)
        {
            _service = service;

        }

        [HttpGet]
        public HttpResponseMessage GetCompliance(string createDon)
        {
           // DateTime dt;
           //if(! DateTime.TryParse(createDon, out dt))
           //     return    Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);
        

        int k = 1;
            var cp = _service.LoadCompliance();
            
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        public HttpResponseMessage SaveCompliance(Compliance[] compliance)
        {
            var cp = _service.SubmitCompliances(compliance.ToList());


            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}
