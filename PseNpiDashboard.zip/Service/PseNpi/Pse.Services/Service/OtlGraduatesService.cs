﻿using Pse.Data.Models;
using Pse.Services.Manager;
using System;
using System.Collections.Generic;

namespace Pse.Services.Service
{
    public class OtlGraduatesService : IOtlGraduatesService
    {
        private readonly IOtlGraduatesManager _manager;

        public OtlGraduatesService(IOtlGraduatesManager manager)
        {
            _manager = manager;
        }

        public OtlGraduate AddOtlGraduate(OtlGraduate otlGraduate)
        {
            return _manager.AddOtlGraduate(otlGraduate);
        }

        public List<OtlGraduate> LoadAllOtlGraduates()
        {
            return _manager.LoadAllOtlGraduates();
        }

        public List<OtlGraduate> LoadGraduatesByCreationDate(DateTime creationDate)
        {
            return _manager.LoadGraduatesByCreationDate(creationDate);
        }

        public List<OtlGraduate> LoadLatestOtlGraduates()
        {
            return _manager.LoadLatestOtlGraduates();
        }


        public List<OtlGraduate> LoadOtlGraduatesById(int Id)
        {
            return _manager.LoadOtlGraduatesById(Id);
        }

        public List<OtlGraduate> LoadOtlGraduatesByKeyCode(string keycode)
        {
            return _manager.LoadOtlGraduatesByKeyCode(keycode);
        }

        public OtlGraduate UpdateOtlGraduate(OtlGraduate otlGraduate)
        {
            return _manager.UpdateOtlGraduate(otlGraduate);
        }
    }
}