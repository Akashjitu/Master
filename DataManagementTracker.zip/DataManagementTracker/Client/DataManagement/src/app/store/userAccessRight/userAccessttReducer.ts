import { Action } from '@ngrx/store';
import * as UserAccesstAction from './userAccesstAction';
import { Employee } from 'src/app/model/employee';


export interface IAppState {
    readonly userAccess: Employee[];
}


export function userAccessReducer(state: Employee[] = [], action: UserAccesstAction.Actions) {

    switch (action.type) {

        case UserAccesstAction.ADD_USER_ACCESS: {

            
            return [...state, action.payload]

        }

        case UserAccesstAction.LOAD_USER_ACCESS: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case UserAccesstAction.UPDATE_USER_ACCESS: {
            const employee = (action.payload as Employee);
           
            const todo = state.find(t => t.id === employee.id);

            console.log("find "+JSON.stringify(todo));
            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                todo.displayName = employee.displayName,
                todo.accessType = employee.accessType
                todo.accessName = employee.accessName
                todo.id = employee.id
                todo.userName = employee.userName

                let sliceArray = state.splice(index, 1, todo);
               
               

               
            }
            
            return state.slice();
        }



        default:
            return state;
    }
}