﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CollectionConstant.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Desktop.Modules.Charts.Constants
{
    /// <summary>
    /// Class ChartConstant.
    /// </summary>
    public static class ChartConstant
    {

        /// <summary>
        /// The message select x axis type
        /// </summary>
        public const string MessageSelectXAxisType = "Please select any X-AxisType";
        /// <summary>
        /// The information
        /// </summary>
        public const string Information = "information";
    }
}