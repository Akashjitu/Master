﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Navigation
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 01-27-2020
// ***********************************************************************
// <copyright file="MainRibbonBar.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.Navigation.Views
{
    /// <summary>
    /// Interaction logic for MainRibbonBar.xaml
    /// </summary>
    public partial class MainRibbonBar : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MainRibbonBar" /> class.
        /// </summary>
        public MainRibbonBar()
        {
            InitializeComponent();
        }
    }
}
