﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="RestSharpHelper.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using RestClientServices.Contracts;
using RestClientServices.Services;
using RestSharp;
using System;
using System.Collections.Generic;

namespace RestClientServices.Helper
{
    /// <summary>
    /// Class RestSharpHelper.
    /// </summary>
    internal class RestSharpHelper
    {
        /// <summary>
        /// The rest client
        /// </summary>
        private IRestClient restClient;

        /// <summary>
        /// Gets or sets the service base URL.
        /// </summary>
        /// <value>The service base URL.</value>
        public Uri ServiceBasePath { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="RestSharpHelper" /> class.
        /// </summary>
        /// <param name="restClient">The rest client.</param>
        public RestSharpHelper(IRestClient restClient)
        {
            this.restClient = restClient;
            ServiceBasePath = this.restClient.BaseUrl;
        }

        /// <summary>
        /// Executes the request.
        /// </summary>
        /// <param name="requestService">The request service.</param>
        /// <returns>ServiceResponse.</returns>
        public ServiceResponse ExecuteRequest(IRestServiceRequest requestService)
        {
            var request = GetRestRequest(requestService);
            restClient.BaseUrl = this.ServiceBasePath;
            IRestResponse response = restClient.Execute(request);

            if (response != null)
            {
                ServiceResponse serviceResponse = new ServiceResponse();
                serviceResponse.IsSuccess = response.IsSuccessful;
                serviceResponse.Content = response.Content;
                serviceResponse.ResponseCode = response.StatusCode;
                return serviceResponse;
            }

            return null;
        }

        /// <summary>
        /// Gets the rest request.
        /// </summary>
        /// <param name="requestService">The request service.</param>
        /// <returns>IRestRequest.</returns>
        private IRestRequest GetRestRequest(IRestServiceRequest requestService)
        {
            IRestRequest _request = null;
            switch (requestService.RequestType)
            {
                case RequestTypes.GET:
                    {
                        _request = new RestRequest(requestService.ResourcePath, Method.GET);
                    }
                    break;

                case RequestTypes.POST:
                    {
                        _request = new RestRequest(requestService.ResourcePath, Method.POST);
                        setBody(ref _request, requestService);
                    }
                    break;

                case RequestTypes.PUT:
                    {
                        _request = new RestRequest(requestService.ResourcePath, Method.PUT);
                        setBody(ref _request, requestService);
                    }
                    break;
            }

            setUrlparams(ref _request, requestService);
            setQueryparams(ref _request, requestService);
            setHeaderparams(ref _request, requestService);

            return _request;
        }

        /// <summary>
        /// Sets the urlparams.
        /// </summary>
        /// <param name="req">The req.</param>
        /// <param name="requestService">The request service.</param>
        private void setUrlparams(ref IRestRequest req, IRestServiceRequest requestService)
        {
            foreach (KeyValuePair<string, object> entry in requestService.PathParams)
            {
                req.AddUrlSegment(entry.Key, entry.Value);
            }
        }

        /// <summary>
        /// Sets the queryparams.
        /// </summary>
        /// <param name="req">The req.</param>
        /// <param name="requestService">The request service.</param>
        private void setQueryparams(ref IRestRequest req, IRestServiceRequest requestService)
        {
            foreach (KeyValuePair<string, object> entry in requestService.Queryparams)
            {
                req.AddQueryParameter(entry.Key, entry.Value as string);
            }
        }

        /// <summary>
        /// Sets the headerparams.
        /// </summary>
        /// <param name="req">The req.</param>
        /// <param name="requestService">The request service.</param>
        private void setHeaderparams(ref IRestRequest req, IRestServiceRequest requestService)
        {
            foreach (KeyValuePair<string, object> entry in requestService.HeaderParams)
            {
                req.AddHeader(entry.Key, entry.Value as string);
            }
        }

        /// <summary>
        /// Sets the body.
        /// </summary>
        /// <param name="req">The req.</param>
        /// <param name="requestService">The request service.</param>
        private void setBody(ref IRestRequest req, IRestServiceRequest requestService)
        {
            req.AddJsonBody(requestService.BodyParam);
            
        }
    }
}