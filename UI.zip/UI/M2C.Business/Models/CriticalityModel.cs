﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="CriticalityModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Business.Models
{
    /// <summary>
    /// safety parametr values
    /// </summary>
    public enum SafetyIssue
    {
        /// <summary>
        /// The low risk
        /// </summary>
        Low_Risk = 1,
        /// <summary>
        /// The high risk
        /// </summary>
        High_Risk = 4
    }

    /// <summary>
    /// Quality parameter values
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QualityParametrValue
    {
        /// <summary>
        /// The low impact
        /// </summary>
        public const int Low_Impact = 1;
        /// <summary>
        /// The average impact
        /// </summary>
        public const int Average_Impact = 2;
        /// <summary>
        /// The high impact t
        /// </summary>
        public const double High_ImpactT = 2.5;
        /// <summary>
        /// The very high impact
        /// </summary>
        public const double Very_high_Impact = 2.8;
    }

    /// <summary>
    /// criticality output values
    /// </summary>
    public enum CriticalityValue
    {
        /// <summary>
        /// The not critical
        /// </summary>
        Not_Critical = 1,
        /// <summary>
        /// The somewhat critical
        /// </summary>
        Somewhat_Critical = 2,
        /// <summary>
        /// The critical
        /// </summary>
        Critical = 3,
        /// <summary>
        /// The very critical
        /// </summary>
        Very_Critical = 4
    }


    /// <summary>
    /// Criticality key value pair
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CriticalityKV<T>
    {
        /// <summary>
        /// Gets or sets the key.
        /// </summary>
        /// <value>The key.</value>
        public string Key { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public T value { get; set; }
    }


    /// <summary>
    /// Criticality string Values
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CriticalitystringValues
    {
        /// <summary>
        /// The low impact
        /// </summary>
        public const string LOW_IMPACT = "Low Impact";
        /// <summary>
        /// The average impact
        /// </summary>
        public const string AVERAGE_IMPACT = "Average Impact";
        /// <summary>
        /// The high impact
        /// </summary>
        public const string HIGH_IMPACT = "High Impact";
        /// <summary>
        /// The very high impact
        /// </summary>
        public const string VERY_HIGH_IMPACT = "Very High Impact";
        /// <summary>
        /// The not critical
        /// </summary>
        public const string NotCritical = "Not Critical";
        /// <summary>
        /// The somewhat critical
        /// </summary>
        public const string SomewhatCritical = "Somewhat Critical";
        /// <summary>
        /// The critical
        /// </summary>
        public const string Critical = "Critical";
        /// <summary>
        /// The very critical
        /// </summary>
        public const string VeryCritical = "Very Critical";
        /// <summary>
        /// The low risk
        /// </summary>
        public const string LOW_RISK = "Low Risk";
    }

}