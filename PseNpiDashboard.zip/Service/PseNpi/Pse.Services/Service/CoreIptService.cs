﻿using Pse.Data.Models;
using Pse.Services.Manager;
using System;
using System.Collections.Generic;

namespace Pse.Services.Service
{
    public class CoreIptService : ICoreIptService
    {
        private readonly ICoreIptManager _manager;

        public CoreIptService(ICoreIptManager manager)
        {
            _manager = manager;
        }

        public CoreIpt AddCoreIpt(CoreIpt CoreIpt)
        {
            return _manager.AddCoreIpt(CoreIpt);
        }

        public List<CoreIpt> LoadAllCoreIpt()
        {
            return _manager.LoadAllCoreIpt();
        }

        public List<CoreIpt> LoadCoreIptByCreationDate(DateTime creationDate)
        {
            return _manager.LoadCoreIptByCreationDate(creationDate);
        }

        public List<CoreIpt> LoadLatestCoreIpt()
        {
            return _manager.LoadLatestCoreIpt();
        }


        public List<CoreIpt> LoadCoreIptById(int Id)
        {
            return _manager.LoadCoreIptById(Id);
        }

        public List<CoreIpt> LoadCoreIptByKeyCode(string keycode)
        {
            return _manager.LoadCoreIptByKeyCode(keycode);
        }

        public CoreIpt UpdateCoreIpt(CoreIpt CoreIpt)
        {
            return _manager.UpdateCoreIpt(CoreIpt);
        }
    }
}