export interface Employee {
    eid: number,
    userName: string,
    city: string,
    company: string;
    country: string;
    department: string;
    displayName: string;
    emailAddress: string;
    extension: string;
    fax: string;
    firstName: string;
    homePhone: string;
    lastName: string;
    loginName: string;
    loginNameWithDomain: string;
    manager: string;
    managerName: string;
    middleName: string;
    mobile: string;
    postalCode: string;
    state: string;
    streetAddress: string;
    title: string;
    accessType: number,
    accessName: string;
    id: number
}