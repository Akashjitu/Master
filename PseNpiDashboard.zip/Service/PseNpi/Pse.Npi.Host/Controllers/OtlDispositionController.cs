﻿using Pse.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class OtlDispositionController : ApiController
    {
        ISpeService _service;
        public OtlDispositionController(ISpeService service)
        {
            _service = service;

        }

        [HttpGet]
        public HttpResponseMessage Get(string date)
        {
            DateTime dt;
            if (!DateTime.TryParse(date, out dt))
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);

            var data = _service.LoadOtlDispositionByDate(new Data.Models.OtlDispositionDetails() { CreatedDate = dt });
            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}
