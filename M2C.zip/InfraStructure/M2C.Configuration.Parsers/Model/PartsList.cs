﻿// ***********************************************************************
// Assembly         : M2C.Configuration.Parsers
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="PartsList.cs" company="M2C.Configuration.Parsers">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;

namespace M2C.Configuration.Parsers.Model
{
    /// <summary>
    /// Class PartsList.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class PartsList
    {
        /// <summary>
        /// Gets or sets the product items.
        /// </summary>
        /// <value>The product items.</value>
        public List<BaseProduct> ProductItems { get; set; } = new List<BaseProduct>();
    }
}
