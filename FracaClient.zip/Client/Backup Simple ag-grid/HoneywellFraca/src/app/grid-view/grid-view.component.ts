import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FracaInfo } from '../Models/fraca-info';
import { Observable } from 'rxjs';
import { Store, select } from '@ngrx/store';
import { IAppState } from '../store/fracaReducer';
import { FracaService } from '../service/fraca-service.service';
import { ShareDataService } from '../service/share-data.service'
import { filter, map } from 'rxjs/operators'
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
@Component({
  selector: 'app-grid-view',
  templateUrl: './grid-view.component.html',
  styleUrls: ['./grid-view.component.scss']
})
export class GridViewComponent implements OnInit {

  public defaultColDef;

  columnDefs = [
    { headerName: 'Fraca # ', field: 'FracaNo', sortable: true, filter: true },
    { headerName: 'Part Number', field: 'PartNo', sortable: true, filter: true },
    { headerName: 'Open Date', field: 'OpenDate', sortable: true, filter: true },
    { headerName: 'Close Date', field: 'CloseDate', sortable: true, filter: true },
    { headerName: 'Failed Date', field: 'FailedDate', sortable: true, filter: true },
    { headerName: 'Product', field: 'Product', sortable: true, filter: true, hide: true },
    { headerName: 'Program', field: 'Program', sortable: true, filter: true, hide: true },
    { headerName: 'Customer', field: 'Customer', sortable: true, filter: true, hide: true },
    { headerName: 'Test Env', field: 'TestEnv', sortable: true, filter: true, hide: true },
    { headerName: 'Originator', field: 'Originator', sortable: true, filter: true, },
    { headerName: 'Resp Eng', field: 'RespEng', sortable: true, filter: true, hide: true },
    { headerName: 'System', field: 'System', sortable: true, filter: true, hide: true },
    { headerName: 'Electrical', field: 'Electrical', sortable: true, filter: true, hide: true },
    { headerName: 'EMI', field: 'Emi', sortable: true, filter: true, hide: true },
    { headerName: 'Closed By', field: 'ClosedBy', sortable: true, filter: true },
    { headerName: 'Test Doc #', field: 'TestDoc', sortable: true, filter: true, hide: true },
    { headerName: 'Paragraph', field: 'Paragraph', sortable: true, filter: true, hide: true },
    { headerName: 'Test Type', field: 'TestType', sortable: true, filter: true, hide: true },
    { headerName: 'Failure Code', field: 'FailureCode', sortable: true, filter: true, hide: true },
    { headerName: 'End Unit', field: 'EndUnit', sortable: true, filter: true, hide: true },
    { headerName: 'Level #1', field: 'Level1', sortable: true, filter: true, hide: true },
    { headerName: 'Level #2', field: 'Level2', sortable: true, filter: true, hide: true },
    { headerName: 'Nomenclature', field: 'Nomenclature', sortable: true, filter: true, hide: true },
    { headerName: 'Serial Number', field: 'SerialNumber', sortable: true, filter: true, hide: true },
    { headerName: 'Designator', field: 'Designator', sortable: true, filter: true, hide: true },
    { headerName: 'InflightShutdown', field: 'InflightShutdown', sortable: true, filter: true, hide: true },
    { headerName: 'InflightPowerLoss', field: 'InflightPowerLoss', sortable: true, filter: true, hide: true },
    { headerName: 'Chargeability', field: 'Chargeability', sortable: true, filter: true, hide: true },
    { headerName: 'SafetyAffected', field: 'SafetyAffected', sortable: true, filter: true, hide: true },
    { headerName: 'FailureToStart', field: 'FailureToStart', sortable: true, filter: true, hide: true },
    { headerName: 'ProblemDescription', field: 'ProblemDescription', sortable: true, filter: true, hide: true },
    { headerName: 'Finding', field: 'Finding', sortable: true, filter: true, hide: true },
    { headerName: 'Analysis', field: 'Analysis', sortable: true, filter: true, hide: true },
    { headerName: 'AccessType', field: 'AccessType', sortable: true, filter: true, hide: true },
    { headerName: 'Status', field: 'Status', sortable: true, filter: true, hide: true },

 
  ];

  rowData: Observable<FracaInfo>

  selectedRow: any;
  private gridApi;
  private gridColumnApi;
  modalRef: BsModalRef;
  message: any;

  constructor(public store: Store<IAppState>, 
    private service: FracaService, 
    private modalService: BsModalService, private shareDataService: ShareDataService ) {
    this.defaultColDef = { resizable: true, sortable: true, filter: true };
    this.rowData = this.store.select('fracaReducer');
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }

  ngOnInit() {
    this.service.getAllFraca();
    this.shareDataService.currentMessage.subscribe( message=> this.message = message);
  }

  ngOnDestroy(): void {

  }

  onSelectionChanged() {
    var selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows != null) {
      this.selectedRow = selectedRows[0];

    }

  }
  onRowDoubleClicked(template: TemplateRef<any>) {
    this.shareDataService.changeMessage( this.selectedRow );
    this.modalRef = this.modalService.show(template, { class: "my-modal" });
  }

  download(){

    if(this.selectedRow==undefined)
    alert('Please select any Fraca row from Grid');

    this.service.reportDownload((<FracaInfo>this.selectedRow).FracaNo);
  }
}
