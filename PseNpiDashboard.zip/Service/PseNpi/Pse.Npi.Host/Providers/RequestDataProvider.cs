﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Pse.Npi.Host.Logs;
namespace Pse.Npi.Host.Providers
{
    public class RequestDataProvider
    {
        public static string GetValue(System.Web.HttpContext current, TypeOfData type)
        {

            switch (type)
            {
                case TypeOfData.UserName:
                    var aray = current.User.Identity.Name.Split('\\');
                    LogWriter.LogWrite(" GetValue----------- " + current.User.Identity.Name);
                    if (aray.Length > 1)
                        return aray[1];
                    if (aray.Length == 1)
                        return aray[0];
                    break;
                default:
                    return string.Empty;
            }
            return string.Empty;
        }
    }
    public enum TypeOfData
    {
        UserName
    }
}
