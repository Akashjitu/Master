﻿using System;
using Fraca.Data.Models;
using Microsoft.Reporting.WinForms;
using System.IO;
using System.Collections.Generic;
using System.Reflection;

namespace Fraca.Service.Reporting
{
    public class PdfReportMapper : IPdfReportMapper
    {
        

        public byte[] GetMappedReport(FracaInfo fracainfo)
        {
        var assembly = Assembly.GetExecutingAssembly();
            //   var file=  Assemble .GetEmbeddedResource("Reporting/FracaReport.rdlc");

            
            var resourceName = assembly.GetFile("Fraca.Service.Reporting.Reporting.FracaReport.rdlc");
            //  FracaTemplate

            LocalReport localReport = new LocalReport();
           // ReportDataSource rdsdtHmrMilestones = new ReportDataSource("ETSData", lstTicketReport);
            ReportDataSource reportDataSource = new ReportDataSource("ReportingDataSet", new List<FracaInfo>() { fracainfo });
            localReport.DataSources.Clear();
            localReport.ReportPath = @"FracaReport.rdlc";// Server.MapPath("~/TicketEquipmentReport.rdlc");
            localReport.DataSources.Add(reportDataSource);
            localReport.Refresh();
            
            string strReportType = "pdf";
            string strMimeType;
            string strEncoding;
            string strFileNameExtension;
            string strDeviceInfo = "";
            //<DeviceInfo>" +
            //                           "  <OmitDocumentMap>true</OmitDocumentMap>" +
            //                           "  <OmitFormulas>False</OmitFormulas>" +
            //                           "  <RemoveSpace>0.125in</RemoveSpace>" +
            //                           "<SimplePageHeaders>false</SimplePageHeaders>" +
            //                           "</DeviceInfo>";

            Warning[] arrStrWarnings;
            string[] arrStrStreams;
          
            byte[] bytes = localReport.Render(strReportType, strDeviceInfo, out strMimeType, out strEncoding, out strFileNameExtension, out arrStrStreams, out arrStrWarnings);
//
          //  File.Delete("Fraca Report.pdf");

           // File.WriteAllBytes("Fraca Report.pdf", bytes);

            return bytes;
        }



        //private void generateReport(string serchString)
        //{
        //    try
        //    {
        //        List<TicketReport> lstTicketReport = new List<TicketReport>();

        //        lstTicketReport = getReportData(serchString);

        //        var user = User.Identity.Name.Split('\\')[1];

        //        DateTime dateTime = DateTime.UtcNow.Date;
        //        string dataPart = dateTime.ToString("dd-MMM-yyyy");

        //        LocalReport lclRptHmrMilestones = new LocalReport();
        //        ReportDataSource rdsdtHmrMilestones = new ReportDataSource("ETSData", lstTicketReport);
        //        lclRptHmrMilestones.DataSources.Clear();
        //        lclRptHmrMilestones.ReportPath = Server.MapPath("~/TicketEquipmentReport.rdlc");
        //        lclRptHmrMilestones.DataSources.Add(rdsdtHmrMilestones);
        //        lclRptHmrMilestones.Refresh();
        //        string strReportType = "excel";
        //        string strMimeType;
        //        string strEncoding;
        //        string strFileNameExtension;
        //        string strDeviceInfo = "<DeviceInfo>" +
        //                                   "  <OmitDocumentMap>true</OmitDocumentMap>" +
        //                                   "  <OmitFormulas>False</OmitFormulas>" +
        //                                   "  <RemoveSpace>0.125in</RemoveSpace>" +
        //                                   "<SimplePageHeaders>false</SimplePageHeaders>" +
        //                                   "</DeviceInfo>";

        //        Warning[] arrStrWarnings;
        //        string[] arrStrStreams;
        //        ///*Render Excel Report*/
        //        byte[] bytes = lclRptHmrMilestones.Render(strReportType, strDeviceInfo, out strMimeType, out strEncoding, out strFileNameExtension, out arrStrStreams, out arrStrWarnings);
        //        string fileName = Server.MapPath("~/Report/") + "TicketEquipmentReport_" + user + "_" + dataPart + ".xlsx";

        //        //using (FileStream fs = new FileStream(fileName, FileMode.Create))
        //        //{
        //        //    fs.Write(bytes, 0, bytes.Length);
        //        //    fs.Flush();
        //        //    fs.Close();
        //        //}

        //        //writelog("User: " + user + " Part Result Count: " + lstNGPDM.Count, "NO");
        //        //sendMail(fileName);

        //        string contentType = "application/vnd.ms-excel";

        //        Response.Buffer = false; //transmitfile self buffers
        //        Response.Clear();
        //        Response.ClearContent();
        //        Response.ClearHeaders();
        //        Response.ContentType = contentType;
        //        Response.AppendHeader("Content-Disposition", "attachment;filename=" + "TicketEquipmentReport.xls");
        //        Response.BinaryWrite(bytes);
        //        //Response.TransmitFile(fileName);
        //        lstTicketReport.Clear();
        //        Response.End();
        //        //}


        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }
        //}

    }
}
