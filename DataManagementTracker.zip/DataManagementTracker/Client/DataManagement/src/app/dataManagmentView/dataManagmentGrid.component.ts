import { Component, OnInit, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataManagementService } from '../services/data-management.service';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/dataManagement/dataManagementReducer';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { IDayCalendarConfig, DatePickerComponent } from 'ng2-date-picker';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { ReferenceService } from '../services/referenceService';
import { DataManagmentColumns } from './dataManagmentColumns';
import { Router } from '@angular/router';
import { ShareDataService } from '../services/share-data.service';
import { EmployeeService } from '../services/employeeService';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { catchError } from 'rxjs/operators';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-dataManagmentGrid',
  templateUrl: './dataManagmentGrid.component.html',
  styleUrls: ['./dataManagmentGrid.component.css']
})
export class DataManagmentGridComponent implements OnInit {
  UsersInfo: any;
  selectedRow: any;
  programs: any;
  referenceData: any;
  registerForm: FormGroup;
  validate = "true"
  modalRef: BsModalRef;
  gridApi;
  gridColumnApi;
  isExportFilter = false;
  columnDefs;
  defaultColDef;
  rowData: any;
  searchText;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  theme = 'ag-theme-balham';
  @ViewChild('requestorForm')  private requestorForm : TemplateRef<any>
  @ViewChild('dateFromDp') public dateFromDp: DatePickerComponent;
  @ViewChild('dateToDp') public dateToDp: DatePickerComponent;
  filterForm: FormGroup;
  displayDate;
  dayPickerConfig = {
    locale: 'en',
    format: 'YYYY-MM-DD',
    monthFormat: 'MMMM, YYYY',
    firstDayOfWeek: 'mo'
  } as IDayCalendarConfig;



  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '10rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',
    uploadUrl: 'v1/images', // if needed,
    fonts: [{ class: 'arial', name: 'Arial' },
    { class: 'times-new-roman', name: 'Times New Roman' },
    { name: "Comic Sans MS", class: "comic-sans-ms" },
    { name: "Courier New", class: "courier-new" },
    { name: "Georgia", class: "georgia" },
    { name: "Verdana", class: "verdana" },
    { name: "Impact", class: "impact" },
    ], showToolbar: true,
    enableToolbar: true
  };


  createForm() {
    this.filterForm = this.fb.group({
      dateFrom: new FormControl(),
      dateTo: new FormControl(),
    });
  }

  ngOnInit() {

    // this.referenceService.getAllReference();
  }
  constructor(private http: HttpClient,
    private service: DataManagementService,
    public referenceService: ReferenceService,
    public store: Store<IAppState>,
    private modalService: BsModalService,
    private shareDataService: ShareDataService,
    private employeeService: EmployeeService,
    private datePipe: DatePipe,
    private spinner: NgxSpinnerService,
    private router: Router,
    private fb: FormBuilder) {
    this.initColumns();
    this.createForm();
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      enableFilter: true,
      //width: 100,
      //editable: true,
      filter: true
    };
    //  this.service.getAlDataManagement();


  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    this.store.select('dataManagementReducer').subscribe(data => {
      this.rowData = data;
    });

    this.store.select('referenceReducer').subscribe(data => {
      this.referenceData = data;
      console.log('reference ' + data);
    });

    this.initColumnsList();
  }


  initColumns() {
    this.columnDefs = DataManagmentColumns.columns;

    this.selectedRow = Object.assign({}, DataManagmentColumns.rowInfo);//DataManagmentColumns.rowInfo;
    this.selectedRow.requestReceivedDate = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.requestorComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.cmComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.dmComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.honeywellComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
  }

  autoSizeAll() {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.getColumn('id').setSort("desc")
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  export() {
    console.log('Export Click')
    console.log('isExportFilter :- ' + this.isExportFilter)
    if (this.isExportFilter == false) {
      this.service.reportDownloadAll();
    } else {
      this.service.reportDownloadByFilter(this.selectedRow);
    }

  }


  onSelectionChanged() {
    var selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows != null) {
      this.programs = this.referenceData.programs.filter(s => s.customerId == selectedRows[0].customerId);
      this.selectedRow = selectedRows[0];

    }
  }

  onRowDoubleClicked() {
    console.log(JSON.stringify(this.selectedRow));
    this.shareDataService.changeMessage(this.selectedRow);
    this.router.navigate(['dm']);
  }

  onAddNewRequest(clickfrom){
    if(clickfrom=='add' &&  this.referenceData.access.accessType== 2){
      this.selectedRow = Object.assign({}, DataManagmentColumns.rowInfo); //{...DataManagmentColumns.rowInfo};
      this.selectedRow.requestor = this.referenceData.access.eid;
      this.selectedRow.requestReceivedDate = this.datePipe.transform(new Date(), "yyyy-MM-dd");
      this.selectedRow.requestorComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
      this.selectedRow.cmComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
      this.selectedRow.dmComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
      this.selectedRow.honeywellComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
      this.selectedRow.accessUIType= 4;
      this.shareDataService.changeMessage(this.selectedRow);
    }
    else{
      this.showTemplate(this.requestorForm)
      return;
    }
    
    this.router.navigate(['dm']);
  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(this.searchText);
  }

  onItemSelect(item: any) {
    console.log(item);
    this.gridColumnApi.setColumnsVisible([item], true);

  }
  onDeSelect(item: any) {
    console.log(item);
    this.gridColumnApi.setColumnsVisible([item], false);

  }
  onSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], true);
    }
  }

  onDeSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], false);
    }
  }


  initColumnsList() {
    var allColumnIds = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'colId',
      textField: 'headerName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push({ colId: column.colId, headerName: column.colId });

    });
    this.selectedItems = [
      { colId: 'requestor', headerName: 'requestor' },
      { colId: 'requestReceivedDate', headerName: 'requestReceivedDate' }
    ];

    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      if (allColumns[index].visible === true) {
        this.selectedItems.push({ colId: allColumns[index].colId, headerName: allColumns[index].colId })
      }

    }
    this.dropdownList = allColumnIds;

  }

  showTemplate(template: TemplateRef<any>) {
    //this.shareDataService.changeMessage( this.selectedRow ); loadPliByFilter
    this.selectedRow = Object.assign({}, DataManagmentColumns.rowInfo);// DataManagmentColumns.rowInfo;
    this.selectedRow.requestor = this.referenceData.access.eid;
    this.modalRef = this.modalService.show(template, { class: 'gray modal-lg' });
  }

  onSearch() {
    this.service.loadDataManagementFilter(this.selectedRow);
    this.modalRef.hide();
  }

  onExportChange(value) {
    this.isExportFilter = value;
  }

  clearFilters() {
    console.log("clearFilters");
    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }



  selectedcustomer: any;
  onCustomerNameChange() {

    // this.selectedRow.customerName = this.selectedcustomer;
    this.programs = this.referenceData.programs.filter(s => s.customerId == this.selectedRow.customerId);
    console.log(this.selectedcustomer);
  }

  onSubmit() {
    console.log("Row _ " + this.selectedRow)

    if(this.selectedRow.requestorComments.length >=4000){
      alert("Requestor Comments length should not be more than 4000 characters ") 
      return;
    }

    console.log("validateInPut" + this.validateInPut())
    if (this.validateInPut() == true) {
      alert("Please fill all red boxes.")
      return;
    }
    else {
      this.service.addDataManagement(this.selectedRow)
    }


    this.modalRef.hide()
  }

  validateInPut() {
    return (
      (this.selectedRow.requestor == undefined || this.selectedRow.requestor == "" || this.selectedRow.requestor.length == 0) ||
      (this.selectedRow.requestReceivedDate == undefined || this.selectedRow.requestReceivedDate == "" || this.selectedRow.requestReceivedDate.length == 0) ||
      (this.selectedRow.siteId == undefined || this.selectedRow.siteId == "" || this.selectedRow.siteId.length == 0) &&
      (this.selectedRow.documentPartNumber == undefined || this.selectedRow.documentPartNumber == "" || this.selectedRow.documentPartNumber.length == 0) ||
      (this.selectedRow.documentTitle == undefined || this.selectedRow.documentTitle == "" || this.selectedRow.documentTitle.length == 0) ||
      (this.selectedRow.customerId == undefined || this.selectedRow.customerId == "" || this.selectedRow.customerId.length == 0) ||
      (this.selectedRow.programId == undefined || this.selectedRow.programId == "" || this.selectedRow.programId.length == 0) ||
      (this.selectedRow.priority == undefined || this.selectedRow.priority == "" || this.selectedRow.priority.length == 0) ||
      (this.selectedRow.dataManager == undefined || this.selectedRow.dataManager == "" || this.selectedRow.dataManager.length == 0) ||
      (this.selectedRow.cm == undefined || this.selectedRow.cm == "" || this.selectedRow.cm.length == 0) &&
      (this.selectedRow.requestorComments == undefined || this.selectedRow.requestorComments == "" || this.selectedRow.requestorComments.length == 0))
  }

  focusOut(element, helper) {
    console.log(element)
    console.log(helper)
    //ng-reflect-model="sdsad"
    var helperElt = (helper as HTMLElement);

    console.log("Event " + (helper as HTMLElement).innerText)
    this.employeeService.getEmployeeById(element).subscribe(emp => {
      helperElt.hidden = emp != '' ? false : true;
      helperElt.innerText = emp;
    });
  }

  onClearFields() {
    // selectedRow.requestor
    this.selectedRow = {
      id: 0,
      requestor: this.referenceData.access.eid,
      requestReceivedDate: this.datePipe.transform(new Date(), "yyyy-MM-dd"),
      site: '',
      siteId: 0,
      documentPartNumber: '',
      revision: '',
      documentTitle: '',
      ecn: '',
      customerName: '',
      customerId: 0,
      programNames: '',
      programId: 0,
      priority: 'Low',
      dataManager: '',
      cm: '',
      requestorComments: '',
      documentType: '',
      endItemPartNumber: '',
      categoryOfChange: '',
      scnNumber: '',
      cmComments: '',
      sdrlNumber: '',
      sdrlTitle: '',
      exportDisclosure:'',
      nomenclature: '',
      customerReferenceNumber: '',
      honeywellTransmittalLetter: '',
      dmDateSentToCustomer: null,
      honStatus: 'OnHold',
      requiredDispositionDate: '',
      dispositionStatus: 'PENDING',
      customerStatus: 'OnHold',
      apProgram: '',
      impactedPoDate: '',
      bcaPrimaryReviewerEngineer: '',
      bcaPa: '',
      dmComments: '',
      honeywellComments: '',
      createdBy: '',
      createdDate: null,
      updatedBy: '',
      updatedDate: null,
      isActive: '',
      requestorId:''
    }
    this.editorConfig.editable = true;
    this.selectedRow.requestReceivedDate = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.requestorComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.cmComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.dmComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
    this.selectedRow.honeywellComments = this.datePipe.transform(new Date(), "yyyy-MM-dd");
  }

  onEmpSearchTemplate(property, value, template: TemplateRef<any>) {
    this.EmployeeSetproperty = property;
    this.modalRef = this.modalService.show(template, { class: 'gray modal-lg' });
  }
  EmployeeSetproperty: any;
  seachBy = 0;
  capction = 'Employee ID';
  searchValue: '';
  
  onEmpSearch() {
  

    if(this.searchValue==null || this.searchValue ==''){
      alert('Please insert Search value like :- First Name, Email, E-ID.');
      return;
    }
    this.spinner.show();
    this.employeeService.getEmployeeBySearch(this.searchValue, this.seachBy)
     .subscribe(emp => {
      this.UsersInfo = emp;
      this.spinner.hide();
    },
    err => {
      this.spinner.hide();
      alert('Service Error. please your input');
      console.log(`ERROR: ${err}`);
    });
  }

  onSeachBy(value) {
    this.seachBy = value
    this.capction = '';
    switch (value) {
      case 0:
        this.capction = 'Employee ID';
        break;
      case 2:
        this.capction = 'Mail';
        break;
      case 3:
        this.capction = 'Display Name';
        break;

      case 1:
        this.capction = 'First Name';
        break;
    }
  }
  onUserSelect(userInfo) {

    console.log("userInfo " + JSON.stringify(userInfo))
    console.log("EmployeeSetproperty " + this.EmployeeSetproperty)
    switch (this.EmployeeSetproperty) {
      case 'CM':
        this.selectedRow.cm = userInfo.eid;
        break;
      case 'DM':
        this.selectedRow.dataManager = userInfo.eid;
        break;

    }
    this.modalRef.hide();
  }

  onRequestorComments(event) {
    // this.editorConfig.editable = true;
    // console.log("length "+ event.length);
    // if (event.length >= 4000) {
    //   return false;
    // }
  }
}

