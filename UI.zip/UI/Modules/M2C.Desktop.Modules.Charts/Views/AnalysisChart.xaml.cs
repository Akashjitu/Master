﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="AnalysisChart.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Windows;
using System.Windows.Controls;
using M2C.Business.Contracts;
using M2C.Desktop.Modules.Charts.ChartExports;

namespace M2C.Desktop.Modules.Charts.Views
{
    /// <summary>
    /// Interaction logic for ChartsView.xaml
    /// </summary>
    public partial class AnalysisChart : UserControl
    {
        /// <summary>
        /// My profile
        /// </summary>
        private readonly IMyProfileLogic _myProfile;
        /// <summary>
        /// Initializes a new instance of the <see cref="AnalysisChart" /> class.
        /// </summary>
        /// <param name="myProfile">My profile.</param>
        public AnalysisChart(IMyProfileLogic myProfile)
        {
            _myProfile = myProfile;
            InitializeComponent();
        }

        /// <summary>
        /// Handles the OnClick event of the MenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void MenuItem_OnClick(object sender, RoutedEventArgs e)
        {
            IExportChart exportChart = new ExportChart(_myProfile);
            var type = ExportType.Word;
            if (sender is MenuItem menuItem)
                type = (ExportType)Enum.Parse(typeof(ExportType), menuItem.Tag.ToString(), true);

            if (AnalysisChartStackPanel.Height > 0)
            {
                exportChart.Export(rootAnalysisChart, null, type);
                return;
            }
            exportChart.Export(rootObsolescenceAnalysisChart, null, type);
        }
    }
}