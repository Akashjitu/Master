import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestor-entry',
  templateUrl: './requestor-entry.component.html',
  styleUrls: ['./requestor-entry.component.sass']
})
export class RequestorEntryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
