﻿using AppConfiguration;
using DataRepository.DBContracts;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RestClientServices.Contracts;
using RestClientServices.Services;
using RestSharp;
using Schneider.M2C.OpenExcel.Parser.Model;
using SyncServiceLibrary.Implementation;
using SyncServiceLibrary.Mapper;
using SyncServiceLibrary.Model;
using System;
using System.Collections.Generic;
using WinRegistryServices.Contracts;
using Range = DomainModels.IbCatalogModels.Range;

namespace SyncServiceLibrary.Tests
{

    /// <summary>
    /// Testclass for ProductSynchronizer
    /// </summary>
    [TestClass]
    public class ProductSynchronizerTest : TestBase
    {
        private Mock<IAppConfigurations> mockAppConfigurations;
        private Mock<ISyncServiceQueries> mockSyncServiceQueries;
        private Mock<IRestServicesFactory> mockRestServicesFactory;
        private Mock<IProductQueries> mockProductQueries;
        private Mock<ISyncServiceDataMapper> mockSyncServiceDataMapper;
        private Mock<IProductSyncService> mockProductSyncService;
        private Mock<IRestClientService> mockRestClientService;
        private ProductSyncService mockProductSync;
        private Mock<IRestClient> IRestClientMock { get; set; }
        private Mock<IBrandQueries> mockBrandQueries;
        private Mock<IDeviceTypeQueries> mockDeviceTypeQueries;
        private Mock<IRangeQueries> mockRangeQueries;
        private Mock<ISubRangeQueries> mockSubRangeQueries;
        private Mock<IRestResponse> mockRestResponse;
        private Mock<IRegistryStoreManger> mockRegistryStoreManger;

        /// <summary>
        /// Test initialize method
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            mockAppConfigurations = MockRepo.Create<IAppConfigurations>();
            mockSyncServiceQueries = MockRepo.Create<ISyncServiceQueries>();
            mockRestServicesFactory = MockRepo.Create<IRestServicesFactory>();
            mockProductQueries = MockRepo.Create<IProductQueries>();
            mockSyncServiceDataMapper = MockRepo.Create<ISyncServiceDataMapper>();
            mockProductSyncService = MockRepo.Create<IProductSyncService>();
            mockRestClientService = MockRepo.Create<IRestClientService>();
            IRestClientMock = MockRepo.Create<IRestClient>();
            mockRegistryStoreManger = MockRepo.Create<IRegistryStoreManger>();
            mockAppConfigurations.Setup(x => x.SyncServicePath).Returns("https://schneider-m2c-apis-dev.azurewebsites.net/m2cdesktop");

            mockProductSync = new ProductSyncService(mockAppConfigurations.Object, IRestClientMock.Object, mockRegistryStoreManger.Object);

            mockBrandQueries = MockRepo.Create<IBrandQueries>();
            mockDeviceTypeQueries = MockRepo.Create<IDeviceTypeQueries>();
            mockRangeQueries = MockRepo.Create<IRangeQueries>();
            mockSubRangeQueries = MockRepo.Create<ISubRangeQueries>();
            mockRestResponse = MockRepo.Create<IRestResponse>();
          
        }

        /// <summary>
        /// Constructor Test
        /// </summary>
        [TestMethod]
        public void ProductSynchronizerConstructorTest()
        {
            mockRestServicesFactory.Setup(x => x.GetRestClientService<IProductSyncService>(It.IsAny<RestServiceTypes>())).Returns(mockProductSync);
            ProductSynchronizer prodSync = new ProductSynchronizer(mockSyncServiceQueries.Object, mockAppConfigurations.Object, mockRestServicesFactory.Object, mockProductQueries.Object, mockSyncServiceDataMapper.Object, mockBrandQueries.Object, mockDeviceTypeQueries.Object, mockRangeQueries.Object, mockSubRangeQueries.Object);
        }

        /// <summary>
        /// All positive test case
        /// </summary>
        [TestMethod]
        public void SyncToLocalTest()
        {
            List<Brand> lstBrand = new List<Brand>() { new Brand() { Id=1, Name="Brand1"},
                                                      new Brand(){Id=2, Name="Brand2"}};

            List<Range> lstRange = new List<Range>() { new Range() { Id=1, Name="Range1"} ,
                                                      new Range(){Id=2, Name="Range2"} };

            List<DeviceType> lstDeviceType = new List<DeviceType>() { new DeviceType() { Id=1, Type="Type1"},
                                                                     new DeviceType(){Id=2, Type="Type2"}};

            SyncHistory syncHistory = new SyncHistory() { ID = 4, RetryCount = 0, Version = 2, SyncDate = Convert.ToDateTime("2020-03-25 00:00:00") };
            SyncHistory updatedSyncHostory = new SyncHistory() { ID = 4, RetryCount = 0, Version = 2, SyncDate = Convert.ToDateTime("2020-03-25 00:00:00"), Status = 3 };

            ProductSyncModel[] syncedProducts = { new ProductSyncModel() { eventType = "Added" } };

            mockRestServicesFactory.Setup(x => x.GetRestClientService<IProductSyncService>(It.IsAny<RestServiceTypes>())).Returns(mockProductSync);

            ProductSynchronizer prodSyncchronizer = new ProductSynchronizer(mockSyncServiceQueries.Object, mockAppConfigurations.Object, mockRestServicesFactory.Object, mockProductQueries.Object, mockSyncServiceDataMapper.Object, mockBrandQueries.Object, mockDeviceTypeQueries.Object, mockRangeQueries.Object, mockSubRangeQueries.Object);

            //Mocking the fetch last sync data Query
            mockSyncServiceQueries.Setup(x => x.GetLastSyncDate()).Returns(Convert.ToDateTime("2020-03-25 00:00:00"));
            //Mocking the save queries
            mockSyncServiceQueries.Setup(x => x.SaveSyncHistory(It.IsAny<SyncHistory>())).Returns(syncHistory);
            mockBrandQueries.Setup(x => x.SaveBrands(It.IsAny<List<Brand>>()));
            mockDeviceTypeQueries.Setup(x => x.SaveDeviceTypes(It.IsAny<List<DeviceType>>()));
            mockRangeQueries.Setup(x => x.SaveRanges(It.IsAny<List<Range>>()));
            mockSubRangeQueries.Setup(x => x.SaveSubRanges(It.IsAny<List<SubRange>>()));
            mockProductQueries.Setup(x => x.SaveProducts(It.IsAny<List<Product>>()));
            //Mocking the load queries
            mockRangeQueries.Setup(x => x.LoadRanges()).Returns(lstRange);
            mockBrandQueries.Setup(x => x.LoadBrands()).Returns(lstBrand);
            mockDeviceTypeQueries.Setup(x => x.LoadDeviceTypes()).Returns(lstDeviceType);
            //Mocking UpdateSyncHistory
            mockSyncServiceQueries.Setup(x => x.UpdateSyncHistory(It.IsAny<SyncHistory>())).Returns(updatedSyncHostory);

            //mocking the execute Response

            mockRestResponse.Setup(x => x.IsSuccessful).Returns(true);
            string contents = "[{\"eventId\":\"0d6543b5 - 09b9 - 47e2 - b80c - 0003970ceba7\",\"eventDateUtc\":\"2020 - 03 - 26T08: 32:08.919037\",\"eventType\":\"Added\",\"tableName\":\"OneIbCatalog\",\"recordId\":\"TBUARTNJPN25S1D035\",\"eventDataDetails\":\" \",\"versionNumber\":1}]";
            mockRestResponse.Setup(x => x.Content).Returns(contents);

            //Mocking the Execute function
            IRestClientMock.Setup(x => x.Execute(It.IsAny<IRestRequest>())).Returns(mockRestResponse.Object);

            Action act = () => prodSyncchronizer.SyncToLocal((SyncResultModel model) => { });
            act.Should().NotThrow();
        }

        /// <summary>
        /// Negative test case
        /// </summary>
        [TestMethod]
        public void SyncToLocalAPIExceptionTest()
        {
            mockRestServicesFactory.Setup(x => x.GetRestClientService<IProductSyncService>(It.IsAny<RestServiceTypes>())).Returns(mockProductSync);
            ProductSynchronizer prodSyncchronizer = new ProductSynchronizer(mockSyncServiceQueries.Object, mockAppConfigurations.Object, mockRestServicesFactory.Object, mockProductQueries.Object, mockSyncServiceDataMapper.Object, mockBrandQueries.Object, mockDeviceTypeQueries.Object, mockRangeQueries.Object, mockSubRangeQueries.Object);

            //Mocking the fetch last sync data Query
            mockSyncServiceQueries.Setup(x => x.GetLastSyncDate()).Returns(Convert.ToDateTime("2020-03-25 00:00:00"));

            //mocking the execute Response
            IRestResponse<ProductSyncModel[]> response = new RestResponse<ProductSyncModel[]>();

            response.Content = "test";

            mockRestResponse.Setup(x => x.IsSuccessful).Returns(true);

            //Mocking the Execute function for API call exception
            IRestClientMock.Setup(x => x.Execute(It.IsAny<IRestRequest>())).Throws(new Exception());

            Action act = () => prodSyncchronizer.SyncToLocal((SyncResultModel model) => { });
            act.Should().NotThrow();


        }

        /// <summary>
        /// DB Exception test case
        /// </summary>
        [TestMethod]
        public void SyncToLocaDBExceptionlTest()
        {
            List<Brand> lstBrand = new List<Brand>() { new Brand() { Id=1, Name="Brand1"},
                                                      new Brand(){Id=2, Name="Brand2"}};

            List<Range> lstRange = new List<Range>() { new Range() { Id=1, Name="Range1"} ,
                                                      new Range(){Id=2, Name="Range2"} };

            List<DeviceType> lstDeviceType = new List<DeviceType>() { new DeviceType() { Id=1, Type="Type1"},
                                                                     new DeviceType(){Id=2, Type="Type2"}};

            SyncHistory syncHistory = new SyncHistory() { ID = 4, RetryCount = 0, Version = 2, SyncDate = Convert.ToDateTime("2020-03-25 00:00:00") };
            SyncHistory updatedSyncHostory = new SyncHistory() { ID = 4, RetryCount = 0, Version = 2, SyncDate = Convert.ToDateTime("2020-03-25 00:00:00"), Status = 3 };

            ProductSyncModel[] syncedProducts = { new ProductSyncModel() { eventType = "Added" } };

            mockRestServicesFactory.Setup(x => x.GetRestClientService<IProductSyncService>(It.IsAny<RestServiceTypes>())).Returns(mockProductSync);

            ProductSynchronizer prodSyncchronizer = new ProductSynchronizer(mockSyncServiceQueries.Object, mockAppConfigurations.Object, mockRestServicesFactory.Object, mockProductQueries.Object, mockSyncServiceDataMapper.Object, mockBrandQueries.Object, mockDeviceTypeQueries.Object, mockRangeQueries.Object, mockSubRangeQueries.Object);

            //Mocking the fetch last sync data Query
            mockSyncServiceQueries.Setup(x => x.GetLastSyncDate()).Returns(Convert.ToDateTime("2020-03-25 00:00:00"));
            //Mocking the save queries
            mockSyncServiceQueries.Setup(x => x.SaveSyncHistory(It.IsAny<SyncHistory>())).Returns(syncHistory);
            mockBrandQueries.Setup(x => x.SaveBrands(It.IsAny<List<Brand>>()));
            mockDeviceTypeQueries.Setup(x => x.SaveDeviceTypes(It.IsAny<List<DeviceType>>()));
            mockRangeQueries.Setup(x => x.SaveRanges(It.IsAny<List<Range>>()));
            mockSubRangeQueries.Setup(x => x.SaveSubRanges(It.IsAny<List<SubRange>>()));
            mockProductQueries.Setup(x => x.SaveProducts(It.IsAny<List<Product>>())).Throws(new Exception()); ;
            //Mocking the load queries
            mockRangeQueries.Setup(x => x.LoadRanges()).Returns(lstRange);
            mockBrandQueries.Setup(x => x.LoadBrands()).Returns(lstBrand);
            mockDeviceTypeQueries.Setup(x => x.LoadDeviceTypes()).Throws(new Exception());
            //Mocking UpdateSyncHistory
            mockSyncServiceQueries.Setup(x => x.UpdateSyncHistory(It.IsAny<SyncHistory>())).Returns(updatedSyncHostory);

            //mocking the execute Response

            mockRestResponse.Setup(x => x.IsSuccessful).Returns(true);
            string contents = "[{\"eventId\":\"0d6543b5 - 09b9 - 47e2 - b80c - 0003970ceba7\",\"eventDateUtc\":\"2020 - 03 - 26T08: 32:08.919037\",\"eventType\":\"Added\",\"tableName\":\"OneIbCatalog\",\"recordId\":\"TBUARTNJPN25S1D035\",\"eventDataDetails\":\" \",\"versionNumber\":1}]";
            mockRestResponse.Setup(x => x.Content).Returns(contents);

            //Mocking the Execute function
            IRestClientMock.Setup(x => x.Execute(It.IsAny<IRestRequest>())).Returns(mockRestResponse.Object);

            Action act = () => prodSyncchronizer.SyncToLocal((SyncResultModel model) => { });
            act.Should().NotThrow();
        }
    }
}