﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IFilterIbCatalogStatusIpCreationQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogFilter;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IFilterIbCatalogStatusIpCreationQueries
    /// </summary>
    public interface IFilterIbCatalogStatusIpCreationQueries
    {
        /// <summary>
        /// Filters the ib catalog status ip creations.
        /// </summary>
        /// <param name="filterIbCatalogStatusIpCreation">The filter ib catalog status ip creation.</param>
        /// <returns>List&lt;FilterIbCatalogStatusIpCreation&gt;.</returns>
        List<FilterIbCatalogStatusIpCreation> FilterIbCatalogStatusIpCreations(FilterIbCatalogStatusIpCreation filterIbCatalogStatusIpCreation);

        /// <summary>
        /// Filters the ib catalog status ip creations.
        /// </summary>
        /// <returns>List&lt;FilterIbCatalogStatusIpCreation&gt;.</returns>
        List<FilterIbCatalogStatusIpCreation> FilterIbCatalogStatusIpCreations();
    }
}