import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AgTtiComponent } from './ag-tti/ag-tti.component';
import { KeyMainViewComponent } from './keycode/key-main-view/key-main-view.component';
import { MainDashBoardComponent } from './main-dash-board/main-dash-board.component';
import {PliSummaryComponent} from './pli-summary/pli-summary.component';
import { EffectivenessAnalysisComponent } from './effectiveness-analysis/effectiveness-analysis.component';
import { OtlCatMilestonesComponent } from './otl-cat-milestones/otl-cat-milestones.component';
import { EffectivenessPartsListComponent } from './effectiveness-parts-list/effectiveness-parts-list.component';
import { OtlGraduatesComponent } from './otl-graduates/otl-graduates.component';
import { CoreIptMemberListComponent } from './core-ipt-member-list/core-ipt-member-list.component';
import { OtlDispositionComponent } from './otl-disposition/otl-disposition.component';
import { OtlHealthComponent } from './otl-health/otl-health.component';
import { OtlMorNotesComponent } from './otl-mor-notes/otl-mor-notes.component';
import { PpmFutureComponent } from './ppm-future/ppm-future.component';
import { UserControlComponent } from './admin/user-control/user-control.component';
import { UserInfoComponent } from './admin/user-info/user-info.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { OtlScoreCardInfoComponent } from './otl-score-card/otl-score-card.component';
import { OtlSummaryGridComponent } from './otl-summary-grid/otl-summary-grid.component';



const routes: Routes = [
  { path: 'home', component: MainDashBoardComponent },
  { path: 'keycode',      component: KeyMainViewComponent },
  { path: 'tti',      component: AgTtiComponent },
  { path: 'pli',      component: PliSummaryComponent },
  { path: 'analysis',      component: EffectivenessAnalysisComponent },
  { path: 'otlmilestones',      component: OtlCatMilestonesComponent },
  { path: 'parts',      component: EffectivenessPartsListComponent },
  { path: 'graduates',      component: OtlGraduatesComponent },
  { path: 'ipt',      component: CoreIptMemberListComponent },
  { path: 'disposition',      component: OtlDispositionComponent },
  { path: 'otlhealth',      component: OtlHealthComponent },
  { path: 'notes',      component: OtlMorNotesComponent },
  { path: 'ppmFuture',      component: PpmFutureComponent },
  { path: 'usersetting',      component: UserControlComponent },
  { path: 'userinfo',      component: UserInfoComponent },
  { path: 'feedback',      component: FeedbackComponent },
  { path: 'otlscorecard',      component: OtlScoreCardInfoComponent },
  { path: 'otlsummerygrid',      component: OtlSummaryGridComponent },
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
