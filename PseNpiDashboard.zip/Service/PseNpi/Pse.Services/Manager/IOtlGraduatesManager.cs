﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;

namespace Pse.Services.Manager
{
    public interface IOtlGraduatesManager
    {
        List<OtlGraduate> LoadAllOtlGraduates();

        List<OtlGraduate> LoadGraduatesByCreationDate(DateTime creationDate);

        List<OtlGraduate> LoadOtlGraduatesByKeyCode(string keycode);

        List<OtlGraduate> LoadLatestOtlGraduates();

        List<OtlGraduate> LoadOtlGraduatesById(int Id);

        OtlGraduate AddOtlGraduate(OtlGraduate otlGraduate);

        OtlGraduate UpdateOtlGraduate(OtlGraduate otlGraduate);
    }
}