import { Action } from '@ngrx/store';
import * as DataManagementAction from './dataManagementAction';
import { DataManagement } from 'src/app/model/data.management';


export interface IAppState {
    readonly compliance: DataManagement[];
}


export function dataManagementReducer(state: DataManagement[] = [], action: DataManagementAction.Actions) {

    switch (action.type) {

        case DataManagementAction.ADD_DATA_MANAGEMENT: {
            return [...state, action.payload]

        }

        case DataManagementAction.LOAD_DATA_MANAGEMENT: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case DataManagementAction.UPDATE_DATA_MANAGEMENT: {
            const dataManagement = (action.payload as DataManagement);
            const todo = state.find(t => t.id === dataManagement.id);

            if (todo != undefined || todo != null) {

                todo.id                        =		dataManagement.id;                         
                todo.requestor                 =		dataManagement.requestor      ;            
                todo.requestReceivedDate       =		dataManagement.requestReceivedDate ;       
                todo.site                      =		dataManagement.site            ;           
                todo.siteId                    =		dataManagement.siteId         ;            
                todo.documentPartNumber        =		dataManagement.documentPartNumber  ;       
                todo.revision                  =		dataManagement.revision          ;         
                todo.documentTitle             =		dataManagement.documentTitle    ;          
                todo.ecn                       =		dataManagement.ecn              ;          
                todo.customerName              =		dataManagement.customerName     ;          
                todo.customerId                =		dataManagement.customerId       ;          
                todo.programNames              =		dataManagement.programNames     ;          
                todo.programId 					=		dataManagement.programId ;
                todo.priority                  =		dataManagement.priority         ;          
                todo.dataManager               =		dataManagement.dataManager     ;           
                todo.cm                        =		dataManagement.cm              ;           
                todo.requestorComments         =		dataManagement.requestorComments  ;        
                todo.documentType              =		dataManagement.documentType       ;        
                todo.endItemPartNumber         =		dataManagement.endItemPartNumber  ;        
                todo.categoryOfChange          =		dataManagement.categoryOfChange   ;        
                todo.scnNumber                 =		dataManagement.scnNumber         ;         
                todo.cmComments                =		dataManagement.cmComments         ;        
                todo.sdrlNumber                =		dataManagement.sdrlNumber          ;       
                todo.sdrlTitle                 =		dataManagement.sdrlTitle            ;      
                todo.nomenclature              =		dataManagement.nomenclature          ;     
                todo.customerReferenceNumber   =		dataManagement.customerReferenceNumber;    
                todo.honeywellTransmittalLetter=		dataManagement.honeywellTransmittalLetter ;
                todo.dmDateSentToCustomer      =		dataManagement.dmDateSentToCustomer       ;
                todo.honStatus                 =		dataManagement.honStatus                  ;
                todo.requiredDispositionDate   =		dataManagement.requiredDispositionDate    ;
                todo.dispositionStatus         =		dataManagement.dispositionStatus          ;
                todo.customerStatus            =		dataManagement.customerStatus             ;
                todo.apProgram                 =		dataManagement.apProgram                  ;
                todo.impactedPoDate            =		dataManagement.impactedPoDate             ;
                todo.bcaPrimaryReviewerEngineer=		dataManagement.bcaPrimaryReviewerEngineer ;
                todo.bcaPa                     =		dataManagement.bcaPa                      ;
                todo.dmComments                =		dataManagement.dmComments                 ;
                todo.honeywellComments         =		dataManagement.honeywellComments          ;
                todo.createdBy                 =		dataManagement.createdBy                  ;
                todo.createdDate               =		dataManagement.createdDate                ;
                todo.updatedBy                 =		dataManagement.updatedBy                  ;
                todo.updatedDate               =		dataManagement.updatedDate                ;
                todo.isActive                  =		dataManagement.isActive                   ;
                

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            
            return state.slice();
        }



        default:
            return state;
    }
}