﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ContactType.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class ContactType.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ContactType
    {
        /// <summary>
        /// Gets or sets the contact type identifier.
        /// </summary>
        /// <value>The contact type identifier.</value>
        [Key]
        [Column(Order = 1)]
        public int ContactTypeID { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the contacts.
        /// </summary>
        /// <value>The contacts.</value>
        public ICollection<Contact> Contacts { get; set; }
    }
}