﻿// ***********************************************************************
// Assembly         : InputParserLibary
// Author           : SESA56024
// Created          : 04-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="OpenXMLWriter.cs" company="InputParserLibary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using InputParserLibary.Contracts;
using InputParserLibary.DataModels;
using System.Collections.Generic;

namespace InputParserLibary.Implementation
{
    /// <summary>
    /// IExcelWriter implementation with OpenXml
    /// </summary>
    /// <seealso cref="InputParserLibary.Contracts.IExcelWriter" />
    public class OpenXMLWriter : IExcelWriter
    {
        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>The file path.</value>
        public string FilePath { get; set; }

        /// <summary>
        /// The document
        /// </summary>
        private SpreadsheetDocument _document;
        /// <summary>
        /// The workbook part
        /// </summary>
        private WorkbookPart _workbookPart;
        /// <summary>
        /// The worksheet part
        /// </summary>
        private WorksheetPart _worksheetPart;
        /// <summary>
        /// The sheets
        /// </summary>
        private Sheets _sheets;
        /// <summary>
        /// The active sheet
        /// </summary>
        private Sheet _activeSheet;

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenXMLWriter" /> class.
        /// </summary>
        public OpenXMLWriter()
        {
        }

        /// <summary>
        /// Adds the work book.
        /// </summary>
        public void AddWorkBook()
        {
            if (!string.IsNullOrEmpty(FilePath))
            {
                _document = SpreadsheetDocument.Create(FilePath, SpreadsheetDocumentType.Workbook);
                _workbookPart = _document.AddWorkbookPart();
                _workbookPart.Workbook = new Workbook();
            }
        }

        /// <summary>
        /// Adds the worksheet.
        /// </summary>
        /// <param name="Name">The name.</param>
        public void AddWorksheet(string Name)
        {
            _worksheetPart = _workbookPart.AddNewPart<WorksheetPart>();
            _worksheetPart.Worksheet = new Worksheet();
            _sheets = _workbookPart.Workbook?.Sheets ?? _workbookPart.Workbook.AppendChild(new Sheets());
            Sheet sheet = new Sheet() { Id = _workbookPart.GetIdOfPart(_worksheetPart), SheetId = 1, Name = Name };
            _sheets.Append(sheet);
        }

        /// <summary>
        /// Closes this instance.
        /// </summary>
        public void Close()
        {
            _document.Dispose();
        }

        /// <summary>
        /// Sets the active sheet.
        /// </summary>
        /// <param name="index">The index.</param>
        public void SetActiveSheet(int index)
        {
        }

        /// <summary>
        /// Sets the work book.
        /// </summary>
        /// <param name="index">The index.</param>
        public void SetWorkBook(int index)
        {
        }

        /// <summary>
        /// Writes the specified columns.
        /// </summary>
        /// <param name="Columns">The columns.</param>
        /// <param name="Rows">The rows.</param>
        public void Write(List<ExcelDataColumn> Columns, List<ExcelDataRow> Rows)
        {
            Save();

            SheetData sheetData = _worksheetPart.Worksheet.AppendChild(new SheetData());

            Row headerRow = new Row();

            foreach (var header in Columns)
            {
                Bold bold = new Bold();
                Cell cell = WritetoCellCell(header.HeaderName, CellValues.String);
                cell.AppendChild(bold);
                headerRow.Append(cell);
            }
            sheetData.AppendChild(headerRow);

            //setting the data row
            for (int i = 0; i < Rows.Count;)
            {
                Row row = new Row();
                for (int j = 0; j < Columns.Count; j++)
                {
                    if (!string.IsNullOrEmpty(Rows[i].DataType) && Rows[i].DataType?.ToLower() == "int")
                    {
                        row.Append(WritetoCellCell(Rows[i].CellData, CellValues.Number));
                    }
                    else
                    {
                        row.Append(WritetoCellCell(Rows[i].CellData, CellValues.String));
                    }
                    i++;
                }

                sheetData.AppendChild(row);
            }

            Save();
        }

        /// <summary>
        /// Writes the specified columns.
        /// </summary>
        /// <param name="Columns">The columns.</param>
        /// <param name="Rows">The rows.</param>
        public void Write(ExcelDataColumn Columns, ExcelDataRow Rows)
        {
        }

        /// <summary>
        /// Writetoes the cell cell.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="dataType">Type of the data.</param>
        /// <returns>Cell.</returns>
        private Cell WritetoCellCell(string value, CellValues dataType)
        {
            return new Cell()
            {
                CellValue = new CellValue(value),
                DataType = new EnumValue<CellValues>(dataType)
            };
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        private void Save()
        {
            if (_workbookPart != null)
            {
                _workbookPart?.Workbook.Save();
            }
        }
    }
}