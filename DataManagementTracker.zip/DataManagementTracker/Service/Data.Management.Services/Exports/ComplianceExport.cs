﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;
using System;

namespace Pse.Services.ExcelExports
{
    public class ComplianceExport : IComplianceExports
    {
        public byte[] Export(List<Compliance> compliance)
        {
            throw new NotImplementedException();
        }
    }
}