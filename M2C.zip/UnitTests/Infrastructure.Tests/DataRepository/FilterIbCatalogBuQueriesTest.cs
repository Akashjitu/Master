﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogFilter;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class FilterIbCatalogBuQueriesTest : TestBase
    {
        private IQueryable<FilterIbCatalogBu> filterList;
        private Mock<DbSet<FilterIbCatalogBu>> filterMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            FilterIbCatalogBu filterObj = new FilterIbCatalogBu() { Id = 1, Name = "Name1" };
            List<FilterIbCatalogBu> filter = new List<FilterIbCatalogBu>() { filterObj };
            filterList = filter.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();

            filterMock = MockRepo.Create<DbSet<FilterIbCatalogBu>>();
            filterMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(filterList.Provider);
            filterMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(filterList.Expression);
            filterMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(filterList.ElementType);
            filterMock.As<IQueryable<FilterIbCatalogBu>>().Setup(m => m.GetEnumerator()).Returns(filterList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.FilterIbCatalogBus).Returns(filterMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void FilterIbCatalogBuQueriesConstructorTest()
        {
            IFilterIbCatalogBuQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            filter.Should().NotBeNull();
            ((IDisposable)filter).Dispose();
        }

        [TestMethod]
        public void FilterIbCatalogBuQueriesFilterIbCatalogBuTest()
        {
            IFilterIbCatalogBuQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            List<FilterIbCatalogBu> filterRes = filter.FilterIbCatalogBu();
            filterRes.Should().HaveCount(1);
            ((IDisposable)filter).Dispose();
        }

        [TestMethod]
        public void FilterIbCatalogBuQueriesFilterIbCatalogBubyFilterTest()
        {
            FilterIbCatalogBu filters = null;

            IFilterIbCatalogBuQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            List<FilterIbCatalogBu> filterRes = filter.FilterIbCatalogBu(filters);
            filterRes.Should().BeNull();
            filters = new FilterIbCatalogBu() { Id = 1, Name = "Name1" };
            filterRes = filter.FilterIbCatalogBu(filters);
            filterRes.Should().HaveCount(1);
            ((IDisposable)filter).Dispose();
        }
    }
}