﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="OperationModeControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.Events;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class OperationModeControlViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class OperationModeControlViewModel : BindableBase
    {
        /// <summary>
        /// The operation mode
        /// </summary>
        private ObservableCollection<OperationModeModel> _operationMode;
        /// <summary>
        /// The selected node
        /// </summary>
        private static INode _selectedNode;
        /// <summary>
        /// The is operation mode visible
        /// </summary>
        private bool isOperationModeVisible;
        /// <summary>
        /// The inventories
        /// </summary>
        private List<Inventory> _inventories;
        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService _sharedContextService;
        /// <summary>
        /// Gets the dialog service.
        /// </summary>
        /// <value>The dialog service.</value>
        public IDialogService DialogService { get; }

        /// <summary>
        /// operation mode collection
        /// </summary>
        /// <value>The operation mode grid.</value>
        public ObservableCollection<OperationModeModel> OperationModeGrid
        {
            get => _operationMode;
            set => SetProperty(ref _operationMode, value);
        }

        /// <summary>
        /// visibility check variable
        /// </summary>
        /// <value><c>true</c> if this instance is operation mode visible; otherwise, <c>false</c>.</value>
        public bool IsOperationModeVisible
        {
            get => isOperationModeVisible;
            set => SetProperty(ref isOperationModeVisible, value);
        }

        /// <summary>
        /// inventories
        /// </summary>
        /// <value>The inventories.</value>
        public List<Inventory> Inventories
        {
            get => _inventories;
            set => SetProperty(ref _inventories, value);
        }

        /// <summary>
        /// Gets or sets the add operation mode command.
        /// </summary>
        /// <value>The add operation mode command.</value>
        public DelegateCommand AddOperationModeCommand { get; set; }
        /// <summary>
        /// The context model
        /// </summary>
        private ProjectContextModel ContextModel;

        /// <summary>
        /// Initializes a new instance of the <see cref="OperationModeControlViewModel" /> class.
        /// </summary>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        public OperationModeControlViewModel(IDialogService dialogService, IEventAggregator eventAggregator, ISharedContextService sharedContextService)
        {
            DialogService = dialogService;
            OperationModeGrid = new ObservableCollection<OperationModeModel>();
            Inventories = new List<Inventory>();
            AddOperationModeCommand = new DelegateCommand(OnAddOperationMode);
            eventAggregator.GetEvent<IBTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            eventAggregator.GetEvent<InventoryModelEvent>().Subscribe(OnAddInventories);
            this._sharedContextService = sharedContextService;
            ContextModel = this._sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
        }

        /// <summary>
        /// Called when [add inventories].
        /// </summary>
        /// <param name="inventories">The inventories.</param>
        private void OnAddInventories(List<Inventory> inventories)
        {
            Inventories = inventories;
        }

        /// <summary>
        /// node selection change event handler
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnNodeSelectionChanged(INode node)
        {
            _selectedNode = node;

            if (_selectedNode is IOperationMode)
            {
                if ((_selectedNode as IOperationMode)?.OperationParams.HourlyProduction is null)

                {
                    ((IOperationMode) _selectedNode).OperationParams = new OperationModeModel()
                    {
                        OperatingMode = BusinessConstants.OPERATION_MODE1,
                        HourlyProduction = BusinessConstants.HOURLY_PRODUCTION1,
                        Age = "0",
                        StartDate = DateTime.Now,
                        EndDate = DateTime.Now
                    };

                    OperationModeGrid.Clear();
                    OperationModeGrid.Add((_selectedNode as IOperationMode)?.OperationParams);
                    if (ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).Any())
                    ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).FirstOrDefault().OperationParams = (_selectedNode as IOperationMode)?.OperationParams;
                    if (ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.LineNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).Any())
                        ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.LineNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).FirstOrDefault().OperationParams = (_selectedNode as IOperationMode)?.OperationParams;

                   
                }
                else
                {
                    OperationModeGrid.Clear();
                    OperationModeGrid.Add((_selectedNode as IOperationMode)?.OperationParams);
                }
            }
        }

        /// <summary>
        /// Adding operation mode
        /// </summary>
        private void OnAddOperationMode()
        {
            if (_selectedNode.Inventories == null || !_selectedNode.Inventories.Any())
            {
                MessageBox.Show($"Inventory is missing.", "Alert - Operation modes and life cycle", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            else
            {
                var param = new DialogParameters { { "OperationMode", OperationModeGrid } };
                DialogService.ShowDialog("OperationModeDialogue", param, CloseOperationModeDialogCallback);
            }
        }

        /// <summary>
        /// operation mode dialogue call back
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        private void CloseOperationModeDialogCallback(IDialogResult dialogResult)
        {
            if (dialogResult.Result != ButtonResult.OK)
                return;

            if (dialogResult.Parameters.TryGetValue(CollectionConstant.Add, out OperationModeModel operationMode))
            {
                if (operationMode != null)
                {
                    OperationModeGrid.Clear();
                    OperationModeGrid.Add(operationMode);

                    MachineNode machineNode = _selectedNode as MachineNode;
                    if (machineNode != null) machineNode.OperationParams = operationMode;
                    if (ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).Any())
                        ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).FirstOrDefault().OperationParams= operationMode;
                    if (ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.LineNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).Any())
                        ContextModel.InstalledBase.Factories.SelectMany(x => x.WorkShopNodes).SelectMany(x => x.LineNodes).SelectMany(x => x.MachineNodes).Where(i => i.Id == ((MachineNode)_selectedNode).Id).FirstOrDefault().OperationParams = operationMode;

                   
                }
            }
        }
    }
}