import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestorEntryComponent } from './requestor-entry.component';

describe('RequestorEntryComponent', () => {
  let component: RequestorEntryComponent;
  let fixture: ComponentFixture<RequestorEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestorEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestorEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
