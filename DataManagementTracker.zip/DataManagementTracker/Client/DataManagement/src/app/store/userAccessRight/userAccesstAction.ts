
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { DataManagement } from 'src/app/model/data.management';


export const ADD_USER_ACCESS = 'ADD_USER_ACCESS';
export const LOAD_USER_ACCESS = 'LOAD_USER_ACCESS';
export const REMOVE_USER_ACCESS = 'REMOVE_USER_ACCESS';
export const UPDATE_USER_ACCESS: string = 'UPDATE_USER_ACCESS';



export class LoadUserAccess implements Action {
    readonly type = LOAD_USER_ACCESS;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddUserAccess implements Action {
    readonly type = ADD_USER_ACCESS;

    constructor(public payload: any) { }
}

export class UpdateUserAccess implements Action {
    readonly type = UPDATE_USER_ACCESS;

    constructor(public payload: any) { }
}

export class RemoveUserAccess implements Action {
    readonly type = REMOVE_USER_ACCESS;

    constructor(public payload: number) { }
}


export type Actions = AddUserAccess | UpdateUserAccess | RemoveUserAccess;
