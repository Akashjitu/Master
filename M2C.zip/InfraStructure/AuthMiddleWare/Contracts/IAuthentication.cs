﻿// ***********************************************************************
// Assembly         : AuthMiddleWare
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IAuthentication.cs" company="Schneider Electric">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace AuthMiddleWare.Contracts
{
    /// <summary>
    /// Authentication layer
    /// </summary>
    public interface IAuthentication
    {
        /// <summary>
        /// Gets the access token.
        /// </summary>
        /// <param name="AuthCode">The authentication code.</param>
        /// <returns>System.String.</returns>
        string getAccessToken(string AuthCode);

        /// <summary>
        /// Gets the login URL.
        /// </summary>
        /// <returns>System.String.</returns>
        string GetLoginPath();
    }
}