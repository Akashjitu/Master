import { Injectable } from '@angular/core';
import { Observable, of, pipe, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { FracaInfo } from '../Models/fraca-info';
import { filter, map, catchError } from 'rxjs/operators'
import { IAppState } from '../store/fracaReducer'
import * as state from '../store/fracaReducer'
import * as FracaAction from './../store/fracaAction';
import { Store } from '@ngrx/store';
import { FracaData } from '../models/fraca-data';
import { NotifierService } from 'angular-notifier';
import {environment } from '../../environments/environment'
import { EmployeeInfo } from '../models/employee-info';
@Injectable({
  providedIn: 'root'
})
export class FracaService {

  headers
  url = environment.apiBaseUrl + 'Fraca/';
  constructor(private http: HttpClient, private store: Store<IAppState>, private notifier: NotifierService ) {
    this.headers = new HttpHeaders({
      'Accept': 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
     'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
     'withCredentials': 'true',
  });
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
      this.showNotification('error',  error.error.message)
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    return throwError(
      'Something bad happened; please try again later.');
  }

  public showNotification( type: string, message: string ): void {
    console.log( 'showNotification');
		  this.notifier.notify( type, message );
  }

  getAllFraca() {
console.log('URL ' + this.url);
this.http.get<FracaData>(this.url,  {headers : this.headers})
      .subscribe(FracaData => this.store.dispatch(new FracaAction.LoadFraca(FracaData)),
      err => {console.log(`ERROR: ${err}`), 
      this.showNotification('error', 'Whoops, something went wrong. Not able to connect with FRACA Service')}, );
  }

SearchByFilter(criteria){
  this.http.post<FracaData>(environment.apiBaseUrl + 'Filter/', criteria, {headers : this.headers})
  .subscribe(FracaData => this.store.dispatch(new FracaAction.LoadFraca(FracaData)),
  err => {console.log(`ERROR: ${err}`),
   this.showNotification('error', 'Whoops, something went wrong. Not able to connect with Fraca Service')}, );

  console.log(criteria);
}

  addNewFraca(fracaInfo: FracaInfo) {
    console.log(fracaInfo)
    return this.http.post<FracaInfo>(this.url, fracaInfo,  { headers: this.headers})
      .pipe(
        catchError(this.handleError)
      ).subscribe(infoData => {
        this.store.dispatch(new FracaAction.AddFraca(infoData)), this.showNotification('success', 'Successfully Add New Fraca Report'); },
        err => {console.log(`ERROR: ${err}`),
         this.showNotification('error', 'Whoops, something went wrong. Please Check Input with text length'); },
      );
  }


  UpdateFraca(farcaInfo: FracaInfo) {
    console.log (this.url + farcaInfo.FracaNo + '/');
    return this.http.put<FracaInfo>(this.url + '?fracaNo=' + farcaInfo.FracaNo , farcaInfo,  { headers: this.headers})
      .pipe(
        catchError(this.handleError)
      ).subscribe(infoData => {
        this.store.dispatch(new FracaAction.UpdateFraca(infoData));
        this.showNotification('success', 'Successfully Report Updated');
      },
        err => {console.log(`ERROR: ${err}`),
         this.showNotification('error', 'Whoops, something went wrong. Please Check Input with text length'); },
      );
    }

    reportDownload(fracaId){
      console.log(fracaId);
      this.http.get(environment.apiBaseUrl + 'File?fracaId=' + fracaId , {responseType: 'arraybuffer', headers: this.headers} )
     .subscribe(response => { this.downLoadFile(response, 'application/pdf')},
     err => {console.log(`ERROR: ${err}`),
      this.showNotification('error', 'Whoops, Not able to connect with service. Please check FRACA Service'); });
    }


   private downLoadFile(data: any, type: string) {
      var blob = new Blob([data], { type: type});
      var url = window.URL.createObjectURL(blob);
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, 'Fraca Report.pdf');
     } else {
        window.open(url);
    }
  }


  getEmployeeInfo(id) {
    return  this.http.get<EmployeeInfo>(environment.apiBaseUrl + 'Employee/?id=' + id, {headers : this.headers});
    }
}
