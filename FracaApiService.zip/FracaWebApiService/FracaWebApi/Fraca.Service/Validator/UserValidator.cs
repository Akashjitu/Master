﻿using System;
using System.Collections.Generic;
using Fraca.Data.Models;
using Fraca.Service.Manager;
using Fraca.Service.ServiceConsumer;


namespace Fraca.Service.Validator
{
    public class UserValidator : IUserValidator
    {
        private readonly IFracaServiceManage _fracaServiceManage;
        IEmployeeServcie _employeeServcie;

        public UserValidator(IFracaServiceManage fracaServiceManage, IEmployeeServcie employeeServcie)
        {
            _fracaServiceManage = fracaServiceManage;
            _employeeServcie = employeeServcie;
        }

        public bool IsUserValid(string id)
        {
            var info = _employeeServcie.GetEmployeeInfo(id);

            if (info != null)
                return true;

            return false;
        }


        public bool IsValidForUpdate(string fracaNo, FracaInfo fracaInfo, string userid)
        {
            var fracadata = _fracaServiceManage.GetFracaById(fracaNo);
            var info = fracadata.FracaInfo[0];

            if (info.Originator == userid)
                return true;
            if (info.RespEng == userid && !string.IsNullOrEmpty(fracaInfo.ClosedBy) && fracaInfo.Status == "Completed")
                return true;
            if (info.RespEng == userid && string.IsNullOrEmpty(fracaInfo.ClosedBy) && fracaInfo.Status == "InProgress")
                return true;
            if (info.System == userid)
                return true;

            if (info.Electrical == userid)
                return true;
            if (info.Emi == userid)
                return true;

            return false;
        }

        public List<FracaInfo> MapAccess(string userid, List<FracaInfo> infos)
        {

            foreach (var info in infos)
            {
                info.AccessType = UserAccessType.ReadOnly;

               
                if ((info.Originator == userid || info.RespEng == userid || info.System == userid || info.Electrical == userid || info.Emi == userid) && (info.Status== "InProgress"))
                {
                    info.AccessType = UserAccessType.Edit;
                }
                
                if (info.RespEng == userid)
                {
                    info.AccessType = UserAccessType.Complete;
                }

               
            }


            return infos;
        }

        public bool IsValidForDelete(string fracaNo, string eid)
        {
            var fracadata = _fracaServiceManage.GetFracaById(fracaNo);
            var info = fracadata.FracaInfo[0];

            if (info.Originator == eid)
                return true;
            if (info.RespEng == eid)
                return true;

            return false;
        }
    }
}