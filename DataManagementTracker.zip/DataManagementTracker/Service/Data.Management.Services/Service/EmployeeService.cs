﻿using Data.Management.Data.Models;
using Data.Management.Data.Models.Enum;
using Data.Management.Services.DataBaseAccessObject;
using Honeywell.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Data.Management.Services.Service
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IDataManagementDbAccess _dbAccess;
        private readonly IActiveDirectoryHelper _activeDirectoryHelper;
        public EmployeeService(IDataManagementDbAccess dbAccess, IActiveDirectoryHelper activeDirectoryHelper)
        {
            _dbAccess = dbAccess;
            _activeDirectoryHelper = activeDirectoryHelper;
        }

     

        public List<EmployeeInfo> GetEmployeeInfo(string value, EmployeeSearchType type)
        {
            switch (type)
            {
                case EmployeeSearchType.id:
                    var info = _activeDirectoryHelper.GetUsersByFilte(value, SearchType.LOGINNAME);
                    return GetMappedEmployeeInfo(info.ToArray());
               
                case EmployeeSearchType.firstName:
                    return GetMappedEmployeeInfo(_activeDirectoryHelper.GetUsersByFilte(value, SearchType.FIRSTNAME).ToArray());
                case EmployeeSearchType.mail:
                    return GetMappedEmployeeInfo(_activeDirectoryHelper.GetUsersByFilte(value, SearchType.EMAILADDRESS).ToArray());
                case EmployeeSearchType.displayName:
                    return GetMappedEmployeeInfo(_activeDirectoryHelper.GetUsersByFilte(value, SearchType.DISPLAYNAME).ToArray());
                default:
                    break;
            }

            return null;
        }


        private List<EmployeeInfo> GetMappedEmployeeInfo(params ADUserDetail[] aduserDetail)
        {

            if (aduserDetail == null || aduserDetail.Length ==0)
                new EmployeeInfo();

            return aduserDetail.Select(i => new EmployeeInfo()
            {
                EID = i.EID,
                UserName = i.DisplayName,
                City = i.City,
                Company = i.Company,
                Country = i.Country,
                Department = i.Department,
                DisplayName = i.DisplayName,
                EmailAddress = i.EmailAddress,
                Extension = i.Extension,
                Fax = i.Fax,
                FirstName = i.FirstName,
                HomePhone = i.HomePhone,
                LastName = i.LastName,
                LoginName = i.LoginName,
                LoginNameWithDomain = i.LoginNameWithDomain,
                //Manager = userInfo.Manager.DisplayName,
                ManagerName = i.ManagerName,
                MiddleName = i.MiddleName,
                Mobile = i.Mobile,
                PostalCode = i.PostalCode,
                State = i.State,
                StreetAddress = i.StreetAddress,
                Title = i.Title
            }).ToList();

        }

        public EmployeeInfo GetEmployeeInfo(string id)
        {
            var userInfo = _activeDirectoryHelper.GetUserByLoginName(id);
            if (userInfo == null)
                return new EmployeeInfo();
            var employeeInfo = new EmployeeInfo()
            {
                EID = id,
                UserName = userInfo.DisplayName,
                City = userInfo.City,
                Company = userInfo.Company,
                Country = userInfo.Country,
                Department = userInfo.Department,
                DisplayName = userInfo.DisplayName,
                EmailAddress = userInfo.EmailAddress,
                Extension = userInfo.Extension,
                Fax = userInfo.Fax,
                FirstName = userInfo.FirstName,
                HomePhone = userInfo.HomePhone,
                LastName = userInfo.LastName,
                LoginName = userInfo.LoginName,
                LoginNameWithDomain = userInfo.LoginNameWithDomain,
                //Manager = userInfo.Manager.DisplayName,
                ManagerName = userInfo.ManagerName,
                MiddleName = userInfo.MiddleName,
                Mobile = userInfo.Mobile,
                PostalCode = userInfo.PostalCode,
                State = userInfo.State,
                StreetAddress = userInfo.StreetAddress,
                Title = userInfo.Title
            };

            return employeeInfo;
        }

        public EmployeeInfo UpdateEmployeeAccess(EmployeeInfo employeeInfo)
        {
            var emp = _dbAccess.UpdateEmployeeAccess(employeeInfo);

            if (emp != null)
            {
                emp.AccessName = ((AccessDbType)emp.AccessType).ToString();
                var info = GetEmployeeInfo(emp.EID);
                if (info != null)
                {
                    emp.DisplayName = info.DisplayName;
                }
            }
            return emp;
        }

        public EmployeeInfo AddEmployeeAccess(EmployeeInfo employeeInfo)
        {
            var emp = _dbAccess.AddEmployeeAccess(employeeInfo);


            if (emp != null)
            {
                emp.AccessName = ((AccessDbType)emp.AccessType).ToString();
                var info = GetEmployeeInfo(emp.EID);
                if (info != null)
                {
                    emp.DisplayName = info.DisplayName;
                }
            }
            return emp;
        }

        public List<EmployeeInfo> GetAllEmployeeAccess(string eid)
        {
            EmployeeAccessRight employeeAccessRight = new EmployeeAccessRight();
            var data = _dbAccess.GetAllEmployeeAccess();

            if (data != null)
                foreach (var emp in data)
                {
                    UpdateAccess(emp);
                }
           

            return data;
        }

        private  void UpdateAccess(EmployeeInfo emp)
        {
            emp.AccessName = ((AccessDbType)emp.AccessType).ToString();

            var info = GetEmployeeInfo(emp.EID);
            if (info != null)
            {
                emp.DisplayName = info.DisplayName;
            }
        }
    }

    public enum EmployeeSearchType
    {
        id,
        firstName,
        mail,
        displayName,    
    }
}