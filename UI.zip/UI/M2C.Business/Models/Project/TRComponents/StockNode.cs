﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="StockNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Models.Project.IBComponents;
using Prism.Ioc;
using Prism.Unity;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace M2C.Business.Models.Project.TRComponents
{
    /// <summary>
    /// Stock node Business Model
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.TRComponents.TRBaseNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class StockNode : Node, ICloneable, IDelete
    {
        /// <summary>
        /// Prevents a default instance of the <see cref="StockNode"/> class from being created.
        /// </summary>
        StockNode()
        {

        }
        /// <summary>
        /// Initializes a new instance of the <see cref="StockNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public StockNode(string name)
        {
            this.Name = name;
            this.NodeType = NodeType.STOCK;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="StockNode" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="parentNode">The parent node.</param>
        public StockNode(int id, string name, INode parentNode)
        {
            Id = id;
            ParentNode = parentNode;
            this.Name = name;
            this.NodeType = NodeType.STOCK;
        }

        /// <summary>
        /// Creates a new object that is a copy of the current instance.
        /// </summary>
        /// <returns>A new object that is a copy of this instance.</returns>
        public object Clone()
        {
            var cloneNode = MemberwiseClone() as StockNode;
            if (cloneNode != null)
            {
                var customerDocument = new ObservableCollection<CustomerDocument>();
                foreach (var doc in CustomerDocuments)
                    customerDocument.Add(new CustomerDocument() { Name = doc.Name, FilePath = doc.FilePath });

                cloneNode.CopyOfNodeInventories = GetCopyOfNodeInventories();
                cloneNode.CustomerDocuments = customerDocument;
            }
            return cloneNode;
        }

        /// <summary>
        /// Deletes this instance.
        /// </summary>
        public void Delete()
        {
            (this.ParentNode as MaintenanceNode)?.StockNodes.Remove(this);
        }
    }


    /// <summary>
    /// Extension class for stock node for adding the inventory for stock nodes
    /// </summary>
    public static class StockNodeExt
    {
        /// <summary>
        /// Import inventory
        /// </summary>
        /// <param name="stockNode">The stock node.</param>
        /// <param name="trComponents">The tr components.</param>
        public static void ImportInventory(this StockNode stockNode, List<TRImportModel> trComponents)
        {
            if (Application.Current != null)
            {
                IContainerProvider containProvider = (Application.Current as PrismApplication)?.Container;
                var _inventoryMapper = containProvider.Resolve<IInventoryMapper>();

                var IBComponenetsrow = trComponents.Where(x => x.Configuration == stockNode.Name).ToList();


                var inventory = _inventoryMapper.Map(IBComponenetsrow, new List<INode>() { stockNode });

                foreach (var invnt in inventory)
                {
                    stockNode.MasterInventories.Add(invnt);
                }
            }
        }
    }

}