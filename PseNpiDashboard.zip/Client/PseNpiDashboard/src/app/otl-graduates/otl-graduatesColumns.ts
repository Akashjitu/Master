
import { DatePipe } from '@angular/common';

export class OtlGraduatesColumns {
constructor(private datePipe: DatePipe){}

    static  columns =
     [
        { field: 'id',                              colId: 	    'id',	                   		hide: true,	    headerName: 	'Id',	},
        { field: 'keyCode',                        colId: 	'keyCode',	               	hide: false,	headerName: 	'Key Code',	},
        { field: 'programName',                      colId: 	'programName',	       			hide: false,	headerName: 	'Program Name',	},
        { field: 'sbu',                      colId: 	'sbu',	       			hide: false,	headerName: 	'SBU',	},
        { field: 'gbe',                    colId: 	'gbe',	            hide: false,	headerName: 	'GBE',	},
        { field: 'successOtl',                      colId: 	'successOtl',	       			hide: false,	headerName: 	'Successful Otl',	},
        { field: 'updatedDate',                    colId: 	'updatedDate',	            hide: true,	headerName: 	'Updated Date',	},
        { field: 'updatedBy',                    colId: 	'updatedBy',	            hide: true,	headerName: 	'Updated By',	},
        { field: 'active',                    colId: 	'active',	            hide: true,	headerName: 	'Active',	},
        { field: 'createdDate',                    colId: 	'createdDate',	            hide: true,	headerName: 	'Created Date',	},
        { field: 'createBy',                    colId: 	'createBy',	            hide: true,	headerName: 	'Create By',	},
    ];

}

      	
