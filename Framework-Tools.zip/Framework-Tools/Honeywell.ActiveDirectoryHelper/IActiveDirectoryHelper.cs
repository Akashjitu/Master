﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Honeywell.ActiveDirectory
{
    public interface IActiveDirectoryHelper
    {
        ADUserDetail GetUserByLoginName(string userName);
        List<ADUserDetail> GetUserFromGroup(string groupName, string DomainName);

        List<ADProfile> GetUsersByFirstName(string fName);
        List<ADUserDetail> GetUsersByLoginName(string userName);

        List<ADUserDetail> GetUsersByFilte(string value, SearchType searchType);
    }
}
