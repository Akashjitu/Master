﻿//using PSENPI.App_Start;
using Autofac;
using Autofac.Integration.WebApi;
using Pse.Data.Models;
using Pse.Services.DataBaseAccessObject.Loader;
using Pse.Services.Exports;
using Pse.Services.Manager;
using Pse.Services.Mappers;
using Pse.Services.Service;
using Spea.Service.DataBaseAccessObject.Saver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace Pse.Npi.Host
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var config = GlobalConfiguration.Configuration;
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            // IOCConfig.RegisterComponents();

            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            
            var assemblyType = typeof(TtiPartAlignment).GetTypeInfo();

            builder.RegisterAssemblyTypes(assemblyType.Assembly)
            .Where(t => t.Name.EndsWith("Service"))
            .AsImplementedInterfaces()
            .InstancePerRequest();

            config.EnableCors(new EnableCorsAttribute("*", "*", "*"));
            config.EnableCors();

            builder.RegisterWebApiFilterProvider(config);
            builder.RegisterType<SpeService>().As<ISpeService>().InstancePerRequest();
            builder.RegisterType<SpeServiceManage>().As<ISpeServiceManage>().InstancePerRequest();


            builder.RegisterType<ServiceDataLoader>().As<IServiceDataLoader>().InstancePerRequest();
            builder.RegisterType<SeviceDataSave>().As<ISeviceDataSave>().InstancePerRequest();

            
            builder.RegisterType<ComplianceDataAccess>().As<IComplianceDataAccess>().InstancePerRequest();
            builder.RegisterType<TtiDataAccess>().As<ITtiDataAccess>().InstancePerRequest();
            builder.RegisterType<EffectivenessAnalysisDataAccess>().As<IEffectivenessAnalysisDataAccess>().InstancePerRequest();
            builder.RegisterType<EffectivenessDataAccess>().As<IEffectivenessDataAccess>().InstancePerRequest();
            builder.RegisterType<OtlDispositionDataAccess>().As<IOtlDispositionDataAccess>().InstancePerRequest();
            builder.RegisterType<SimpleExport>().As<ISimpleExport>().InstancePerRequest();
            builder.RegisterType<OtlAnalysisDataAccess>().As<IOtlAnalysisDataAccess>().InstancePerRequest();

            builder.RegisterType<PliDataAccess>().As<IPliDataAccess>().InstancePerRequest();

            builder.RegisterType<EscapesMapper>().As<IEscapesMapper>().InstancePerRequest(); 
                builder.RegisterType<EscapesDataAccess>().As<IEscapesDataAccess>().InstancePerRequest();

            builder.RegisterType<OtlSummeryService>().As<IOtlSummeryService>().InstancePerRequest();
            builder.RegisterType<OtlSummeryManager>().As<IOtlSummeryManager>().InstancePerRequest();
            builder.RegisterType<OtlSummeryDataAccess>().As<IOtlSummeryDataAccess>().InstancePerRequest();



            builder.RegisterType<OtlScoreCardDataAccess>().As<IOtlScoreCardDataAccess>().InstancePerRequest();
            builder.RegisterType<OtlScoreCardManager>().As<IOtlScoreCardManager>().InstancePerRequest();
            builder.RegisterType<OtlScoreCardService>().As<IOtlScoreCardService>().InstancePerRequest();

            builder.RegisterType<OtlGraduatesService>().As<IOtlGraduatesService>().InstancePerRequest();
            builder.RegisterType<OtlGraduatesManager>().As<IOtlGraduatesManager>().InstancePerRequest();
            builder.RegisterType<OtlGraduatesDataAccess>().As<IOtlGraduatesDataAccess>().InstancePerRequest();



            builder.RegisterType<CoreIptDataAccess>().As<ICoreIptDataAccess>().InstancePerRequest();
            builder.RegisterType<CoreIptManager>().As<ICoreIptManager>().InstancePerRequest();
            builder.RegisterType<CoreIptService>().As<ICoreIptService>().InstancePerRequest();

            



            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }
    }
}
