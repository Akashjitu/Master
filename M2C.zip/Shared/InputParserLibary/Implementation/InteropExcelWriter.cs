﻿// ***********************************************************************
// Assembly         : InputParserLibary
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="InteropExcelWriter.cs" company="InputParserLibary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using InputParserLibary.Contracts;
using InputParserLibary.DataModels;
using Microsoft.Office.Interop.Excel;
using System.Collections.Generic;

namespace InputParserLibary.Implementation
{
    /// <summary>
    /// Class InteropExcelWriter.
    /// Implements the <see cref="InputParserLibary.Contracts.IExcelWriter" />
    /// </summary>
    /// <seealso cref="InputParserLibary.Contracts.IExcelWriter" />
    public class InteropExcelWriter : IExcelWriter
    {
        /// <summary>
        /// The excel application
        /// </summary>
        private Application excelApp;
        /// <summary>
        /// The work book
        /// </summary>
        private Workbook workBook;
        /// <summary>
        /// The work sheet
        /// </summary>
        private Worksheet workSheet;
        /// <summary>
        /// The application factory
        /// </summary>
        private ICOMAppFactory appFactory;

        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>The file path.</value>
        public string FilePath { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="InteropExcelWriter" /> class.
        /// </summary>
        /// <param name="AppFactory">The application factory.</param>
        public InteropExcelWriter(ICOMAppFactory AppFactory)
        {
            this.appFactory = AppFactory;
        }

        /// <summary>
        /// Adding workbook
        /// </summary>
        public void AddWorkBook()
        {
            excelApp = appFactory.getExcelApp();
            excelApp.Visible = true;
            excelApp.Workbooks.Add();
        }

        /// <summary>
        /// setting work book
        /// </summary>
        /// <param name="index">The index.</param>
        public void SetWorkBook(int index)
        {
            workBook = excelApp.Workbooks[index];
        }

        /// <summary>
        /// Adding work sheet Name
        /// </summary>
        /// <param name="Name">The name.</param>
        public void AddWorksheet(string Name)
        {
            workSheet.Name = Name;
        }

        /// <summary>
        /// setting worksheet name
        /// </summary>
        /// <param name="index">The index.</param>
        public void SetActiveSheet(int index)
        {
            workSheet = (Worksheet)workBook.Sheets[index];
        }

        /// <summary>
        /// Excel writing function for Export
        /// </summary>
        /// <param name="Columns">The columns.</param>
        /// <param name="Rows">The rows.</param>
        public void Write(List<ExcelDataColumn> Columns, List<ExcelDataRow> Rows)
        {
            int column = 1;
            int row = 2;

            Range rng = workSheet.Cells[1] as Range;
            if (rng != null) rng.EntireRow.Font.Bold = true;

            //setting Header row bold
            foreach (var header in Columns)
            {
                workSheet.Cells[1, column] = header.HeaderName;
                column++;
            }
            column = 1;

            //setting row data
            foreach (var data in Rows)
            {
                if (column <= Columns.Count)
                {
                    workSheet.Cells[row, column] = data.CellData;

                    column++;
                }
                else
                {
                    column = 1;
                    row++;
                    workSheet.Cells[row, column] = data.CellData;
                    column++;
                    
                }
            }
        }

        /// <summary>
        /// oveload for writing single row and single column
        /// </summary>
        /// <param name="Columns">The columns.</param>
        /// <param name="Rows">The rows.</param>
        public void Write(ExcelDataColumn Columns, ExcelDataRow Rows)
        {
        }

        /// <summary>
        /// Closes this instance.
        /// </summary>
        public void Close()
        {
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(workSheet);
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(workBook);
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(excelApp);
        }
    }
}