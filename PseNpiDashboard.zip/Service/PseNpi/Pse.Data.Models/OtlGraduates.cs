﻿using Oracle.Data.Access;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pse.Data.Models
{
    public class OtlGraduate
    {

        [Columns("P_KEY_CODE")]
        public string KeyCode { get; set; }
        [Columns("P_PROGRAM_NAME")]
        public string ProgramName { get; set; }
        [Columns("P_SBU")]
        public string Sbu { get; set; }
        [Columns("P_GBE")]
        public string Gbe { get; set; }
        [Columns("P_SUCCESS_OTL")]
        public DateTime SuccessOtl { get; set; }
        [Columns("P_ISACTIVE")]
        public string Isactive { get; set; }
        [Columns("P_UPDATED_DATE")]
        public DateTime Updated_Date { get; set; }
        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get; set; }
        [Columns("P_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }
        [Columns("P_CREATED_BY")]
        public string CreatedBy { get; set; }
        [Columns("P_ID")]
        public int Id { get; set; }

    }
}
