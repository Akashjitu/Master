﻿using Pse.Data.Models;
using Pse.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class OtlGraduatesController : ApiController
    {
        private IOtlGraduatesService _service;

        public OtlGraduatesController(IOtlGraduatesService service)
        {
            _service = service;
        }

        [HttpGet]
        public HttpResponseMessage GeOtlGraduates()
        {
            var cp = _service.LoadAllOtlGraduates();
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        public HttpResponseMessage AddOtlGraduates(OtlGraduate otlGraduate)
        {
            var cp = _service.AddOtlGraduate(otlGraduate);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPut]
        public HttpResponseMessage UpdateOtlGraduatesy(int id, OtlGraduate otlGraduate)
        {
            var cp = _service.UpdateOtlGraduate(otlGraduate);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}
