﻿// ***********************************************************************
// Assembly         : AuthMiddleWare
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-20-2020
// ***********************************************************************
// <copyright file="IDMSAuthorization.cs" company="Schneider Electric">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AuthMiddleWare.Contracts;
using AuthMiddleWare.Models;
using Newtonsoft.Json.Linq;
using RestClientServices.Contracts;
using RestClientServices.Services;
using System;
using System.Text;

namespace AuthMiddleWare.Implementations
{
    /// <summary>
    /// IDMS Authorization
    /// </summary>
    /// <seealso cref="AuthMiddleWare.Contracts.IAuthorization" />
    public class IDMSAuthorization : IAuthorization
    {
        /// <summary>
        /// The rest services factory
        /// </summary>
        private readonly IRestServicesFactory restServicesFactory;
        /// <summary>
        /// The rest client service
        /// </summary>
        private IRestClientService restClientService;

        /// <summary>
        /// Initializes a new instance of the <see cref="IDMSAuthorization" /> class.
        /// </summary>
        /// <param name="restServicesFactory">The rest services factory.</param>
        public IDMSAuthorization(IRestServicesFactory restServicesFactory)
        {
            this.restServicesFactory = restServicesFactory;
            this.restClientService = this.restServicesFactory.GetRestClientService<IAuthService>(RestServiceTypes.AUTH_SERVICE);
        }

        /// <summary>
        /// Gets the decoded token.
        /// </summary>
        /// <param name="jwtToken">The JWT token.</param>
        /// <returns>TokenJsonModel.</returns>
        public TokenJsonModel GetDecodedToken(string jwtToken)
        {
            TokenJsonModel tokenJsonModel = new TokenJsonModel();
            try
            {
                var idtokenItems = GetJObjectFromToken(jwtToken);
                tokenJsonModel.Email = idtokenItems["email"].Value<string>();
                tokenJsonModel.Name = $"{idtokenItems["firstName"].Value<string>()} {idtokenItems["lastName"].Value<string>()}";
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }

            return tokenJsonModel;
        }

        /// <summary>
        /// Validates the token.
        /// </summary>
        /// <param name="jwtToken">The JWT token.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool ValidateToken(string jwtToken)
        {
            try
            {
                var idtokenItems = GetJObjectFromToken(jwtToken);
                var exp = idtokenItems["exp"]?.ToString();
                double unixTimeStamp = Convert.ToDouble(exp);
                System.DateTime expDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                expDateTime = expDateTime.AddSeconds(unixTimeStamp).ToLocalTime();

                int diff = DateTime.Compare(expDateTime, DateTime.Now);

                if (diff >= 0)
                {
                    return (ValidateTokenOnline(jwtToken) ?? true);
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the j object from token.
        /// </summary>
        /// <param name="jwtToken">The JWT token.</param>
        /// <returns>JObject.</returns>
        private JObject GetJObjectFromToken(string jwtToken)
        {
            if (string.IsNullOrEmpty(jwtToken))
            {
                return null;
            }
            string converted = jwtToken.Replace('-', '+').Replace('_', '/');

            //Separate header, body and signature of the OAuth ID Token
            var result = converted.Split('.');
            string header = result[0];
            string body = result[1];
            string signature = result[2];

            //If body doesn't have proper length, add '=' characters at the end
            while ((body.Length % 4) != 0)
            {
                body = body + "=";
            }

            //Get decoded string for body of the ID Token
            var base64DecodedBody = System.Convert.FromBase64String(body);

            //Parse the JSON structure of the decoded body
            return JObject.Parse(Encoding.UTF8.GetString(base64DecodedBody));
        }

        /// <summary>
        /// Validates the token online.
        /// </summary>
        /// <param name="jwtToken">The JWT token.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool? ValidateTokenOnline(string jwtToken)
        {
            try
            {
                //Construct Request for getting token
                IRestServiceRequest request = new RestServiceRequest() { ResourcePath = "ValidateToken" };
                request.HeaderParams.Add("accessToken", jwtToken);

                string response = this.restClientService.Execute<string>(request);

                return !string.IsNullOrEmpty(response) ? response.ToLower() == "true" ? true : false : (bool?)null;
            }
            catch (Exception Ex)
            {
                //Off-line exception
                return null;
            }
        }
    }
}