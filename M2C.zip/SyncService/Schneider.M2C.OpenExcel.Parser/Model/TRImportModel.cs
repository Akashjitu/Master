﻿// ***********************************************************************
// Assembly         : Schneider.M2C.OpenExcel.Parser
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="TRImportModel.cs" company="Schneider.M2C.OpenExcel.Parser">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace Schneider.M2C.OpenExcel.Parser.Model
{
    /// <summary>
    /// Class TRImportModel.
    /// </summary>
    public class TRImportModel
    {
        /// <summary>
        /// Gets or sets the maintenancezone.
        /// </summary>
        /// <value>The maintenancezone.</value>
        [ExcelParserColumn(ExcelParserConstants.MAINTENANCE_ZONE)]
        public string Maintenancezone { get; set; }

        /// <summary>
        /// Gets or sets the configuration.
        /// </summary>
        /// <value>The configuration.</value>
        [ExcelParserColumn(ExcelParserConstants.CONFIGURATION)]
        public string Configuration { get; set; }

        /// <summary>
        /// Gets or sets the reference.
        /// </summary>
        /// <value>The reference.</value>
        [ExcelParserColumn(ExcelParserConstants.REFERENCE)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        [ExcelParserColumn(ExcelParserConstants.DESCRIPTION)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the pv.
        /// </summary>
        /// <value>The pv.</value>
        [ExcelParserColumn(ExcelParserConstants.PV)]
        public string PV { get; set; }

        /// <summary>
        /// Gets or sets the sv.
        /// </summary>
        /// <value>The sv.</value>
        [ExcelParserColumn(ExcelParserConstants.SV)]
        public string SV { get; set; }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        [ExcelParserColumn(ExcelParserConstants.QUANTTY)]
        public string Quantity { get; set; }

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        [ExcelParserColumn(ExcelParserConstants.BRAND)]
        public string Brand { get; set; }

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        [ExcelParserColumn(ExcelParserConstants.COMMENT)]
        public string Comment { get; set; }
    }
}