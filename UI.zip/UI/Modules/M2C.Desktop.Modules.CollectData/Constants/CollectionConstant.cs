﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-27-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="CollectionConstant.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.Constants
{
    /// <summary>
    /// Class CollectionConstant.
    /// </summary>
    public static class CollectionConstant
    {
        /// <summary>
        /// The configuration file filter
        /// </summary>
        public const string ConfigFileFilter = "Config files (*.xml, *.FEF) | *.xml; *.FEF";
        /// <summary>
        /// The message corrupted file
        /// </summary>
        public const string MessageCorruptedFile = "File corrupted or invalid file.";
        /// <summary>
        /// The invalid file
        /// </summary>
        public const string InvalidFile = "Invalid file";
        /// <summary>
        /// The message parameter product not found
        /// </summary>
        public const string MessageParameterProductNotFound = "Product(s) not found:- \n {0}";

        /// <summary>
        /// The message parameter product replacement
        /// </summary>
        public const string MessageParameterProductReplacement = "Product(s) Replacement Detail:- \n {0}";
        /// <summary>
        /// The successfully mapped
        /// </summary>
        public const string SuccessfullyMapped = "Successfully Mapped";
        /// <summary>
        /// The range
        /// </summary>
        public const string Range = "RANGE";
        /// <summary>
        /// The device type
        /// </summary>
        public const string DeviceType = "DEVICE-TYPE";
        /// <summary>
        /// The brand
        /// </summary>
        public const string Brand = "BRAND";
        /// <summary>
        /// The ok
        /// </summary>
        public const string Ok = "OK";
        /// <summary>
        /// The add inventory
        /// </summary>
        public const string AddInventory = "Add Inventory";
        /// <summary>
        /// The installed based
        /// </summary>
        public const string InstalledBased = "InstalledBased";
        /// <summary>
        /// The technical resource
        /// </summary>
        public const string TechnicalResource = "TechnicalResource";
        /// <summary>
        /// The year
        /// </summary>
        public const string Year = "Year";
        /// <summary>
        /// The years
        /// </summary>
        public const string Years = "Years";
        /// <summary>
        /// The message inventory selection
        /// </summary>
        public const string MessageInventorySelection = "Please select any Reference\n or validate the config file ";
        /// <summary>
        /// The information
        /// </summary>
        public const string Information = "Information";
        /// <summary>
        /// The information inventory
        /// </summary>
        public const string InfoInventory = "InfoInventory";
        /// <summary>
        /// The delete
        /// </summary>
        public const string Delete = "DELETE";
        /// <summary>
        /// The edit
        /// </summary>
        public const string Edit = "EDIT";
        /// <summary>
        /// The information
        /// </summary>
        public const string Info = "INFO";
        /// <summary>
        /// The view details
        /// </summary>
        public const string ViewDetails = "VIEW DETAILS";
        /// <summary>
        /// The customer document file dialog
        /// </summary>
        public const string CustomerDocumentFileDialog = "CustomerDocumentFileDialog";
        /// <summary>
        /// The edit inventory control
        /// </summary>
        public const string EditInventoryControl = "EditInventoryControl";
        /// <summary>
        /// The inventory details control
        /// </summary>
        public const string InventoryDetailsControl = "InventoryDetailsControl";
        /// <summary>
        /// The message delete inventory
        /// </summary>
        public const string MessageDeleteInventory= "There is/are {0} inventories currently selected. Are you sure you want to delete the selected inventories";
        /// <summary>
        /// The delete inventories
        /// </summary>
        public const string DeleteInventories = "Delete inventories";
        /// <summary>
        /// The add inventory dialog
        /// </summary>
        public const string AddInventoryDialog = "AddInventoryDialog";
        /// <summary>
        /// The add
        /// </summary>
        public const string Add = "Add";
        /// <summary>
        /// The add configuration
        /// </summary>
        public const string AddConfig ="AddConfig";
        /// <summary>
        /// The overall information
        /// </summary>
        public const string OverallInformation = "Overall Information";
        /// <summary>
        /// The columns
        /// </summary>
        public const string Columns = "Columns";
        /// <summary>
        /// The is selected
        /// </summary>
        public const string IsSelected = "IsSelected";
        /// <summary>
        /// The open
        /// </summary>
        public const string Open = "Open";
        /// <summary>
        /// The close
        /// </summary>
        public const string Close = "Close";
        /// <summary>
        /// The cancel
        /// </summary>
        public const string Cancel = "Cancel";
        /// <summary>
        /// The message file name path
        /// </summary>
        public const string MessageFileNamePath = "Please provide Name and File Location.";
        /// <summary>
        /// The add customer documents
        /// </summary>
        public const string AddCustomerDocuments = "Add Customer Document";
        /// <summary>
        /// The criticality dialog
        /// </summary>
        public const string CriticalityDialog = "CriticalityDialog";
        /// <summary>
        /// The install based columns
        /// </summary>
        public const string InstallBasedColumns = "InstallBasedColumns";
        /// <summary>
        /// The technical resource columns
        /// </summary>
        public const string TechnicalResourceColumns = "TechnicalResourceColumns";
        /// <summary>
        /// The customer document columns
        /// </summary>
        public const string CustomerDocumentColumns = "CustomerDocumentColumns";
        /// <summary>
        /// The year1
        /// </summary>
        public const string Year1 = "Year1";
        /// <summary>
        /// The year2
        /// </summary>
        public const string Year2 = "Year2";
        /// <summary>
        /// The year3
        /// </summary>
        public const string Year3 = "Year3";
        /// <summary>
        /// The year4
        /// </summary>
        public const string Year4 = "Year4";
        /// <summary>
        /// The maintenance zone
        /// </summary>
        public const string MaintenanceZone = "MaintenanceZone";
        /// <summary>
        /// The factory
        /// </summary>
        public const string Factory = "Factory";
        /// <summary>
        /// The workshop
        /// </summary>
        public const string Workshop = "Workshop";
        /// <summary>
        /// The machine
        /// </summary>
        public const string Machine = "Machine";
        /// <summary>
        /// The line
        /// </summary>
        public const string Line = "Line";
        /// <summary>
        /// The message file not exist
        /// </summary>
        public const string MessageFileNotExist = "File does not exist.";
        /// <summary>
        /// The message select document
        /// </summary>
        public const string MessageSelectDocument = "Please select anyone Document.";
        /// <summary>
        /// The delete documents
        /// </summary>
        public const string DeleteDocuments = "Delete Documents";
        /// <summary>
        /// The message delete document
        /// </summary>
        public const string MessageDeleteDocument = "There are {0} Document(s) currently selected. Are you sure you want to delete the selected Document(s)";
        /// <summary>
        /// The configuration
        /// </summary>
        public const string Configuration = "Configuration";
        /// <summary>
        /// The m2 c
        /// </summary>
        public const string M2C = "M2C";
        /// <summary>
        /// The title
        /// </summary>
        public const string Title = "Title";
        /// <summary>
        /// The is cancel visible
        /// </summary>
        public const string IsCancelVisible = "IsCancelVisible";
        /// <summary>
        /// The message label
        /// </summary>
        public const string MessageLabel = "MessageLabel";
        /// <summary>
        /// The message collection
        /// </summary>
        public const string MessageCollection = "MessageCollection";
        /// <summary>
        /// The message
        /// </summary>
        public const string Message = "Message";
        /// <summary>
        /// The not defined
        /// </summary>
        public const string NotDefined = "Not Defined";
        /// <summary>
        /// The not critical
        /// </summary>
        public const string NotCritical = "Not Critical";
        /// <summary>
        /// The somewhat critical
        /// </summary>
        public const string SomewhatCritical = "Somewhat Critical";
        /// <summary>
        /// The critical
        /// </summary>
        public const string Critical = "Critical";
        /// <summary>
        /// The very critical
        /// </summary>
        public const string VeryCritical = "Very Critical";

    }
}