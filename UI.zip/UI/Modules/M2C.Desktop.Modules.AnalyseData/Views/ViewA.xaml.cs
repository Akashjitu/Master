﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.AnalyseData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ViewA.xaml.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.AnalyseData.Views
{
    /// <summary>
    /// Interaction logic for ViewA.xaml
    /// </summary>
    public partial class ViewA : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ViewA" /> class.
        /// </summary>
        public ViewA()
        {
            InitializeComponent();
        }
    }
}
