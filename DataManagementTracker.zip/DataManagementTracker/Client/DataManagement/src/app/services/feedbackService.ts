import { environment } from 'src/environments/environment';
import { IAppState } from '../store/dataManagement/dataManagementReducer';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { NotifierService } from 'angular-notifier';
@Injectable({
    providedIn: 'root'
  })
export class FeedbackService{
    headers: any;

    url = environment.apiBaseUrl;
    fileBaseUrl = environment.fileBaseUrl;
  
    constructor(private http: HttpClient, private store: Store<IAppState>, private spinner: NgxSpinnerService,
        private notifier: NotifierService) {
      this.headers = new HttpHeaders({
        Accept: 'application/json',
        'zumo-api-version': '2.0.0',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': 'true',
       'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
       withCredentials: 'true',
    });
     }
    
     sendFeedback(value: any) {
        this.spinner.show();
        return this.http.post(this.url + 'Feedback', value, { headers: this.headers })
          .pipe(
            catchError( err => this.handleError(err))
          ).subscribe(infoData => {
            //this.store.dispatch(new UserAccesstAction.AddUserAccess(infoData));
            this.spinner.hide();
            this.showNotification('success', 'Successfully Send Feedback');
          },
            err => {
              console.log(`ERROR: ${err}`);
              console.log("ERROR: "+  JSON.stringify( err) );
              this.showNotification('error', 'Whoops, something went wrong. Please check the Service');
             // this.showNotification('error', 'Mail not send.'); 
              this.spinner.hide();
            },
          );
    }
    private handleError(error: HttpErrorResponse) {
       
        console.error("Service Error :- " + error.error);
             if (error.error instanceof ErrorEvent) {
            console.error('An error occurred:', error.error.message);
            this.showNotification('error', error.error.message)
        } else {
            console.error(
                `Backend returned code ${error.status}, ` +
                `body was: ${error.error}`);
                this.showNotification('error', 'Mail not send. '); 
        }
        return throwError('Something bad happened; please try again later.' + error.error);
    }

    public showNotification(type: string, message: string): void {
        this.notifier.notify(type, message);
    }
    }