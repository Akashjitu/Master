﻿
namespace Employee.Service.Manager
{
    public interface IEmployeeServiceManage
    {
        void ConsumeApi();
    }
}
