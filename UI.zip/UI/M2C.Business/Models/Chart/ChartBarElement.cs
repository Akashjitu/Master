﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ChartBarElement.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;

namespace M2C.Business.Models.Chart
{
    /// <summary>
    /// Class ChartBarElement.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ChartBarElement : BindableBase
    {
        /// <summary>
        /// The name
        /// </summary>
        private string _name;
        /// <summary>
        /// The configuration count
        /// </summary>
        private int _configCount;

        /// <summary>
        /// Gets or sets the configuration count.
        /// </summary>
        /// <value>The configuration count.</value>
        public int ConfigCount
        {
            get => _configCount;
            set => SetProperty(ref _configCount, value);
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get => _name;
            set => SetProperty(ref _name, value);
        }
    }
}