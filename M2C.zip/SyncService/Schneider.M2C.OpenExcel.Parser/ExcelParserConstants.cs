﻿// ***********************************************************************
// Assembly         : Schneider.M2C.OpenExcel.Parser
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ExcelParserConstants.cs" company="Schneider.M2C.OpenExcel.Parser">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace Schneider.M2C.OpenExcel.Parser
{
    /// <summary>
    /// Class ExcelParserConstants.
    /// </summary>
    public static class ExcelParserConstants
    {
        /// <summary>
        /// The factory
        /// </summary>
        public const string FACTORY = "Factory";

        /// <summary>
        /// The workshop
        /// </summary>
        public const string WORKSHOP = "Workshop";

        /// <summary>
        /// The line
        /// </summary>
        public const string LINE = "Line";

        /// <summary>
        /// The machine
        /// </summary>
        public const string MACHINE = "Machine";

        /// <summary>
        /// The machine criticity
        /// </summary>
        public const string MACHINE_CRITICITY = "Machine criticity";

        /// <summary>
        /// The configuration name
        /// </summary>
        public const string CONFIGURATION_NAME = "Configuration";

        /// <summary>
        /// The configuration type
        /// </summary>
        public const string CONFIGURATION_TYPE = "Config. type";

        /// <summary>
        /// The reference
        /// </summary>
        public const string REFERENCE = "Reference";

        /// <summary>
        /// The description
        /// </summary>
        public const string DESCRIPTION = "Description";

        /// <summary>
        /// The pv
        /// </summary>
        public const string PV = "PV number";

        /// <summary>
        /// The sv
        /// </summary>
        public const string SV = "SV number";

        /// <summary>
        /// The quantty
        /// </summary>
        public const string QUANTTY = "Quantity";

        /// <summary>
        /// The brand
        /// </summary>
        public const string BRAND = "Brand";

        /// <summary>
        /// The comment
        /// </summary>
        public const string COMMENT = "Comment";

        /// <summary>
        /// The maintenance zone
        /// </summary>
        public const string MAINTENANCE_ZONE = "Maintenance zone";

        /// <summary>
        /// The configuration
        /// </summary>
        public const string CONFIGURATION = "Configuration";

        /// <summary>
        /// The stock
        /// </summary>
        public const string STOCK = "Stock";
    }
}