﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="ExcelImport.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using Prism.Services.Dialogs;
using Schneider.M2C.OpenExcel.Parser;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class ExcelImport.
    /// Implements the <see cref="M2C.Business.Contracts.IExcelImport" />
    /// </summary>
    /// <seealso cref="M2C.Business.Contracts.IExcelImport" />
    public class ExcelImport : IExcelImport
    {
        /// <summary>
        /// The excel parser
        /// </summary>
        private readonly IExcelParser _excelParser;

        /// <summary>
        /// The inventory mapper
        /// </summary>
        private readonly IInventoryMapper _inventoryMapper;

        /// <summary>
        /// The dialog service
        /// </summary>
        private readonly IDialogService _dialogService;

        /// <summary>
        /// The ib model
        /// </summary>
        private List<IBImportModel> ibModel;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExcelImport" /> class.
        /// </summary>
        /// <param name="excelParser">The excel parser.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        /// <param name="dialogService">The dialog service.</param>
        public ExcelImport(IExcelParser excelParser, IInventoryMapper inventoryMapper, IDialogService dialogService)
        {
            _dialogService = dialogService;
            _inventoryMapper = inventoryMapper;
            this._excelParser = excelParser;
        }

        /// <summary>
        /// TRComponent import function
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <param name="trNode">The tr node.</param>
        /// <returns>TRNode.</returns>
        /// <exception cref="InvalidOperationException">Invalide/Empty file</exception>
        /// <exception cref="ApplicationException"></exception>
        public void TRBaseNodeImport(string filePath, TRNode trNode)
        {
            try
            {
                var columnLst = GetColumnsForTr();

                List<TRImportModel> trModel = _excelParser.GetModelFromExcel<TRImportModel>(filePath, "Data", columnLst);

                if (trModel is null || trModel.FirstOrDefault().Maintenancezone == null)
                {
                    throw new InvalidOperationException("Invalide/Empty file");
                }

                trNode.ImportMaintenance(trModel);
            }
            catch (ApplicationException ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        /// <summary>
        /// IBcomponenet import function
        /// </summary>
        /// <param name="filepath">The filepath.</param>
        /// <param name="installedBase">The installed base.</param>
        /// <returns>InstalledBase.</returns>
        /// <exception cref="InvalidOperationException">Invalide/Empty file</exception>
        /// <exception cref="ApplicationException"></exception>
        public void IBComponentImport(string filepath, InstalledBase installedBase)
        {
            try
            {
                var columnLst = GetColumnsForIb();

                ibModel = _excelParser.GetModelFromExcel<IBImportModel>(filepath, "Data", columnLst);

                if (ibModel is null || ibModel.FirstOrDefault().Factory == null)
                {
                    throw new InvalidOperationException("Invalide/Empty file");
                }

                installedBase.ImportFactories(ibModel);
            }
            catch (ApplicationException ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        /// <summary>
        /// Gets the columns for ib.
        /// </summary>
        /// <returns>List&lt;System.String&gt;.</returns>
        private static List<string> GetColumnsForIb()
        {
            return new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N" };
        }

        /// <summary>
        /// Gets the columns for tr.
        /// </summary>
        /// <returns>List&lt;System.String&gt;.</returns>
        private static List<string> GetColumnsForTr()
        {
            return new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H", "I" };
        }

        /// <summary>
        /// Trs the base node import.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <returns>TRNode.</returns>
        /// <exception cref="ApplicationException"></exception>
        public TRNode TRBaseNodeImport(string filePath)
        {
            var trNode = new TRNode();
            try
            {
                var trComponents = _excelParser.GeModelsFromExcel<TRImportModel>(filePath, "Data", 1, 2);
                trNode.ImportMaintenance(trComponents);
            }
            catch (ApplicationException ex)
            {
                throw new ApplicationException(ex.Message);
            }

            return trNode;
        }

        /// <summary>
        /// function to import inventory details
        /// </summary>
        /// <param name="filepath">The filepath.</param>
        /// <param name="configNodes">The configuration nodes.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        /// <exception cref="InvalidOperationException">Invalide/Empty file</exception>
        public List<Inventory> IbInventoryImport(string filepath, List<Node> configNodes)
        {
            var colLst = GetColumnsForIb();

            if (ibModel is null || ibModel.FirstOrDefault().Factory == null)
            {
                throw new InvalidOperationException("Invalide/Empty file");
            }

            var inventories = _inventoryMapper.Map(ibModel, configNodes.Cast<INode>().ToList());
            var notFoundInventories = ibModel?.Where(i => !string.IsNullOrEmpty(i.Reference) && inventories.All(k => k.Reference.Trim() != i.Reference.Trim())).Select(i => i.Reference).ToList();
            ShowMessages(notFoundInventories);
            return inventories;
        }

        /// <summary>
        /// function to import inventory details
        /// </summary>
        /// <param name="filepath">The filepath.</param>
        /// <param name="stockNodes">The stock nodes.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        /// <exception cref="InvalidOperationException">Invalid /Empty file</exception>
        public List<Inventory> TrInventoryImport(string filepath, List<StockNode> stockNodes)
        {
            var columnLst = GetColumnsForTr();
            var trModel = _excelParser.GetModelFromExcel<TRImportModel>(filepath, "Data", columnLst);
            if (trModel is null || trModel.FirstOrDefault().Maintenancezone == null)
            {
                throw new InvalidOperationException("Invalid /Empty file");
            }

            var inventories = _inventoryMapper.Map(trModel, stockNodes.Cast<INode>().ToList());
            var notFoundInventories = trModel?.Where(i => !string.IsNullOrEmpty(i.Reference) && inventories.All(k => k.Reference.Trim() != i.Reference.Trim())).Select(i => i.Reference).ToList();
            ShowMessages(notFoundInventories);

            return inventories;
        }

        /// <summary>
        /// Shows the messages.
        /// </summary>
        /// <param name="messages">The messages.</param>
        private void ShowMessages(IReadOnlyCollection<string> messages)
        {
            if (messages == null || !messages.Any())
                return;
            var parameters = new DialogParameters
            {
                {"MessageLabel", "Product(s) not found."}, {"MessageCollection", messages},
                {"Title", "Missing Product(s)"},
            };

            _dialogService.ShowDialog("CustomMessageCollectionDialog", parameters, null);
        }
    }
}