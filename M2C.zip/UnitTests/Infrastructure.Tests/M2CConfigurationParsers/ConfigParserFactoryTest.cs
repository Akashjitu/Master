﻿using FluentAssertions;
using M2C.Configuration.Parsers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Infrastructure.Tests.M2CConfigurationParsers
{
    [TestClass]
    public class ConfigParserFactoryTest
    {
        [TestMethod]
        public void GetParserTest()
        {
            IConfigParser parser = ConfigParserFactory.GetParser(ParserType.LEGACY);
            parser.Should().NotBeNull();

            parser = ConfigParserFactory.GetParser(ParserType.NONE);
            parser.Should().BeNull();
        }
    }
}