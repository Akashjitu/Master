﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IBProjectComponent.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DomainModels.Common;
using Microsoft.EntityFrameworkCore;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class IBProjectComponent.
    /// Implements the <see cref="DomainModels.Common.ChangeTrack" />
    /// </summary>
    /// <seealso cref="DomainModels.Common.ChangeTrack" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class IBProjectComponent : ChangeTrack
    {
        /// <summary>
        /// Gets or sets the component identifier.
        /// </summary>
        /// <value>The component identifier.</value>
        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ComponentId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is linked.
        /// </summary>
        /// <value><c>true</c> if this instance is linked; otherwise, <c>false</c>.</value>
        public bool IsLinked { get; set; }

        /// <summary>
        /// Gets or sets the name of the component.
        /// </summary>
        /// <value>The name of the component.</value>
        [Required]
        public string ComponentName { get; set; }

        /// <summary>
        /// Gets or sets the project.
        /// </summary>
        /// <value>The project.</value>
        [ForeignKey("ProjectID")]
        public Project Project { get; set; }

        /// <summary>
        /// Gets or sets the metadata.
        /// </summary>
        /// <value>The metadata.</value>
        [ForeignKey("MetadataID")]
        public virtual Metadata Metadata { get; set; }

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        [ForeignKey("CommentId")]
        public virtual Comment Comment { get; set; }

        /// <summary>
        /// Gets or sets the type of the ib componenet.
        /// </summary>
        /// <value>The type of the ib componenet.</value>
        [ForeignKey("ComponentTypeID")]
        public virtual IBComponenetType IBComponenetType { get; set; }

        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public ICollection<XrefProduct> Products { get; set; }

        /// <summary>
        /// Gets or sets the node identifier.
        /// </summary>
        /// <value>The node identifier.</value>
        public int NodeID { get; set; }

        /// <summary>
        /// Gets or sets the parent identifier.
        /// </summary>
        /// <value>The parent identifier.</value>
        public int ParentID { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is tr node.
        /// Flag Field to identify resources belong to Technical Resource or not
        /// </summary>
        /// <value><c>true</c> if this instance is tr node; otherwise, <c>false</c>.</value>
        public bool IsTRNode { get; set; }

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="builder">The builder.</param>
        public static void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<IBProjectComponent>(entity =>
            {
                entity.Property(e => e.IsLinked).HasDefaultValue<bool>(true);
                entity.Property(e => e.IsTRNode).HasDefaultValue<bool>(false);
            });

            //Base class Modeling
            OnModelCreating<Contact>(builder);
        }
    }
}