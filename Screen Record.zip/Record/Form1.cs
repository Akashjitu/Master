﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using Microsoft.Expression.Encoder.ScreenCapture;
using Microsoft.Expression.Encoder.Devices;
using Microsoft.Expression.Encoder;
using System.Collections.ObjectModel;
using System.IO;
using System.Diagnostics;

namespace Record
{
    public partial class Form1 : Form

    {
        private ScreenCaptureJob jobsc;
        private string workDir= @"C:\\CaptureFiles\";


        Collection<EncoderDevice> audioDevices;
        EncoderDevice audioSelected;
        Collection<EncoderDevice> videoDevices;
        EncoderDevice videoSelected;
        Stopwatch watch = new Stopwatch();
        public Form1()
        {
            InitializeComponent();
            Initialization();
        }


        private void Initialization()
        {
             audioDevices = EncoderDevices.FindDevices(EncoderDeviceType.Audio);
            comboBox1.Items.AddRange(audioDevices.Select(i => i.Name).ToArray());

            videoDevices = EncoderDevices.FindDevices(EncoderDeviceType.Video);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Start();
            ScreenCap();
            
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            if (jobsc != null)
            {
                timer1.Stop();
                jobsc.Stop();
                label1.Text = "Stop";
            }
            else
                label1.Text = "Please Start";


        }


        private void ScreenCap()
        {

            if (audioSelected == null)
            {
                MessageBox.Show("Select Audio");
                return;
            }
            watch.Reset();
            watch.Start();
            label1.Text = "Start";
            string pcName = System.Environment.MachineName;
            jobsc = new ScreenCaptureJob();
            jobsc.ScreenCaptureVideoProfile.FrameRate = 5;
            jobsc.AddAudioDeviceSource(audioSelected);
            jobsc.ScreenCaptureAudioProfile.Channels = 1;
            jobsc.ScreenCaptureAudioProfile.SamplesPerSecond = 32000;
            jobsc.ScreenCaptureAudioProfile.BitsPerSample = 16;
            jobsc.ScreenCaptureAudioProfile.Bitrate = new Microsoft.Expression.Encoder.Profiles.ConstantBitrate(20);
          //  Rectangle capRect = new Rectangle(388, 222, 1056, 608);  //iMacros billpc slides only

            Rectangle capRect = GetScreen();  //iMacros billpc slides only
            jobsc.CaptureRectangle = capRect;
            var filename = string.Format("CurrentScreenCapture {0}.avi", DateTime.Now.ToString("dd-MM-yyy hh-mm tt"));
            File.Delete(workDir + filename);
            jobsc.OutputScreenCaptureFileName = (workDir + filename);
            jobsc.Start();
        }

        public Rectangle GetScreen()
        {
            return Screen.FromControl(this).Bounds;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (audioDevices != null && audioDevices.Count > 0)
                audioSelected = audioDevices[comboBox1.SelectedIndex];
        }

        private void btnPush_Click(object sender, EventArgs e)
        {
            if (jobsc != null && jobsc.Status == RecordStatus.Running)
            {
                timer1.Stop();
                jobsc.Pause();
                label1.Text = "Pause";
                watch.Stop();
                btnPush.Text = "Resume";
            }
            else if (jobsc != null && jobsc.Status == RecordStatus.Paused)
            {
                label1.Text = "Please Start";
                timer1.Start();
                watch.Start();
                jobsc.Resume();

                btnPush.Text = "Push";

            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            var videotimes = new TimeSpan(watch.ElapsedTicks);

            if (videotimes > new TimeSpan(0, 10, 0))
            {
                btnStop_Click(null, null);
                btnStart_Click(null, null);
            }
        

            label1.Text = videotimes.ToString();
        }

    }
}
