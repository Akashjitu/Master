﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.ExcelExports
{
    public interface IComplianceExports
    {
        byte[] Export(List<Compliance> compliance);
    }
}