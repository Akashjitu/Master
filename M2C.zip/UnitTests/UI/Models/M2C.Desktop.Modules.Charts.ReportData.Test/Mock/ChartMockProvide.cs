﻿using System.Collections.ObjectModel;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;

namespace M2C.Desktop.Modules.Charts.ReportData.Test.Mock
{
    public static class ChartMockProvide
    {
        private static readonly ObservableCollection<Inventory> Inventories = GetInventories();
        private static readonly ObservableCollection<Inventory> TrInventories = GetTrInventories();


        private static InstalledBase _installedBased ;
        private static TRNode _technicalResource = new TRNode() { Id = 1, Name = "TechnicalResource", MaintenanceNodes = GetMaintenanceNode(), MasterInventories = TrInventories };


        public static INode GetInstalledBasedNodeTree()
        {
            return _installedBased = new InstalledBase() { Id = 1, Name = "Installed Base", MasterInventories = Inventories, Factories = GetFactoryNodeNode() };
        }

        public static INode GetTechnicalResourceNodeTree()
        {
            return _technicalResource = new TRNode() { Id = 1, Name = "TechnicalResource", MaintenanceNodes = GetMaintenanceNode(), MasterInventories = TrInventories };
        }


        public static ObservableCollection<MaintenanceNode> GetMaintenanceNode()
        {
            var nodes = new ObservableCollection<MaintenanceNode>();
            var maintenance1 = new MaintenanceNode("Maintenance1")
            {
                Id = 2,
                NodeType = NodeType.MAINTENANCEZONE,
                ParentNode = _technicalResource,
                MasterInventories = Inventories,

            };
            maintenance1.StockNodes = GetStockNode(maintenance1);
            var maintenance2 = new MaintenanceNode("Maintenance2")
            {
                Id = 3,
                NodeType = NodeType.MAINTENANCEZONE,
                ParentNode = _technicalResource,
                MasterInventories = Inventories,
            };
            maintenance2.StockNodes = GetStockNode(maintenance2);
            nodes.Add(maintenance1);
            nodes.Add(maintenance2);
            return nodes;
        }

        public static ObservableCollection<FactoryNode> GetFactoryNodeNode()
        {
            ObservableCollection<FactoryNode> nodes = new ObservableCollection<FactoryNode>();


            var factory1 = new FactoryNode
            {
                Name = "Factory1",
                Id = 2,
                NodeType = NodeType.FACTORY,
                ParentNode = _installedBased,
                MasterInventories = Inventories,
            };

            factory1.WorkShopNodes = GetWorkShopNodes(factory1);

            var factory2 = new FactoryNode
            {
                Name = "Factory1",
                Id = 2,
                NodeType = NodeType.FACTORY,
                ParentNode = _installedBased,
                MasterInventories = Inventories,
            };


            nodes.Add(factory1);
            nodes.Add(factory2);
            return nodes;

        }
        public static ObservableCollection<WorkShopNode> GetWorkShopNodes(INode parentNode)
        {
            var nodes = new ObservableCollection<WorkShopNode>();
            var workshop1 = new WorkShopNode
            {
                Id = 4,
                NodeType = NodeType.WORKSHOP,
                Name = "Workshop1",
                ParentNode = parentNode as Node,
                MasterInventories = Inventories,
            };

            var workshop2 = new WorkShopNode
            {
                Id = 5,
                NodeType = NodeType.WORKSHOP,
                Name = "Workshop2",
                ParentNode = parentNode as Node,
                MasterInventories = Inventories,
            };
            workshop1.MachineNodes = GetMachineNodes(workshop1);
            workshop2.LineNodes = GetLineNodes(workshop2);

            nodes.Add(workshop1);
            nodes.Add(workshop2);
            return nodes;

        }

        public static ObservableCollection<LineNode> GetLineNodes(INode parentNode)
        {
            var nodes = new ObservableCollection<LineNode>();
            var line1 = new LineNode
            {
                Id = 6,
                NodeType = NodeType.LINE,
                Name = "Line1",
                ParentNode = parentNode as Node,
                MasterInventories = Inventories,

            };
            line1.MachineNodes = GetMachineNodes(line1);
            var line2 = new LineNode
            {
                Id = 7,
                NodeType = NodeType.LINE,
                Name = "Line2",
                ParentNode = parentNode as Node,
                MasterInventories = Inventories,
            };
            nodes.Add(line1);
            nodes.Add(line2);
            return nodes;

        }

        public static ObservableCollection<MachineNode> GetMachineNodes(INode parentNode)
        {
            //"Not Critical", CriticalityValue.Non_Critical);
            //"Somewhat Critical", CriticalityValue.Somewhat_Critical);
            //"Critical", CriticalityValue.Critical);
            //"Very Critical", CriticalityValue.Very_Critical);
            var nodes = new ObservableCollection<MachineNode>();
            var machine1 = new MachineNode
            {

                Id = 8,
                NodeType = NodeType.MACHINE,
                Name = "Machine1",
                ParentNode = parentNode as Node,
                MasterInventories = Inventories,
                CriticalityParams = new CriticalityModel() { SelectedValue = "Somewhat Critical" }
            };
            machine1.ConfigNodes = GetConfigNode(machine1);
            var machine2 = new MachineNode
            {
                Id = 9,
                NodeType = NodeType.MACHINE,
                Name = "Machine2",
                ParentNode = parentNode as Node,
                MasterInventories = Inventories,
                CriticalityParams = new CriticalityModel() { SelectedValue = "Very Critical" }
            };
            nodes.Add(machine1);
            nodes.Add(machine2);
            return nodes;

        }

        public static ObservableCollection<ConfigNode> GetConfigNode(INode parentNode)
        {
            var nodes = new ObservableCollection<ConfigNode>
            {

                new ConfigNode
                {
                    Id =10,
                    NodeType = NodeType.PLC_CONFIG,
                    Name = "PLC1",
                    ParentNode = parentNode as Node,
                    MasterInventories = Inventories,
                },
                new ConfigNode
                {
                    Id =11,
                    NodeType = NodeType.SHMI_CONFIG,   ParentNode = parentNode as Node,
                    MasterInventories = Inventories,
                    Name="HMI"
                },
                new ConfigNode
                {
                    Id =12,
                    NodeType = NodeType.MD_CONFIG,   ParentNode = parentNode as Node,
                    MasterInventories = Inventories,
                    Name = "Motion1"
                }
            };
            return nodes;

        }

        public static ObservableCollection<StockNode> GetStockNode(INode parentNode)
        {
            var nodes = new ObservableCollection<StockNode>
            {
                new StockNode( "StockNode1"){Id =4,
                    NodeType = NodeType.STOCK ,ParentNode = parentNode as Node,
                    MasterInventories = Inventories,},
                new StockNode("StockNode2"){Id =5, ParentNode = parentNode as Node,
                    NodeType = NodeType.STOCK,
                    MasterInventories = Inventories,},
                new StockNode("StockNode3"){Id =6,
                    NodeType = NodeType.STOCK,ParentNode = parentNode as Node,
                    MasterInventories = Inventories,}
            };
            return nodes;
        }

        public static ObservableCollection<Inventory> GetInventories()
        {
            ObservableCollection<Inventory> isinventories = new ObservableCollection<Inventory>()
            {
                new Inventory()
                {
                    Factory = "Factory1",
                    Workshop = "Workshop1",
                    Line="N/A",
                    Machine = "Machine1",
                    Configuration = "PLC Configuration",
                    Range = "Modicon Quantum",
                    Reference = "140DDI84100R",
                    Name = "Exchange 140DDI84100",
                    Quantity = 4,
                    PvNumber = "2",
                    SvNumber = "2",
                    Brand = "Schneider Electric",
                    Year = "#FFDC0A0A",//Red,
                    Year1 =  "#FFDC0A0A",
                    Year2 =  "#FFDC0A0A",
                    Year3 =  "#FFDC0A0A",
                    Year4 =  "#FFDC0A0A",
                    Dosa = "2018",
                    DoS = "2018",
                    EoS = "2019",
                    FactoryId = 2,//3
                    WorkshopId = 4,//5
                    LineId = 0,
                    MachineId = 8,//9
                    ConfigurationId = 10//
                },
                new Inventory()
                {
                    Factory = "Factory1",
                    Workshop = "Workshop1",
                    Line="N/A",
                    Machine = "Machine1",
                    Configuration = "PLC Configuration",
                    Range = "Modicon Quantum",
                    Reference = "140CPU11302R",
                    Name = "Exchange 140CPU11302",
                    Quantity = 2,
                    PvNumber = "2",
                    SvNumber = "2",
                    Brand = "Schneider Electric",
                    Year = "#FF3DCD58",//Green,
                    Year1 =  "#FF3DCD58",
                    Year2 = "#FF3DCD58",
                    Year3 =  "#FF3DCD58",
                    Year4 =  "#FF3DCD58",
                    Dosa = "2018",
                    DoS = "2018",
                    EoS = "2022",
                    FactoryId = 2,//3
                    WorkshopId = 4,//5
                    LineId = 0,
                    MachineId = 8,//9
                    ConfigurationId = 10//
                },
                new Inventory()
                {
                    Factory = "Factory1",
                    Workshop = "Workshop1",
                    Line="N/A",
                    Machine = "Machine1",
                    Configuration = "PLC Configuration",
                    Range = "Modicon Quantum",
                    Reference = "NWBM85C002",
                    Name = "ASSY BRIDGE/MUX",
                    Quantity = 3,
                    PvNumber = "2",
                    SvNumber = "2",
                    Brand = "Schneider Electric",
                    Year = "#FFFFD100",//Yellow,
                    Year1 =  "#FFFFD100",
                    Year2 = "#FFFFD100",
                    Year3 =  "#FFFFD100",
                    Year4 =  "#FFFFD100",
                    Dosa = "2018",
                    DoS = "2018",
                    EoS = "2020",
                    FactoryId = 2,//3
                    WorkshopId = 4,//5
                    LineId = 0,
                    MachineId = 8,//9
                    ConfigurationId = 10//
                }
            };
            return isinventories;

        }


        public static ObservableCollection<Inventory> GetTrInventories()
        {
            ObservableCollection<Inventory> inventories = new ObservableCollection<Inventory>()
            {
                new Inventory()
                {
                    MaintenanceZone = "Maintenance1",
                    Factory = "Factory1",
                    Workshop = "Workshop1",
                    Line="N/A",
                    Machine = "Machine1",
                    Configuration = "Stock",
                    Range = "Modicon Quantum",
                    Reference = "140DDI84100R",
                    Name = "Exchange 140DDI84100",
                    Quantity = 4,
                    PvNumber = "2",
                    SvNumber = "2",
                    Brand = "Schneider Electric",
                    Year = "#FFDC0A0A",//Red,
                    Year1 =  "#FFDC0A0A",
                    Year2 =  "#FFDC0A0A",
                    Year3 =  "#FFDC0A0A",
                    Year4 =  "#FFDC0A0A",
                    Dosa = "2018",
                    DoS = "2018",
                    EoS = "2019",
                    FactoryId = 2,//3
                    WorkshopId = 4,//5
                    LineId = 0,
                    MachineId = 8,//9
                    ConfigurationId = 10//
                },
                new Inventory()
                {
                    MaintenanceZone = "Maintenance1",
                    Factory = "Factory1",
                    Workshop = "Workshop1",
                    Line="N/A",
                    Machine = "Machine1",
                    Configuration = "Stock1",
                    Range = "Modicon Quantum",
                    Reference = "140CPU11302R",
                    Name = "Exchange 140CPU11302",
                    Quantity = 2,
                    PvNumber = "2",
                    SvNumber = "2",
                    Brand = "Schneider Electric",
                    Year = "#FF3DCD58",//Green,
                    Year1 =  "#FF3DCD58",
                    Year2 = "#FF3DCD58",
                    Year3 =  "#FF3DCD58",
                    Year4 =  "#FF3DCD58",
                    Dosa = "2018",
                    DoS = "2018",
                    EoS = "2022" ,
                    FactoryId = 2,//3
                    WorkshopId = 4,//5
                    LineId = 0,
                    MachineId = 8,//9
                    ConfigurationId = 10//
                },
                new Inventory()
                {
                    MaintenanceZone = "Maintenance1",
                    Factory = "Factory1",
                    Workshop = "Workshop1",
                    Line="N/A",
                    Machine = "Machine1",
                    Configuration = "Stock1",
                    Range = "Modicon Quantum",
                    Reference = "NWBM85C002",
                    Name = "ASSY BRIDGE/MUX",
                    Quantity = 3,
                    PvNumber = "2",
                    SvNumber = "2",
                    Brand = "Schneider Electric",
                    Year = "#FFFFD100",//Yellow,
                    Year1 =  "#FFFFD100",
                    Year2 = "#FFFFD100",
                    Year3 =  "#FFFFD100",
                    Year4 =  "#FFFFD100",
                    Dosa = "2018",
                    DoS = "2018",
                    EoS = "2020" ,
                    FactoryId = 2,//3
                    WorkshopId = 4,//5
                    LineId = 0,
                    MachineId = 8,//9
                    ConfigurationId = 10//
                }
            };
            return inventories;

        }

    }
}
