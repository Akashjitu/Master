﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="InputValidator.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows.Controls;
using System.Windows.Input;

namespace M2C.Desktop.Core.CommonValidations
{
    /// <summary>
    /// Class InputValidator.
    /// </summary>
    public static class InputValidator
    {
        /// <summary>
        /// Ares all valid numeric chars.
        /// </summary>
        /// <param name="str">The string.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public static bool AreAllValidNumericChars(string str)
        {
            var returnValue = true;
            if ((str == NumberFormatInfo.CurrentInfo.NegativeSign) |
                (str == NumberFormatInfo.CurrentInfo.PositiveSign))
                return true;

            var l = str.Length;
            for (var i = 0; i < l; i++)
            {
                var ch = str[i];
                returnValue &= char.IsDigit(ch);
            }

            return returnValue;
        }

        /// <summary>
        /// Maximums the length reached.
        /// </summary>
        /// <param name="e">The <see cref="TextCompositionEventArgs" /> instance containing the event data.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public static bool MaxLengthReached(TextCompositionEventArgs e)
        {
            var textBox = (TextBox) e.OriginalSource;
            var precision = textBox.MaxLength - 2;

            var textToValidate = textBox.Text.Insert(textBox.CaretIndex, e.Text).Replace("-", "");
            var numericValues = textToValidate.Split();

            return numericValues.Length <= 2 && numericValues[0].Length <= precision && numericValues.Length == 1;
        }

        /// <summary>
        /// Determines whether the specified text is number.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns><c>true</c> if the specified text is number; otherwise, <c>false</c>.</returns>
        public static bool IsNumber(string text)
        {
            var regex = new Regex("[^0-9]+");
            return regex.IsMatch(text);
        }
    }
}