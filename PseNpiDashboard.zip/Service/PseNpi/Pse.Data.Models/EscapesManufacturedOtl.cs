﻿using System.Collections.Generic;

namespace Pse.Data.Models
{
    public class EscapesManufacturedOtl
    {
        public Dictionary<int, int[]> EscapesManufacturedAfterOtl { get; set; }
    }
}