﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProjectResetEvent.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project;
using Prism.Events;

namespace M2C.Desktop.Core.GlobalEvents
{
    /// <summary>
    /// triggered when want to reset project
    /// </summary>
    public class ProjectResetEvent : PubSubEvent<bool>
    {
        /// <summary>
        /// Creates new data.
        /// </summary>
        /// <value>The new data.</value>
        public object NewData { get; set; }
    }
}