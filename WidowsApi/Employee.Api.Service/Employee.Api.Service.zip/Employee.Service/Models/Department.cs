﻿
namespace Employee.Service.Models
{
   public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int company_id { get; set; }
    }
}
