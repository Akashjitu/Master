﻿using Data.Management.Data.Models;
using DataManagement.Data.Models;
using System;
using System.Collections.Generic;

namespace Data.Management.Services.DataBaseAccessObject
{
    public interface IDataManagementDbAccess
    {
        List<DataManagementTrack> LoadAllDataManagements();

        List<DataManagementTrack> LoadById(int id);

        List<DataManagementTrack> LoadMaxRequestorId(string requestorId);

        List<DataManagementTrack> LoadByDate(DateTime created);

        DataManagementTrack AddNew(DataManagementTrack dataManagement);

        List<Site> LoadSites();

        List<Program> LoadPrograms();

        List<Customer> LoadCustomers();

        DataManagementTrack UpdateData(DataManagementTrack dataManagement);

        List<EmployeeInfo> GetUserDbAccess(string eid);

        int AddUserDbAccess(string eid, int access);
        List<EmployeeInfo> GetAllEmployeeAccess();
        EmployeeInfo AddEmployeeAccess(EmployeeInfo employeeInfo);
        EmployeeInfo UpdateEmployeeAccess(EmployeeInfo employeeInfo);

        EmployeeInfo GetEmployeeAccessByEid(EmployeeInfo employeeInfo);
    }
}