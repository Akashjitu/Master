﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProductSyncService.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using Newtonsoft.Json;
using RestClientServices.Contracts;
using RestClientServices.Helper;
using RestSharp;
using System;
using WinRegistryServices.Contracts;

namespace RestClientServices.Services
{
    /// <summary>
    /// Product Sync service
    /// </summary>
    /// <seealso cref="RestClientServices.Contracts.IRestClientService" />
    /// <seealso cref="RestClientServices.Contracts.IProductSyncService" />
    public class ProductSyncService : IProductSyncService
    {
        /// <summary>
        /// The application configurations
        /// </summary>
        private readonly IAppConfigurations appConfigurations;

        /// <summary>
        /// The registry store manger
        /// </summary>
        private readonly IRegistryStoreManger registryStoreManger;

        /// <summary>
        /// The rest sharp helper
        /// </summary>
        private readonly RestSharpHelper restSharpHelper;

        /// <summary>
        /// The response
        /// </summary>
        private ServiceResponse response = new ServiceResponse();

        /// <summary>
        /// Gets the service base path.
        /// </summary>
        /// <value>The service base path.</value>
        public string ServiceBasePath { get => appConfigurations.SyncServicePath; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductSyncService" /> class.
        /// </summary>
        /// <param name="appConfigurations">The application configurations.</param>
        /// <param name="restClient">The rest client.</param>
        /// <param name="registryStoreManger">The registry store manger.</param>
        public ProductSyncService(IAppConfigurations appConfigurations, IRestClient restClient,
            IRegistryStoreManger registryStoreManger)
        {
            this.appConfigurations = appConfigurations;
            this.registryStoreManger = registryStoreManger;
            restClient.BaseUrl = new Uri(this.ServiceBasePath);
            this.restSharpHelper = new RestSharpHelper(restClient);
        }

        /// <summary>
        /// Executes the specified request.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request">The request.</param>
        /// <returns>T.</returns>
        public T Execute<T>(IRestServiceRequest request)
        {
            try
            {
                response = restSharpHelper.ExecuteRequest(request);
                if (response != null && response.IsSuccess)
                {
                    return JsonConvert.DeserializeObject<T>(response.Content);
                }
                else
                {
                    return (T)Convert.ChangeType(null, typeof(T)); ;
                }
            }
            catch (Exception ex)
            {
                return (T)Convert.ChangeType(null, typeof(T)); ;
            }
        }

        /// <summary>
        /// Gets the product update by date.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="LastSyncDate">The last synchronize date.</param>
        /// <returns>T.</returns>
        public T getProductUpdateByDate<T>(string LastSyncDate)
        {
            IRestServiceRequest restServiceRequest = new RestServiceRequest()
            {
                ResourcePath = "Product/{lastSyncDate}"
            };
            restServiceRequest.HeaderParams.Add("Authorization", $"Bearer {registryStoreManger.GetValue("Accesstoken")}");

            restServiceRequest.PathParams.Add("lastSyncDate", LastSyncDate);

            return this.Execute<T>(restServiceRequest);
        }
    }
}