
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { DataManagement } from 'src/app/model/data.management';


export const ADD_DATA_MANAGEMENT = 'ADD_DATA_MANAGEMENT';
export const LOAD_DATA_MANAGEMENT = 'LOAD_DATA_MANAGEMENT';
export const REMOVE_DATA_MANAGEMENT = 'REMOVE_DATA_MANAGEMENT';
export const UPDATE_DATA_MANAGEMENT: string = 'UPDATE_DATA_MANAGEMENT';



export class LoadDataManagement implements Action {
    readonly type = LOAD_DATA_MANAGEMENT;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddDataManagement implements Action {
    readonly type = ADD_DATA_MANAGEMENT;

    constructor(public payload: any) { }
}

export class UpdateDataManagement implements Action {
    readonly type = UPDATE_DATA_MANAGEMENT;

    constructor(public payload: any) { }
}

export class RemoveDataManagement implements Action {
    readonly type = REMOVE_DATA_MANAGEMENT;

    constructor(public payload: number) { }
}


export type Actions = AddDataManagement | UpdateDataManagement | RemoveDataManagement;
