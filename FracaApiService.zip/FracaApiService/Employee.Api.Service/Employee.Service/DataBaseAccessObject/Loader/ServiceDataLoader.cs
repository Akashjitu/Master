﻿using Fraca.Data.Models;
using Fraca.DataBaseAccessObject;



namespace Fraca.Service.DataBaseAccessObject.Loader
{
    public class ServiceDataLoader : IServiceDataLoader
    {
        public FracaData GetAllFracaData()
        {
            using (var frc = new FracaDataAccess())
            {
                return new FracaData { FracaInfo = frc.LoadAllFraca() };
            }
        }

        public FracaData GetFracaByDate(FracaCriteria criteria)
        {
            using (var frc = new FracaDataAccess())
            {
                return new FracaData { FracaInfo = frc.GetFracaByDate(criteria.FromDate, criteria.ToDate) };
            }
        }

        public FracaData GetFracaByFilter(FracaCriteria criteria)
        {
            using (var frc = new FracaDataAccess())
            {
                return new FracaData { FracaInfo = frc.GetFracaByFilter(criteria.FracaNo, criteria.PartNo) };
            }
        }

        public FracaData GetFracaById(string Fracaid)
        {
            using (var frc = new FracaDataAccess())
            {
                return new FracaData { FracaInfo = frc.GetFracaById(Fracaid) };
            }
        }

        public FracaData GetFracaByPartNo(string partNo)
        {
            using (var frc = new FracaDataAccess())
            {
                return new FracaData { FracaInfo = frc.GetFracaByPartNo(partNo) };
            }
        }












        //public List<FracaInfo> GetFraca()
        //{
        //    Random generator = new Random();


        //    List<FracaInfo> fraca = new List<FracaInfo>();
        //    for (int i = 0; i < 20; i++)
        //    {
        //        fraca.Add(new FracaInfo()
        //        {

        //            FracaNo = string.Format("IND {0}", generator.Next(0, 999999).ToString("D6")),
        //            PartNo = "51090360-001",
        //            OpenDate = DateTime.Today.AddDays(i).ToString("MM/dd/yyyy"),
        //            CloseDate = DateTime.Today.AddDays(i + 2).ToString("MM/dd/yyyy"),
        //            FailedDate = DateTime.Today.AddDays(i - 5).ToString("MM/dd/yyyy"),
        //            Product = "SCU",
        //            Program = "B737",
        //            Customer = "Boeing Commercial",
        //            TestEnv = "EMI",
        //            Originator = "Sy. Tong",
        //            RespEng = "Andrecu, Mchael",
        //            System = "Panikh Nirav",
        //            Electrical = "Ma-Jack",
        //            Emi = "Sy-Tong",
        //            ClosedBy = "Andrecu, Mchael- Project Engineer ",
        //            TestDoc= "14C00083",
        //            Paragraph = "9.15 RFRS",
        //            TestType = "QUAL",
        //            FailureCode = "Included",
        //            EndUnit = "1",
        //            Level1 = "1",
        //            Level2 = "1",
        //            NcmendAture = "1",
        //            SerialNumber = Guid.NewGuid().ToString(),
        //            Designator = "1"
        //        });


        //    }
        //    return fraca;
        //}


    }



}


