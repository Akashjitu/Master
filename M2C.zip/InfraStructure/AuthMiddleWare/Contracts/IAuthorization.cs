﻿// ***********************************************************************
// Assembly         : AuthMiddleWare
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IAuthorization.cs" company="Schneider Electric">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AuthMiddleWare.Models;

namespace AuthMiddleWare.Contracts
{
    /// <summary>
    /// Authorization layer
    /// </summary>
    public interface IAuthorization
    {
        /// <summary>
        /// Gets the decoded token.
        /// </summary>
        /// <param name="jwtToken">The JWT token.</param>
        /// <returns>TokenJsonModel.</returns>
        TokenJsonModel GetDecodedToken(string jwtToken);

        /// <summary>
        /// Validates the token.
        /// </summary>
        /// <param name="jwtToken">The JWT token.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool ValidateToken(string jwtToken);
    }
}