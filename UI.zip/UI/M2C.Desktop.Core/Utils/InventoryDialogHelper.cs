﻿using M2C.Business;
using Prism.Services.Dialogs;
using System.Collections.Generic;

namespace M2C.Desktop.Core.Utils
{
    public class InventoryDialogHelper
    {
        private readonly IDialogService _dialogService;

        public InventoryDialogHelper(IDialogService dialogService)
        {
            this._dialogService = dialogService;
        }

        /// <summary>
        /// Show Message Box Dialog
        /// </summary>
        /// <param name="messages">The messages.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool ShowMessages(IReadOnlyCollection<string> messages)
        {
            try
            {
                var returnValue = false;
                if (messages == null)
                {
                    return false;
                }

                var parameters = new DialogParameters
            {
                {BusinessConstants.MessageLabel,"Below products got updated"},
                {BusinessConstants.MessageCollection, messages},
                {BusinessConstants.Title, "Project Update"},
                {BusinessConstants.IsCancelVisible, true}// set if require Cancel button
            };

                _dialogService.ShowDialog("CustomMessageCollectionDialog", parameters,
                    result => returnValue = result.Result == ButtonResult.OK);
                return returnValue;
            }
            catch
            {
                return false;
            }
        }
    }
}