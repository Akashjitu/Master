﻿// ***********************************************************************
// Assembly         : M2C.Configuration.Parsers
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ParserFactory.cs" company="M2C.Configuration.Parsers">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Configuration.Parsers.LegacyParsers;

namespace M2C.Configuration.Parsers
{
    /// <summary>
    /// Factory Class for PArsers
    /// </summary>
    public class ConfigParserFactory
    {
        /// <summary>
        /// Gets the parser.
        /// </summary>
        /// <param name="parserType">Type of the parser.</param>
        /// <returns>IConfigParser.</returns>
        public static IConfigParser GetParser(ParserType parserType)
        {
            IConfigParser parser = null;

            switch (parserType)
            {
                case ParserType.LEGACY:
                    {
                        parser = new LegacyParser();
                        break;
                    }
                default: break;
            }

            return parser;
        }
    }
}
