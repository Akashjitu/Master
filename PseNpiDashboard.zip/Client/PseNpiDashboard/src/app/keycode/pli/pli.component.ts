import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-pli',
  templateUrl: './pli.component.html',
  styleUrls: ['./pli.component.css']
})
export class PliComponent implements OnInit {
  ngOnInit(): void {
   
  }

}

