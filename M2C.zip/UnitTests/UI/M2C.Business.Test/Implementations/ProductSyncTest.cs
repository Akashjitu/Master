﻿using DataRepository.DBContracts;
using FluentAssertions;
using M2C.Business.Contracts;
using M2C.Business.Implementations;
using M2C.Business.Mappers.ProjectMap;
using M2C.Business.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Schneider.M2C.OpenExcel.Parser;
using SyncServiceLibrary.Contracts;
using System;

namespace M2C.Business.Test.Implementations
{
    [TestClass]
    public class ProductSyncTest : TestBase
    {
        protected Mock<IProductQueries> productQueries { get; set; }

        protected Mock<IExcelParser> ExcelParserMock { get; set; }
        protected Mock<IProductSynchronizer> mockProductsynchronizer;
        protected Mock<IProjectSynchronizer> mockProjectSynchronizer;

        protected Mock<ISyncProjectQueries> mockSyncProjectQueries;
        protected Mock<IProjectMapper> mockProjectMapper;
        protected Mock<IProjectLogic> mockIProjectLogic;

        [TestInitialize]
        public void TestIniTialize()
        {
            productQueries = MockRepo.Create<IProductQueries>();
            ExcelParserMock = MockRepo.Create<IExcelParser>();
            mockProductsynchronizer = MockRepo.Create<IProductSynchronizer>();
            mockProjectSynchronizer = MockRepo.Create<IProjectSynchronizer>();
            mockSyncProjectQueries = MockRepo.Create<ISyncProjectQueries>();
            mockProjectMapper = MockRepo.Create<IProjectMapper>();
            mockIProjectLogic = MockRepo.Create<IProjectLogic>();
        }

        [TestMethod]
        public void ProductSyncConstructorTest()
        {
            ProductSync prodSync = new ProductSync(mockProductsynchronizer.Object, mockProjectSynchronizer.Object, mockSyncProjectQueries.Object,
                mockProjectMapper.Object, mockIProjectLogic.Object);
            prodSync.Should().NotBeNull();
        }

        [TestMethod]
        public void SyncProductTest()
        {
            ProductSync prodSync = new ProductSync(mockProductsynchronizer.Object, mockProjectSynchronizer.Object, mockSyncProjectQueries.Object,
                 mockProjectMapper.Object, mockIProjectLogic.Object);
            Action act = () => prodSync.SyncProduct((SyncProcessModel model) => { });
            act.Should().NotThrow();
        }
    }
}