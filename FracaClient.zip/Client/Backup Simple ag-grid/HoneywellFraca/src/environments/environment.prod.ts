export const environment = {
  production: true,
  name:'Prod',
  //apiBaseUrl:'http://localhost:8080/Api/'
  //apiBaseUrl:'http://localhost/FracaService/api/'
  apiBaseUrl: 'http://approvalworkflowtool.honeywell.com/FracaService/api/'
};
