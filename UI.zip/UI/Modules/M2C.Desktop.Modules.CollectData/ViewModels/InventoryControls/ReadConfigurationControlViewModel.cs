// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-20-2020
// ***********************************************************************
// <copyright file="ReadConfigurationControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Configuration.Parsers;
using M2C.Configuration.Parsers.Model;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.UIModels;
using Microsoft.Win32;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Xml.Serialization;
using Brush = System.Windows.Media.Brush;

namespace M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls
{
    /// <summary>
    /// This is a view-model Class. it help Ui to Provide Data and Actions.
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="M2C.Desktop.Modules.CollectData.ICommonInventory" />
    public class ReadConfigurationControlViewModel : BindableBase, ICommonInventory
    {
        /// <summary>
        /// The c dialog all supported formats
        /// </summary>
        private const string c_DlgAllSupportedFormats = "All supported formats|*.asc;*.env;*.cfg;*.dcf;*.pwx;*.bin;*.fef;*.xef;*.zef|";
        /// <summary>
        /// The c dialog concept project
        /// </summary>
        private const string c_DlgConceptProject = "Concept Projects (*.asc)|*.asc|";
        /// <summary>
        /// The c dialog modsoft project
        /// </summary>
        private const string c_DlgModsoftProject = "Modsoft Projects (*.cfg, *.env)|*.cfg;*.env|";
        /// <summary>
        /// The c dialog pro worx NXT project
        /// </summary>
        private const string c_DlgProWORXNxtProject = "ProWORX Nxt Projects (*.dcf)|*.dcf|";
        /// <summary>
        /// The c dialog pro wor X32 project
        /// </summary>
        private const string c_DlgProWORX32Project = "ProWORX32 Projects (*.pwx)|*.pwx|";
        /// <summary>
        /// The c dialog ts x7 project
        /// </summary>
        private const string c_DlgTSX7Project = "TSX 7 Projects (*.bin)|*.bin|";
        /// <summary>
        /// The c dialog p l7 project
        /// </summary>
        private const string c_DlgPL7Project = "PL7 Pro Projects (*.fef)|*.fef|";
        /// <summary>
        /// The c dialog unity xef project
        /// </summary>
        private const string c_DlgUnityXEFProject = "Unity Pro Projects (*.xef, *.zef)|*.xef;*.zef";

        #region Class Fields

        /// <summary>
        /// Open the File FileDialog box for read the config file
        /// </summary>
        private readonly OpenFileDialog _openFileDialog;

        /// <summary>
        /// The selected file name
        /// </summary>
        private string _selectedFileName;
        /// <summary>
        /// The common inventory reference
        /// </summary>
        private readonly ICommonInventoryReference _commonInventoryReference;
        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator eventAggregator;
        /// <summary>
        /// The selected product
        /// </summary>
        private ProductModel _selectedProduct;
        /// <summary>
        /// The product models
        /// </summary>
        private readonly List<ProductModel> _productModels;
        /// <summary>
        /// The valid configuration message
        /// </summary>
        private string _validConfigMessage;
        /// <summary>
        /// The foreground color
        /// </summary>
        private Brush _foregroundColor;

        #endregion Class Fields

        #region Commands

        /// <summary>
        /// Raise event for open FileDialog box.
        /// </summary>
        /// <value>The on file selection command.</value>
        public DelegateCommand<string> OnFileSelectionCommand { get; set; }

        /// <summary>
        /// Raise event for validate the Config file Products.
        /// </summary>
        /// <value>The on validation command.</value>
        public DelegateCommand<string> OnValidationCommand { get; set; }

        #endregion Commands

        #region Properties

        /// <summary>
        /// Set TextBlock color based on the message
        /// </summary>
        /// <value>The color of the foreground.</value>
        public Brush ForegroundColor { get => _foregroundColor; set => SetProperty(ref _foregroundColor, value); }

        /// <summary>
        /// Gets or sets the valid configuration message.
        /// </summary>
        /// <value>The valid configuration message.</value>
        public string ValidConfigMessage { get => _validConfigMessage; set => SetProperty(ref _validConfigMessage, value, OnMessageSet); }

        /// <summary>
        /// Bind selected File name with Ui
        /// </summary>
        /// <value>The name of the selected file.</value>
        public string SelectedFileName { get => _selectedFileName; set => SetProperty(ref _selectedFileName, value); }

        /// <summary>
        /// UI Selected Product
        /// </summary>
        /// <value>The selected product.</value>
        public ProductModel SelectedProduct { get => _selectedProduct; set => SetProperty(ref _selectedProduct, value); }

        /// <summary>
        /// List of Selected Product from Config File
        /// </summary>
        /// <value>The selected products.</value>
        public List<ProductModel> SelectedProducts => _productModels;

        #endregion Properties

        /// <summary>
        /// Initialize Class fields.
        /// </summary>
        /// <param name="commonInventoryReference">use for Provide Data from Database</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        public ReadConfigurationControlViewModel(ICommonInventoryReference commonInventoryReference, IEventAggregator eventAggregator)
        {
            _commonInventoryReference = commonInventoryReference;
            this.eventAggregator = eventAggregator;
            OnFileSelectionCommand = new DelegateCommand<string>(OnFileSelection);
            OnValidationCommand = new DelegateCommand<string>(OnValidation);
            _productModels = new List<ProductModel>();
            _openFileDialog = new OpenFileDialog
            {
                Filter = CollectionConstant.ConfigFileFilter
            };
        }

        /// <summary>
        /// Event handler message test change
        /// </summary>
        private void OnMessageSet()
        {
            ForegroundColor = string.Compare(ValidConfigMessage, CollectionConstant.SuccessfullyMapped,
                    StringComparison.InvariantCulture) == 0
                    ? new BrushConverter().ConvertFromString("#2ce310") as SolidColorBrush
                    : new BrushConverter().ConvertFromString("#ed0505") as SolidColorBrush;
        }

        /// <summary>
        /// Open Dialog box for Select the File
        /// </summary>
        /// <param name="obj">The object.</param>
        private void OnFileSelection(string obj)
        {
            _openFileDialog.Filter = c_DlgAllSupportedFormats
                   + c_DlgConceptProject
                   + c_DlgModsoftProject
                   + c_DlgModsoftProject
                   + c_DlgProWORXNxtProject
                   + c_DlgProWORX32Project
                   + c_DlgTSX7Project
                   + c_DlgPL7Project
                   + c_DlgUnityXEFProject;
            if (_openFileDialog.ShowDialog() != true) return;
            ValidConfigMessage = string.Empty;
            SelectedFileName = _openFileDialog.FileName.Trim();
            _productModels.Clear();
            //lucky .. possible to remove validate button. on file open window do the operation.. need clear picture
            //if (!string.IsNullOrEmpty(SelectedFileName))
            //{
            //    var productNotFound = new List<string>();
            //    var products = GetProductModelByConfigParser(SelectedFileName, ref productNotFound);
            //    if (products == null)
            //        return;
            //    _productModels.AddRange(products);
            //}
        }

        /// <summary>
        /// Validate read and input Config File
        /// </summary>
        /// <param name="actionName">Name of The Action</param>
        private void OnValidation(string actionName)
        {
            if (string.IsNullOrEmpty(SelectedFileName) || !File.Exists(SelectedFileName))
            {
                MessageBox.Show($"Please select configuration file.", "Alert", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            var productNotFound = new List<string>();
            var products = GetProductModelByConfigParser(SelectedFileName, ref productNotFound);
            if (products == null)
                return;
            _productModels.AddRange(products);
        }

        /// <summary>
        /// Get the Product Models fro Config File
        /// </summary>
        /// <param name="filepath">Config File Path</param>
        /// <param name="productNotFound">The product not found.</param>
        /// <returns>List of ProductModel</returns>
        public IEnumerable<ProductModel> GetProductModelByConfigParser(string filepath, ref List<string> productNotFound)
        {
            try
            {
                if (string.IsNullOrEmpty(filepath) || !File.Exists(filepath))
                    return new List<ProductModel>();
                eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.VISIBLE });
                //set parse type
                var parser = ConfigParserFactory.GetParser(ParserType.LEGACY);
                //read file
                parser.ReadSourceFile(filepath);

                using (TextReader reader = new StringReader(parser.getXML()))
                {
                    var result = (configExchangeFile)new XmlSerializer(typeof(configExchangeFile)).Deserialize(reader);
                    var baseProducts = result.GetBOM();
                    var productModels = GetProductModels(baseProducts);

                    productNotFound = baseProducts.Where(baseProduct => !string.IsNullOrEmpty(baseProduct.name) &&
                            productModels.All(product => baseProduct.name != product.Identifier))
                        .Select(i => i.name).ToList();

                    ValidConfigMessage = productNotFound.Any()
                        ? string.Format(CollectionConstant.MessageParameterProductNotFound,
                            string.Join("\n", productNotFound))
                        : CollectionConstant.SuccessfullyMapped;

                    //Find Product replacement Details, and then add in ValidConfigMessage 
                    var replacementDetails = baseProducts
                        .Where(baseProduct => !string.IsNullOrEmpty(baseProduct.ReplacementDetail))
                        .Select(i => i.ReplacementDetail).ToList();

                    if (replacementDetails.Count > 0)
                    {
                        ValidConfigMessage += "\n\n";
                        ValidConfigMessage += string.Format(CollectionConstant.MessageParameterProductReplacement,
                            string.Join("\n", replacementDetails));
                    }
                    return productModels;
                }
            }
            catch (Exception ex)
            {
                ValidConfigMessage = CollectionConstant.MessageCorruptedFile;
                return null;
            }
            finally
            {
                eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
            }
        }

        /// <summary>
        /// Get The Products from Database.
        /// </summary>
        /// <param name="baseProducts">The base products.</param>
        /// <returns>Get List of Product modules</returns>
        private IEnumerable<ProductModel> GetProductModels(IEnumerable<BaseProduct> baseProducts)
        {
            var productModels = new List<ProductModel>();
            foreach (var baseProduct in baseProducts)
            {
                if (string.IsNullOrEmpty(baseProduct.name)) continue;

                var product = _commonInventoryReference.GetProductsByIdentifier(baseProduct.name);

                if (product == null) continue;

                product.Quantity = baseProduct.Count.ToString();
                productModels.Add(product);
            }

            return productModels;
        }
    }
}