﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="RangeModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;
using System;
using System.Collections.Generic;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class RangeModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class RangeModel : BindableBase
    {
        /// <summary>
        /// The name
        /// </summary>
        private string _name;
        /// <summary>
        /// The ops description
        /// </summary>
        private string _opsDescription;
        /// <summary>
        /// The identifier
        /// </summary>
        private int _id;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get => _id; set => SetProperty(ref _id, value); }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get => _name; set => SetProperty(ref _name, value); }

        /// <summary>
        /// Gets or sets the ops description.
        /// </summary>
        /// <value>The ops description.</value>
        public string OpsDescription { get => _opsDescription; set => SetProperty(ref _opsDescription, value); }

        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>The created date.</value>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the updated date.
        /// </summary>
        /// <value>The updated date.</value>
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Gets or sets the sub ranges.
        /// </summary>
        /// <value>The sub ranges.</value>
        public List<SubRangeModel> SubRanges { get; set; }
        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public List<ProductModel> Products { get; set; }
    }
}
