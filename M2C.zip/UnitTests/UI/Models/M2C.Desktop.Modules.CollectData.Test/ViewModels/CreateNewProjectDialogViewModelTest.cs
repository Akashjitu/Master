﻿using M2C.Desktop.Modules.CollectData.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Prism.Services.Dialogs;
using System;

namespace M2C.Desktop.Modules.CollectData.Test.ViewModels
{
    [TestClass]
    public class CreateNewProjectDialogViewModelTest
    {
        private CreateNewProjectDialogViewModel _createNewProjectDialogViewModel;

        [TestInitialize]
        public void Setup()
        {
           // _createNewProjectDialogViewModel = new CreateNewProjectDialogViewModel();
        }
    }
}