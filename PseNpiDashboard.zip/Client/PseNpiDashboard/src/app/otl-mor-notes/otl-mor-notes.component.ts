import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otl-mor-notes',
  templateUrl: './otl-mor-notes.component.html',
  styleUrls: ['./otl-mor-notes.component.sass']
})
export class OtlMorNotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
