﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReportDataConstant.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Desktop.Modules.Charts.ReportData.Constants
{
    /// <summary>
    /// Class ReportDataConstant.
    /// </summary>
    public static class ReportDataConstant
    {

        /// <summary>
        /// The message select x axis type
        /// </summary>
        public const string MessageSelectXAxisType = "Please select any X-AxisType";
        /// <summary>
        /// The information
        /// </summary>
        public const string Information = "information";
    }
}