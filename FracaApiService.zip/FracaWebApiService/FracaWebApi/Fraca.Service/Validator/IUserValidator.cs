﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Fraca.Data.Models;

namespace Fraca.Service.Validator
{
   public interface IUserValidator
    {
        bool IsUserValid(string id);
        
        bool IsValidForUpdate(string fracaNo, FracaInfo fracaInfo, string userid);

        List<FracaInfo> MapAccess(string userid, List<FracaInfo> infos);
        bool IsValidForDelete(string fracaNo, string eid);
    }
}
