﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 04-15-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ISyncProjectQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Sync Project Queries
    /// </summary>
    public interface ISyncProjectQueries
    {
        /// <summary>
        /// Gets all projects to synchronize.
        /// </summary>
        /// <returns>List&lt;Project&gt;.</returns>
        List<Project> GetAllProjectsToSync();

        /// <summary>
        /// Updates the last synchronize by.
        /// </summary>
        /// <param name="ProjectID">The project identifier.</param>
        /// <param name="ProjectReferenceId">The project reference identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool UpdateLastSyncBy(int ProjectID, string ProjectReferenceId);
    }
}