﻿
using Fraca.Data.Models;

namespace Fraca.Service.Manager
{
    public interface IFracaServiceManage
    {
        FracaData GetAllFracaData();

        FracaData GetFracaById(string Fracaid);
        FracaData GetFracaByDate(FracaCriteria criteria);
        FracaData GetFracaByFilter(FracaCriteria criteria);


        FracaInfo UpdateFraca(string Fracaid, FracaInfo fracaInfo);

        void DeleteFraca(string Fracaid);
        FracaInfo AddNewFraca(FracaInfo fracainfo);

        byte[] GetFracaPdfReport(string fracaId);
    }
}
