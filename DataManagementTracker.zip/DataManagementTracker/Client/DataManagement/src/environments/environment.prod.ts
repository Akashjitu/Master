export const environment = {
  production: true,
  apiBaseUrl: 'http://approvalworkflowtool.honeywell.com/CustomerApprovalService/api/',
  fileBaseUrl: 'http://approvalworkflowtool.honeywell.com/CustomerApprovalService/'

  //  apiBaseUrl: 'http://approvalworkflowtool.honeywell.com/DataManagementService/api/',
  //  fileBaseUrl: 'http://approvalworkflowtool.honeywell.com/DataManagementService/'
};
