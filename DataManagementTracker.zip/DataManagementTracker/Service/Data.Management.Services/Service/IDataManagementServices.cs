﻿
using DataManagement.Data.Models;
using System;
using System.Collections.Generic;

namespace Data.Management.Services
{
    public interface IDataManagementServices
    {
        List<DataManagementTrack> LoadAllDataManagements();
        List<DataManagementTrack> LoadById(int id);
        List<DataManagementTrack> LoadByDate(DateTime created);

       DataManagementTrack AddNew(DataManagementTrack dataManagement);
        DataManagementTrack UpdateData(DataManagementTrack dataManagement);



        //byte[] ExportEffectivenesAnalysis(EffectivenessAnalysis effectivenessAnalysis);

    }
}