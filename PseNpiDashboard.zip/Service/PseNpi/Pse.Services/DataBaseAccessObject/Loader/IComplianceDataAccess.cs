﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IComplianceDataAccess
    {
        List<Compliance> LoadCompliance();

        int AddCompliance(Compliance compliance);

        int DeleteCompliance(Compliance compliance);

        int UpdateCompliance(Compliance compliance);
    }
}