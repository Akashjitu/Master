﻿using Data.Management.Service.Host.ExceptionFilters;
using Data.Management.Services.Service;
using Honeywell.ActiveDirectory;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Data.Management.Service.Host.Controllers
{
   [ LogExceptionFilterAttribute]
    public class EmployeeController : ApiController
    {
       private readonly IEmployeeService _employeeService;
        IActiveDirectoryHelper _activeDirectoryHelper;
        public EmployeeController(IEmployeeService employeeService,   IActiveDirectoryHelper activeDirectoryHelper)
        {
            _employeeService = employeeService;
            _activeDirectoryHelper = activeDirectoryHelper;
        }


        [HttpGet]
        public HttpResponseMessage GetEmployeeName(string id)
        {
            var employ = _activeDirectoryHelper.GetUsersByFilte(id, SearchType.LOGINNAME);

            if (employ == null || employ.Count == 0)
                 employ = _activeDirectoryHelper.GetUsersByFilte(id, SearchType.EMAILADDRESS);

            if ((employ == null || employ.Count == 0))
                return Request.CreateResponse(HttpStatusCode.OK, "Employee Not Found.", JsonMediaTypeFormatter.DefaultMediaType);
           
                return Request.CreateResponse(HttpStatusCode.OK, employ[0].DisplayName, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpGet]
        [Route("api/Employee/search")]
        public HttpResponseMessage GetEmployeeName(string value, int type)
        {
          var Employees=  _employeeService.GetEmployeeInfo(value, (EmployeeSearchType)type);


            return Request.CreateResponse(HttpStatusCode.OK, Employees, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}