﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="DeviceTypeControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Mvvm;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using M2C.Business.GlobalFields;

namespace M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls
{
    /// <summary>
    /// ViewModel for DeviceTypeControl.
    /// Provide Binding Data and Event
    /// </summary>
    public class DeviceTypeControlViewModel : BindableBase, ICommonInventory
    {
        #region Event Command

        /// <summary>
        /// Event for All Combo box Selection Change
        /// </summary>
        /// <value>The on selection change command.</value>
        public DelegateCommand<string> OnSelectionChangeCommand { get; set; }

        /// <summary>
        /// event When user Start typing
        /// </summary>
        /// <value>The on key up p change command.</value>
        public DelegateCommand<RoutedEventArgs> OnKeyUpPChangeCommand { get; set; }

        #endregion Event Command

        #region Class Fields

        /// <summary>
        /// The products
        /// </summary>
        private List<ProductModel> _products;
        /// <summary>
        /// The device types
        /// </summary>
        private List<DeviceTypeModel> _deviceTypes;
        /// <summary>
        /// The ranges
        /// </summary>
        private List<RangeModel> _ranges;
        /// <summary>
        /// The selected range models
        /// </summary>
        private RangeModel _selectedRangeModels;
        /// <summary>
        /// The device type model
        /// </summary>
        private DeviceTypeModel _deviceTypeModel;
        /// <summary>
        /// The common inventory common reference
        /// </summary>
        private readonly ICommonInventoryReference _commonInventoryCommonReference;
        /// <summary>
        /// The selected product
        /// </summary>
        private ProductModel _selectedProduct;
        /// <summary>
        /// The device type collection
        /// </summary>
        private static List<DeviceTypeModel> _deviceTypeCollection;

        #endregion Class Fields

        #region Properties

        /// <summary>
        /// Product Based on the Selection. bind with Reference combo box.
        /// </summary>
        /// <value>The products.</value>
        public List<ProductModel> Products { get => _products; set => SetProperty(ref _products, value); }

        /// <summary>
        /// Get Device Type Based on Brand  and  range Selection.
        /// </summary>
        /// <value>The device types.</value>
        public List<DeviceTypeModel> DeviceTypes { get => _deviceTypes; set => SetProperty(ref _deviceTypes, value); }

        /// <summary>
        /// Ger range based on Brand selection
        /// </summary>
        /// <value>The ranges.</value>
        public List<RangeModel> Ranges { get => _ranges; set => SetProperty(ref _ranges, value); }

        /// <summary>
        /// Get Selected range from range combo box Selection.
        /// </summary>
        /// <value>The selected range models.</value>
        public RangeModel SelectedRangeModels { get => _selectedRangeModels; set => SetProperty(ref _selectedRangeModels, value); }

        /// <summary>
        /// Get Selected Device type based on Device type combo box Selection
        /// </summary>
        /// <value>The type of the selected device.</value>
        public DeviceTypeModel SelectedDeviceType { get => _deviceTypeModel; set => SetProperty(ref _deviceTypeModel, value); }

        /// <summary>
        /// Get Selected  Product based on Reference Combo box Selection
        /// </summary>
        /// <value>The selected product.</value>
        public ProductModel SelectedProduct { get => _selectedProduct; set => SetProperty(ref _selectedProduct, value); }

        /// <summary>
        /// Get Collection of Selected  Product based if multiple selected
        /// </summary>
        /// <value>The selected products.</value>
        public List<ProductModel> SelectedProducts => SelectedProduct != null
            ? new List<ProductModel> { SelectedProduct }
            : new List<ProductModel>();

        #endregion Properties

        /// <summary>
        /// Initialize Class fields
        /// </summary>
        /// <param name="commonInventoryCommonReference">The common inventory common reference.</param>
        public DeviceTypeControlViewModel(ICommonInventoryReference commonInventoryCommonReference)
        {
            _commonInventoryCommonReference = commonInventoryCommonReference;
            OnKeyUpPChangeCommand = new DelegateCommand<RoutedEventArgs>(OnKeyUpPChange);
            OnSelectionChangeCommand = new DelegateCommand<string>(OnSelectionChange);
            DeviceTypes = _deviceTypeCollection = _commonInventoryCommonReference.GetDeviceTypesByNodeType(GlobalFiled.SelectedNodeType).OrderBy(i => i.Type).ToList();
        }

        /// <summary>
        /// Event Handler when user start typing
        /// </summary>
        /// <param name="identifier">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void OnKeyUpPChange(RoutedEventArgs identifier)
        {
        }

        /// <summary>
        /// event Handler based on thr user combo box selection change
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        private void OnSelectionChange(string identifier)
        {
            if (string.IsNullOrEmpty(identifier))
                return;
            switch (identifier.ToUpper())
            {
                case CollectionConstant.Range:
                    if (SelectedDeviceType == null || SelectedRangeModels == null)
                        return;

                    SelectedProduct = null;
                    Products = _commonInventoryCommonReference.GetProductsByDeviceIdAndRangeId(SelectedDeviceType.Id, SelectedRangeModels.Id);
                    break;

                case CollectionConstant.DeviceType:
                    if (SelectedDeviceType == null)
                        return;
                    Products?.Clear();
                    SelectedProduct = null;
                    Ranges = _commonInventoryCommonReference.GetRangeByDeviceTypeIds(SelectedDeviceType.Id);
                    break;
            }
        }
    }
}