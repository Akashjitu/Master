import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { GridViewComponent } from './grid-view/grid-view.component';
import { AgGridModule } from 'ag-grid-angular';
import { FilterComponent } from './filter/filter.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import {FracaService } from './service/fraca-service.service';
import { ShareDataService } from './service/share-data.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { StoreModule} from '@ngrx/store'
import { reducer} from './store/fracaReducer';
import { FormsModule } from '@angular/forms';
import { EntryFormComponent } from './entry-form/entry-form.component';
import { TooltipModule } from 'ng2-tooltip-directive';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { NotifierModule, NotifierOptions, NotifierService } from 'angular-notifier';
import { AngularEditorModule } from '@kolkov/angular-editor';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {CdkStepperModule} from '@angular/cdk/stepper';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule,
} from '@angular/material';

const customNotifierOptions: NotifierOptions = {
  position: {
		horizontal: {
			position: 'right',
			distance: 12
		},
		vertical: {
			position: 'top',
			distance: 12,
			gap: 10
		}
	},
  theme: 'material',
  behaviour: {
    autoHide: 5000,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 4
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 300,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 300,
      easing: 'ease',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};

@NgModule({
  declarations: [
    AppComponent,
    GridViewComponent,
    FilterComponent,
    EntryFormComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserAnimationsModule,
    NoopAnimationsModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    DragDropModule,
   ScrollingModule,
    CdkStepperModule,
    CdkTableModule,
   CdkTreeModule,



    BrowserModule,
    AgGridModule.withComponents([]),
    ModalModule.forRoot(),
    AngularEditorModule,
    TooltipModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'fracareport', component: GridViewComponent },
      //{ path: '', redirectTo: '#', pathMatch: 'full' },
     // { path: 'home1', component: PageNotFoundComponent }
    ]),
    FormsModule,
    NotifierModule.withConfig(customNotifierOptions),
    StoreModule.forRoot({
      fracaReducer: reducer
    })
  ],
  providers: [FracaService, ShareDataService],
  bootstrap: [AppComponent]
})



export class AppModule { 
}
