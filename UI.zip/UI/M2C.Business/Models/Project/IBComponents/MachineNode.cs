﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="MachineNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using M2C.Business.Contracts;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Data;
using M2C.Business.GlobalFields;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Class MachineNode.
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class MachineNode : Node, IChildNode, ICloneable, IDelete, ICriticality, IOperationMode
    {
        /// <summary>
        /// The configuration nodes
        /// </summary>
        private ObservableCollection<ConfigNode> _configNodes;

        /// <summary>
        /// The criticality parameters
        /// </summary>
        private CriticalityModel criticalityParameters;
        /// <summary>
        /// criticalityParameters
        /// </summary>
        /// <value>The criticality parameters.</value>
        public CriticalityModel CriticalityParameters { get => criticalityParameters; set { SetProperty(ref criticalityParameters, value); } }

        /// <summary>
        /// The operation parameters
        /// </summary>
        private OperationModeModel _operationParams = new OperationModeModel();

        /// <summary>
        /// Initializes a new instance of the <see cref="MachineNode" /> class.
        /// </summary>
        public MachineNode()
        {
            this.NodeType = NodeType.MACHINE;
            _configNodes = new ObservableCollection<ConfigNode>();
            ConfigNodes.CollectionChanged += ConfigNodes_CollectionChanged;
            CriticalityParameters = new CriticalityModel();
        }

        /// <summary>
        /// Handles the CollectionChanged event of the ConfigNodes control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void ConfigNodes_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MachineNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public MachineNode(string name)
        {
            this.NodeType = NodeType.MACHINE;
            this.Name = name;
            _configNodes = new ObservableCollection<ConfigNode>();
            ConfigNodes.CollectionChanged += ConfigNodes_CollectionChanged;
            CriticalityParameters = new CriticalityModel();
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="MachineNode" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="parentNode">The parent node.</param>
        public MachineNode(int id, string name, INode parentNode)
        {
            Id = id;
            ParentNode = parentNode;
            this.NodeType = NodeType.MACHINE;
            this.Name = name;
            _configNodes = new ObservableCollection<ConfigNode>();
            ConfigNodes.CollectionChanged += ConfigNodes_CollectionChanged;
            CriticalityParameters = new CriticalityModel();
        }

        /// <summary>
        /// Gets or sets the configuration nodes.
        /// </summary>
        /// <value>The configuration nodes.</value>
        public ObservableCollection<ConfigNode> ConfigNodes { get => _configNodes; set => SetProperty(ref _configNodes, value); }

        // public string Criticality { get; set; }
        /// <summary>
        /// Gets or sets the criticality parameters.
        /// </summary>
        /// <value>The criticality parameters.</value>
        public CriticalityModel CriticalityParams { get; set; }

        /// <summary>
        /// operation modes
        /// </summary>
        /// <value>The operation parameters.</value>
        public OperationModeModel OperationParams { get => _operationParams; set => _operationParams = value; }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        public CompositeCollection ChildNodes
        {
            get
            {
                return new CompositeCollection()
                    {
                        new CollectionContainer() { Collection = ConfigNodes }
                    };
            }
        }

        /// <summary>
        /// Adds the child.
        /// </summary>
        /// <param name="components">The components.</param>
        internal void AddChild(List<IBProjectComponent> components)
        {
            var configComponents = components.Where(x => (x.IBComponenetType.ComponentTypeID == 6 ||//PLC Config
                                             x.IBComponenetType.ComponentTypeID == 7 ||//Motion & Drive Config
                                             x.IBComponenetType.ComponentTypeID == 8 ||//Scada HMI Config
                                             x.IBComponenetType.ComponentTypeID == 9)//Open Configuration Config
                                            && x.ParentID == this.Id).ToList();
            foreach (var c in configComponents)
            {
                var cnf = new ConfigNode(c.NodeID, c.ComponentName, ((NodeType)c.IBComponenetType.ComponentTypeID),
                    this);
                
                ConfigNodes.Add(cnf);
            }
        }

        /// <summary>
        /// Creates a new object that is a copy of the current instance.
        /// </summary>
        /// <returns>A new object that is a copy of this instance.</returns>
        public object Clone()
        {
            MachineNode cloneNode = this.MemberwiseClone() as MachineNode;
            if (cloneNode != null)
            {
                cloneNode.ParentNode = null;
                cloneNode.Id = null;

                cloneNode.ConfigNodes = new ObservableCollection<ConfigNode>();
                cloneNode.ConfigNodes.CollectionChanged += ConfigNodes_CollectionChanged;
                foreach (var c in this.ConfigNodes)
                {
                    var confignode = c.Clone() as ConfigNode;
                    confignode.Id = GlobalFiled.GenerateRandomId();
                    cloneNode.ConfigNodes.Add(confignode);
                    if (confignode != null) confignode.ParentNode = cloneNode;
                }

                return cloneNode;
            }
            return cloneNode;
        }

        /// <summary>
        /// Deletes this instance.
        /// </summary>
        public void Delete()
        {
            if (this.ParentNode is LineNode)
            {
                (this.ParentNode as LineNode)?.MachineNodes.Remove(this);
            }
            else if (this.ParentNode is WorkShopNode)
            {
                (this.ParentNode as WorkShopNode)?.MachineNodes.Remove(this);
            }
        }
    }

    /// <summary>
    /// extension class for MacihneNode for adding the configuration for machines
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class MachineExt
    {
        /// <summary>
        /// importing function for configuration
        /// </summary>
        /// <param name="machine">The machine.</param>
        /// <param name="IBComponenets">The ib componenets.</param>
        /// <exception cref="ApplicationException"></exception>
        public static void ImportConfig(this MachineNode machine, List<IBImportModel> IBComponenets)
        {
            IEnumerable<IBImportModel> IBComponenetsrow = IBComponenets.Where(x => x.Machine == machine.Name);
            var configInfo = IBComponenetsrow.
           Select(i => new
           {
               configName = i.ConfigurationName,
               configType = i.ConfigurationType,
           }).Distinct().ToList();

            try
            {
                if (configInfo.Any())
                {
                    foreach (var con in configInfo)
                    {
                        if (con.configName != null && con.configType != null)
                        {
                            var configType = con.configType;
                            if (con.configType.Any(char.IsDigit))
                                configType = con.configType.Remove(0, 3);

                            var configNode = new ConfigNode(GlobalFiled.GenerateRandomId(), con.configName, FindConfigType(configType), machine);
                            // configNode.ParentNode = machine;
                            //Import should be done to attached node only, Node ID is mandatory for filtering
                            machine.ConfigNodes.Add(configNode);
                            configNode.ImportInventory(IBComponenetsrow.ToList());
                        }
                    }
                }
            }
            catch (ArgumentNullException ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        /// <summary>
        /// comparing the config type
        /// </summary>
        /// <param name="configType">Type of the configuration.</param>
        /// <returns>NodeType.</returns>
        private static NodeType FindConfigType(string configType)
        {
            if (string.IsNullOrEmpty(configType))
                return NodeType.NONE;

            switch (configType.Trim().ToUpper())
            {
                case "PLC_CONFIG":
                case "PLC":
                case "PLC CONFIGURATION":
                    return NodeType.PLC_CONFIG;

                case "SHMI_CONFIG":
                case "SCADA HMI":
                case "SCADA HMI CONFIGURATION":
                    return NodeType.SHMI_CONFIG;

                case "MD_CONFIG":
                case "MOTION & DRIVE":
                case "MOTION & DRIVE CONFIGURATION":
                    return NodeType.MD_CONFIG;

                case "OPEN_CONFIG":
                case "OPEN":
                case "OPEN CONFIGURATION":
                    return NodeType.OPEN_CONFIG;

                default: return NodeType.NONE;
            }
        }

        /// <summary>
        /// Gets all nodes.
        /// </summary>
        /// <param name="machine">The machine.</param>
        /// <returns>List&lt;Node&gt;.</returns>
        public static List<Node> GetAllNodes(this MachineNode machine)
        {
            List<Node> nodes = new List<Node>();

            foreach (var n in machine.ConfigNodes)
            {
                nodes.Add(n);
            }

            return nodes;
        }
    }
}