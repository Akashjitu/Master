﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="RegionNames.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Desktop.Core
{
    /// <summary>
    /// Class RegionNames.
    /// </summary>
    public static class RegionNames
    {
        /// <summary>
        /// The content region
        /// </summary>
        public const string ContentRegion = "ContentRegion";
        /// <summary>
        /// The ribbon region
        /// </summary>
        public const string RibbonRegion = "RibbonRegion";
        /// <summary>
        /// The side bar tree vew region
        /// </summary>
        public const string SideBarTreeVewRegion = "SideBarTreeVewRegion";
        /// <summary>
        /// The propertise pane region
        /// </summary>
        public const string PropertisePaneRegion = "PropertisePaneRegion";
        /// <summary>
        /// The technical resource side bar tree vew region
        /// </summary>
        public const string TechnicalResourceSideBarTreeVewRegion = "TechnicalResourceSideBarTreeVewRegion";
        /// <summary>
        /// The technical resource propertise pane region
        /// </summary>
        public const string TechnicalResourcePropertisePaneRegion = "TechnicalResourcePropertisePaneRegion";
        /// <summary>
        /// The collect data region
        /// </summary>
        public const string CollectDataRegion = "CollectDataRegion";

        /// <summary>
        /// The side tool bar for Chart
        /// </summary>
        public const string SideChartToolBarRegion = "SideChartToolBarRegion";


        /// <summary>
        /// The  Analysis Chart
        /// </summary>
        public const string AnalysisChartRegion = "AnalysisChartRegion";


        /// <summary>
        /// The  Chart Container
        /// </summary>
        public const string ChartContainerRegion = "ChartContainerRegion";

        /// <summary>
        /// The  Report Data Container
        /// </summary>
        public const string ReportDataContainerRegion = "ReportDataContainer";

        /// <summary>
        /// The side tool bar for Chart
        /// </summary>
        public const string ReportExportToolsRegion = "ReportExportToolsRegion";

        /// <summary>
        /// The analyze data region
        /// </summary>
        public const string AnalyzeDataRegion = "AnalyzeDataRegion";
        /// <summary>
        /// The report data region
        /// </summary>
        public const string ReportDataRegion = "ReportDataRegion";

        /// <summary>
        /// The inventory region
        /// </summary>
        public const string InventoryRegion = "InventoryRegion";

        /// <summary>
        /// The Customer Documents region
        /// </summary>
        public const string CustomerDocumentsRegion = "CustomerDocumentsRegion";
    }
}
