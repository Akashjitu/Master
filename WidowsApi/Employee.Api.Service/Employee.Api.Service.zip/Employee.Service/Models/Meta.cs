﻿namespace Employee.Service.Models
{
    public class Meta
    {
        public int Page { get; set; }
        public int Total { get; set; }
    }
}