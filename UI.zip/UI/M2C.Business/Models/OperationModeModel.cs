﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="OperationModeModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class OperationModeModel.
    /// </summary>
    public class OperationModeModel
    {
        /// <summary>
        /// Gets or sets the operating mode.
        /// </summary>
        /// <value>The operating mode.</value>
        public string OperatingMode { get; set; }

        /// <summary>
        /// Gets or sets the hourly production.
        /// </summary>
        /// <value>The hourly production.</value>
        public string HourlyProduction { get; set; }
        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>The start date.</value>
        public DateTime? StartDate { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [date visibility].
        /// </summary>
        /// <value><c>null</c> if [date visibility] contains no value, <c>true</c> if [date visibility]; otherwise, <c>false</c>.</value>
        public bool? DateVisibility { get; set; }
        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>The end date.</value>
        public DateTime? EndDate { get; set; }
        /// <summary>
        /// Gets or sets the age.
        /// </summary>
        /// <value>The age.</value>
        public string Age { get; set; }
        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get; set; }

    }

}
