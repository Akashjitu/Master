import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { IAppState } from 'src/app/store/userAccessRight/userAccessttReducer';
import { EmployesAccessService } from 'src/app/services/employesAccessService';
import { EmployeeService } from 'src/app/services/employeeService';

@Component({
  selector: 'app-user-control',
  templateUrl: './user-control.component.html',
  styleUrls: ['./user-control.component.css']
})
export class UserControlComponent implements OnInit {

  accessTitle: string
  submitButtion: string;
  
  gridApi;
  gridColumnApi;
  columnDefs: any;
  defaultColDef;
  rowData: any;
  selectedRow= {
    eid: '',
    accessType: 0,
    displayName:'',
    id:0
  };

  currentUser={
    eid: '',
    accessType: 0,
    displayName:'',
    id:0
  }
  modalRef: BsModalRef;

  constructor(public store: Store<IAppState>,
    private modalService: BsModalService, private service: EmployesAccessService,private employeeService: EmployeeService,) { 

    }

  ngOnInit() {
    this.accessTitle = 'Add New User Access.';
    this.submitButtion = 'Add New User';

    this.columnDefs =
      [
        { field: 'id', colId: 'id', hide: true, headerName: 'Id', },
        { field: 'eid', colId: 'eid', hide: false, headerName: 'Employee ID', },
        { field: 'displayName', colId: 'displayName', hide: false, headerName: 'Display Name', },
        { field: 'accessType', colId: 'accessType', hide: true, headerName: 'Access Type ID', },
        { field: 'accessName', colId: 'accessName', hide: false, headerName: 'Access Type', },
      ];
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      enableFilter: true,
      //width: 100,
      // editable: true,
      filter: true
    };

    this.service.getAllEmployeeAccess();
    this.store.select('userAccessReducer').subscribe(data => {
      this.rowData = data;
    });
    this.store.select('referenceReducer').subscribe(data => {
      this.currentUser = data.access;
      console.log('reference ' + data);
    });
  }

  onAddUpdate() {
    if(this.accessTitle === "Update User Access"){
    this.service.updateEmployeeAccess(this.selectedRow);
  }
    else {
      this.service.addEmployeeAccess(this.selectedRow);
    }

    this.modalRef.hide();
  }


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
  }

  autoSizeAll() {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.getColumn('id').setSort("desc")
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }
  searchText: any;
  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(this.searchText);
  }

  onSelectionChanged() {
    var selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows != null) {
      this.selectedRow = selectedRows[0];
    }

  }
  onRowDoubleClicked(template) {
console.log(this.currentUser.accessType)
if(this.currentUser.accessType ==0 || this.currentUser.accessType == 1){
  alert('Please Check Admin for Access.');
  return;
}
else{

    this.submitButtion = "Update User";
    this.accessTitle = "Update User Access"
    this.modalRef = this.modalService.show(template);
  }
  }

  onAddNew(template){
    if(this.currentUser.accessType ==0 || this.currentUser.accessType == 1){
      alert('Please Check Admin for Access.');
      return;
    }else{
    this.submitButtion = "Add New User";
    this.accessTitle = "Add New User Access."
    this.selectedRow.eid= '';
    this.selectedRow.accessType=0;
    this.modalRef = this.modalService.show(template);}
  }

  focusOut(element, helper){
    console.log(element)
    console.log(helper)
    //ng-reflect-model="sdsad"
   var  helperElt=   (helper as HTMLElement);
   
    console.log( "Event " +   (helper as HTMLElement).innerText)
    this.employeeService.getEmployeeById(element).subscribe(emp => {
    helperElt.hidden =  emp!='' ?false: true;
    helperElt.innerText= emp;
      });
  }

  clearFilters() {
    console.log("clearFilters");
    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }
}
