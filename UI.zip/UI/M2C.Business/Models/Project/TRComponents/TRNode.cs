﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="TRNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using M2C.Business.Models.Project.IBComponents;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Data;
using DomainModels.ProjectModels;
using M2C.Business.GlobalFields;

namespace M2C.Business.Models.Project.TRComponents
{
    /// <summary>
    /// Technical resource node
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.TRComponents.TRBaseNode" />
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TRNode : Node, IChildNode
    {
        /// <summary>
        /// The maintenance nodes
        /// </summary>
        private ObservableCollection<MaintenanceNode> _maintenanceNodes;

        /// <summary>
        /// Initializes a new instance of the <see cref="TRNode" /> class.
        /// </summary>
        public TRNode()
        {
            Id = 0;
            this.Name = "Technical Resource";
            this.NodeType = NodeType.TECHNICALRESOURCE;
            _maintenanceNodes = new ObservableCollection<MaintenanceNode>();
            MaintenanceNodes.CollectionChanged += MaintenanceNodes_CollectionChanged;
        }

        /// <summary>
        /// Handles the CollectionChanged event of the MaintenanceNodes control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void MaintenanceNodes_CollectionChanged(object sender,
            System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Gets or sets the maintenance nodes.
        /// </summary>
        /// <value>The maintenance nodes.</value>
        public ObservableCollection<MaintenanceNode> MaintenanceNodes
        {
            get => _maintenanceNodes;
            set => SetProperty(ref _maintenanceNodes, value);
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        public CompositeCollection ChildNodes
        {
            get
            {
                return new CompositeCollection()
                {
                    new CollectionContainer() {Collection = MaintenanceNodes}
                };
            }
        }

        /// <summary>
        /// Adds the child.
        /// </summary>
        /// <param name="components">The components.</param>
        public void AddChild(List<IBProjectComponent> components)
        {
            foreach (var c in components
                .Where(x => x.IBComponenetType.ComponentTypeID == (int)NodeType.MAINTENANCEZONE && x.ParentID == Id).ToList())
            {
                var maintenanceNode = new MaintenanceNode(c.NodeID, c.ComponentName, this);
                maintenanceNode.AddChild(components);
                MaintenanceNodes.Add(maintenanceNode);
            }

        }
    }

    /// <summary>
    /// extension class for importing maintenance node for the TR Node
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class TRNodeExt
    {
        /// <summary>
        /// Imports the maintenance.
        /// </summary>
        /// <param name="trNode">The tr node.</param>
        /// <param name="trComponents">The tr components.</param>
        public static void ImportMaintenance(this TRNode trNode, List<TRImportModel> trComponents)
        {
            if (trComponents != null)
            {
                var maintenanceZone = trComponents.Select(x => x.Maintenancezone).Distinct();
                foreach (var maintenance in maintenanceZone)
                {
                    if (maintenance != null)
                    {
                        var maintenanceNode = new MaintenanceNode(GlobalFiled.GenerateRandomId(), maintenance, trNode);
                        var tRComponents = trComponents.Where(i =>
                            string.Compare(i.Maintenancezone, maintenance, StringComparison.OrdinalIgnoreCase) == 0).ToList();
                        //Import should be done to attached node only, Node ID is mandatory for filtering
                        trNode.MaintenanceNodes.Add(maintenanceNode);
                        maintenanceNode.ImportStock(tRComponents);

                    }
                }
            }
        }

        /// <summary>
        /// Gets all Child nodes.
        /// </summary>
        /// <param name="trNode">The tr node.</param>
        /// <returns>List&lt;Node&gt;.</returns>
        public static List<Node> GetAllNodes(this TRNode trNode)
        {
            var nodes = new List<Node> { trNode };
            foreach (var node in trNode.MaintenanceNodes)
            {
                nodes.Add(node);
                nodes.AddRange(node.GetAllNodes());
            }

            return nodes;
        }
    }
}