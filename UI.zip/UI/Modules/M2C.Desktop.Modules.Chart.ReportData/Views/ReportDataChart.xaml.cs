﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="ReportDataChart.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using M2C.Business.Models.Chart;

namespace M2C.Desktop.Modules.Charts.ReportData.Views
{
    /// <summary>
    /// Interaction logic for ReportDataChart.xaml
    /// </summary>
    public partial class ReportDataChart : UserControl
    {
        /// <summary>
        /// The chart elements
        /// </summary>
        /// <summary>
        /// The chart elements
        /// </summary>
        private ObservableCollection<ChartBarElement> _chartElements;
        /// <summary>
        /// The x axes label
        /// </summary>
        /// <summary>
        /// The x axes label
        /// </summary>
        private string _xAxesLabel;
        /// <summary>
        /// The y axes label
        /// </summary>
        /// <summary>
        /// The y axes label
        /// </summary>
        private string _yAxesLabel;
        /// <summary>
        /// The header label
        /// </summary>
        /// <summary>
        /// The header label
        /// </summary>
        private string _headerLabel;
        /// <summary>
        /// The yellow chart elements
        /// </summary>
        /// <summary>
        /// The yellow chart elements
        /// </summary>
        private ObservableCollection<ChartBarElement> _yellowChartElements;
        /// <summary>
        /// The green chart elements
        /// </summary>
        /// <summary>
        /// The green chart elements
        /// </summary>
        private ObservableCollection<ChartBarElement> _greenChartElements;
        /// <summary>
        /// The red chart elements
        /// </summary>
        /// <summary>
        /// The red chart elements
        /// </summary>
        private ObservableCollection<ChartBarElement> _redChartElements;

        /// <summary>
        /// Collection of Pi Chart
        /// </summary>
        /// <summary>
        /// The pi chart elements
        /// </summary>
        private DependencyProperty _piChartElements;

        /// <summary>
        /// The chart elements property
        /// </summary>
        /// <summary>
        /// The pi chart elements property
        /// </summary>
        public static readonly DependencyProperty PiChartElementsProperty =
            DependencyProperty.Register("PiChartElements", typeof(ObservableCollection<ChartBarElement>), typeof(ReportDataChart), new UIPropertyMetadata(null));

        /// <summary>
        /// The chart elements property
        /// </summary>
        /// <summary>
        /// The chart elements property
        /// </summary>
        public static readonly DependencyProperty ChartElementsProperty =
            DependencyProperty.Register("ChartElements", typeof(ObservableCollection<ChartBarElement>), typeof(ReportDataChart), new UIPropertyMetadata(null));

        /// <summary>
        /// The header label property
        /// </summary>
        /// <summary>
        /// The header label property
        /// </summary>
        public static readonly DependencyProperty HeaderLabelProperty =
            DependencyProperty.Register("HeaderLabel", typeof(string), typeof(ReportDataChart), new UIPropertyMetadata(string.Empty));

        /// <summary>
        /// The x axes label property
        /// </summary>
        /// <summary>
        /// The x axes label property
        /// </summary>
        public static readonly DependencyProperty XAxesLabelProperty =
            DependencyProperty.Register("XAxesLabel", typeof(string), typeof(ReportDataChart), new UIPropertyMetadata(string.Empty));

        /// <summary>
        /// The y axes label property
        /// </summary>
        /// <summary>
        /// The y axes label property
        /// </summary>
        public static readonly DependencyProperty YAxesLabelProperty =
            DependencyProperty.Register("YAxesLabel", typeof(string), typeof(ReportDataChart), new UIPropertyMetadata(string.Empty));

        /// <summary>
        /// The red chart elements property
        /// </summary>
        /// <summary>
        /// The red chart elements property
        /// </summary>
        public static readonly DependencyProperty RedChartElementsProperty =
            DependencyProperty.Register("RedChartElements", typeof(ObservableCollection<ChartBarElement>), typeof(ReportDataChart), new UIPropertyMetadata(null));

        /// <summary>
        /// The yellow chart elements property
        /// </summary>
        /// <summary>
        /// The yellow chart elements property
        /// </summary>
        public static readonly DependencyProperty YellowChartElementsProperty =
            DependencyProperty.Register("YellowChartElements", typeof(ObservableCollection<ChartBarElement>), typeof(ReportDataChart), new UIPropertyMetadata(null));

        /// <summary>
        /// The green chart elements property
        /// </summary>
        /// <summary>
        /// The green chart elements property
        /// </summary>
        public static readonly DependencyProperty GreenChartElementsProperty =
            DependencyProperty.Register("GreenChartElements", typeof(ObservableCollection<ChartBarElement>), typeof(ReportDataChart), new UIPropertyMetadata(null));






        /// <summary>
        /// Initializes a new instance of the <see cref="ReportDataChart"/> class.
        /// </summary>
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportDataChart"/> class.
        /// </summary>
        public ReportDataChart()
        {
            InitializeComponent();
            if (GreenChartElements == null)
                GreenChartElements = new ObservableCollection<ChartBarElement>();
            if (YellowChartElements == null)
                YellowChartElements = new ObservableCollection<ChartBarElement>();
            if (RedChartElements == null)
                RedChartElements = new ObservableCollection<ChartBarElement>();
            //   PiChartElements= new ObservableCollection<ChartBarElement>();
        }

        /// <summary>
        /// Collection of Pi Chart
        /// </summary>
        /// <value>The pi chart elements.</value>
        public ObservableCollection<ChartBarElement> PiChartElements
        {
            get { return (ObservableCollection<ChartBarElement>)GetValue(_piChartElements); }
            set { SetValue(_piChartElements, value); }
        }

        /// <summary>
        /// Gets or sets the chart elements.
        /// </summary>
        /// <value>The chart elements.</value>
        public ObservableCollection<ChartBarElement> ChartElements
        {
            get { return (ObservableCollection<ChartBarElement>)GetValue(ChartElementsProperty); }
            set { SetValue(ChartElementsProperty, value); }
        }

        /// <summary>
        /// Gets or sets the header label.
        /// </summary>
        /// <value>The header label.</value>
        public string HeaderLabel
        {
            get { return (string)GetValue(HeaderLabelProperty); }
            set { SetValue(HeaderLabelProperty, value); }
        }

        /// <summary>
        /// Gets or sets the x axes label.
        /// </summary>
        /// <value>The x axes label.</value>
        public string XAxesLabel
        {
            get { return (string)GetValue(XAxesLabelProperty); }
            set { SetValue(XAxesLabelProperty, value); }
        }
        /// <summary>
        /// Gets or sets the y axes label.
        /// </summary>
        /// <value>The y axes label.</value>
        public string YAxesLabel
        {
            get { return (string)GetValue(YAxesLabelProperty); }
            set { SetValue(YAxesLabelProperty, value); }
        }


        /// <summary>
        /// Gets or sets the red chart elements.
        /// </summary>
        /// <value>The red chart elements.</value>
        public ObservableCollection<ChartBarElement> RedChartElements
        {
            get { return (ObservableCollection<ChartBarElement>)GetValue(RedChartElementsProperty); }
            set { SetValue(RedChartElementsProperty, value); }
        }
        /// <summary>
        /// Gets or sets the yellow chart elements.
        /// </summary>
        /// <value>The yellow chart elements.</value>
        public ObservableCollection<ChartBarElement> YellowChartElements
        {
            get { return (ObservableCollection<ChartBarElement>)GetValue(YellowChartElementsProperty); }
            set { SetValue(YellowChartElementsProperty, value); }
        }
        /// <summary>
        /// Gets or sets the green chart elements.
        /// </summary>
        /// <value>The green chart elements.</value>
        public ObservableCollection<ChartBarElement> GreenChartElements
        {
            get { return (ObservableCollection<ChartBarElement>)GetValue(GreenChartElementsProperty); }
            set { SetValue(GreenChartElementsProperty, value); }
        }
    }
}
