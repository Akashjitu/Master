import { DatePipe } from '@angular/common';

export class PliSummaryColumns {
    constructor(private datePipe: DatePipe){}


    static  columns =[
        {
          headerName: "Key Code",
          field: "keyCode",
          colId: "keyCode", hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Program Name",
          field: "programName",
          colId: "programName",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Program PM",
          field: "programPM",
          colId: "programPM",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, };
          }
        },
        {
          headerName: "SBU",
          field: "sbu",
          colId: "sbu",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        }, {
          headerName: "GBE",
          field: "gbe",
          colId: "gbe",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        }, {
          headerName: "IPDS Phase",
          field: "ipdsPhase",
          colId: "ipdsPhase",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "IRF Health",
          field: "irfHealth",
          colId: "irfHealth",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "Ese Health",
          field: "eseHealth",
          colId: "eseHealth",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "CRF Health",
          field: "crfHealth",
          colId: "crfHealth",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "RTY",
          field: "rtyhealth",
          colId: "rtyhealth",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "UPC",
          field: "upc",
          colId: "upc",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "APQP",
          field: "apqpHealth",
          colId: "apqpHealth",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "Pli Rating",
          field: "pliRating",
          colId: "pliRating",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
  
        {
          headerName: "Otl Health",
          field: "otlHealth",
          colId: "otlHealth",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }
        },
        {
          headerName: "OTL Commnets",
          field: "otlCommnets",
          colId: "otlCommnets",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Id",
          field: "id",
          colId: "id",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Updated By",
          field: "updatedBy",
          colId: "updatedBy",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "Created By",
          field: "createdBy",
          colId: "createdBy",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "No Of New Parts",
          field: "noOfNewParts",
          colId: "noOfNewParts",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "No Of New Parts On Contract",
          field: "noOfNewPartsOnContract",
          colId: "noOfNewPartsOnContract",
          hide: true,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
          headerName: "ESE 2.0",
          field: "eseNewVersion",
          colId: "eseNewVersion",
          hide: false,
          cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value };
          }
        },
        {
            headerName: "IRF",
            field: "irf",
            colId: "irf",
            hide: true,
            cellStyle: function (params) {
              return { "background-color": params.value, 'color': params.value };
            }
          },
          {
            headerName: "CRF",
            field: "crf",
            colId: "crf",
            hide: true,
            cellStyle: function (params) {
              return { "background-color": params.value, 'color': params.value };
            }
          },
          {
            headerName: "Ece Escapes",
            field: "eceEscapes",
            colId: "eceEscapes",
            hide: true,
            cellStyle: function (params) {
              return { "background-color": params.value, 'color': params.value };
            }
          },
      ];
}