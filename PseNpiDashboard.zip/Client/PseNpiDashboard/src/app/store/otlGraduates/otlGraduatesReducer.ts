

import { Action } from '@ngrx/store';
import * as OtlGraduatesAction from './otlGraduatesAction';
import { OtlGraduates } from 'src/app/model/otlGraduates';




export interface IAppState {
    readonly compliance: OtlGraduates[];
}


export function otlGraduatesReducer(state: OtlGraduates[] = [], action: OtlGraduatesAction.Actions) {

    switch (action.type) {

        case OtlGraduatesAction.ADD_OTL_GRADUATES: {
            return [...state, action.payload]

        }

        case OtlGraduatesAction.LOAD_OTL_GRADUATES: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case OtlGraduatesAction.UPDATE_OTL_GRADUATES: {
            const tti = (action.payload as OtlGraduates);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            //return Object.assign([], state);
            return state.slice();
        }



        default:
            return state;
    }
}