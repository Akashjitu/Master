﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ICommonInventory.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using System.Collections.Generic;

namespace M2C.Desktop.Modules.CollectData
{
    /// <summary>
    /// Interface ICommonInvetory
    /// </summary>
    public interface ICommonInventory
    {
        /// <summary>
        /// From View Selected Product
        /// </summary>
        /// <value>The selected product.</value>
        ProductModel SelectedProduct { get; set; }


        /// <summary>
        /// List of Selected Product
        /// </summary>
        /// <value>The selected products.</value>
        List<ProductModel> SelectedProducts { get; }
    }
}