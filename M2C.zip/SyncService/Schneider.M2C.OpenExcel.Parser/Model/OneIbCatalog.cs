﻿// ***********************************************************************
// Assembly         : Schneider.M2C.OpenExcel.Parser
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="OneIbCatalog.cs" company="Schneider.M2C.OpenExcel.Parser">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Newtonsoft.Json;

namespace Schneider.M2C.OpenExcel.Parser.Model
{
    /// <summary>
    /// Class OneIbCatalog.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OneIbCatalog
    {
        /// <summary>
        /// Gets or sets the bu.
        /// </summary>
        /// <value>The bu.</value>
        [ExcelParserColumn("BU")]
        public string Bu { get; set; }

        /// <summary>
        /// Gets or sets the brand legacy.
        /// </summary>
        /// <value>The brand legacy.</value>
        [ExcelParserColumn("Brand  (Legacy)")]
        public string BrandLegacy { get; set; }

        /// <summary>
        /// Gets or sets the range legacy.
        /// </summary>
        /// <value>The range legacy.</value>
        [ExcelParserColumn("Range (Legacy)")]
        public string RangeLegacy { get; set; }

        /// <summary>
        /// Gets or sets the device type legacy.
        /// </summary>
        /// <value>The device type legacy.</value>
        [ExcelParserColumn("Device type  (Legacy)")]
        public string DeviceTypeLegacy { get; set; }

        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        [ExcelParserColumn("Product Identifier")]
        public string ProductIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the product identifier category.
        /// </summary>
        /// <value>The product identifier category.</value>
        [ExcelParserColumn("Product Identifier Category")]
        public string ProductIdentifierCategory { get; set; }

        /// <summary>
        /// Gets or sets the product description.
        /// </summary>
        /// <value>The product description.</value>
        [ExcelParserColumn("Product Description")]
        public string ProductDescription { get; set; }

        /// <summary>
        /// Gets or sets the serviceable.
        /// </summary>
        /// <value>The serviceable.</value>
        [ExcelParserColumn("Serviceable  (Y/N)")]
        public string Serviceable { get; set; }

        /// <summary>
        /// Gets or sets the traceable.
        /// </summary>
        /// <value>The traceable.</value>
        [ExcelParserColumn("Traceable (Y/N)")]
        public string Traceable { get; set; }

        /// <summary>
        /// Gets or sets the service business value.
        /// </summary>
        /// <value>The service business value.</value>
        [ExcelParserColumn("Service Business Value")]
        public string ServiceBusinessValue { get; set; }

        /// <summary>
        /// Gets or sets the ops brand code.
        /// </summary>
        /// <value>The ops brand code.</value>
        [ExcelParserColumn("OPS Brand Code")]
        public string OpsBrandCode { get; set; }

        /// <summary>
        /// Gets or sets the ops brand description.
        /// </summary>
        /// <value>The ops brand description.</value>
        [ExcelParserColumn("OPS Brand Description")]
        public string OpsBrandDescription { get; set; }

        /// <summary>
        /// Gets or sets the ops range code.
        /// </summary>
        /// <value>The ops range code.</value>
        [ExcelParserColumn("OPS Range Code")]
        public int OpsRangeCode { get; set; }

        /// <summary>
        /// Gets or sets the ops range description.
        /// </summary>
        /// <value>The ops range description.</value>
        [ExcelParserColumn("OPS Range Description")]
        public string OpsRangeDescription { get; set; }

        /// <summary>
        /// Gets or sets the SDH sub range code.
        /// </summary>
        /// <value>The SDH sub range code.</value>
        [ExcelParserColumn("SDH SubRange Code")]
        public string SdhSubRangeCode { get; set; }

        /// <summary>
        /// Gets or sets the SDH sub range description.
        /// </summary>
        /// <value>The SDH sub range description.</value>
        [ExcelParserColumn("SDH SubRange Description")]
        public string SdhSubRangeDescription { get; set; }

        /// <summary>
        /// Gets or sets the ops device type code.
        /// </summary>
        /// <value>The ops device type code.</value>
        [ExcelParserColumn("OPS Device type Code")]
        public string OpsDeviceTypeCode { get; set; }

        /// <summary>
        /// Gets or sets the ops device type description.
        /// </summary>
        /// <value>The ops device type description.</value>
        [ExcelParserColumn("OPS Device type description")]
        public string OpsDeviceTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the end of production or phase out.
        /// </summary>
        /// <value>The end of production or phase out.</value>
        [ExcelParserColumn("End of production or Phase out")]
        public int EndOfProductionOrPhaseOut { get; set; }

        /// <summary>
        /// Gets or sets the end of commercialisation.
        /// </summary>
        /// <value>The end of commercialisation.</value>
        [ExcelParserColumn("End of commercialisation")]
        public int EndOfCommercialisation { get; set; }

        /// <summary>
        /// Gets or sets the obsolescence year.
        /// </summary>
        /// <value>The obsolescence year.</value>
        [ExcelParserColumn("Obsolescence year (spare parts availability not guaranteed anymore)")]
        public int ObsolescenceYear { get; set; }

        /// <summary>
        /// Gets or sets the end of services year or withdrawal year or end of support.
        /// </summary>
        /// <value>The end of services year or withdrawal year or end of support.</value>
        [ExcelParserColumn("End of services year or Withdrawal year  or End of support")]
        public int EndOfServicesYearOrWithdrawalYearOrEndOfSupport { get; set; }

        /// <summary>
        /// Gets or sets the average life duration or useful life years.
        /// </summary>
        /// <value>The average life duration or useful life years.</value>
        [ExcelParserColumn("Average life duration or  useful life  (years)")]
        public int AverageLifeDurationOrUsefulLifeYears { get; set; }

        /// <summary>
        /// Gets or sets the warranty duration in months from shipment date.
        /// </summary>
        /// <value>The warranty duration in months from shipment date.</value>
        [ExcelParserColumn("Warranty duration in months (from shipment date)")]
        public int WarrantyDurationInMonthsFromShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets the name of the BFS skill expertise.
        /// </summary>
        /// <value>The name of the BFS skill expertise.</value>
        [ExcelParserColumn("bFS_Skill_Expertise_Name")]
        public string BfsSkillExpertiseName { get; set; }

        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <value>The source.</value>
        [ExcelParserColumn("Source")]
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets the status relevant for ip creation.
        /// </summary>
        /// <value>The status relevant for ip creation.</value>
        [ExcelParserColumn("Status - Relevant for IP Creation")]
        public string StatusRelevantForIpCreation { get; set; }

        /// <summary>
        /// Creates new valuerework.
        /// </summary>
        /// <value>The new value rework.</value>
        [ExcelParserColumn("New value Rework")]
        public string NewValueRework { get; set; }

        /// <summary>
        /// Gets or sets the is se brand.
        /// </summary>
        /// <value>The is se brand.</value>
        [ExcelParserColumn("Is SE Brand ?")]
        public string IsSeBrand { get; set; }

        /// <summary>
        /// Gets or sets the include installation services.
        /// </summary>
        /// <value>The include installation services.</value>
        [ExcelParserColumn("Include Installation Services")]
        public string IncludeInstallationServices { get; set; }

        /// <summary>
        /// Gets or sets the asset registration.
        /// </summary>
        /// <value>The asset registration.</value>
        [ExcelParserColumn("Asset\nRegistration")]
        public string AssetRegistration { get; set; }

        /// <summary>
        /// Gets or sets the activation sub range.
        /// </summary>
        /// <value>The activation sub range.</value>
        [ExcelParserColumn("Activation\nSub-Range")]
        public string ActivationSubRange { get; set; }

        /// <summary>
        /// Gets or sets the level1.
        /// </summary>
        /// <value>The level1.</value>
        [ExcelParserColumn("Level 1")]
        public string Level1 { get; set; }

        /// <summary>
        /// Gets or sets the level2.
        /// </summary>
        /// <value>The level2.</value>
        [ExcelParserColumn("Level 2")]
        public string Level2 { get; set; }

        /// <summary>
        /// Gets or sets the level3.
        /// </summary>
        /// <value>The level3.</value>
        [ExcelParserColumn("Level 3")]
        public string Level3 { get; set; }

        /// <summary>
        /// Gets or sets the level4.
        /// </summary>
        /// <value>The level4.</value>
        [ExcelParserColumn("Level 4")]
        public string Level4 { get; set; }

        /// <summary>
        /// Gets or sets the icon drop list.
        /// </summary>
        /// <value>The icon drop list.</value>
        [ExcelParserColumn("Icon\nDrop list")]
        public string IconDropList { get; set; }

        /// <summary>
        /// Gets or sets the picture shopping kiosk.
        /// </summary>
        /// <value>The picture shopping kiosk.</value>
        [ExcelParserColumn("Picture\n(Shopping Kiosk)")]
        public string PictureShoppingKiosk { get; set; }

        /// <summary>
        /// Gets or sets the comments picture.
        /// </summary>
        /// <value>The comments picture.</value>
        [ExcelParserColumn("Comments Picture")]
        public string CommentsPicture { get; set; }

        /// <summary>
        /// Gets or sets the connectable.
        /// </summary>
        /// <value>The connectable.</value>
        [ExcelParserColumn("Connectable")]
        public string Connectable { get; set; }

        /// <summary>
        /// Gets or sets the power kva.
        /// </summary>
        /// <value>The power kva.</value>
        [ExcelParserColumn("Power (kVA)")]
        public double PowerKva { get; set; }

        /// <summary>
        /// Gets or sets the update ato r.
        /// </summary>
        /// <value>The update ato r.</value>
        [ExcelParserColumn("Update (A to R columns)")]
        public string UpdateAtoR { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public int Version { get; set; }
    }
}