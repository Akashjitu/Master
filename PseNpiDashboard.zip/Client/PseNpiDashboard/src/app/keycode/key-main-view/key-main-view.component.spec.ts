import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyMainViewComponent } from './key-main-view.component';

describe('KeyMainViewComponent', () => {
  let component: KeyMainViewComponent;
  let fixture: ComponentFixture<KeyMainViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KeyMainViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeyMainViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
