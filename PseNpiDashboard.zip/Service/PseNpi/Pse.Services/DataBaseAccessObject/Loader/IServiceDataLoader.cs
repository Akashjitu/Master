﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IServiceDataLoader
    {
        List<TtiPartAlignment> LoadTtiById(TtiPartAlignment ttiPartAlignment);

        List<TtiPartAlignment> LoadTtiByDate(TtiPartAlignment ttiPartAlignment);

        List<TtiPartAlignment> LoadTtiByParameter(TtiPartAlignment ttiPartAlignment);

        List<TtiPartAlignment> LoadTti();

        List<Data.Models.Compliance> LoadCompliance();

        List<Data.Models.Effectiveness> LoadEffectivenesByPart(Data.Models.Effectiveness effectiveness);

        List<Data.Models.Effectiveness> LoadEffectivenesById(Data.Models.Effectiveness effectiveness);

        List<Data.Models.Effectiveness> LoadEffectivenesByDate(Data.Models.Effectiveness effectiveness);

        List<Data.Models.Effectiveness> LoadPppPartInfo(Data.Models.Effectiveness effectiveness);

        List<EffectivenessAnalysisDataAccess> LoadEffectivenesAnalysis();

        List<EffectivenessAnalysisDataAccess> LoadEffectivenessAnalysisByCreationDate(EffectivenessAnalysisDataAccess effectivenessAnalysis);

        List<EffectivenessAnalysisDataAccess> LoadEffectivenessAnalysisById(EffectivenessAnalysisDataAccess effectivenessAnalysis);

        List<EffectivenessAnalysisDataAccess> LoadEffectivenessAnalysisByPart(EffectivenessAnalysisDataAccess effectivenessAnalysis);
    }
}