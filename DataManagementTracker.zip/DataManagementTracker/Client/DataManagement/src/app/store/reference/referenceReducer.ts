import { Action } from '@ngrx/store';
import * as ReferenceAction from './referenceAction';
import { DataManagement } from 'src/app/model/data.management';


export interface IAppState {
    readonly reference: any;
}


export function referenceReducer(state: DataManagement[] = [], action: ReferenceAction.LoadReference) {

    switch (action.type) {

        case ReferenceAction.LOAD_REFERENCE: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        default:
            return state;
    }
}