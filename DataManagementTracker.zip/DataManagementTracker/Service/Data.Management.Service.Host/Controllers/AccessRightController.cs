﻿using Data.Management.Data.Models;
using Data.Management.Service.Host.ExceptionFilters;
using Data.Management.Service.Host.Providers;
using Data.Management.Services.Service;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;


namespace Data.Management.Service.Host.Controllers
{
    [LogExceptionFilterAttribute]
    public class AccessRightController : ApiController
    {
        private readonly IEmployeeService _employeeService;

        public AccessRightController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpGet]
        public HttpResponseMessage GetAllEmployeeAccess()
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //if (string.IsNullOrEmpty(eid))
           ////eid = "H161961";
            var access = _employeeService.GetAllEmployeeAccess(eid);
            return Request.CreateResponse(HttpStatusCode.OK, access, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        public HttpResponseMessage AddEmployeeAccess(EmployeeInfo employeeInfo)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //if (string.IsNullOrEmpty(eid))
           ////eid = "H161961";
            EmployeeInfo access = _employeeService.AddEmployeeAccess(employeeInfo);

            return Request.CreateResponse(HttpStatusCode.OK, access, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPut]
        public HttpResponseMessage UpdateEmployeeAccess(int id, EmployeeInfo employeeInfo)
        {

            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //if (string.IsNullOrEmpty(eid))
           ////eid = "H161961";


            EmployeeInfo access = _employeeService.UpdateEmployeeAccess(employeeInfo);

            return Request.CreateResponse(HttpStatusCode.OK, access, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}