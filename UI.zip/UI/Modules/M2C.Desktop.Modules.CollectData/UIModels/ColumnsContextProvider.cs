﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ColumnsContextProvider.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.CollectData.Constants;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using DateTime = System.DateTime;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Class ColumnsContextProvider.
    /// </summary>
    public static class ColumnsContextProvider
    {
        /// <summary>
        /// The context node items
        /// </summary>
        private static readonly List<ContextItem> InstallBasedContextNodeItems;

        /// <summary>
        /// The context items
        /// </summary>
        private static readonly List<ContextItem> InstallBasedContextItems;

        /// <summary>
        /// The grid column descriptions
        /// </summary>
        private static readonly List<GridColumnDescription> InstallBasedGridColumns;

        /// <summary>
        /// The technical resource columns
        /// </summary>
        private static readonly List<GridColumnDescription> TechnicalResourceColumns;

        /// <summary>
        /// The technical resource context node items
        /// </summary>
        private static readonly List<ContextItem> TechnicalResourceContextNodeItems;

        /// <summary>
        /// The technical resource context items
        /// </summary>
        private static readonly List<ContextItem> TechnicalResourceContextItems;

        /// <summary>
        /// Initializes static members of the <see cref="ColumnsContextProvider" /> class.
        /// </summary>
        static ColumnsContextProvider()
        {
            InstallBasedGridColumns = new List<GridColumnDescription>();
            TechnicalResourceColumns = new List<GridColumnDescription>();

            InstallBasedContextItems = new List<ContextItem>();
            TechnicalResourceContextItems = new List<ContextItem>();
            InstallBasedContextNodeItems = new List<ContextItem>();
            TechnicalResourceContextNodeItems = new List<ContextItem>();
        }

        /// <summary>
        /// Gets the columns.
        /// </summary>
        /// <param name="contextItems">The context items.</param>
        /// <returns>IEnumerable&lt;GridColumnDescription&gt;.</returns>
        public static IEnumerable<GridColumnDescription> GetInstallBasedColumns(out List<ContextItem> contextItems)
        {
            AddInstallBasedGridColumns();
            InstallBasedContextNodeItems.AddRange(InstallBasedContextItems);
            contextItems = InstallBasedContextItems;
            return InstallBasedGridColumns;
        }

        /// <summary>
        /// Gets the technical resource columns.
        /// </summary>
        /// <param name="contextItems">The context items.</param>
        /// <returns>IEnumerable&lt;GridColumnDescription&gt;.</returns>
        public static IEnumerable<GridColumnDescription> GetTechnicalResourceColumns(out List<ContextItem> contextItems)
        {
            AddTechnicalResourceColumns();
            contextItems = TechnicalResourceContextItems;
            TechnicalResourceContextNodeItems.AddRange(contextItems);
            return TechnicalResourceColumns;
        }

        /// <summary>
        /// Adds the install based grid columns.
        /// </summary>
        private static void AddInstallBasedGridColumns()
        {
            InstallBasedGridColumns.Clear();
            InstallBasedContextItems.Clear();

            var installBasedColumnsPath = ConfigurationManager.AppSettings[CollectionConstant.InstallBasedColumns];
            if (string.IsNullOrEmpty(installBasedColumnsPath))
                return;

            var installedBasedColumn = JsonConvert.DeserializeObject<List<GridColumnDescription>>(File.ReadAllText(installBasedColumnsPath));
            if (installedBasedColumn != null)
                InstallBasedGridColumns.AddRange(installedBasedColumn);
            AddYears(InstallBasedGridColumns);
            if (InstallBasedGridColumns.Count <= 0) return;
            var contexts = InstallBasedGridColumns.Where(i => i.IsContextItem).Select(i => new ContextItem

            {
                DisplayName = i.Header,
                IsChecked = true,
                MenuItemName = $"itmBtn{i.DisplayMember}",
                Visibility = true,
            });
            var selectionColumn = InstallBasedGridColumns.FirstOrDefault(i => i.SortMember == CollectionConstant.IsSelected);
            if (selectionColumn != null)
                selectionColumn.Visibility = Visibility.Hidden;
            InstallBasedContextItems.AddRange(contexts);

        }

        /// <summary>
        /// Adds the technical resource columns.
        /// </summary>
        private static void AddTechnicalResourceColumns()
        {
            TechnicalResourceColumns.Clear();
            TechnicalResourceContextItems.Clear();
            var columnsPath = ConfigurationManager.AppSettings[CollectionConstant.TechnicalResourceColumns];
            if (string.IsNullOrEmpty(columnsPath))
                return;

            var technicalResourceColumns =
                JsonConvert.DeserializeObject<List<GridColumnDescription>>(File.ReadAllText(columnsPath));
            if (technicalResourceColumns != null)
                TechnicalResourceColumns.AddRange(technicalResourceColumns);
            AddYears(TechnicalResourceColumns);
            if (TechnicalResourceColumns.Count <= 0) return;
            var contexts = TechnicalResourceColumns.Where(i => i.IsContextItem).Select(i => new ContextItem
            {
                DisplayName = i.Header,
                IsChecked = true,
                MenuItemName = $"itmBtn{i.DisplayMember}",
                Visibility = true,
            });

            var selectionColumn = TechnicalResourceColumns.FirstOrDefault(i => i.SortMember == CollectionConstant.IsSelected);
            if (selectionColumn != null)
                selectionColumn.Visibility = Visibility.Hidden;
            TechnicalResourceContextItems.AddRange(contexts);

        }

        /// <summary>
        /// Adds the years.
        /// </summary>
        /// <param name="gridColumnDescriptions">The grid column descriptions.</param>
        private static void AddYears(IReadOnlyCollection<GridColumnDescription> gridColumnDescriptions)
        {
            var year = gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year);
            if (year != null && string.IsNullOrEmpty(year.Header))
                year.Header = DateTime.Today.Year.ToString();

            var year1 = gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year1);
            if (year1 != null && string.IsNullOrEmpty(year1.Header))
                year1.Header = DateTime.Today.AddYears(1).Year.ToString();

            var year2 = gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year2);
            if (year2 != null && string.IsNullOrEmpty(year2.Header))
                year2.Header = DateTime.Today.AddYears(2).Year.ToString();

            var year3 = gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year3);
            if (year3 != null && string.IsNullOrEmpty(year3.Header))
                year3.Header = DateTime.Today.AddYears(3).Year.ToString();

            var year4 = gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year4);
            if (year4 != null && string.IsNullOrEmpty(year4.Header))
                year4.Header = DateTime.Today.AddYears(4).Year.ToString();
        }

        /// <summary>
        /// Hides the column by node.
        /// </summary>
        /// <param name="nodeType">Type of the node.</param>
        /// <param name="updatedContextItems">The updated context items.</param>
        public static void HideInstallBasedColumnByNode(NodeType nodeType, out List<ContextItem> updatedContextItems)
        {
            var selectionColumn = InstallBasedGridColumns.FirstOrDefault(i => i.SortMember == CollectionConstant.IsSelected);
            if (selectionColumn != null)
                selectionColumn.Visibility = Visibility.Hidden;
            InstallBasedContextNodeItems.ForEach(i =>
            {
                i.IsChecked = false;
                InstallBasedContextItems.Remove(i);
            });

            switch (nodeType)
            {
                case NodeType.INSTALLEDBASE:
                    InstallBasedContextNodeItems.ForEach(i =>
                    {
                        InstallBasedContextItems.Add(i);
                        i.IsChecked = true;
                    });
                    break;

                case NodeType.FACTORY:
                    InstallBasedContextNodeItems.Where(i => i.DisplayName != CollectionConstant.Factory).ToList()
                        .ForEach(i =>
                        {
                            InstallBasedContextItems.Add(i);
                            i.IsChecked = true;
                        });
                    break;

                case NodeType.WORKSHOP:
                    InstallBasedContextNodeItems.Where(i => i.DisplayName != CollectionConstant.Factory && i.DisplayName != CollectionConstant.Workshop).ToList()
                        .ForEach(i =>
                        {
                            InstallBasedContextItems.Add(i);
                            i.IsChecked = true;
                        });
                    break;

                case NodeType.LINE:
                    InstallBasedContextNodeItems.Where(i =>
                            i.DisplayName != CollectionConstant.Factory &&
                            i.DisplayName != CollectionConstant.Workshop &&
                            i.DisplayName != CollectionConstant.Line)
                        .ToList()
                        .ForEach(i =>
                        {
                            InstallBasedContextItems.Add(i);
                            i.IsChecked = true;
                        });
                    break;

                case NodeType.MACHINE:
                    InstallBasedContextNodeItems.Where(i =>
                            i.DisplayName != CollectionConstant.Factory &&
                            i.DisplayName != CollectionConstant.Workshop &&
                            i.DisplayName != CollectionConstant.Machine &&
                            i.DisplayName != CollectionConstant.Line)
                        .ToList()
                        .ForEach(i =>
                        {
                            InstallBasedContextItems.Add(i);
                            i.IsChecked = true;
                        });
                    break;

                case NodeType.OPEN_CONFIG:
                case NodeType.PLC_CONFIG:
                case NodeType.MD_CONFIG:
                case NodeType.SHMI_CONFIG:
                    InstallBasedContextNodeItems.Where(i =>
                            i.DisplayName != CollectionConstant.Factory &&
                            i.DisplayName != CollectionConstant.Workshop &&
                            i.DisplayName != CollectionConstant.Machine &&
                            i.DisplayName != CollectionConstant.Line &&
                            i.DisplayName != CollectionConstant.Configuration
                           )
                        .ToList()
                        .ForEach(i =>
                        {
                            InstallBasedContextItems.Add(i);
                            i.IsChecked = true;
                        });
                    if (selectionColumn != null) selectionColumn.Visibility = Visibility.Visible;
                    break;
            }

            updatedContextItems = InstallBasedContextItems;
        }

        /// <summary>
        /// Hides the technical resource column by node.
        /// </summary>
        /// <param name="nodeType">Type of the node.</param>
        /// <param name="updatedContextItems">The updated context items.</param>
        public static void HideTechnicalResourceColumnByNode(NodeType nodeType, out List<ContextItem> updatedContextItems)
        {
            var selectionColumn = TechnicalResourceColumns.FirstOrDefault(i => i.SortMember == CollectionConstant.IsSelected);
            if (selectionColumn != null)
                selectionColumn.Visibility = Visibility.Hidden;

            TechnicalResourceContextNodeItems.ForEach(i =>
            {
                i.IsChecked = false;
                TechnicalResourceContextItems.Remove(i);
            });

            switch (nodeType)
            {
                case NodeType.TECHNICALRESOURCE:
                    TechnicalResourceContextNodeItems.ForEach(i =>
                    {
                        TechnicalResourceContextItems.Add(i);
                        i.IsChecked = true;
                    });
                    break;

                case NodeType.MAINTENANCEZONE:
                    TechnicalResourceContextNodeItems.Where(i =>
                            i.DisplayName != CollectionConstant.MaintenanceZone).ToList()
                        .ForEach(i =>
                        {
                            TechnicalResourceContextItems.Add(i);
                            i.IsChecked = true;
                        });
                    break;

                case NodeType.STOCK:
                case NodeType.COMPETENCIES:
                    TechnicalResourceContextNodeItems.Where(i =>
                            i.DisplayName != CollectionConstant.MaintenanceZone &&
                            i.DisplayName != CollectionConstant.Configuration
                        )
                        .ToList()
                        .ForEach(i =>
                        {
                            TechnicalResourceContextItems.Add(i);
                            i.IsChecked = true;
                        });
                    if (selectionColumn != null) selectionColumn.Visibility = Visibility.Visible;
                    break;
            }

            updatedContextItems = TechnicalResourceContextItems;
        }
    }

    /// <summary>
    /// Class Extensions.
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        /// Converts to sentence.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns>System.String.</returns>
        public static string ToSentence(this string input)
        {
            return string.IsNullOrEmpty(input) ? string.Empty : new string(input.SelectMany((c, i) => i > 0 && char.IsUpper(c) ? new[] { ' ', c } : new[] { c }).ToArray());
        }

        /// <summary>
        /// Gets the type of the parent of.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="element">The element.</param>
        /// <returns>T.</returns>
        public static T GetParentOfType<T>(this DependencyObject element) where T : DependencyObject
        {
            Type type = typeof(T);
            if (element == null) return null;
            DependencyObject parent = VisualTreeHelper.GetParent(element);
            if (parent == null && ((FrameworkElement)element).Parent is DependencyObject) parent = ((FrameworkElement)element).Parent;
            if (parent == null) return null;
            else if (parent.GetType() == type || parent.GetType().IsSubclassOf(type)) return parent as T;
            return GetParentOfType<T>(parent);
        }
    }
}