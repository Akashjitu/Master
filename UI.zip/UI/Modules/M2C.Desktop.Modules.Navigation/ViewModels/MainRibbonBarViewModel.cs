﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Navigation
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-20-2020
// ***********************************************************************
// <copyright file="MainRibbonBarViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models.Project;
using M2C.Desktop.Core;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.Enums;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Core.Resources;
using M2C.Desktop.Core.Utils;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using SchneiderElectric.BrandIdentity.AboutBox;
using System;
using System.IO;
using System.Windows;

namespace M2C.Desktop.Modules.Navigation.ViewModels
{
    /// <summary>
    /// Class MainRibbonBarViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="System.IDisposable" />
    public class MainRibbonBarViewModel : BindableBase, IDisposable
    {
        #region PRIVATE FIELDS

        /// <summary>
        /// The global menu commands
        /// </summary>
        private IGlobalMenuComands _globalMenuComands;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// The region manager
        /// </summary>
        private readonly IRegionManager _regionManager;

        /// <summary>
        /// The file open service
        /// </summary>
        private readonly IFileOpenDialogue fileOpen;

        /// <summary>
        /// The project logic
        /// </summary>
        private readonly IProjectLogic projectLogic;

        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService sharedContextService;

        /// <summary>
        /// The new project command
        /// </summary>
        private DelegateCommand _newProjectCommand;

        /// <summary>
        /// The save project command
        /// </summary>
        private DelegateCommand _saveProjectCommand;

        /// <summary>
        /// The export project command
        /// </summary>
        private DelegateCommand _exportProjectCommand;

        /// <summary>
        /// The save button enable
        /// </summary>
        private bool saveButtonEnable = false;

        /// <summary>
        /// The settings command
        /// </summary>
        private DelegateCommand _settingsCommand;

        /// <summary>
        /// Gets or sets the download command.
        /// </summary>
        /// <value>The download command.</value>
        public DelegateCommand<string> DownloadCommand { get; set; }

        /// <summary>
        /// Gets the dialog service.
        /// </summary>
        /// <value>The dialog service.</value>
        public IDialogService DialogService { get; }

        /// <summary>
        /// Gets the templateDownload service
        /// </summary>
        private ITemplateDownloadLogic iTemplateDownloadLogic;

        /// <summary>
        /// The product synchronize
        /// </summary>
        private readonly IProductSync productSync;

        /// <summary>
        /// The open project command
        /// </summary>
        private DelegateCommand<int?> _OpenProjectCommand;

        /// <summary>
        /// The enable badge
        /// </summary>
        private bool enableBadge = false;

        /// <summary>
        /// The badge value
        /// </summary>
        private string badgeValue = "0";

        private readonly InventoryDialogHelper inventoryDialogHelper;

        #endregion PRIVATE FIELDS

        /// <summary>
        /// My profile
        /// </summary>
        private readonly IMyProfileLogic myProfile;

        /// <summary>
        /// Gets or sets the project property command.
        /// </summary>
        /// <value>The project property command.</value>
        public DelegateCommand ProjectPropertyCommand { get; set; }

        /// <summary>
        /// Gets or sets the loaded command.
        /// </summary>
        /// <value>The loaded command.</value>
        public DelegateCommand LoadedCommand { get; set; }

        /// <summary>
        /// Gets or sets the dummy command.
        /// </summary>
        /// <value>The dummy command.</value>
        public DelegateCommand DummyCommand { get; set; } = new DelegateCommand(() =>
        {
            MessageBox.Show("Not Implemented");
        });

        /// <summary>
        /// Gets or sets the about box command.
        /// </summary>
        /// <value>
        /// The about box command.
        /// </value>
        public DelegateCommand AboutBoxCommand { get; set; }

        /// <summary>
        /// Gets or sets the close active project.
        /// </summary>
        /// <value>
        /// The close active project.
        /// </value>
        public DelegateCommand CloseActiveProject { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="MainRibbonBarViewModel" /> class.
        /// </summary>
        /// <param name="globalMenuComands">The global menu commands.</param>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="regionManager">The region manager.</param>
        /// <param name="fileOpen">The file open.</param>
        /// <param name="projectLogic">The project logic.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        /// <param name="myProfile">My profile.</param>
        /// <param name="_iTemplateDownloadLogic">The i template download logic.</param>
        /// <param name="productSync">The product synchronize.</param>
        public MainRibbonBarViewModel(IGlobalMenuComands globalMenuComands, IDialogService dialogService,
            IEventAggregator eventAggregator, IRegionManager regionManager,
            IFileOpenDialogue fileOpen, IProjectLogic projectLogic,
            ISharedContextService sharedContextService, IMyProfileLogic myProfile,
            ITemplateDownloadLogic _iTemplateDownloadLogic, IProductSync productSync)
        {
            this.myProfile = myProfile;

            globalMenuComands.NewProjectCommand.RegisterCommand(NewProjectCommand);
            globalMenuComands.SaveCommand.RegisterCommand(SaveProjectCommand);
            globalMenuComands.ExportProjectCommand.RegisterCommand(ExportProjectCommand);
            globalMenuComands.OpenProjectCommand.RegisterCommand(OpenProjectCommand);

            _globalMenuComands = globalMenuComands;
            DialogService = dialogService;
            _eventAggregator = eventAggregator;
            _regionManager = regionManager;
            this.fileOpen = fileOpen;
            this.projectLogic = projectLogic;
            this.sharedContextService = sharedContextService;
            inventoryDialogHelper = new InventoryDialogHelper(dialogService);
            _eventAggregator.GetEvent<ProjectChangeEvent>().Subscribe(ProjectChange);
            this._eventAggregator.GetEvent<ServerSyncEvent>().Subscribe(refreshProjectSyncButton, ThreadOption.UIThread, false,
                              processmsg => processmsg == "ProjectSync");
            DownloadCommand = new DelegateCommand<string>(OnClickDownload);
            iTemplateDownloadLogic = _iTemplateDownloadLogic;
            this.productSync = productSync;
            ProjectPropertyCommand = new DelegateCommand(OnClickProjectProperty, canExecuteProjectPropertyCommand);
            LoadedCommand = new DelegateCommand(onLoadedCommand);
            AboutBoxCommand = new DelegateCommand(onShowAboutBox);
            CloseActiveProject = new DelegateCommand(() => { onCloseActiveProject(); }, canCloseActiveProject);
        }

        /// <summary>
        /// Gets or sets the global menu commands.
        /// </summary>
        /// <value>The global menu commands.</value>
        public IGlobalMenuComands GlobalMenuComands
        {
            get => _globalMenuComands;
            set => SetProperty(ref _globalMenuComands, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether [save button enable].
        /// </summary>
        /// <value><c>true</c> if [save button enable]; otherwise, <c>false</c>.</value>
        public bool SaveButtonEnable
        {
            get => saveButtonEnable;
            set => SetProperty(ref saveButtonEnable, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether [enable badge].
        /// </summary>
        /// <value><c>true</c> if [enable badge]; otherwise, <c>false</c>.</value>
        public bool EnableBadge { get => enableBadge; set => SetProperty(ref enableBadge, value); }

        /// <summary>
        /// Gets or sets the badge value.
        /// </summary>
        /// <value>The badge value.</value>
        public string BadgeValue { get => badgeValue; set => SetProperty(ref badgeValue, value); }

        /// <summary>
        /// Creates new project-command.
        /// </summary>
        /// <value>The new project command.</value>
        public DelegateCommand NewProjectCommand => _newProjectCommand ?? (_newProjectCommand = new DelegateCommand(ExecuteNewproject));

        /// <summary>
        /// Executes the new project.
        /// </summary>
        private void ExecuteNewproject()
        {
            if (onCloseActiveProject())
            {
                if (string.IsNullOrEmpty(myProfile.GetProfile()?.FirstName))
                {
                    DialogService.ShowDialog("MyProfileDialog", null, (IDialogResult result) =>
                    {
                        if (result.Result == ButtonResult.OK)
                        {
                            ShowNewProjectDialog();
                        }
                    });
                }
                else
                {
                    ShowNewProjectDialog();
                }
            }
        }

        /// <summary>
        /// Gets the save project command.
        /// </summary>
        /// <value>The save project command.</value>
        public DelegateCommand SaveProjectCommand => _saveProjectCommand ?? (_saveProjectCommand = new DelegateCommand(ExecuteSaveproject, CanExecuteSave)
            .ObservesProperty(() => SaveButtonEnable));

        /// <summary>
        /// Executes the save project.
        /// </summary>
        private void ExecuteSaveproject()
        {
        }

        /// <summary>
        /// Determines whether this instance [can execute save].
        /// </summary>
        /// <returns><c>true</c> if this instance [can execute save]; otherwise, <c>false</c>.</returns>
        private bool CanExecuteSave()
        {
            return SaveButtonEnable;
        }

        /// <summary>
        /// Gets the settings command.
        /// </summary>
        /// <value>The settings command.</value>
        public DelegateCommand SettingsCommand => _settingsCommand ?? (_settingsCommand = new DelegateCommand(ExecuteSettings));

        /// <summary>
        /// Executes the settings.
        /// </summary>
        private void ExecuteSettings()
        {
            DialogService.ShowDialog("MyProfileDialog", null, null);
        }

        /// <summary>
        /// Gets the export project command.
        /// </summary>
        /// <value>The export project command.</value>
        public DelegateCommand ExportProjectCommand => _exportProjectCommand ?? (_exportProjectCommand = new DelegateCommand(ExecuteImportproject, CanExecuteImport)
         .ObservesProperty(() => SaveButtonEnable));

        /// <summary>
        /// Executes the import project.
        /// </summary>
        private void ExecuteImportproject()
        {
        }

        /// <summary>
        /// Determines whether this instance [can execute import].
        /// </summary>
        /// <returns><c>true</c> if this instance [can execute import]; otherwise, <c>false</c>.</returns>
        private bool CanExecuteImport()
        {
            return SaveButtonEnable;
        }

        /// <summary>
        /// Subscribe call back for ProjectContextModel changes from child VM
        /// </summary>
        /// <param name="contextModel">Project context model.</param>
        public void ProjectChange(ProjectContextModel contextModel)
        {
            if (contextModel != null)
            {
                SaveButtonEnable = true;
                ProjectPropertyCommand.RaiseCanExecuteChanged();
                CloseActiveProject.RaiseCanExecuteChanged();
            }
        }

        /// <summary>
        /// Gets the open project command.
        /// </summary>
        /// <value>The open project command.</value>
        public DelegateCommand<int?> OpenProjectCommand =>
            _OpenProjectCommand ?? (_OpenProjectCommand = new DelegateCommand<int?>(ExecuteOpenProject));

        /// <summary>
        /// Executes the open project.
        /// </summary>
        /// <param name="OpenMode">The open mode.</param>
        private void ExecuteOpenProject(int? OpenMode)
        {
            try
            {
                if (OpenMode == null)
                {
                    return;
                }

                if (sharedContextService.IsSavePending)
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to save the project before exit?", "Save Project",
                       MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
                    if (result == MessageBoxResult.Yes)
                    {
                        GlobalMenuComands.SaveCommand.Execute("");
                        sharedContextService.IsSavePending = false;
                    }
                }

                ProjectContextModel contextModel = null;
                if (OpenMode == 1)
                {
                    DialogService.ShowDialog("OpenProjectDialog", null, (IDialogResult Projectresult) =>
                    {
                        if (Projectresult.Result == ButtonResult.OK)
                        {
                            contextModel = Projectresult.Parameters.GetValue<ProjectContextModel>("data");
                        }
                    });
                }
                else if (OpenMode == 2)
                {
                    fileOpen.Filter = "M2C Files|*.m2c;";

                    if (fileOpen.ShowDialog() == true)
                    {
                        //Modal pop-up call back from Business layer
                        projectLogic.UpdateInventoryCallback = inventoryDialogHelper.ShowMessages;
                        contextModel = projectLogic.ReadProject(fileOpen.FileName.Trim());
                        contextModel.isOpenedFromFile = true;
                    }
                }

                if (contextModel != null)
                {
                    _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage()
                    { Message = "Opening Project", status = OverlayStatus.VISIBLE });

                    sharedContextService.Remove(UIConstants.PROJECTCONTEXT);
                    sharedContextService.Add<ProjectContextModel>(UIConstants.PROJECTCONTEXT, contextModel);
                    ResetNewProjectArea("NewProjectView");
                    _eventAggregator.GetEvent<ProjectChangeEvent>().Publish(contextModel);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show("Error in Opening Project", "ERROR", System.Windows.MessageBoxButton.OK,
                    System.Windows.MessageBoxImage.Error);
            }
            finally
            {
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage()
                { Message = "Opening Project Successful", status = OverlayStatus.HIDDEN });
            }
        }

        /// <summary>
        /// Resets the new project area.
        /// </summary>
        /// <param name="regionName">Name of the region.</param>
        private void ResetNewProjectArea(string regionName)
        {
            foreach (var reg in _regionManager.Regions)
            {
                reg.RemoveAll();
            }
            _eventAggregator.GetEvent<ProjectResetEvent>().Publish(true);
            _regionManager.RequestNavigate(RegionNames.ContentRegion, regionName);
            CloseActiveProject.RaiseCanExecuteChanged();
        }

        /// <summary>
        /// Shows the new project dialog.
        /// </summary>
        private void ShowNewProjectDialog()
        {
            var param = new DialogParameters { { "Mode", ProjectCreateModes.NEW } };

            try
            {
                DialogService.ShowDialog("CreateNewProjectDialog", param, (IDialogResult Projectresult) =>
                {
                    if (Projectresult.Result == ButtonResult.OK)
                    {
                        ResetNewProjectArea("NewProjectView");
                    }
                });
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            _globalMenuComands.NewProjectCommand.UnregisterCommand(NewProjectCommand);
            _globalMenuComands.SaveCommand.UnregisterCommand(SaveProjectCommand);
            _globalMenuComands.ExportProjectCommand.UnregisterCommand(ExportProjectCommand);
        }

        #region PRIVATE FUNCTIONS

        /// <summary>
        /// Called when [click download].
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        private void OnClickDownload(string parameter)
        {
            string filepath = Environment.CurrentDirectory;

            try
            {
                switch (parameter)
                {
                    case "IB":

                        var IBTemplate = $"{filepath}\\Data\\M2C data import template.xltm";// new Updated template, with proper Criticality &  Configuration type , Also updated VB code of validation.
                        iTemplateDownloadLogic.ExcelTemplateDownload(IBTemplate);
                        break;

                    case "TR":
                        var TRTemplate = $"{filepath}\\Data\\M2C stock data import template.xlt";
                        iTemplateDownloadLogic.ExcelTemplateDownload(TRTemplate);
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in downloading the template", "ERROR", MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Called when [click project property].
        /// </summary>
        private void OnClickProjectProperty()
        {
            DialogParameters param = new DialogParameters { { "Mode", ProjectCreateModes.EDIT } };
            DialogService.ShowDialog("CreateNewProjectDialog", param, null);
        }

        /// <summary>
        /// Determines whether this instance [can execute project property command] the specified object.
        /// </summary>
        /// <returns><c>true</c> if this instance [can execute project property command] the specified object; otherwise, <c>false</c>.</returns>
        private bool canExecuteProjectPropertyCommand()
        {
            return this.sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT) != null;
        }

        /// <summary>
        /// Refreshes the project synchronize button.
        /// </summary>
        /// <param name="msg">The MSG.</param>
        private void refreshProjectSyncButton(string msg)
        {
            var projects = productSync.GetProjectsToSync();
            if (projects.Count > 0)
            {
                EnableBadge = true;
                BadgeValue = projects.Count.ToString();
            }
            else
            {
                EnableBadge = false;
                BadgeValue = "0";
            }
        }

        /// <summary>
        /// Ons the loaded command.
        /// </summary>
        private void onLoadedCommand()
        {
            refreshProjectSyncButton("");
        }

        /// <summary>
        /// On the show about box.
        /// </summary>
        private void onShowAboutBox()
        {
            SoftwareInfo softwareInfo = new SoftwareInfo(
                    AppResource.GetResourceString("M2C"),
                    typeof(MainRibbonBarViewModel).Assembly.GetName().Version.ToString(),
                    new Uri("pack://application:,,,/Resources/img/M2c.png"),
                    new CopyrightInfo(AppResource.GetResourceString("Schneider-Electric"),
                    AppResource.GetResourceString("CopyrightYear")))
            {
                Description = AppResource.GetResourceString("M2C_Description")
            };

            softwareInfo.Subcomponents.Add(new SoftwareComponentInfo("BrandIdentity", "4.11.0"));
            softwareInfo.Subcomponents.Add(new SoftwareComponentInfo("DevExpress", "19.2.6"));

            var licenseInfo = new LicenseInfo("SchneiderUser", AppResource.GetResourceString("Schneider-Electric"), "", "");
            if (File.Exists(Directory.GetCurrentDirectory() + "\\Resources\\EULA_FINAL_2018.rtf"))
            {
                licenseInfo.AddEula("English", Directory.GetCurrentDirectory() + "\\Resources\\EULA_FINAL_2018.rtf");
            }

            var aboutViewModel = new AboutViewModel(softwareInfo, licenseInfo);
            AboutDialog dialog = new AboutDialog();
            dialog.SetModel(aboutViewModel);
            dialog.ShowInTaskbar = true;
            dialog.MaxHeight = 600;
            dialog.MaxWidth = 800;
            dialog.SizeToContent = SizeToContent.WidthAndHeight;
            dialog.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            dialog.ShowDialog();
        }

        /// <summary>
        /// Ons the close active project.
        /// </summary>
        private bool onCloseActiveProject()
        {
            MessageBoxResult messageBoxResult = MessageBoxResult.None;
            if (sharedContextService.IsSavePending)
            {
                messageBoxResult = MessageBox.Show("Do you want to save the project before exit?", "Save Project",
                   MessageBoxButton.YesNoCancel, MessageBoxImage.Question, MessageBoxResult.Yes);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    GlobalMenuComands.SaveCommand.Execute("");
                }
            }
            if (messageBoxResult != MessageBoxResult.Cancel)
            {
                sharedContextService.IsSavePending = false;
                _eventAggregator.GetEvent<ProjectChangeEvent>().Publish(null);
                sharedContextService.Remove(UIConstants.PROJECTCONTEXT);
                ResetNewProjectArea("EmptyProject");
            }

            return messageBoxResult != MessageBoxResult.Cancel;
        }

        private bool canCloseActiveProject()
        {
            return sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT) != null;
        }

        #endregion PRIVATE FUNCTIONS
    }
}