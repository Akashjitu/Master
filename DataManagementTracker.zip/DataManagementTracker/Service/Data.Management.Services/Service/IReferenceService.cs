﻿using Data.Management.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Management.Services.Service
{
    public interface IReferenceService
    {
        Reference LoadReference(string eid);
    }
}
