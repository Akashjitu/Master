﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 02-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProjectQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DomainModels.Common;
using DomainModels.ProjectModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataRepository.Queries
{
    /// <summary>
    /// Class ProjectQueries.
    /// Implements the <see cref="DataRepository.DBContracts.IProjectQueries" />
    /// Implements the <see cref="DataRepository.DBContracts.IPositionQueries" />
    /// Implements the <see cref="DataRepository.DBContracts.ICountryQueries" />
    /// Implements the <see cref="DataRepository.DBContracts.IProfileQueries" />
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="DataRepository.DBContracts.IProjectQueries" />
    /// <seealso cref="DataRepository.DBContracts.IPositionQueries" />
    /// <seealso cref="DataRepository.DBContracts.ICountryQueries" />
    /// <seealso cref="DataRepository.DBContracts.IProfileQueries" />
    /// <seealso cref="System.IDisposable" />
    public class ProjectQueries : IProjectQueries, IPositionQueries, ICountryQueries, IProfileQueries, IDisposable
    {
        /// <summary>
        /// The database context factory
        /// </summary>
        private readonly IDbContextFactory _dbContextFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectQueries" /> class.
        /// </summary>
        /// <param name="dbContextFactory">The database context factory.</param>
        public ProjectQueries(IDbContextFactory dbContextFactory)
        {
            _dbContextFactory = dbContextFactory;
        }

        /// <summary>
        /// Provide All Projects.
        /// </summary>
        /// <returns>List&lt;Project&gt;.</returns>
        public List<Project> GetAllProjects()
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
            {
                return context.Projects
                    .Include(i => i.Customer)
                    .Include(i => i.Contacts)
                    .Include(i => i.IBProjectComponents)
                    .ThenInclude(ib => ib.IBComponenetType)
                    .Include(i => i.OperationModes)
                    .Include(i => i.ProjectInventories)
                    .Include(i => i.InventoryComments)
                     .Include(i => i.Criticalities)

                    .ToList();
            }
        }

        /// <summary>
        /// Get Project by Id
        /// </summary>
        /// <param name="projectId">The project identifier.</param>
        /// <returns>Project.</returns>
        public Project GetProject(int projectId)
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
            {
                //Getting inventory separate to load fast
                var inventories = context.ProjectInventories.Where(project => project.ProjectId == projectId).ToList();
                var inventoryComments = context.InventoryComments.Where(project => project.ProjectId == projectId).ToList();

                var product = context.Projects
                    .Include(i => i.Customer).ThenInclude(m => m.Country)
                    .Include(i => i.Criticalities)
                    .Include(i => i.OperationModes).FirstOrDefault(i => i.ProjectID == projectId);

                if (product == null) return null;
                product.ProjectInventories = inventories;
                product.InventoryComments = inventoryComments;
                product.IBProjectComponents = context.IBProjectComponents
                    .Include(ib => ib.IBComponenetType)
                .Where(x => x.Project.ProjectID == projectId).ToList();
                product.Contacts = context.Contacts.
                    Include(cont => cont.ContactType)
                    .Include(cont => cont.Country)
                    .Include(cont=>cont.Position)
                    .Where(x => x.Project.ProjectID == projectId).ToList();
                return product;
            }
        }

        /// <summary>
        /// Projects only not mapping
        /// </summary>
        /// <returns>List&lt;Project&gt;.</returns>
        public List<Project> GetOnlyProjects()
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
            {
                return context.Projects.Include(i => i.Customer)

                    .Include(i => i.Contacts)
                    .ThenInclude(type => type.ContactType)
                    .Include(i => i.IBProjectComponents)

                    .ThenInclude(ib => ib.IBComponenetType).ToList();
            }
        }

        /// <summary>
        /// Loads the countries.
        /// </summary>
        /// <returns>List&lt;Country&gt;.</returns>
        public List<Country> LoadCountries()
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
                return context.Countries.ToList();
        }

        /// <summary>
        /// Loads the positions.
        /// </summary>
        /// <returns>List&lt;Position&gt;.</returns>
        public List<Position> LoadPositions()
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
                return context.Positions.ToList();
        }

        /// <summary>
        /// Saves the profile.
        /// </summary>
        /// <param name="profile">The profile.</param>
        public void SaveProfile(Profile profile)
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
            {
                if (profile == null)
                    return;
                var updateProfile = context.Profiles.FirstOrDefault(i => i.Id == profile.Id);
                if (updateProfile != null)
                {
                    updateProfile.Updated = DateTime.Now;
                    updateProfile.CountryId = profile.CountryId;
                    updateProfile.PositionId = profile.PositionId;
                    updateProfile.Email = string.IsNullOrEmpty(profile.Email) ? string.Empty : profile.Email.Trim();
                    updateProfile.Fax = string.IsNullOrEmpty(profile.Fax) ? string.Empty : profile.Fax.Trim();
                    updateProfile.CountryId = profile.CountryId;
                    updateProfile.FirstName = string.IsNullOrEmpty(profile.FirstName) ? string.Empty : profile.FirstName.Trim();
                    updateProfile.LastName = string.IsNullOrEmpty(profile.LastName) ? string.Empty : profile.LastName.Trim();
                    updateProfile.MobileNumber = string.IsNullOrEmpty(profile.MobileNumber) ? string.Empty : profile.MobileNumber.Trim();
                    updateProfile.PostalCode = string.IsNullOrEmpty(profile.PostalCode) ? string.Empty : profile.PostalCode.Trim();
                    updateProfile.Region = string.IsNullOrEmpty(profile.Region) ? string.Empty : profile.Region.Trim();
                    updateProfile.Town = string.IsNullOrEmpty(profile.Town) ? string.Empty : profile.Town.Trim();
                    updateProfile.Street = string.IsNullOrEmpty(profile.Street) ? string.Empty : profile.Street.Trim();
                    updateProfile.Telephone = string.IsNullOrEmpty(profile.Telephone) ? string.Empty : profile.Telephone.Trim();
                }
                else
                {
                    profile.Updated = profile.Created = DateTime.Today;
                    context.Profiles.Add(profile);
                }

                context.SaveChanges();
            }
        }

        /// <summary>
        /// Removes the profile.
        /// </summary>
        /// <param name="profileId">The profile identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool RemoveProfile(int profileId)
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
            {
                var removeProfile = context.Profiles.FirstOrDefault(i => i.Id == profileId);
                if (removeProfile != null)
                    context.Profiles.Remove(removeProfile);
                return Convert.ToBoolean(context.SaveChanges());
            }
        }

        /// <summary>
        /// Gets the profile.
        /// </summary>
        /// <returns>Profile.</returns>
        public Profile GetProfile()
        {
            using (var context = _dbContextFactory.Create<IProjectDbContext>())
                return !context.Profiles.Any()
                    ? new Profile()
                    : context.Profiles.Include(i => i.Country).Include(i => i.Position).FirstOrDefault();
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
        }
    }
}