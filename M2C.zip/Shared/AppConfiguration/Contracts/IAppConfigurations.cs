﻿// ***********************************************************************
// Assembly         : AppConfiguration
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-20-2020
// ***********************************************************************
// <copyright file="IAppConfigurations.cs" company="AppConfiguration">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace AppConfiguration
{
    /// <summary>
    /// App settings configurations Contract
    /// </summary>
    public interface IAppConfigurations
    {
        /// <summary>
        /// Gets the install based columns.
        /// </summary>
        /// <value>The install based columns.</value>
        string InstallBasedColumns { get; }

        /// <summary>
        /// Gets the technical resource columns.
        /// </summary>
        /// <value>The technical resource columns.</value>
        string TechnicalResourceColumns { get; }

        /// <summary>
        /// Gets the customer document columns.
        /// </summary>
        /// <value>The customer document columns.</value>
        string CustomerDocumentColumns { get; }

        /// <summary>
        /// Gets the synchronize service path.
        /// </summary>
        /// <value>The synchronize service path.</value>
        string SyncServicePath { get; }

        /// <summary>
        /// Gets the idms application.
        /// </summary>
        /// <value>The idms application.</value>
        string IDMSApplication { get; }

        /// <summary>
        /// Gets the authentication service path.
        /// </summary>
        /// <value>The authentication service path.</value>
        string AuthServicePath { get; }

        /// <summary>
        /// Gets the retry count.
        /// </summary>
        /// <value>The retry count.</value>
        string RetryCount { get; }
    }
}