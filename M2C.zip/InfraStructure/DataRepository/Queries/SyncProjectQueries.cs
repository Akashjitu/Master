﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 04-15-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="SyncProjectQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DomainModels.ProjectModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataRepository.Queries
{
    /// <summary>
    /// SyncProjectQueries
    /// </summary>
    /// <seealso cref="DataRepository.DBContracts.ISyncProjectQueries" />
    public class SyncProjectQueries : ISyncProjectQueries
    {
        /// <summary>
        /// The database context factory
        /// </summary>
        private readonly IDbContextFactory dbContextFactory;

        /// <summary>
        /// Initializes a new instance of the <see cref="SyncProjectQueries" /> class.
        /// </summary>
        /// <param name="dbContextFactory">The database context factory.</param>
        public SyncProjectQueries(IDbContextFactory dbContextFactory)
        {
            this.dbContextFactory = dbContextFactory;
        }

        /// <summary>
        /// Gets all projects to synchronize.
        /// </summary>
        /// <returns>List&lt;Project&gt;.</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public List<Project> GetAllProjectsToSync()
        {
            using (var context = dbContextFactory.Create<IProjectDbContext>())
            {
                return context.Projects.Where(x => x.LastSyncDate == null || x.LastSyncDate.Value < x.ModifiedOn).ToList();
            }
        }

        /// <summary>
        /// Updates the last synchronize by. ProjectID
        /// Update to current date time
        /// </summary>
        /// <param name="ProjectID">The project identifier.</param>
        /// <param name="ProjectReferenceId">The project reference identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool UpdateLastSyncBy(int ProjectID, string ProjectReferenceId)
        {
            try
            {
                using (var context = dbContextFactory.Create<IProjectDbContext>())
                {
                    Project Proj = context.Projects.First(x => x.ProjectID == ProjectID);

                    Proj.ProjectReferenceId = ProjectReferenceId;
                    Proj.LastSyncDate = DateTime.Now;
                    
                    context.SaveChanges();
                }

                return true;
            }
            catch (Exception Ex)
            {
                return false;
            }
        }
    }
}