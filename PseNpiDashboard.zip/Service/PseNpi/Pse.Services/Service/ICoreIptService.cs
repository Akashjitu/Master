﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pse.Services.Service
{
   public interface ICoreIptService
    {
        List<CoreIpt> LoadAllCoreIpt();

        List<CoreIpt> LoadCoreIptByCreationDate(DateTime creationDate);

        List<CoreIpt> LoadCoreIptByKeyCode(string keycode);

        List<CoreIpt> LoadLatestCoreIpt();

        List<CoreIpt> LoadCoreIptById(int Id);

        CoreIpt AddCoreIpt(CoreIpt coreIpt);

        CoreIpt UpdateCoreIpt(CoreIpt coreIpt);
    }
}
