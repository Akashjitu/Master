﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.ExcelExports
{
    public interface IOtlDispositionExports
    {
        byte[] Export(List<OtlDispositionDetails> otlDispositions);
    }
}