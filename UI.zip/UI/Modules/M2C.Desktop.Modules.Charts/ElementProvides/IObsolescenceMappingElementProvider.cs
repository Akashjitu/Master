﻿using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    /// <summary>
    /// Provider the obsolescence mapping.
    /// </summary>
    public interface IObsolescenceMappingElementProvider
    {
        /// <summary>
        /// Creates the obsolescence mapping.
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        ChartBarElements GetObsolescenceMapping(ChartParameter chartParameter,
            NodeType type = NodeType.OPEN_CONFIG);
    }
}