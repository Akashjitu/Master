﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.ExcelExports
{
    public interface IEffectivenessAnalysisExports
    {
        byte[] Export(List<EffectivenessAnalysis>eEffectivenessAnalysis);
    }
}