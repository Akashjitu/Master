

import { Action } from '@ngrx/store';
import * as AccoladeAction from './accoladeAction';
import { TtiPartAlignment } from '../model/ttiPartAlignment';


export interface IAppState {
    readonly ttiPartAlignment: TtiPartAlignment[];
}


const initialState: TtiPartAlignment = {
    Id : 1,
    Accolade_KC: '',
    Heatmap_KC: '',
    Program_Name: '',
    IPDS_Current_Phase: '',
    Prod_SBU: '',
    GBE: '',
    PAC: '',
    Honeywell_Part_Number: '',
    OTL_Baseline_Date: '',
    OTL_Forecast_Date: '',
    OTL_Baseline_Date_refresh: '',
    OTL_Forecast_Data_refresh: '',
    Part_Description: '',
    End_Item_LRU: '',
    Make_Buy: '',
    Production_Site: '',
    PM: '',
    PE: '',
    Qty_Per_Shipset: '',
    AME_NPD_Engineer: '',
    Eng_Chief: '',
    APQP_Level: '',
    RTY_Validation_Method: '',
    Part_of_Baseline: '',
    Part_of_OTL_TTI: '',
    Added_Removed_from_OTL_TTI: new  Date(),
    Part_of_RTY_TTI: '',
    Added_Removed_from_RTY_TTI:  new  Date(),
    Part_of_PPM_TTI: '',
    Added_to_PPM_TTI:  new  Date(),
    PG5_Exit_Date: '',
    Successful_OTL: '',
    Successful_RTY: '',
    Successful_UPC: '',
    Successful_PPM: '',
    NOTES: '',
    Record_Number: '',
    UpdateBy: '',
    pInfoUpdateDate:  new  Date(),
    InfoCreatedDate:  new  Date(),

}

export function reducer(state: TtiPartAlignment[] = [], action: AccoladeAction.Actions) {

    switch (action.type) {

        case AccoladeAction.ADD_ACCOLADE: {
            return [...state, action.payload]

        }

        case AccoladeAction.LOAD_ACCOLADE: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
         //  console.log("after : "+JSON.stringify(state));
            return state;
        }

        case AccoladeAction.UPDATE_ACCOLADE: {
            let tti = (<TtiPartAlignment>action.payload);
            var todo = state.find(t => t.Heatmap_KC == tti.Heatmap_KC);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                // todo.PartNo = fracaInfo.PartNo;
                // todo.OpenDate = fracaInfo.OpenDate;
                // todo.CloseDate = fracaInfo.CloseDate;
                // todo.FailedDate = fracaInfo.FailedDate;
                // todo.Product = fracaInfo.Product;
                // todo.Program = fracaInfo.Program;
                // todo.Customer = fracaInfo.Customer;
                // todo.TestEnv = fracaInfo.TestEnv;
                // todo.Originator = fracaInfo.Originator;
                // todo.RespEng = fracaInfo.RespEng;
                // todo.System = fracaInfo.System;
                // todo.Electrical = fracaInfo.Electrical;
                // todo.Emi = fracaInfo.Emi;
                // todo.ClosedBy = fracaInfo.ClosedBy;
                // todo.TestDoc = fracaInfo.TestDoc;
                // todo.Paragraph = fracaInfo.Paragraph;
                // todo.TestType = fracaInfo.TestType;
                // todo.FailureCode = fracaInfo.FailureCode;
                // todo.EndUnit = fracaInfo.EndUnit;
                // todo.Level1 = fracaInfo.Level1;
                // todo.Level2 = fracaInfo.Level2;
                // todo.Nomenclature = fracaInfo.Nomenclature;
                // todo.SerialNumber = fracaInfo.SerialNumber;
                // todo.Designator = fracaInfo.Designator;
                // todo.InflightShutdown = fracaInfo.InflightShutdown;
                // todo.InflightPowerLoss = fracaInfo.InflightPowerLoss;
                // todo.Chargeability = fracaInfo.Chargeability;
                // todo.SafetyAffected = fracaInfo.SafetyAffected;
                // todo.FailureToStart = fracaInfo.FailureToStart;
                // todo.ProblemDescription = fracaInfo.ProblemDescription;
                // todo.Finding = fracaInfo.Finding;
                // todo.Analysis = fracaInfo.Analysis;
                // todo.Status= fracaInfo.Status;
                // todo.AccessType = fracaInfo.AccessType;

                let sliceArray = state.splice(index, 1, todo);
         
            }
            //return Object.assign([], state);
            return state.slice();
         
        }



        default:
            return state;
    }
}