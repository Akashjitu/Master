﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using ActiveDirectoryHelper;
using Newtonsoft.Json;

namespace Fraca.Service.ServiceConsumer
{
    public class EmployeeServcie : IEmployeeServcie
    {
        public List<ADUserDetail> GetEmployeeInfo(string eid)
        {
            ActiveDirectoryHelper.ActiveDirectoryHelper activDir = new ActiveDirectoryHelper.ActiveDirectoryHelper();
            return activDir.GetUsersByLoginName(eid);
        }
    }
}