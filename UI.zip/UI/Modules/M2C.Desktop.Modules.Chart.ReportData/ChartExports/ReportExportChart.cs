﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="ReportExportChart.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows;
using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using DevExpress.XtraRichEdit.API.Native.Implementation;
using M2C.Business.Contracts;
using M2C.Business.Implementations;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Modules.Charts.ReportData.Models;
using User.Digital.Sign;
using CharacterStyle = DevExpress.XtraRichEdit.Model.CharacterStyle;
using Document = DevExpress.XtraRichEdit.API.Native.Document;

namespace M2C.Desktop.Modules.Charts.ReportData.ChartExports
{
    /// <summary>
    /// Enum ExportType
    /// </summary>
    /// <summary>
    /// Enum ExportType
    /// </summary>
    public enum ExportType
    {
        /// <summary>
        /// The word
        /// </summary>
        /// <summary>
        /// The word
        /// </summary>
        Word = 0,
        /// <summary>
        /// The excel
        /// </summary>
        /// <summary>
        /// The excel
        /// </summary>
        Excel,
        /// <summary>
        /// The PDF
        /// </summary>
        /// <summary>
        /// The PDF
        /// </summary>
        Pdf,
        /// <summary>
        /// The HTML
        /// </summary>
        /// <summary>
        /// The HTML
        /// </summary>
        HTML
    }

    /// <summary>
    /// Class ReportExportChart.
    /// Implements the <see cref="M2C.Desktop.Modules.Charts.ReportData.ChartExports.IReportExportChart" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.Charts.ReportData.ChartExports.IReportExportChart" />
    /// <summary>
    /// Class ReportExportChart.
    /// Implements the <see cref="M2C.Desktop.Modules.Charts.ReportData.ChartExports.IReportExportChart" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.Charts.ReportData.ChartExports.IReportExportChart" />
    public class ReportExportChart : IReportExportChart
    {
        /// <summary>
        /// The chart heading
        /// </summary>
        /// <summary>
        /// The chart heading
        /// </summary>
        private const string ChartHeading = "<h3 style=\"font - family:Arial Rounded MT Bold; color:#33cc33;\">{0}</h3>";

        /// <summary>
        /// My profile
        /// </summary>
        private readonly IMyProfileLogic _myProfile;
        /// <summary>
        /// Gets or sets the installed base node.
        /// </summary>
        /// <value>The installed base node.</value>
        public INode InstalledBaseNode { get; set; }
        /// <summary>
        /// Gets or sets the tr node.
        /// </summary>
        /// <value>The tr node.</value>
        public INode TrNode { get; set; }
        /// <summary>
        /// The export type
        /// </summary>
        private ExportType _exportType;
        /// <summary>
        /// The company name
        /// </summary>
        private readonly string _companyName;
        /// <summary>
        /// The color provider
        /// </summary>
        private readonly IStatusColorProvider _colorProvider;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportExportChart" /> class.
        /// </summary>
        /// <param name="colorProvider">The color provider.</param>
        /// <param name="myProfile">My profile.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        public ReportExportChart(IStatusColorProvider colorProvider, IMyProfileLogic myProfile,
            ISharedContextService sharedContextService)
        {
            _colorProvider = colorProvider;
            _myProfile = myProfile;
            var projectContext = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
            _companyName = projectContext.Customer.CompanyName;
        }

        /// <summary>
        /// Exports the specified chart images.
        /// </summary>
        /// <param name="chartImages">The chart images.</param>
        /// <param name="headingValue">The heading value.</param>
        /// <param name="exportType">Type of the export.</param>
        /// <param name="saveFileLocation">The save file location.</param>
        public void Export(List<Image> chartImages, string headingValue, ExportType exportType, string saveFileLocation)
        {
            if (string.IsNullOrEmpty(saveFileLocation) || chartImages == null || chartImages.Count == 0)
                return;
            var fileSaveLocation = saveFileLocation;
            _exportType = exportType;
            var documentFormat = DevExpress.XtraRichEdit.DocumentFormat.Doc;

            if (exportType == ExportType.Word)
                documentFormat = DevExpress.XtraRichEdit.DocumentFormat.OpenXml;

            var profile = _myProfile.GetProfile();

            if (!File.Exists("ReportTemplates\\Obsolescence report-Landscape.docx"))
            {
                MessageBox.Show("Template file not Found", "Information", MessageBoxButton.OK);
                return;
            }
            using (var documentServer = new RichEditDocumentServer())
            {
                if (documentServer.LoadDocument("ReportTemplates\\Obsolescence report-Landscape.docx"))
                {
                    var doc = documentServer.Document;
                    documentServer.Options.Behavior.Save = DocumentCapability.Enabled;
                    documentServer.Options.Export.Html.EmbedImages = true;

                    foreach (var selection in doc.Sections)
                        selection.Page.Landscape = true;

                    var bookmarkCollection = doc.Bookmarks;
                    foreach (var bookmark in bookmarkCollection)//database Binding
                    {
                        var property = profile.GetType().GetProperties().FirstOrDefault(i => i.Name == bookmark.Name);
                        if (property == null)
                            continue;
                        var propertyValue = property.GetValue(profile, null);
                        var range = bookmark.Range;
                        var bmStart = range.Start;
                        documentServer.Document.Delete(range);
                        documentServer.Document.InsertText(bmStart, propertyValue.ToString());
                    }

                    //if (string.IsNullOrEmpty(headingValue) && chartControl.Titles.Count > 0)
                    //    headingValue = chartControl.Titles[0].Content.ToString();

                    var bmChartLabel = bookmarkCollection["ChartLabel"];
                    if (bmChartLabel != null && !string.IsNullOrEmpty(headingValue))
                    {
                        var rangeChartLabel = bmChartLabel.Range;
                        var bmRangeChartLabelStart = rangeChartLabel.Start;
                        documentServer.Document.Delete(rangeChartLabel);
                        documentServer.Document.InsertHtmlText(bmRangeChartLabelStart, string.Format(ChartHeading, headingValue));
                    }

                    var bmChart = bookmarkCollection["Chart"];
                    if (bmChart != null)
                    {
                        var chartRange = bmChart.Range;
                        var bmChartStart = chartRange.Start;
                        documentServer.Document.Delete(chartRange);
                        // var image = GetChartImage1(chartControl);
                        // doc.Images.Insert(bmChartStart, DocumentImageSource.FromImage(image));
                        MapTableWithImage(doc, bmChartStart, chartImages);
                        MapInventories(doc, InstalledBaseNode.MasterInventories.ToList());
                    }

                    var bmDateChart = bookmarkCollection["Date"];
                    if (bmDateChart != null)
                    {
                        var chartRange = bmDateChart.Range;
                        var bmChartStart = chartRange.Start;
                        documentServer.Document.Delete(chartRange);
                        documentServer.Document.InsertText(bmChartStart, DateTime.Today.ToString("dd MMMM yyyy"));
                    }

                    var bmPhoneChart = bookmarkCollection["Phone"];
                    if (bmPhoneChart != null)
                    {
                        var chartRange = bmPhoneChart.Range;
                        var bmChartStart = chartRange.Start;
                        documentServer.Document.Delete(chartRange);
                        documentServer.Document.InsertText(bmChartStart, profile.Telephone);
                    }

                    var bmCompanyChart = bookmarkCollection["Company"];
                    if (bmCompanyChart != null)
                    {
                        var chartRange = bmCompanyChart.Range;
                        var bmChartStart = chartRange.Start;
                        documentServer.Document.Delete(chartRange);
                        documentServer.Document.InsertText(bmChartStart, _companyName);
                    }

                    MapTopologyTable(documentServer.Document, InstalledBaseNode);
                }
                InsertFileMetaData(documentServer);
                if (File.Exists(fileSaveLocation))
                    File.Delete(fileSaveLocation);

                switch (exportType)
                {
                    case ExportType.Word:
                        documentServer.SaveDocument(fileSaveLocation, documentFormat);
                        EncryptionDigitalSignature.SignOfficeFile(fileSaveLocation);
                        break;

                    case ExportType.Excel:
                        //documentServer.SaveDocument(fileSaveLocation, DevExpress.XtraRichEdit.DocumentFormat.);
                        break;

                    case ExportType.Pdf:
                        documentServer.ExportToPdf(fileSaveLocation);
                        break;

                    case ExportType.HTML:
                        using (var htmlFileStream = new FileStream(fileSaveLocation, FileMode.Create))
                            documentServer.SaveDocument(htmlFileStream, DevExpress.XtraRichEdit.DocumentFormat.Html);
                        break;
                }

            }
        }

        private void InsertFileMetaData(IRichEditDocumentServer documentServer)
        {
            var profile = _myProfile.GetProfile();
            documentServer.Document.DocumentProperties.Creator = profile.FirstName;
            documentServer.Document.DocumentProperties.LastModifiedBy = profile.FirstName;
            documentServer.Document.DocumentProperties.Created = DateTime.Now;
            documentServer.Document.DocumentProperties.Modified = DateTime.Now;

            documentServer.Document.DocumentProperties.Keywords = "Auto generated from M2C Application.";
            documentServer.Document.DocumentProperties.Subject = $"{ _companyName} report generated From M2C Application";
            documentServer.Document.DocumentProperties.Title = $"{ _companyName} Report";
            documentServer.Document.DocumentProperties.Version = AssemblyInfo.Version;
            documentServer.Document.DocumentProperties.Description = $"{_companyName} Report generated From M2C Application";
            documentServer.Document.DocumentProperties.Subject = $"{_companyName} Report auto generated From M2C Application";
            documentServer.Document.DocumentProperties.Revision = 0;
            documentServer.Document.CustomProperties["Email"] = profile.Email;
            documentServer.Document.Fields.Create(documentServer.Document.AppendText("\nCOMPANY: ").End, _companyName);
            documentServer.Document.Fields.Create(documentServer.Document.AppendText("Company: ").End, _companyName);
        }

        /// <summary>
        /// Maps the table.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="documentPosition">The document position.</param>
        /// <param name="images">The images.</param>
        private void MapTableWithImage(Document document, DocumentPosition documentPosition, List<Image> images)
        {
            if (images.Count == 0)
                return;

            // Document document = server.Document;
            Table table = document.Tables.Create(documentPosition, images.Count, 1);
            table.BeginUpdate();
            table.Reset();
            table.TableLayout = TableLayoutType.Fixed;
            table.PreferredWidthType = WidthType.Fixed;
            for (var i = 0; i < table.Rows.Count; i++)
            {
                table[i, 0].PreferredWidthType = WidthType.Fixed;
                table[i, 0].PreferredWidth = DevExpress.Office.Utils.Units.InchesToDocumentsF(10.75f);
            }
            table.Reset();
            //if (_exportType == ExportType.Word)
            table.TableAlignment = TableRowAlignment.Center;
            for (var index = 0; index < table.Rows.Count; index++)
            {
                var tableRow = table.Rows[index];
                document.Images.Insert(table[tableRow.Index, 0].Range.Start, images[index]);
            }

            table.EndUpdate();
        }

        /// <summary>
        /// Maps the inventories.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="inventories">The inventories.</param>
        private void MapInventories(Document document, IReadOnlyList<Inventory> inventories)
        {
            var inventoryTable = FindTable(document, 1, "REFERENCE");

            if (inventoryTable == null)
                return;
            var firstRow = inventoryTable.Rows[0];
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[4].Range.Start, DateTime.Today.Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[5].Range.Start, DateTime.Today.AddYears(1).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[6].Range.Start, DateTime.Today.AddYears(2).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[7].Range.Start, DateTime.Today.AddYears(3).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[8].Range.Start, DateTime.Today.AddYears(4).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[9].Range.Start, DateTime.Today.AddYears(5).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[10].Range.Start, DateTime.Today.AddYears(6).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[11].Range.Start, DateTime.Today.AddYears(7).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[12].Range.Start, DateTime.Today.AddYears(8).Year.ToString());
            document.InsertSingleLineText(inventoryTable.Rows[0].Cells[13].Range.Start, DateTime.Today.AddYears(9).Year.ToString());

            for (var index = 0; index < inventories.Count; index++)
            {
                var row = inventoryTable.Rows.InsertAfter(index);

                document.InsertSingleLineText(row.Cells[0].Range.Start, inventories[index].Reference);
                document.InsertSingleLineText(row.Cells[1].Range.Start, inventories[index].DeviceType);
                document.InsertSingleLineText(row.Cells[2].Range.Start, inventories[index].Range);
                document.InsertSingleLineText(row.Cells[3].Range.Start, inventories[index].Quantity.ToString());

                var yearColor = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear) ? dosaYear : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear) ? dosYear : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear) ? eosYear : (int?)null));

                var year1Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(1).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear1) ? dosaYear1 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear1) ? dosYear1 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear1) ? eosYear1 : (int?)null));

                var year2Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(2).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear2) ? dosaYear2 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear2) ? dosYear2 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear2) ? eosYear2 : (int?)null));

                var year3Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(3).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear3) ? dosaYear3 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear3) ? dosYear3 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear3) ? eosYear3 : (int?)null));

                var year4Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(4).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear4) ? dosaYear4 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear4) ? dosYear4 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear4) ? eosYear4 : (int?)null));

                var year5Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(5).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear5) ? dosaYear5 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear5) ? dosYear5 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear5) ? eosYear5 : (int?)null));

                var year6Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(6).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear6) ? dosaYear6 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear6) ? dosYear6 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear6) ? eosYear6 : (int?)null));

                var year7Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(7).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear7) ? dosaYear7 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear7) ? dosYear7 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear7) ? eosYear7 : (int?)null));

                var year8Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(8).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear8) ? dosaYear8 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear8) ? dosYear8 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear8) ? eosYear8 : (int?)null));

                var year9Color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(_colorProvider.GetYearColor(DateTime.Today.AddYears(9).Year,
                    int.TryParse(inventories[index].Dosa, out var dosaYear9) ? dosaYear9 : (int?)null,
                    int.TryParse(inventories[index].DoS, out var dosYear9) ? dosYear9 : (int?)null,
                    int.TryParse(inventories[index].EoS, out var eosYear9) ? eosYear9 : (int?)null));

                row.Cells[4].BackgroundColor = Color.FromArgb(yearColor.A, yearColor.R, yearColor.G, yearColor.B);
                row.Cells[5].BackgroundColor = Color.FromArgb(year1Color.A, year1Color.R, year1Color.G, year1Color.B);
                row.Cells[6].BackgroundColor = Color.FromArgb(year2Color.A, year2Color.R, year2Color.G, year2Color.B);
                row.Cells[7].BackgroundColor = Color.FromArgb(year3Color.A, year3Color.R, year3Color.G, year3Color.B);
                row.Cells[8].BackgroundColor = Color.FromArgb(year4Color.A, year4Color.R, year4Color.G, year4Color.B);
                row.Cells[9].BackgroundColor = Color.FromArgb(year5Color.A, year5Color.R, year5Color.G, year5Color.B);
                row.Cells[10].BackgroundColor = Color.FromArgb(year6Color.A, year6Color.R, year6Color.G, year6Color.B);
                row.Cells[11].BackgroundColor = Color.FromArgb(year7Color.A, year7Color.R, year7Color.G, year7Color.B);
                row.Cells[12].BackgroundColor = Color.FromArgb(year8Color.A, year8Color.R, year8Color.G, year8Color.B);
                row.Cells[13].BackgroundColor = Color.FromArgb(year9Color.A, year9Color.R, year9Color.G, year9Color.B);
            }

            var color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FF3DCD58");//Green
            foreach (var firstRowCell in firstRow.Cells)
            {
                var characterProperties = document.BeginUpdateCharacters(firstRowCell.Range);
                characterProperties.ForeColor = Color.FromArgb(color.A, color.R, color.G, color.B);
                characterProperties.FontSize = 9;
                characterProperties.Bold = true;
                characterProperties.FontName = "Georgia";
                document.EndUpdateCharacters(characterProperties);
            }
        }


        /// <summary>
        /// Maps the topology table.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="node">The node.</param>
        private static void MapTopologyTable(Document document, INode node)
        {
            var topologies = MapTopologies(node);
            var inventoryTable = FindTable(document, 1, "Factory");
            if (inventoryTable == null)
                return;
            var firstRow = inventoryTable.Rows[0];

            for (var index = 0; index < topologies.Count(); index++)
            {
                var row = inventoryTable.Rows.InsertAfter(index);
                document.InsertText(row.Cells[0].Range.Start, topologies[index].Factory);
                document.InsertText(row.Cells[1].Range.Start, topologies[index].Workhop);
                document.InsertText(row.Cells[2].Range.Start, topologies[index].Line);
                document.InsertText(row.Cells[3].Range.Start, topologies[index].Machine);
                document.InsertText(row.Cells[4].Range.Start, topologies[index].Configuration);
                document.InsertText(row.Cells[5].Range.Start, topologies[index].Criticality);
            }
            var color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FF3DCD58");//Green
            foreach (var firstRowCell in firstRow.Cells)
            {
                var characterProperties = document.BeginUpdateCharacters(firstRowCell.Range);
                characterProperties.ForeColor = Color.FromArgb(color.A, color.R, color.G, color.B);
                characterProperties.FontSize = 9;
                characterProperties.Bold = true;
                characterProperties.FontName = "Georgia";
                document.EndUpdateCharacters(characterProperties);
            }
        }

        /// <summary>
        /// Finds the table.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="rowCount">The row count.</param>
        /// <param name="firstCellValue">The first cell value.</param>
        /// <returns>Table.</returns>
        private static Table FindTable(Document document, int rowCount, string firstCellValue)
        {
            foreach (var documentTable in document.Tables)
            {
                if (documentTable == null || documentTable.Rows.Count != rowCount)
                    continue;
                var value = document.GetText(documentTable[0, 0].Range);
                if (string.IsNullOrEmpty(value) ||
                    string.Compare(value.Trim(), firstCellValue, StringComparison.OrdinalIgnoreCase) != 0)
                    continue;

                return documentTable;
            }
            return null;
        }

        /// <summary>
        /// Maps the topologies.
        /// </summary>
        /// <param name="node">The node.</param>
        /// <returns>List&lt;Topology&gt;.</returns>
        private static List<Topology> MapTopologies(INode node)
        {
            var topologies = new List<Topology>();
            if (node.Inventories == null) return topologies;

            foreach (var inventory in node.Inventories)
            {
                var topology = new Topology()
                {
                    Factory = inventory.Factory,
                    Configuration = inventory.Configuration,
                    Machine = inventory.Machine,
                    Line = inventory.Line,
                    Criticality = inventory.Criticality,
                    Workhop = inventory.Workshop
                };
                if (!topologies.Contains(topology))
                    topologies.Add(topology);
            }

            return topologies;
        }
    }
}