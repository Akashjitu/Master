
import { Component, OnInit, TemplateRef, ViewChild, ElementRef, AfterContentInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataManagementService } from '../services/data-management.service';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/dataManagement/dataManagementReducer';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { IDayCalendarConfig, DatePickerComponent } from 'ng2-date-picker';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { ReferenceService } from '../services/referenceService';
import { DataManagmentColumns } from '../dataManagmentView/dataManagmentColumns';
import { Router } from '@angular/router';
import { ShareDataService } from '../services/share-data.service';
import { EmployeeService } from '../services/employeeService';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { Alert } from 'selenium-webdriver';

@Component({
  selector: 'app-data-management-entry',
  templateUrl: './data-management-entry.component.html',
  styleUrls: ['./data-management-entry.component.sass']
})
export class DataManagementEntryComponent implements OnInit, AfterContentInit {


  dmCommentsEditorConfig: AngularEditorConfig;
  cMCommentsEditorConfig: AngularEditorConfig;
  requestorCommentsEditorConfig: AngularEditorConfig;
  honeywellCommentsEditorConfig: AngularEditorConfig;
  modalRef: BsModalRef;
  accessfields: any;
  programs: any;
  submitButtonCapction: string
  selectedRow: any;
  referenceData: any;
  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '10rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',
    uploadUrl: 'v1/images', // if needed,
    fonts: [{ class: 'arial', name: 'Arial' },
    { class: 'times-new-roman', name: 'Times New Roman' },
    { name: "Comic Sans MS", class: "comic-sans-ms" },
    { name: "Courier New", class: "courier-new" },
    { name: "Georgia", class: "georgia" },
    { name: "Verdana", class: "verdana" },
    { name: "Impact", class: "impact" },
    ],
    showToolbar: true,
    enableToolbar: true,
  };

  @ViewChild('dateFromDp') public dateFromDp: DatePickerComponent;
  @ViewChild('dateToDp') public dateToDp: DatePickerComponent;

  filterForm: FormGroup;
  displayDate;
  dayPickerConfig = {
    locale: 'en',
    format: 'YYYY-MM-DD',
    monthFormat: 'MMMM, YYYY',
    firstDayOfWeek: 'mo'
  } as IDayCalendarConfig;

  dmSentTocustomerForm: FormGroup;
  requiredDispositionForm: FormGroup;
  impactedPOForm: FormGroup;

  constructor(private shareDataService: ShareDataService, public store: Store<IAppState>,
    private router: Router, private service: DataManagementService, private employeeService: EmployeeService,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private modalService: BsModalService,
    private spinner: NgxSpinnerService,
  ) {
    this.selectedRow = DataManagmentColumns.rowInfo;
    this.accessfields = { ...DataManagmentColumns.fieldsReadOnly };

    this.requestorCommentsEditorConfig = { ...DataManagmentColumns.angularEditorConfig };

    this.cMCommentsEditorConfig = { ...DataManagmentColumns.angularEditorConfig };
    this.dmCommentsEditorConfig = { ...DataManagmentColumns.angularEditorConfig };
    this.honeywellCommentsEditorConfig = { ...DataManagmentColumns.angularEditorConfig };

    this.requestorCommentsEditorConfig.editable = false;
    this.dmCommentsEditorConfig.editable = false;
    this.cMCommentsEditorConfig.editable = true;
    this.honeywellCommentsEditorConfig.editable = false;

    this.createForm()
  }

  ngOnInit() {
    this.submitButtonCapction = 'Update';
    this.store.select('referenceReducer').subscribe(data => {
      this.referenceData = data;
      this.programs = data.programs;
    });
    this.shareDataService.currentMessage.subscribe(message => {
      this.selectedRow = message
    });
    // this.onCustomerNameChange()} );

    this.selectedRow.requestReceivedDate = this.datePipe.transform(this.selectedRow.requestReceivedDate, "yyyy-MM-dd");
    console.log('honeywellComments' + this.selectedRow.honeywellComments);

    this.selectedRow.requestorComments = this.selectedRow.requestorComments == '' || this.selectedRow.requestorComments == null ?
      this.datePipe.transform(new Date(), "yyyy-MM-dd") : this.selectedRow.requestorComments;

    this.selectedRow.cmComments = this.selectedRow.cmComments == '' || this.selectedRow.cmComments == null ?
      this.datePipe.transform(new Date(), "yyyy-MM-dd") : this.selectedRow.cmComments;

    this.selectedRow.dmComments = this.selectedRow.dmComments == '' || this.selectedRow.dmComments == null ?
      this.datePipe.transform(new Date(), "yyyy-MM-dd") : this.selectedRow.dmComments;


    this.selectedRow.honeywellComments = this.selectedRow.honeywellComments == '' || this.selectedRow.honeywellComments == null ?
      this.datePipe.transform(new Date(), "yyyy-MM-dd") : this.selectedRow.honeywellComments;

    this.programs = this.referenceData.programs.filter(s => s.customerId == this.selectedRow.customerId)
    this.selectedRow.programId = this.selectedRow.programid;
    this.setAccessFields();
  }

  ngAfterContentInit(): void {
  }

  createForm() {
    this.filterForm = this.fb.group({
      dateFrom: new FormControl(),
      dateTo: new FormControl(),
    });
    this.dmSentTocustomerForm = this.fb.group({
      dateFrom: new FormControl(),
      dateTo: new FormControl(),
    });
    this.requiredDispositionForm = this.fb.group({
      dateFrom: new FormControl(),
      dateTo: new FormControl(),
    });
    this.impactedPOForm = this.fb.group({
      dateFrom: new FormControl(),
      dateTo: new FormControl(),
    });
  }

  onBack() {
    this.router.navigate(['home']);
  }

  onSubmit() {
    console.log("Row _ " + this.selectedRow)
    if (this.submitButtonCapction === 'Add new Request') {
      this.onAdd();
      return;
    }
    else {
      this.onUpdate();
    }
  }

  onAdd() {
    if (this.selectedRow.requestorComments.length >= 4000) {
      alert("Requestor Comments length should not be more than 4000 characters ")
      return;
    }
    if (this.validateInPut() == true) {
      alert("Please fill all red boxes.")
      return;
    }
    else {
      this.service.addDataManagement(this.selectedRow)
      this.router.navigate(['home']);
    }
  }

  onUpdate() {
    if (this.selectedRow.requestorComments.length >= 4000) {
      alert("Requestor Comments length should not be more than 4000 characters ")
      return;
    }
    if (this.selectedRow.cmComments.length >= 4000) {
      alert("CM Comments length should not be more than 4000 characters ")
      return;
    }
    if (this.selectedRow.dmComments.length >= 4000) {
      alert("DM Comments length should not be more than 4000 characters ")
      return;
    }

    if (this.selectedRow.honeywellComments.length >= 4000) {
      alert("Honeywell Comments length should not be more than 4000 characters ")
      return;
    }

    this.service.UpdateDataManagement(this.selectedRow)
    this.router.navigate(['home']);
  }


  validateInPut() {

    let isValid = false;

    if ((this.selectedRow.requestor == undefined || this.selectedRow.requestor == "" || this.selectedRow.requestor.length == 0)) {
      isValid = true;
      alert("Please Fill Requestor.")
    }

    if ((this.selectedRow.customerId == undefined || this.selectedRow.customerId == "" || this.selectedRow.customerId.length == 0)) {
      isValid = true;
      alert("Please Fill Customer.")
    }

    console.log("Row _" + JSON.stringify(this.selectedRow))
    if (this.selectedRow.customerId == 5) {
      if ((this.selectedRow.programNames == undefined || this.selectedRow.programNames == "" || this.selectedRow.programNames.length == 0)) {
        isValid = true;
        alert("Please Fill Program.")
      }

    }
    else if ((this.selectedRow.programId == undefined || this.selectedRow.programId == "" || this.selectedRow.programId.length == 0)) {
      isValid = true;
      alert("Please Fill Program.")
    }


    if ((this.selectedRow.priority == undefined || this.selectedRow.priority == "" || this.selectedRow.priority.length == 0)) {
      isValid = true;
      alert("Please Fill Priority.")
    }
    if ((this.selectedRow.dataManager == undefined || this.selectedRow.dataManager == "" || this.selectedRow.dataManager.length == 0)) {
      isValid = true;
      alert("Please Fill Data Manager.")
    }

    if ((this.selectedRow.cm == undefined || this.selectedRow.cm == "" || this.selectedRow.cm.length == 0)) {
      isValid = true;
      alert("Please Fill CM.")
    }
    if ((this.selectedRow.requestorComments == undefined || this.selectedRow.requestorComments == "" || this.selectedRow.requestorComments.length == 0)) {
      isValid = true;
      alert("Please Fill Requestor Comments.")
    }

    if ((this.selectedRow.requestorComments == undefined || this.selectedRow.requestorComments == "" || this.selectedRow.requestorComments.length == 0)) {
      isValid = true;
      alert("Please Fill Requestor Comments.")
    }


    if ((this.selectedRow.documentTitle == undefined || this.selectedRow.documentTitle == "" || this.selectedRow.documentTitle.length == 0)) {
      isValid = true;
      alert("Please Fill Document Title.")
    }
    if ((this.selectedRow.documentPartNumber == undefined || this.selectedRow.documentPartNumber == "" || this.selectedRow.documentPartNumber.length == 0)) {
      isValid = true;
      alert("Please Fill Document Part Number.")
    }

    if ((this.selectedRow.siteId == undefined || this.selectedRow.siteId == "" || this.selectedRow.siteId.length == 0)) {
      isValid = true;
      alert("Please Fill Site.")
    }
    return isValid;

    // return (
    //   (this.selectedRow.requestor == undefined || this.selectedRow.requestor == "" || this.selectedRow.requestor.length == 0) ||
    //   (this.selectedRow.requestReceivedDate == undefined || this.selectedRow.requestReceivedDate == "" || this.selectedRow.requestReceivedDate.length == 0) ||
    //   (this.selectedRow.siteId == undefined || this.selectedRow.siteId == "" || this.selectedRow.siteId.length == 0) &&
    //   (this.selectedRow.documentPartNumber == undefined || this.selectedRow.documentPartNumber == "" || this.selectedRow.documentPartNumber.length == 0) ||
    //   (this.selectedRow.documentTitle == undefined || this.selectedRow.documentTitle == "" || this.selectedRow.documentTitle.length == 0) ||
    //   (this.selectedRow.customerId == undefined || this.selectedRow.customerId == "" || this.selectedRow.customerId.length == 0) ||
    //   (this.selectedRow.programId == undefined || this.selectedRow.programId == "" || this.selectedRow.programId.length == 0) ||
    //   (this.selectedRow.priority == undefined || this.selectedRow.priority == "" || this.selectedRow.priority.length == 0) ||
    //   (this.selectedRow.dataManager == undefined || this.selectedRow.dataManager == "" || this.selectedRow.dataManager.length == 0) ||
    //   (this.selectedRow.cm == undefined || this.selectedRow.cm == "" || this.selectedRow.cm.length == 0) &&
    //   (this.selectedRow.requestorComments == undefined || this.selectedRow.requestorComments == "" || this.selectedRow.requestorComments.length == 0))
  }


  onCustomerNameChange() {
    if (this.referenceData == null ||
      this.referenceData.programs == null ||
      this.selectedRow == null ||
      this.selectedRow.customerId == 0) {
      return;
    }

    this.programs = this.referenceData.programs.filter(s => s.customerId == this.selectedRow.customerId);
    // this.selectedRow.program.id= this.programs[0].program.Id;
    this.selectedRow.programId = this.programs[0].id;

    // console.log('Program:_ ' + this.selectedRow.program.id)
    console.log('Program:_ ' + this.selectedRow.programId)
  }

  focusOut(element, helper) {

    console.log(element)
    console.log(helper)
    //ng-reflect-model="sdsad"
    var helperElt = (helper as HTMLElement);

    console.log("Event " + (helper as HTMLElement).innerText)
    this.employeeService.getEmployeeById(element).subscribe(emp => {
      helperElt.hidden = emp != '' ? false : true;
      helperElt.innerText = emp;
    });
  }

  setAccessFields() {
    this.accessfields = { ...DataManagmentColumns.fieldsReadOnly };
    this.submitButtonCapction = 'Update';
    this.cMCommentsEditorConfig.editable = false;
    this.honeywellCommentsEditorConfig.editable = false;
    this.requestorCommentsEditorConfig.editable = false;
    this.dmCommentsEditorConfig.editable = false;

    this.dmCommentsEditorConfig.showToolbar = false;
    this.requestorCommentsEditorConfig.showToolbar = false;
    this.honeywellCommentsEditorConfig.showToolbar = false;
    this.cMCommentsEditorConfig.showToolbar = false;


    if (this.selectedRow.accessUIType == 1) {

      this.accessfields.isReadOnlyCmComments = false;
      this.cMCommentsEditorConfig.editable = true;
      this.cMCommentsEditorConfig.showToolbar = true;
      //  this.cMCommentsEditorConfig.editable=true;
    }

    if (this.selectedRow.accessUIType == 2) {

      this.accessfields.isReadOnlyId = false;
      this.accessfields.isReadOnlyRequestor = false;
      this.accessfields.isReadOnlyRequestReceivedDate = null;
      this.accessfields.isReadOnlySite = false;
      this.accessfields.isReadOnlySiteId = false;
      this.accessfields.isReadOnlyDocumentPartNumber = false;
      this.accessfields.isReadOnlyRevision = false;
      this.accessfields.isReadOnlyDocumentTitle = false;
      this.accessfields.isReadOnlyEcn = false;
      this.accessfields.isReadOnlyCustomerName = false;
      this.accessfields.isReadOnlyCustomerId = false;
      this.accessfields.isReadOnlyProgramNames = false;
      this.accessfields.isReadOnlyProgramId = false;
      this.accessfields.isReadOnlyPriority = false;
      this.accessfields.isReadOnlyDataManager = false;
      this.accessfields.isReadOnlyCm = false;
      this.accessfields.isReadOnlyExportDisclosure = false;
      this.accessfields.isReadOnlyRequestorComments = false;
      this.accessfields.isReadOnlyDocumentType = false;
      this.accessfields.isReadOnlyEndItemPartNumber = false;
      this.accessfields.isReadOnlyCategoryOfChange = false;
      this.accessfields.isReadOnlyScnNumber = false;
      this.accessfields.isReadOnlyCmComments = false;
      this.accessfields.isReadOnlySdrlNumber = false;
      this.accessfields.isReadOnlySdrlTitle = false;
      this.accessfields.isReadOnlyNomenclature = false;
      this.accessfields.isReadOnlyCustomerReferenceNumber = false;
      this.accessfields.isReadOnlyHoneywellTransmittalLetter = false;
      this.accessfields.isReadOnlyDmDateSentToCustomer = null;
      this.accessfields.isReadOnlyHonStatus = false;
      this.accessfields.isReadOnlyRequiredDispositionDate = null;
      this.accessfields.isReadOnlyDispositionStatus = false;
      this.accessfields.isReadOnlyCustomerStatus = false;
      this.accessfields.isReadOnlyApProgram = false;
      this.accessfields.isReadOnlyImpactedPoDate = null;
      this.accessfields.isReadOnlyBcaPrimaryReviewerEngineer = false;
      this.accessfields.isReadOnlyBcaPa = false;
      this.accessfields.isReadOnlyDmComments = false;
      this.accessfields.isReadOnlyHoneywellComments = false;
      this.accessfields.isReadOnlyCreatedBy = false;
      this.accessfields.isReadOnlyCreatedDate = null;
      this.accessfields.isReadOnlyUpdatedBy = false;
      this.accessfields.isReadOnlyUpdatedDate = null;
      this.accessfields.isReadOnlyIsActive = false;

      this.requestorCommentsEditorConfig.editable = true;
      this.dmCommentsEditorConfig.editable = true;
      this.cMCommentsEditorConfig.editable = true;
      this.honeywellCommentsEditorConfig.editable = true;

      this.dmCommentsEditorConfig.showToolbar = true;
      this.requestorCommentsEditorConfig.showToolbar = true;
      this.honeywellCommentsEditorConfig.showToolbar = true;
      this.cMCommentsEditorConfig.showToolbar = true;
    }

    if (this.selectedRow.accessUIType == 4) {

      // this.accessfields.isReadOnlyRequestor= false;
      // this.accessfields.isReadOnlyId= false;
      // this.accessfields.isReadOnlyRequestor= false;
      // this.accessfields.isReadOnlyRequestReceivedDate = null;
      // this.accessfields.isReadOnlySite= false;
      // this.accessfields.isReadOnlySiteId=false;
      // this.accessfields.isReadOnlyDocumentPartNumber= false;
      // this.accessfields.isReadOnlyRevision=  false;
      // this.accessfields.isReadOnlyDocumentTitle= false;
      // this.accessfields.isReadOnlyEcn= false;
      // this.accessfields.isReadOnlyCustomerName= false;
      // this.accessfields.isReadOnlyCustomerId=false;
      // this.accessfields.isReadOnlyProgramNames= false;
      // this.accessfields.isReadOnlyProgramId=false;
      // this.accessfields.isReadOnlyPriority= false;
      // this.accessfields.isReadOnlyDataManager= false;
      // this.accessfields.isReadOnlyCm= false;
      // this.accessfields.isReadOnlyExportDisclosure=false;
      // this.accessfields.isReadOnlyRequestorComments= false;
      // this.requestorCommentsEditorConfig.editable =true;
      // this.requestorCommentsEditorConfig.showToolbar= true;
      this.submitButtonCapction = 'Add new Request';

      this.accessfields.isReadOnlyId = false;
      this.accessfields.isReadOnlyRequestor = false;
      this.accessfields.isReadOnlyRequestReceivedDate = null;
      this.accessfields.isReadOnlySite = false;
      this.accessfields.isReadOnlySiteId = false;
      this.accessfields.isReadOnlyDocumentPartNumber = false;
      this.accessfields.isReadOnlyRevision = false;
      this.accessfields.isReadOnlyDocumentTitle = false;
      this.accessfields.isReadOnlyEcn = false;
      this.accessfields.isReadOnlyCustomerName = false;
      this.accessfields.isReadOnlyCustomerId = false;
      this.accessfields.isReadOnlyProgramNames = false;
      this.accessfields.isReadOnlyProgramId = false;
      this.accessfields.isReadOnlyPriority = false;
      this.accessfields.isReadOnlyDataManager = false;
      this.accessfields.isReadOnlyCm = false;
      this.accessfields.isReadOnlyExportDisclosure = false;
      this.accessfields.isReadOnlyRequestorComments = false;
      this.accessfields.isReadOnlyDocumentType = false;
      this.accessfields.isReadOnlyEndItemPartNumber = false;
      this.accessfields.isReadOnlyCategoryOfChange = false;
      this.accessfields.isReadOnlyScnNumber = false;
      this.accessfields.isReadOnlyCmComments = false;
      this.accessfields.isReadOnlySdrlNumber = false;
      this.accessfields.isReadOnlySdrlTitle = false;
      this.accessfields.isReadOnlyNomenclature = false;
      this.accessfields.isReadOnlyCustomerReferenceNumber = false;
      this.accessfields.isReadOnlyHoneywellTransmittalLetter = false;
      this.accessfields.isReadOnlyDmDateSentToCustomer = null;
      this.accessfields.isReadOnlyHonStatus = false;
      this.accessfields.isReadOnlyRequiredDispositionDate = null;
      this.accessfields.isReadOnlyDispositionStatus = false;
      this.accessfields.isReadOnlyCustomerStatus = false;
      this.accessfields.isReadOnlyApProgram = false;
      this.accessfields.isReadOnlyImpactedPoDate = null;
      this.accessfields.isReadOnlyBcaPrimaryReviewerEngineer = false;
      this.accessfields.isReadOnlyBcaPa = false;
      this.accessfields.isReadOnlyDmComments = false;
      this.accessfields.isReadOnlyHoneywellComments = false;
      this.accessfields.isReadOnlyCreatedBy = false;
      this.accessfields.isReadOnlyCreatedDate = null;
      this.accessfields.isReadOnlyUpdatedBy = false;
      this.accessfields.isReadOnlyUpdatedDate = null;
      this.accessfields.isReadOnlyIsActive = false;

      this.requestorCommentsEditorConfig.editable = true;
      this.dmCommentsEditorConfig.editable = true;
      this.cMCommentsEditorConfig.editable = true;
      this.honeywellCommentsEditorConfig.editable = true;

      this.dmCommentsEditorConfig.showToolbar = true;
      this.requestorCommentsEditorConfig.showToolbar = true;
      this.honeywellCommentsEditorConfig.showToolbar = true;
      this.cMCommentsEditorConfig.showToolbar = true;
    }

  }
  EmployeeSetproperty: any;
  UsersInfo: any;
  searchValue: any;

  seachBy = 0;
  capction = 'Employee ID';

  onEmpSearchTemplate(property, value, template: TemplateRef<any>) {
    this.EmployeeSetproperty = property;
    this.modalRef = this.modalService.show(template, { class: 'gray modal-lg' });
  }

  onEmpSearch() {
    if (this.searchValue == null || this.searchValue == '') {
      alert('Please insert Search value like :- First Name, Email, E-ID.');
      return;
    }

    this.spinner.show();
    this.employeeService.getEmployeeBySearch(this.searchValue, this.seachBy)
      .subscribe(emp => {
        this.UsersInfo = emp;
        this.spinner.hide();
      },
        err => {
          this.spinner.hide();
          alert('Service Error. please your input');
          console.log(`ERROR: ${err}`);
        });
  }

  onSeachBy(value) {
    this.seachBy = value
    this.capction = '';
    switch (value) {
      case 0:
        this.capction = 'Employee ID';
        break;
      case 2:
        this.capction = 'Mail';
        break;
      case 3:
        this.capction = 'Display Name';
        break;

      case 1:
        this.capction = 'First Name';
        break;
    }
  }
  onUserSelect(userInfo) {

    console.log("userInfo " + JSON.stringify(userInfo))
    console.log("EmployeeSetproperty " + this.EmployeeSetproperty)
    switch (this.EmployeeSetproperty) {
      case 'CM':
        this.selectedRow.cm = userInfo.eid;
        break;
      case 'DM':
        this.selectedRow.dataManager = userInfo.eid;
        break;
      case 'REQUESTOR':
        this.selectedRow.requestor = userInfo.eid;
        break;
      case 'bcaPrimaryReviewer':
        this.selectedRow.bcaPrimaryReviewerEngineer = userInfo.eid;
        break;

    }
    this.modalRef.hide();
  }
}
