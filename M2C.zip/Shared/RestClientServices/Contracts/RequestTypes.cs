﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="RequestTypes.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace RestClientServices.Contracts
{
    /// <summary>
    /// Enum RequestTypes
    /// </summary>
    public enum RequestTypes
    {
        /// <summary>
        /// The get
        /// </summary>
        GET,
        /// <summary>
        /// The post
        /// </summary>
        POST,
        /// <summary>
        /// The put
        /// </summary>
        PUT

    }
}