﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="IBNodeChainHandler.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project.IBComponents;
using System;
using System.Collections.Generic;
using M2C.Business.GlobalFields;
using M2C.Business.Models.Project;

/// <summary>
/// Chain of responsibility pattern
/// </summary>
namespace M2C.Business.Mappers.IBChainMapper
{
    /// <summary>
    /// main chain handler Interface
    /// </summary>
    public interface IHandler
    {
        /// <summary>
        /// Sets the next.
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <returns>IHandler.</returns>
        IHandler SetNext(IHandler handler);

        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        Node Handle(object request, ref INode currentNode);
    }

    /// <summary>
    /// base class for handlers
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBChainMapper.IHandler" />
    public abstract class AbstractHandler : IHandler
    {
        /// <summary>
        /// The next handler
        /// </summary>
        private IHandler _nextHandler;

        /// <summary>
        /// Sets the next.
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <returns>IHandler.</returns>
        public IHandler SetNext(IHandler handler)
        {
            _nextHandler = handler;
            return handler;
        }

        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        public virtual Node Handle(object request, ref INode currentNode)
        {
            return _nextHandler?.Handle(request, ref currentNode);
        }
    }

    /// <summary>
    /// main Entry class
    /// </summary>
    public static class AddNodeByChain
    {
        /// <summary>
        /// Adds the specified handler.
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <param name="commands">The commands.</param>
        /// <param name="currentNode">The current node.</param>
        public static void Add(AbstractHandler handler, List<string> commands, INode currentNode)
        {
            if (currentNode is ConfigNode)
                return;
            foreach (var cmd in commands)
            {
                var tmpId = handler.Handle(cmd, ref currentNode);
                currentNode = tmpId ?? currentNode;
            }
        }
    }

    /// <summary>
    /// Class InstallBaseHandler.
    /// Implements the <see cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    public class InstallBaseHandler : AbstractHandler
    {
        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        public override Node Handle(object request, ref INode currentNode)
        {
            if ((request as string)?.ToUpper() == "IB" && currentNode is InstalledBase installedBase)
            {
                var fc = new FactoryNode(GlobalFiled.GenerateRandomId(), BusinessConstants.FACTORY, installedBase);
                installedBase.Factories.Add(fc);
                return fc;
            }
            else
            {
                return base.Handle(request, ref currentNode);
            }
        }
    }

    /// <summary>
    /// Class FactoryHandler.
    /// Implements the <see cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    public class FactoryHandler : AbstractHandler
    {
        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        public override Node Handle(object request, ref INode currentNode)
        {
            if ((request as string)?.ToUpper() == "FACTORY" && currentNode is FactoryNode factoryNode)
            {
                var ws = new WorkShopNode(GlobalFiled.GenerateRandomId(), BusinessConstants.WORKSHOP, factoryNode);
                factoryNode.WorkShopNodes.Add(ws);
                return ws;
            }
            else
            {
                return base.Handle(request, ref currentNode);
            }
        }
    }

    /// <summary>
    /// Class WorkShopHandler.
    /// Implements the <see cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    public class WorkShopHandler : AbstractHandler
    {
        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        public override Node Handle(object request, ref INode currentNode)
        {
            if ((request as string)?.ToUpper() == "WORKSHOP" && currentNode is WorkShopNode workShopNode)
            {
                var ln = new LineNode(GlobalFiled.GenerateRandomId(), BusinessConstants.LINE, workShopNode);
                workShopNode.LineNodes.Add(ln);
                return ln;
            }

            if ((request as string)?.ToUpper() == "WORKSHOP-MC" && currentNode is WorkShopNode shopNode)
            {
                var mc = new MachineNode(GlobalFiled.GenerateRandomId(), BusinessConstants.MACHINE, shopNode);
                shopNode.MachineNodes.Add(mc);
                return mc;
            }

            return base.Handle(request, ref currentNode);
        }
    }

    /// <summary>
    /// Class LineHandler.
    /// Implements the <see cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    public class LineHandler : AbstractHandler
    {
        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        public override Node Handle(object request, ref INode currentNode)
        {
            if ((request as string)?.ToUpper() == "LINE" && currentNode is LineNode lineNode)
            {
                var mc = new MachineNode(GlobalFiled.GenerateRandomId(), BusinessConstants.MACHINE, lineNode);
                lineNode.MachineNodes.Add(mc);
                return mc;
            }
            return base.Handle(request, ref currentNode);
        }
    }

    /// <summary>
    /// Class MachineHandler.
    /// Implements the <see cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    public class MachineHandler : AbstractHandler
    {
        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        public override Node Handle(object request, ref INode currentNode)
        {
            if ((request as string)?.ToUpper() == "MACHINE" && currentNode is MachineNode machineNode)
            {
                var configNode = new ConfigNode();
                configNode.Id = GlobalFiled.GenerateRandomId();
                configNode.ParentNode = machineNode;
                machineNode.ConfigNodes.Add(configNode);
                return configNode;
            }
            else
            {
                return base.Handle(request, ref currentNode);
            }
        }
    }

    /// <summary>
    /// Class ConfigHandler.
    /// Implements the <see cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBChainMapper.AbstractHandler" />
    public class ConfigHandler : AbstractHandler
    {
        /// <summary>
        /// Handles the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="currentNode">The current node.</param>
        /// <returns>Node.</returns>
        public override Node Handle(object request, ref INode currentNode)
        {
            string r = (request as string)?.ToUpper();
            if ((r == "PLC_CONFIG" || r == "MD_CONFIG" || r == "SHMI_CONFIG" || r == "OPEN_CONFIG") && currentNode is ConfigNode configNode)
            {
                Enum.TryParse((request as string)?.ToUpper(), out NodeType nodeType);

                configNode.NodeType = nodeType;
                switch (nodeType)
                {
                    case NodeType.PLC_CONFIG:
                        { configNode.Name = BusinessConstants.PLC_CONFIGURATION; }
                        break;

                    case NodeType.MD_CONFIG:
                        { configNode.Name = BusinessConstants.MOTION_DRIVE_CONFIGURATION; }
                        break;

                    case NodeType.SHMI_CONFIG:
                        { configNode.Name = BusinessConstants.SCADA_HMI_CONFIGURATION; }
                        break;

                    case NodeType.OPEN_CONFIG:
                        { configNode.Name = BusinessConstants.OPEN_CONFIGURATION; }
                        break;
                }

                return configNode;
            }
            return base.Handle(request, ref currentNode);
        }
    }
}