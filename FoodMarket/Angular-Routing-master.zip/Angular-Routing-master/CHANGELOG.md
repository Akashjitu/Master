#Changes made to the course since its release:

- December 20, 2018 - The course was updated to Angular v7, Bootstrap 4 with Font Awesome, and RxJS 6. For details on the lsit of course changes, see: https://blogs.msmvps.com/deborahk/angular-routing-course-update-for-v7/

#Changes made to the project files since its release:

- December 20, 2018 - The code was replaced with new start and final folders that leverage the Angular CLI and for Angular v7, RxJS 6, Bootstrap 4, and Font Awesome.
