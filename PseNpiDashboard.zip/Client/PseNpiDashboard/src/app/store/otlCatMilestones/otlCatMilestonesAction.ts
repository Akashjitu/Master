import { Action } from '@ngrx/store';

import { OtlCatMilestone } from 'src/app/model/otlCatMilestone';
export const ADD_OTL_CAT_MILESTONES = 'ADD_OTL_CAT_MILESTONES';
export const LOAD_OTL_CAT_MILESTONES  = 'LOAD_OTL_CAT_MILESTONES';
export const REMOVE_OTL_CAT_MILESTONES  = 'REMOVE_OTL_CAT_MILESTONES';
export const UPDATE_OTL_CAT_MILESTONES : string = 'UPDATE_OTL_CAT_MILESTONES';


export class LoadOtlCatMilestone implements Action {
    readonly type = LOAD_OTL_CAT_MILESTONES;

    constructor(public payload: any) {
    }
}

export class AddOtlCatMilestone implements Action {
    readonly type = ADD_OTL_CAT_MILESTONES;

    constructor(public payload: OtlCatMilestone) { }
}

export class UpdateOtlCatMilestone implements Action {
    readonly type = UPDATE_OTL_CAT_MILESTONES;

    constructor(public payload: OtlCatMilestone) { }
}

export class RemoveOtlCatMilestone implements Action {
    readonly type = REMOVE_OTL_CAT_MILESTONES;

    constructor(public payload: number) { }
}


export type Actions = AddOtlCatMilestone | RemoveOtlCatMilestone | LoadOtlCatMilestone;
