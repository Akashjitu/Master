﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.IO;
using System.Reflection;
using System.Configuration;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.Threading.Tasks;

namespace Hts.Logger
{
    public class LogWriter
    {
        public OracleConnection OracleDataBaseConnection { get { return _oracleConnection; } }
        public static string ConnectionString { get { return _connectionString; } }
        private static string m_exePath = @"C:\CustomerApproval\Service\Logs";
        private static OracleConnection _oracleConnection = null;
        private static string _connectionString = null;
        static bool isLogTableExist;


        [Obsolete("LogWrite is deprecated, please use diffrant LogWrite instead.")]
        private static void LogWrite(string logMessage)
        {
            bool isLogEnable = false;
            bool.TryParse(ConfigurationManager.AppSettings["ENABLE_LOG"], out isLogEnable);

            if (isLogEnable == false)
                return;
            m_exePath = ConfigurationManager.AppSettings["LOG_FILE_DIRECTORY"];

            // m_exePath = Path.GetDirectoryName(typeof(LogWriter).Assembly.Location);
            //Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (!Directory.Exists(m_exePath))
            {
                Directory.CreateDirectory(m_exePath);
            }
            try
            {
                lock (m_exePath)
                {
                    using (StreamWriter w = File.AppendText(m_exePath + "\\" + ConfigurationManager.AppSettings["LOG_FILE_NAME"] + "_" + DateTime.Today.ToString("yyyy-MM-dd") + ".txt"))
                    {
                        Log(logMessage, w);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private static void Log(string logMessage, TextWriter txtWriter)
        {
            try
            {
                txtWriter.Write("\r\nLog Entry : ");
                txtWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(),
                    DateTime.Now.ToLongDateString());
                txtWriter.WriteLine("  :");
                txtWriter.WriteLine("  :{0}", logMessage);
                txtWriter.WriteLine("-------------------------------");
            }
            catch (Exception ex)
            {

            }
        }

        public static void LogWrite(Exception exception, LogType logType)
        {
            Task.Factory.StartNew(() => {
            try
            {
                string exceptionMessage = exception.Message?? string.Empty;
                string exceptionStackTrace = exception.StackTrace ?? string.Empty;
                string innerExceptionMessage = exception.InnerException == null ? string.Empty : exception.InnerException.Message;
                string innerExceptionStackTrace = exception.InnerException == null ? string.Empty : exception.InnerException.StackTrace;
                string projectName = Assembly.GetExecutingAssembly().FullName ?? string.Empty;
                string type = logType.ToString();

                var message = "ExceptionMessage :------------ \n" + exceptionMessage + "-------------------\n Inner Exception Message :------------------ \n" + innerExceptionMessage;
                var stackTrace = "Exception Stack Trace :------------ \n" + exceptionStackTrace + "-------------------\n Inner Stack Trace :------------------ \n" + innerExceptionStackTrace;
                //   ('ERROR_MESSAGE','STACK_TRACE','PROJECT','TYPE')
                var sqlQuery = string.Format(LogConstant.COMMAND_INSERT_LOG, message, stackTrace, projectName, type);
                ExecuteCommand(sqlQuery);
            }
            catch (Exception ex)
            {

              
            }
            });
        }


        public static void LogWrite(string exception, LogType logType)
        {

            string projectName = Assembly.GetExecutingAssembly().FullName;
            string type = logType.ToString();

            var message = exception;
            var stackTrace = string.Empty;



            //   ('ERROR_MESSAGE','STACK_TRACE','PROJECT','TYPE')
            var sqlQuery = string.Format(LogConstant.COMMAND_INSERT_LOG, message, stackTrace, projectName, type);
            ExecuteCommand(sqlQuery);
        }


        private static void ExecuteCommand(string sqlQuery)
        {
            try
            {
                InitConnaction();
                lock (_connectionString)
                {
                 
                    if (!isLogTableExist)
                    {
                        CreateLogTable();
                    }
                    if (_oracleConnection != null && isLogTableExist)
                    {
                        if (_oracleConnection.State == ConnectionState.Closed)
                        {
                            _oracleConnection.Open();
                        }
                        using (var command = _oracleConnection.CreateCommand())
                        {
                            command.CommandText = sqlQuery;
                            command.CommandType = CommandType.Text;
                            var dr = command.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

      
        private static  void CreateLogTable()
        {
            if (_oracleConnection.State == ConnectionState.Closed)
            {
                _oracleConnection.Open();
            }
            using (var command = _oracleConnection.CreateCommand())
            {
                command.CommandText = LogConstant.COMMAND_GET_LOG_TABLE_INFO;
                command.CommandType = CommandType.Text;
                var dr = command.ExecuteReader();
                isLogTableExist = dr.HasRows;

               
            }

            if (isLogTableExist == false)
            {
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = LogConstant.COMMAND_GET_LOG_TABLE_INFO;
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();

                    isLogTableExist = true;
                }
            }
        }


        private static void InitConnaction()
        {
            if (!ConfigurationManager.AppSettings.AllKeys.Contains(LogConstant.CONNECTION_STRING))
            {
                throw new Exception("CONNECTION_STRING not found in your App or web Config, Please Add CONNECTION_STRING as a Key and Value is your Db connection string.");
            }


            _connectionString = ConfigurationManager.AppSettings[LogConstant.CONNECTION_STRING].ToString();

            if (!string.IsNullOrEmpty(_connectionString))
            {
                _oracleConnection = new OracleConnection(_connectionString);
                _oracleConnection.Open();
            }
        }
    }





    public enum LogType
    {
        Information,
        Error,
        Warning
    }
}