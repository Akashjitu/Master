﻿using DataRepository.Database;
using DomainModels.Common;
using DomainModels.IbCatalogFilter;
using DomainModels.IbCatalogModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataRepository.DataProvider
{
    [TestClass]
    public class DataAccessObejctTest
    {
      
    }
}