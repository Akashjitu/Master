﻿
namespace Oracle.Data.Access.Constants
{
    public class DataAccessConstant
    {

        public const string CONNECTION_STRING = "CONNECTION_STRING";
        internal const string SP_INFO = "SELECT  OWNER ,  OBJECT_NAME ,  PACKAGE_NAME ,  OBJECT_ID ,  OVERLOAD ,  SUBPROGRAM_ID ,"+
            "ARGUMENT_NAME ,  POSITION ,  SEQUENCE ,  DATA_LEVEL ,  DATA_TYPE ,  DEFAULTED ,  DEFAULT_VALUE ,"+
            "DEFAULT_LENGTH ,  IN_OUT ,  DATA_LENGTH ,  DATA_PRECISION ,"+
            "DATA_SCALE ,  RADIX ,  CHARACTER_SET_NAME ,  TYPE_OWNER ,  TYPE_NAME ,"+
            "TYPE_SUBNAME ,  TYPE_LINK ,  PLS_TYPE ,  CHAR_LENGTH ,  CHAR_USED ,  ORIGIN_CON_ID FROM ALL_ARGUMENTS WHERE PACKAGE_NAME = '{0}' AND OBJECT_NAME = '{1}'";


    }
}
