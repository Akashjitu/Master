import { Component, OnInit, ViewChild, ElementRef, Inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/fracaReducer';
import * as FracaAction from './../store/fracaAction';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ShareDataService } from '../service/share-data.service';
import { map } from 'rxjs/operators';
import { FracaInfo } from '../Models/fraca-info';
import { FracaService } from '../service/fraca-service.service';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { AccessFraca } from '../models/access_fraca';
//import { DOCUMENT } from '@angular/platform-browser';

@Component({
  selector: 'app-entry-form',
  templateUrl: './entry-form.component.html',
  styleUrls: ['./entry-form.component.scss']
})
export class EntryFormComponent implements OnInit {
  today = new Date();
  jstoday = '';
  farcaInfo: FracaInfo;
  accessFraca : AccessFraca ={
    isReadonlyFracaNo : false,
    isReadonlyPartNo : false,
    isReadonlyOpenDate : false,
    isReadonlyCloseDate : false,
    isReadonlyFailedDate : false,
    isReadonlyProduct : false,
    isReadonlyProgram : false,
    isReadonlyCustomer : false,
    isReadonlyTestEnv : false,
    isReadonlyOriginator : false,
    isReadonlyRespEng : false,
    isReadonlySystem : false,
    isReadonlyElectrical : false,
    isReadonlyEmi : false,
    isReadonlyClosedBy : false,
    isReadonlyTestDoc : false,
    isReadonlyParagraph : false,
    isReadonlyTestType : false,
    isReadonlyFailureCode : false,
    isReadonlyEndUnit : false,
    isReadonlyLevel1 : false,
    isReadonlyLevel2 : false,
    isReadonlyNomenclature : false,
    isReadonlySerial : false,
    isReadonlyDesignator : false,
    isReadonlyInflightShutdown : false,
    isReadonlyInflightPowerLoss : false,
    isReadonlyChargeability : false,
    isReadonlySafetyAffected : false,
    isReadonlyFailureToStart : false,
    isReadonlyProblemDescription : false,
    isReadonlyFinding : false,
    isReadonlyAnalysis : false,
  }
  public showRespEng: boolean = false;
  modalRef: BsModalRef;
  sharemessage: any;
  isNew: boolean;
  isDisableStatus=true;
  statusObj='InProgress';


  constructor(private store: Store<IAppState>,
    private modalService: BsModalService,
    private service: FracaService,
    private shareDataService: ShareDataService) {

    this.jstoday = this.today.toISOString().split('T')[0];

    this.farcaInfo = {
      FracaNo: '',
      PartNo: '',
      OpenDate: this.today,
      CloseDate: null,
      FailedDate: this.today,
      Product: '',
      Program: '',
      Customer: '',
      TestEnv: '',
      Originator: '',
      RespEng: '',
      System: '',
      Electrical: '',
      Emi: '',
      ClosedBy: '',
      TestDoc: '',
      Paragraph: '',
      TestType: '',
      FailureCode: '',
      EndUnit: '',
      Level1: '',
      Level2: '',
      Nomenclature: '',
      SerialNumber: '',
      Designator: '',
      InflightShutdown: false,
      InflightPowerLoss: false,
      Chargeability:false,
      SafetyAffected: false,
      FailureToStart: false,
      ProblemDescription: '',
      Finding: '',
      Analysis: '',
      AccessType : 0,
      Status: 'InProgress'
    }

    this.shareDataService.currentMessage.subscribe(message => {

      this.isNew = !(message.FracaNo === " ");
      this.farcaInfo.FracaNo = message.FracaNo;
      this.farcaInfo.PartNo = message.PartNo;
      this.farcaInfo.OpenDate = message.OpenDate;
      this.farcaInfo.CloseDate = message.CloseDate;
      this.farcaInfo.FailedDate = message.FailedDate;
      this.farcaInfo.Product = message.Product;
      this.farcaInfo.Program = message.Program;
      this.farcaInfo.Customer = message.Customer;
      this.farcaInfo.TestEnv = message.TestEnv;
      this.farcaInfo.Originator = message.Originator;
      this.farcaInfo.RespEng = message.RespEng;
      this.farcaInfo.System = message.System;
      this.farcaInfo.Electrical = message.Electrical;
      this.farcaInfo.Emi = message.Emi;
      this.farcaInfo.ClosedBy = message.ClosedBy;
      this.farcaInfo.TestDoc = message.TestDoc;
      this.farcaInfo.Paragraph = message.Paragraph;
      this.farcaInfo.TestType = message.TestType;
      this.farcaInfo.FailureCode = message.FailureCode;
      this.farcaInfo.EndUnit = message.EndUnit;
      this.farcaInfo.Level1 = message.Level1;
      this.farcaInfo.Level2 = message.Level2;
      this.farcaInfo.Nomenclature = message.Nomenclature;
      this.farcaInfo.SerialNumber = message.SerialNumber;
      this.farcaInfo.Designator = message.Designator;
      this.farcaInfo.InflightShutdown = message.InflightShutdown;
      this.farcaInfo.InflightPowerLoss = message.InflightPowerLoss;
      this.farcaInfo.Chargeability = message.Chargeability;
      this.farcaInfo.SafetyAffected = message.SafetyAffected;
      this.farcaInfo.FailureToStart = message.FailureToStart;
      this.farcaInfo.ProblemDescription = message.ProblemDescription;
      this.farcaInfo.Finding = message.Finding;
      this.farcaInfo.Analysis = message.Analysis;
      this.farcaInfo.AccessType = message.AccessType;
      this.statusObj = message.Status;

      this.setAccess(message.AccessType) ;

      console.log(this.farcaInfo)

      console.log('isNew : ' + this.isNew)
    
    });
    if(this.isNew==false)
    this.setAccess(3);
  }


  ngOnInit() {
  }

  showRespEngbox() {
    this.showRespEng = this.farcaInfo.Originator == '' ? false : true;

  }

  resetform() {
    this.farcaInfo = {
      FracaNo: '',
      PartNo: '',
      OpenDate: new Date(),
      CloseDate: new Date(),
      FailedDate: new Date(),
      Product: '',
      Program: '',
      Customer: '',
      TestEnv: '',
      Originator: '' ,
      RespEng: '',
      System: '',
      Electrical: '',
      Emi: '',
      ClosedBy: '',
      TestDoc: '',
      Paragraph: '',
      TestType: '',
      FailureCode: '',
      EndUnit: '',
      Level1: '',
      Level2: '',
      Nomenclature: '',
      SerialNumber: '',
      Designator: '',
      InflightShutdown: false,
      InflightPowerLoss: false,
      Chargeability: false,
      SafetyAffected: false,
      FailureToStart: false,
      ProblemDescription: '',
      Finding: '',
      Analysis: '',
      AccessType : 0,
      Status: 'InProgress'
    }
  }

  newFraca() {
    var s = console.log(this.farcaInfo)
    if (this.isNew === false) {
      this.service.addNewFraca(this.farcaInfo);
    }
    else {
      this.service.UpdateFraca(this.farcaInfo);
    }

  }

  IsDisableSave=false;
setAccess(acc){
console.log('AccessType :- '+ acc);
  switch(acc){
      case 0:
        {
          this.IsDisableSave=true;
        this.accessFraca.isReadonlyFracaNo = true;
        this.accessFraca.isReadonlyPartNo = true;
        this.accessFraca.isReadonlyOpenDate = true;
        this.accessFraca.isReadonlyCloseDate = true;
        this.accessFraca.isReadonlyFailedDate = true;
        this.accessFraca.isReadonlyProduct = true;
        this.accessFraca.isReadonlyProgram = true;
        this.accessFraca.isReadonlyCustomer = true;
        this.accessFraca.isReadonlyTestEnv = true;
        this.accessFraca.isReadonlyOriginator = true;
        this.accessFraca.isReadonlyRespEng = true;
        this.accessFraca.isReadonlySystem = true;
        this.accessFraca.isReadonlyElectrical = true;
        this.accessFraca.isReadonlyEmi = true;
        this.accessFraca.isReadonlyClosedBy = true;
        this.accessFraca.isReadonlyTestDoc = true;
        this.accessFraca.isReadonlyParagraph = true;
        this.accessFraca.isReadonlyTestType = true,
        this.accessFraca.isReadonlyFailureCode = true;
        this.accessFraca.isReadonlyEndUnit = true;
        this.accessFraca.isReadonlyLevel1 = true;
        this.accessFraca.isReadonlyLevel2 = true;
        this.accessFraca.isReadonlyNomenclature = true;
        this.accessFraca.isReadonlySerial = true;
        this.accessFraca.isReadonlyDesignator = true;
        this.accessFraca.isReadonlyInflightShutdown = true;
        this.accessFraca.isReadonlyInflightPowerLoss = true;
        this.accessFraca.isReadonlyChargeability = true;
        this.accessFraca.isReadonlySafetyAffected = true;
        this.accessFraca.isReadonlyFailureToStart = true;
        this.accessFraca.isReadonlyProblemDescription = true;
        this.accessFraca.isReadonlyFinding = true;
        this.accessFraca.isReadonlyAnalysis = true;
        this.isDisableStatus=true;
        break;
        }
    
   
      case 1:{
        this.IsDisableSave=false;
        this.accessFraca.isReadonlyFracaNo = true;
        this.accessFraca.isReadonlyPartNo = true;
        this.accessFraca.isReadonlyOpenDate = true;
        this.accessFraca.isReadonlyCloseDate = true;
        this.accessFraca.isReadonlyFailedDate = true;
        this.accessFraca.isReadonlyOriginator = true;
        this.accessFraca.isReadonlyRespEng = true;
        this.accessFraca.isReadonlySystem = true;
        this.accessFraca.isReadonlyElectrical = true;
        this.accessFraca.isReadonlyEmi = true;
        this.accessFraca.isReadonlyClosedBy = true;
        this.isDisableStatus=true;
        break;
      }
      
      case 2:{
        this.isDisableStatus=false;
        break;
      }
      
      case 3:{
        this.accessFraca.isReadonlyCloseDate = true;
        this.accessFraca.isReadonlyClosedBy = true;
        this.statusObj = 'InProgress';
        break;
      }
      
}
}
  parseDate(dateString: string): Date {
    if (dateString) {
      return new Date(dateString);
    } else {
      return null;
    }
  }

  myOptions = {
    'placement': 'right',
    'show-delay': 500,
    // 'tooltip':"Clear all fields",
    ' placement':"top",
    'z-index': 1000,
     
}
  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '10rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',
    uploadUrl: 'v1/images', // if needed,
    //fonts:[{name : "Aparajita", class: "Aparajita"}],
    // customClasses: [ // optional
    //   {
    //     name: "quote",
    //     class: "quote",
    //   },
    //   {
    //     name: 'redText',
    //     class: 'redText'
    //   },
    //   {
    //     name: "titleText",
    //     class: "titleText",
    //     tag: "h1",
    //   },
    // ],
    showToolbar:true,
    enableToolbar:true
  };

  changedStatus(value){
    
    if(value=='Completed')
    {
      this.farcaInfo.ClosedBy= this.farcaInfo.RespEng;
      this.farcaInfo.CloseDate = this.today;
      this.farcaInfo.Status= 'Completed'
    }
    else{
      this.farcaInfo.ClosedBy= '';
      this.farcaInfo.CloseDate = null;
      this.farcaInfo.Status= 'InProgress'
    }
   
  }

  focusOutFunction(eltid, eid){
    console.log('focusOut' + eltid + " "+  eid );
  let elt=  (document.getElementById(eltid) as HTMLElement);

  if( elt.innerText=='' ||  elt.innerText== null)
      elt.hidden = true;

  if(elt!=null && eid!=''){
     this.service.getEmployeeInfo(eid).subscribe(emp => {
      elt.hidden =  emp.DisplayName!='' ?false: true;
      elt.innerText= emp.DisplayName;
      });

    }
  }
}
