﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Comment.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class Comment.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Comment
    {
        /// <summary>
        /// Gets or sets the comment identifier.
        /// </summary>
        /// <value>The comment identifier.</value>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CommentId { get; set; }

        /// <summary>
        /// Gets or sets the comment data.
        /// </summary>
        /// <value>The comment data.</value>
        public string CommentData { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        public virtual IBProjectComponent IBProjectComponent { get; set; }
        /// <summary>
        /// Gets or sets the xref product.
        /// </summary>
        /// <value>The xref product.</value>
        public virtual XrefProduct XrefProduct { get; set; }
    }
}