﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-27-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-08-2020
// ***********************************************************************
// <copyright file="InventoryMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using M2C.Business.Contracts;
using M2C.Business.Implementations;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Class InventoryMapper.
    /// Implements the <see cref="M2C.Business.Mappers.IInventoryMapper" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IInventoryMapper" />
    public class InventoryMapper : IInventoryMapper
    {
        /// <summary>
        /// The common inventory reference
        /// </summary>
        private ICommonInventoryReference _commonInventoryReference;

        /// <summary>
        /// The color provider
        /// </summary>
        private static IStatusColorProvider _colorProvider;

        /// <summary>
        /// Initializes a new instance of the <see cref="InventoryMapper" /> class.
        /// </summary>
        /// <param name="commonInventoryReference">The common inventory reference.</param>
        /// <param name="colorProvider">The color provider.</param>
        public InventoryMapper(ICommonInventoryReference commonInventoryReference, IStatusColorProvider colorProvider)
        {
            _commonInventoryReference = commonInventoryReference;
            _colorProvider = colorProvider;
        }

        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="productModels">Collection of ProductModel</param>
        /// <param name="years">The years.</param>
        /// <returns>Collection of Inventory</returns>
        public List<Inventory> Map(List<ProductModel> productModels, Years years)
        {
            return productModels?.Select(i => GetInventory(i, years)).ToList();
        }

        /// <summary>
        /// Get Mapped Inventory from  ProductModel
        /// </summary>
        /// <param name="productModel">ProductModel</param>
        /// <param name="years">The years.</param>
        /// <returns>Inventory</returns>
        public Inventory Map(ProductModel productModel, Years years)
        {
            return productModel == null ? null : GetInventory(productModel, years);
        }

        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="productModels">Collection of ProductModel</param>
        /// <param name="parentNodeTypeAndName">Dictionary with node type with Parent Node Name</param>
        /// <param name="years">The years.</param>
        /// <returns>Collection of Inventory</returns>
        public List<Inventory> Map(List<ProductModel> productModels, Dictionary<NodeType, string> parentNodeTypeAndName, Years years)
        {
            if (productModels == null || parentNodeTypeAndName == null)
                return null;

            var inventories = productModels.Select(i => GetInventory(i, years)).ToList();

            inventories.ForEach(inventory =>
            {
                SetInventoryNodeName(parentNodeTypeAndName, inventory);
            });
            return inventories;
        }

        /// <summary>
        /// Get Mapped Inventory from  ProductModel
        /// </summary>
        /// <param name="productModel">ProductModel</param>
        /// <param name="parentNodeTypeAndName">Dictionary with node type with Parent Node Name</param>
        /// <param name="years">The years.</param>
        /// <returns>Inventory</returns>
        public Inventory Map(ProductModel productModel, Dictionary<NodeType, string> parentNodeTypeAndName, Years years)
        {
            if (productModel == null || parentNodeTypeAndName == null)
                return null;

            var inventory = GetInventory(productModel, years);

            SetInventoryNodeName(parentNodeTypeAndName, inventory);
            return inventory;
        }

        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="productModels">Collection of ProductModel</param>
        /// <param name="node">Current Node</param>
        /// <param name="years">object of 5 Year</param>
        /// <returns>Collection of Inventory</returns>
        public List<Inventory> Map(List<ProductModel> productModels, INode node, Years years)
        {
            if (productModels == null || node == null)
                return null;

            var inventories = productModels.Select(i => GetInventory(i, years)).ToList();

            inventories.ForEach(inventory =>
            {
                SetInventoryNodes(node, inventory);
            });
            return inventories;
        }

        /// <summary>
        /// Get Mapped Inventory from  ProductModels
        /// </summary>
        /// <param name="productModel">Collection of ProductModel</param>
        /// <param name="node">Current Node</param>
        /// <param name="years">object of 5 Year</param>
        /// <returns>Collection of Inventory</returns>
        public Inventory Map(ProductModel productModel, INode node, Years years)
        {
            if (productModel == null || node == null)
                return null;

            var inventory = GetInventory(productModel, years);

            SetInventoryNodes(node, inventory);
            return inventory;
        }

        /// <summary>
        /// Set Node Names and Id to Inventory
        /// </summary>
        /// <param name="node">The node.</param>
        /// <param name="inventory">The inventory.</param>
        private static void SetInventoryNodes(INode node, Inventory inventory)
        {
            if (node == null || inventory == null)
                return;
            inventory.Configuration = "N/A";
            var parentNodeTypeAndNode = node.ParentNodeAndNodeType;
            if (parentNodeTypeAndNode.ContainsKey(NodeType.MAINTENANCEZONE))
            {
                inventory.MaintenanceZone = parentNodeTypeAndNode[NodeType.MAINTENANCEZONE].Name;
                inventory.MaintenanceZoneId = parentNodeTypeAndNode[NodeType.MAINTENANCEZONE].Id ?? -1;
            }

            inventory.Factory = parentNodeTypeAndNode.ContainsKey(NodeType.FACTORY)
                ? parentNodeTypeAndNode[NodeType.FACTORY].Name
                : "N/A";
            inventory.FactoryId = parentNodeTypeAndNode.ContainsKey(NodeType.FACTORY)
                ? parentNodeTypeAndNode[NodeType.FACTORY].Id ?? -1
                : 0;

            inventory.Machine = parentNodeTypeAndNode.ContainsKey(NodeType.MACHINE)
                ? parentNodeTypeAndNode[NodeType.MACHINE].Name
                : "N/A";

            inventory.MachineId = parentNodeTypeAndNode.ContainsKey(NodeType.MACHINE)
                ? parentNodeTypeAndNode[NodeType.MACHINE].Id ?? -1
                : 0;

            inventory.Line = parentNodeTypeAndNode.ContainsKey(NodeType.LINE)
                ? parentNodeTypeAndNode[NodeType.LINE].Name
                : "N/A";

            inventory.LineId = parentNodeTypeAndNode.ContainsKey(NodeType.LINE)
                ? parentNodeTypeAndNode[NodeType.LINE].Id ?? -1
                : 0;

            inventory.Workshop = parentNodeTypeAndNode.ContainsKey(NodeType.WORKSHOP)
                ? parentNodeTypeAndNode[NodeType.WORKSHOP].Name
                : "N/A";
            inventory.WorkshopId = parentNodeTypeAndNode.ContainsKey(NodeType.WORKSHOP)
                ? parentNodeTypeAndNode[NodeType.WORKSHOP].Id ?? -1
                : 0;

            if (parentNodeTypeAndNode.ContainsKey(NodeType.PLC_CONFIG))
            {
                inventory.Configuration = parentNodeTypeAndNode[NodeType.PLC_CONFIG].Name;
                inventory.ConfigurationId = parentNodeTypeAndNode[NodeType.PLC_CONFIG].Id ?? -1;
                inventory.ConfigType = BusinessConstants.PLC_CONFIGURATION;
            }

            if (parentNodeTypeAndNode.ContainsKey(NodeType.MD_CONFIG))
            {
                inventory.Configuration = parentNodeTypeAndNode[NodeType.MD_CONFIG].Name;
                inventory.ConfigurationId = parentNodeTypeAndNode[NodeType.MD_CONFIG].Id ?? -1;
                inventory.ConfigType = BusinessConstants.MOTION_DRIVE_CONFIGURATION;
            }
            if (parentNodeTypeAndNode.ContainsKey(NodeType.OPEN_CONFIG))
            {
                inventory.Configuration = parentNodeTypeAndNode[NodeType.OPEN_CONFIG].Name;
                inventory.ConfigurationId = parentNodeTypeAndNode[NodeType.OPEN_CONFIG].Id ?? -1;
                inventory.ConfigType = BusinessConstants.OPEN_CONFIGURATION;
            }
            if (parentNodeTypeAndNode.ContainsKey(NodeType.SHMI_CONFIG))
            {
                inventory.Configuration = parentNodeTypeAndNode[NodeType.SHMI_CONFIG].Name;
                inventory.ConfigurationId = parentNodeTypeAndNode[NodeType.SHMI_CONFIG].Id ?? -1;
                inventory.ConfigType = BusinessConstants.SCADA_HMI_CONFIGURATION;
            }
            if (parentNodeTypeAndNode.ContainsKey(NodeType.STOCK))
            {
                inventory.Configuration = parentNodeTypeAndNode[NodeType.STOCK].Name;
                inventory.ConfigurationId = parentNodeTypeAndNode[NodeType.STOCK].Id ?? -1;
            }
        }

        /// <summary>
        /// mapping function
        /// </summary>
        /// <param name="iBImportModels">The i b import models.</param>
        /// <returns>Collection of Inventory</returns>
        public List<Inventory> Map(List<IBImportModel> iBImportModels)
        {
            if (iBImportModels == null)
                return null;

            var inventories = new List<Inventory>();
            var years = new Years
            {
                Year = DateTime.Today.Year.ToString(),
                Year1 = DateTime.Today.AddYears(1).Year.ToString(),

                Year2 = DateTime.Today.AddYears(2).Year.ToString(),
                Year3 = DateTime.Today.AddYears(3).Year.ToString(),
                Year4 = DateTime.Today.AddYears(4).Year.ToString(),
            };
            foreach (var ib in iBImportModels)
            {
                var inventory = GetImportModelInventory(ib, years);
                if (inventory != null)
                    inventories.Add(inventory);
            }
            return inventories;
        }

        /// <summary>
        /// mapping function
        /// </summary>
        /// <param name="iBImportModels">The i b import models.</param>
        /// <param name="nodes">The nodes.</param>
        /// <returns>Collection of Inventory</returns>
        public List<Inventory> Map(List<IBImportModel> iBImportModels, List<INode> nodes)
        {
            if (iBImportModels == null)
                return null;

            var inventories = new List<Inventory>();
            var years = new Years
            {
                Year = DateTime.Today.Year.ToString(),
                Year1 = DateTime.Today.AddYears(1).Year.ToString(),
                Year2 = DateTime.Today.AddYears(2).Year.ToString(),
                Year3 = DateTime.Today.AddYears(3).Year.ToString(),
                Year4 = DateTime.Today.AddYears(4).Year.ToString(),
            };
            foreach (var ib in iBImportModels)
            {
                var inventory = GetImportModelInventory(ib, years);
                if (inventory == null)
                    continue;
                var nod = nodes
                       .FirstOrDefault(node => (
                           node.NodeParentNameAndNodeType.ContainsKey(NodeType.FACTORY) &&
                           node.NodeParentNameAndNodeType.ContainsKey(NodeType.WORKSHOP) &&
                           node.NodeParentNameAndNodeType.ContainsKey(NodeType.LINE) &&
                           node.NodeParentNameAndNodeType.ContainsKey(NodeType.MACHINE) &&
                                               node.NodeParentNameAndNodeType[NodeType.FACTORY] == inventory.Factory &&
                                               node.NodeParentNameAndNodeType[NodeType.WORKSHOP] == inventory.Workshop &&
                                               node.NodeParentNameAndNodeType[NodeType.LINE] == inventory.Line &&
                                               node.NodeParentNameAndNodeType[NodeType.MACHINE] == inventory.Machine) &&
                                              (
                                                  (node.NodeParentNameAndNodeType.ContainsKey(NodeType.PLC_CONFIG) && node.NodeParentNameAndNodeType[NodeType.PLC_CONFIG] == inventory.Configuration) ||
                                                  (node.NodeParentNameAndNodeType.ContainsKey(NodeType.MD_CONFIG) && node.NodeParentNameAndNodeType[NodeType.MD_CONFIG] == inventory.Configuration) ||
                                                  (node.NodeParentNameAndNodeType.ContainsKey(NodeType.SHMI_CONFIG) && node.NodeParentNameAndNodeType[NodeType.SHMI_CONFIG] == inventory.Configuration) ||
                                                  (node.NodeParentNameAndNodeType.ContainsKey(NodeType.OPEN_CONFIG) && node.NodeParentNameAndNodeType[NodeType.OPEN_CONFIG] == inventory.Configuration)));
                if (nod == null)
                    nod = nodes
                       .FirstOrDefault(node => (
                           node.NodeParentNameAndNodeType.ContainsKey(NodeType.FACTORY) &&
                           node.NodeParentNameAndNodeType.ContainsKey(NodeType.WORKSHOP) &&
                           !node.NodeParentNameAndNodeType.ContainsKey(NodeType.LINE) &&
                           node.NodeParentNameAndNodeType.ContainsKey(NodeType.MACHINE) &&
                           node.NodeParentNameAndNodeType[NodeType.FACTORY] == inventory.Factory &&
                           node.NodeParentNameAndNodeType[NodeType.WORKSHOP] == inventory.Workshop &&
                           node.NodeParentNameAndNodeType[NodeType.MACHINE] == inventory.Machine) &&
                              (
                                  (node.NodeParentNameAndNodeType.ContainsKey(NodeType.PLC_CONFIG) && node.NodeParentNameAndNodeType[NodeType.PLC_CONFIG] == inventory.Configuration) ||
                               (node.NodeParentNameAndNodeType.ContainsKey(NodeType.MD_CONFIG) && node.NodeParentNameAndNodeType[NodeType.MD_CONFIG] == inventory.Configuration) ||
                               (node.NodeParentNameAndNodeType.ContainsKey(NodeType.SHMI_CONFIG) && node.NodeParentNameAndNodeType[NodeType.SHMI_CONFIG] == inventory.Configuration) ||
                               (node.NodeParentNameAndNodeType.ContainsKey(NodeType.OPEN_CONFIG) && node.NodeParentNameAndNodeType[NodeType.OPEN_CONFIG] == inventory.Configuration)));

                SetInventoryNodes(nod, inventory);
                inventory.Criticality = ib.MachineCriticity;
                inventories.Add(inventory);
            }
            return inventories;
        }

        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="iBImportModels">The i b import models.</param>
        /// <param name="nodes">The nodes.</param>
        /// <returns>Collection of Inventory</returns>
        public List<Inventory> Map(List<TRImportModel> iBImportModels, List<INode> nodes)
        {
            if (iBImportModels == null)
                return null;

            var inventories = new List<Inventory>();
            var years = new Years
            {
                Year = DateTime.Today.Year.ToString(),
                Year1 = DateTime.Today.AddYears(1).Year.ToString(),
                Year2 = DateTime.Today.AddYears(2).Year.ToString(),
                Year3 = DateTime.Today.AddYears(3).Year.ToString(),
                Year4 = DateTime.Today.AddYears(4).Year.ToString(),
            };
            foreach (var ib in iBImportModels)
            {
                var inventory = GetTrImportModelInventory(ib, years);
                if (inventory == null)
                    continue;

                var nod = nodes
                     .FirstOrDefault(node => (
                         node.NodeParentNameAndNodeType.ContainsKey(NodeType.MAINTENANCEZONE) &&
                                             node.NodeParentNameAndNodeType[NodeType.MAINTENANCEZONE] == inventory.MaintenanceZone &&
                                             node.NodeParentNameAndNodeType[NodeType.STOCK] == inventory.Configuration));

                if (nod == null) continue;
                SetInventoryNodes(nod, inventory);

                inventories.Add(inventory);
            }
            return inventories;
        }

        /// <summary>
        /// mapping function
        /// </summary>
        /// <param name="trImportModels">The tr import models.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        public List<Inventory> Map(List<TRImportModel> trImportModels)
        {
            if (trImportModels == null)
                return null;

            var inventories = new List<Inventory>();
            var years = new Years
            {
                Year = DateTime.Today.Year.ToString(),
                Year1 = DateTime.Today.AddYears(1).Year.ToString(),

                Year2 = DateTime.Today.AddYears(2).Year.ToString(),
                Year3 = DateTime.Today.AddYears(3).Year.ToString(),
                Year4 = DateTime.Today.AddYears(4).Year.ToString(),
            };
            foreach (var tr in trImportModels)
            {
                var inv = GetTrImportModelInventory(tr, years);
                if (inv != null)
                    inventories.Add(inv);
            }
            return inventories;
        }

        /// <summary>
        /// Set Node Names to Inventory
        /// </summary>
        /// <param name="parentNodeTypeAndName">Name of the parent node type and.</param>
        /// <param name="inventory">The inventory.</param>
        private static void SetInventoryNodeName(Dictionary<NodeType, string> parentNodeTypeAndName, Inventory inventory)
        {
            inventory.Configuration = "N/A";
            if (parentNodeTypeAndName.ContainsKey(NodeType.MAINTENANCEZONE))
                inventory.MaintenanceZone = parentNodeTypeAndName[NodeType.MAINTENANCEZONE];

            inventory.Factory = parentNodeTypeAndName.ContainsKey(NodeType.FACTORY)
                ? parentNodeTypeAndName[NodeType.FACTORY]
                : "N/A";
            inventory.Machine = parentNodeTypeAndName.ContainsKey(NodeType.MACHINE)
                ? parentNodeTypeAndName[NodeType.MACHINE]
                : "N/A";
            inventory.Line = parentNodeTypeAndName.ContainsKey(NodeType.LINE)
                ? parentNodeTypeAndName[NodeType.LINE]
                : "N/A";
            inventory.Workshop = parentNodeTypeAndName.ContainsKey(NodeType.WORKSHOP)
                ? parentNodeTypeAndName[NodeType.WORKSHOP]
                : "N/A";

            if (parentNodeTypeAndName.ContainsKey(NodeType.PLC_CONFIG))
                inventory.Configuration = parentNodeTypeAndName[NodeType.PLC_CONFIG];
            if (parentNodeTypeAndName.ContainsKey(NodeType.MD_CONFIG))
                inventory.Configuration = parentNodeTypeAndName[NodeType.MD_CONFIG];
            if (parentNodeTypeAndName.ContainsKey(NodeType.OPEN_CONFIG))
                inventory.Configuration = parentNodeTypeAndName[NodeType.OPEN_CONFIG];
            if (parentNodeTypeAndName.ContainsKey(NodeType.SHMI_CONFIG))
                inventory.Configuration = parentNodeTypeAndName[NodeType.SHMI_CONFIG];
            if (parentNodeTypeAndName.ContainsKey(NodeType.STOCK))
                inventory.Configuration = parentNodeTypeAndName[NodeType.STOCK];
        }

        /// <summary>
        /// Get Inventory
        /// </summary>
        /// <param name="productModel">The product model.</param>
        /// <param name="years">The years.</param>
        /// <returns>Inventory.</returns>
        private static Inventory GetInventory(ProductModel productModel, Years years)
        {
            if (string.IsNullOrEmpty(productModel.FullName))
                return null;
            var inventory = new Inventory
            {
                Year = _colorProvider.GetYearColor(int.TryParse(years.Year, out var year) ? year : 0, productModel.EndProductionOrPhaseOut, productModel.EndCommercialization, productModel.EndServicesWithdrawalSupport),
                Year1 = _colorProvider.GetYearColor(int.TryParse(years.Year1, out var year1) ? year1 : 0, productModel.EndProductionOrPhaseOut, productModel.EndCommercialization, productModel.EndServicesWithdrawalSupport),
                Year2 = _colorProvider.GetYearColor(int.TryParse(years.Year2, out var year2) ? year2 : 0, productModel.EndProductionOrPhaseOut, productModel.EndCommercialization, productModel.EndServicesWithdrawalSupport),
                Year3 = _colorProvider.GetYearColor(int.TryParse(years.Year3, out var year3) ? year3 : 0, productModel.EndProductionOrPhaseOut, productModel.EndCommercialization, productModel.EndServicesWithdrawalSupport),
                Year4 = _colorProvider.GetYearColor(int.TryParse(years.Year4, out var year4) ? year4 : 0, productModel.EndProductionOrPhaseOut, productModel.EndCommercialization, productModel.EndServicesWithdrawalSupport),
                Name = productModel.Description,
                DeviceType = productModel.DeviceType.Type,
                DeviceTypeId = productModel.DeviceTypeId,
                Range = productModel.Range.Name,
                RangeId = productModel.RangeId,
                Brand = productModel.Brand.Name,
                BrandId = productModel.BrandId,
                Quantity = int.TryParse(productModel.Quantity, out var quantity) ? quantity : 1,
                Comment = productModel.Comments,
                UnitPrice = productModel.DefaultUnitPrice.ToString(CultureInfo.InvariantCulture),
                PvNumber = productModel.PvNumber,
                SvNumber = productModel.SvNumber,
                Reference = productModel.Identifier,
                Dosa = productModel.EndProductionOrPhaseOut == null || productModel.EndProductionOrPhaseOut == 9999 ? "Not Defined" : productModel.EndProductionOrPhaseOut.ToString(),
                DoS = productModel.EndCommercialization == null || productModel.EndCommercialization == 9999 ? "Not Defined" : productModel.EndCommercialization.ToString(),
                EoS = productModel.EndServicesWithdrawalSupport == null || productModel.EndServicesWithdrawalSupport == 9999 ? "Not Defined" : productModel.EndServicesWithdrawalSupport.ToString(),
                ConfigType = productModel.ConfigType
            };
            inventory.Version = productModel.Version;
            return inventory;
        }

        /// <summary>
        /// Get Inventory
        /// </summary>
        /// <param name="ibImportModel">The ib import model.</param>
        /// <param name="years">The years.</param>
        /// <returns>Inventory.</returns>
        private Inventory GetImportModelInventory(IBImportModel ibImportModel, Years years)
        {
            if (ibImportModel == null)
                return null;
            var databaseProduct = _commonInventoryReference.GetProductsByIdentifier(ibImportModel.Reference);

            if (databaseProduct == null) return null;
            var inventories = Map(databaseProduct, years);

            var inventory = inventories;
            if (inventory != null)
            {
                inventory.Factory = ibImportModel.Factory;
                inventory.Workshop = ibImportModel.Workshop;
                inventory.Line = ibImportModel.Line;
                inventory.Machine = ibImportModel.Machine;
                inventory.PvNumber = ibImportModel.PV;
                inventory.SvNumber = ibImportModel.SV;
                inventory.Quantity = int.TryParse(ibImportModel.Quantity, out var quantity) ? quantity : 1;
                inventory.Comment = ibImportModel.Comment;
                inventory.Configuration = ibImportModel.ConfigurationName;
                inventory.ConfigType = ibImportModel.ConfigurationType;
            }

            return inventory;
        }

        /// <summary>
        /// Import model for technical resource
        /// </summary>
        /// <param name="trImportModel">The tr import model.</param>
        /// <param name="years">The years.</param>
        /// <returns>Inventory.</returns>
        private Inventory GetTrImportModelInventory(TRImportModel trImportModel, Years years)
        {
            if (trImportModel == null)
                return null;
            var databaseProduct = _commonInventoryReference.GetProductsByIdentifier(trImportModel.Reference);

            if (databaseProduct == null) return null;
            var inventory = Map(databaseProduct, years);

            if (inventory != null)
            {
                inventory.MaintenanceZone = trImportModel.Maintenancezone;
                inventory.Configuration = trImportModel.Configuration;
                inventory.PvNumber = trImportModel.PV;
                inventory.SvNumber = trImportModel.SV;
                inventory.Comment = trImportModel.Comment;                
            }

            return inventory;
        }

        /// <summary>
        /// Get ObservableCollection Inventory collection of ProjectInventory
        /// </summary>
        /// <param name="projectInventories">The project inventories.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        public ObservableCollection<Inventory> Map(ICollection<ProjectInventory> projectInventories)
        {
            var inventories = new ObservableCollection<Inventory>();
            inventories.AddRange(projectInventories.Select(i => new Inventory
            {
                Year = i.Year,
                Year1 = i.Year1,
                Year2 = i.Year2,
                Year3 = i.Year3,
                Year4 = i.Year4,
                Name = i.Name,
                DeviceType = i.DeviceType,
                DeviceTypeId = i.DeviceTypeId,
                Range = i.Range,
                RangeId = i.RangeId,
                Brand = i.Brand,
                BrandId = i.BrandId,
                Quantity = i.Quantity,
                Comment = i.Comment,
                UnitPrice = i.UnitPrice,
                PvNumber = i.PvNumber,
                SvNumber = i.SvNumber,
                Reference = i.Reference,
                Dosa = i.Dosa,
                DoS = i.DoS,
                EoS = i.EoS,
                ConfigType = i.ConfigType,
                Factory = i.Factory,
                Machine = i.Machine,
                Line = i.Line,
                Workshop = i.Workshop,
                Configuration = i.Configuration,
                FactoryId = i.FactoryId,
                MachineId = i.MachineId,
                LineId = i.LineId,
                WorkshopId = i.WorkshopId,
                ConfigurationId = i.ConfigurationId,
                SubRange = i.SubRange,
                SubRangeId = i.SubRangeId,
                Strategic = i.Strategic,
                MaintenanceZone = i.MaintenanceZone,
                MaintenanceZoneId = i.MaintenanceZoneId,
                Criticality = i.Criticality,
                Version=i.Version
            }).ToList());

            return inventories;
        }

        /// <summary>
        /// Get ObservableCollection Database updated Inventory collection of ProjectInventory
        /// </summary>
        /// <param name="projectInventories">The project inventories.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        public ObservableCollection<Inventory> MapWithUpdateDatabase(ICollection<ProjectInventory> projectInventories)
        {
            var years = new Years
            {
                Year = DateTime.Today.Year.ToString(),
                Year1 = DateTime.Today.AddYears(1).Year.ToString(),
                Year2 = DateTime.Today.AddYears(2).Year.ToString(),
                Year3 = DateTime.Today.AddYears(3).Year.ToString(),
                Year4 = DateTime.Today.AddYears(4).Year.ToString(),
            };

            if (projectInventories == null)
                return null;

            var returnInventories = new ObservableCollection<Inventory>();
            foreach (var projectInventory in projectInventories)
            {
                ProductModel databaseProduct = _commonInventoryReference.GetProductsByIdentifier(projectInventory.Reference);

                //Populate details from ProductDB data
                Inventory inventories = Map(databaseProduct, years);

                //Adding TreeView Data and meta-data
                inventories.MaintenanceZone = projectInventory.MaintenanceZone;
                inventories.Configuration = projectInventory.Configuration;
                inventories.PvNumber = projectInventory.PvNumber;
                inventories.SvNumber = projectInventory.SvNumber;
                inventories.Comment = projectInventory.Comment;

                inventories.MaintenanceZoneId = projectInventory.MaintenanceZoneId;
                inventories.ConfigurationId = projectInventory.ConfigurationId;
                inventories.FactoryId = projectInventory.FactoryId;
                inventories.WorkshopId = projectInventory.WorkshopId;
                inventories.LineId = projectInventory.LineId;
                inventories.MachineId = projectInventory.MachineId;
                inventories.Machine = projectInventory.Machine;
                inventories.Factory = projectInventory.Factory;
                inventories.Quantity = projectInventory.Quantity;
                inventories.Workshop = projectInventory.Workshop;
                inventories.Line = projectInventory.Line;
                inventories.LineId = projectInventory.LineId;
                inventories.ConfigType = projectInventory.ConfigType;                

                returnInventories.Add(inventories);
            }

            return returnInventories;
        }

        /// <summary>
        /// Get  ProjectInventory from ObservableCollection Inventory
        /// </summary>
        /// <param name="projectInventories">The project inventories.</param>
        /// <returns>List&lt;ProjectInventory&gt;.</returns>
        public List<ProjectInventory> Map(ObservableCollection<Inventory> projectInventories)
        {
            var inventories = new List<ProjectInventory>();

            if (projectInventories != null && projectInventories.Count > 0)
            {
                inventories.AddRange(projectInventories.Select(i => new ProjectInventory
                {
                    Year = i.Year,
                    Year1 = i.Year1,
                    Year2 = i.Year2,
                    Year3 = i.Year3,
                    Year4 = i.Year4,
                    Name = i.Name,
                    DeviceType = i.DeviceType,
                    DeviceTypeId = i.DeviceTypeId,
                    Range = i.Range,
                    RangeId = i.RangeId,
                    Brand = i.Brand,
                    BrandId = i.BrandId,
                    Quantity = i.Quantity,
                    Comment = i.Comment,
                    UnitPrice = i.UnitPrice,
                    PvNumber = i.PvNumber,
                    SvNumber = i.SvNumber,
                    Reference = i.Reference,
                    Dosa = i.Dosa,
                    DoS = i.DoS,
                    EoS = i.EoS,
                    ConfigType = i.ConfigType,
                    Factory = i.Factory,
                    Machine = i.Machine,
                    Line = i.Line,
                    Workshop = i.Workshop,
                    Configuration = i.Configuration,
                    FactoryId = i.FactoryId,
                    MachineId = i.MachineId,
                    LineId = i.LineId,
                    WorkshopId = i.WorkshopId,
                    ConfigurationId = i.ConfigurationId,
                    SubRange = i.SubRange,
                    SubRangeId = i.SubRangeId,
                    Strategic = i.Strategic,
                    MaintenanceZone = i.MaintenanceZone,
                    MaintenanceZoneId = i.MaintenanceZoneId,
                    Criticality = i.Criticality,
                    Version = i.Version
                }).ToList());
            }
            return inventories;
        }

        /// <summary>
        /// Most use while doing paste.
        /// Based on the Target Node Map Inventories
        /// </summary>
        /// <param name="targetNode">The target node.</param>
        /// <param name="cloneNode">The clone node.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        public List<Inventory> TargetNodeMap(INode targetNode, INode cloneNode)
        {
            var inventories = cloneNode.CopyOfNodeInventories.Select(i => new Inventory()
            {
                Year = i.Year,
                Year1 = i.Year1,
                Year2 = i.Year2,
                Year3 = i.Year3,
                Year4 = i.Year4,
                Name = i.Name,
                DeviceType = i.DeviceType,
                DeviceTypeId = i.DeviceTypeId,
                Range = i.Range,
                RangeId = i.RangeId,
                Brand = i.Brand,
                BrandId = i.BrandId,
                Quantity = i.Quantity,
                Comment = i.Comment,
                UnitPrice = i.UnitPrice,
                PvNumber = i.PvNumber,
                SvNumber = i.SvNumber,
                Reference = i.Reference,
                Dosa = i.Dosa,
                DoS = i.DoS,
                EoS = i.EoS,
                ConfigType = i.ConfigType,
                FactoryId = i.FactoryId,
                Factory = i.Factory,
                WorkshopId = i.WorkshopId,
                Workshop = i.Workshop,
                MachineId = i.MachineId,
                Machine = i.Machine,
                LineId = i.LineId,
                Line = i.Line,
                Configuration = i.Configuration,
                ConfigurationId = i.ConfigurationId,
                Criticality = i.Criticality,
                MaintenanceZone = i.MaintenanceZone,
                MaintenanceZoneId = i.MaintenanceZoneId,
                OperationMode = i.OperationMode,
                Strategic = i.Strategic,
                SubRange = i.SubRange,
                SubRangeId = i.SubRangeId,
                Version = i.Version
            }).ToList();

            inventories.ForEach(i => SetInventoryNodes(targetNode, i));
            return inventories;
        }
    }
}