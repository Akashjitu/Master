﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-28-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="InventoryDetailsControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using M2C.Business.Models;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.UIModels;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;

namespace M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls
{
    /// <summary>
    /// ViewModel for Inventory Details.
    /// Provide Binding Data and Event
    /// </summary>
    public class InventoryDetailsControlViewModel : BindableBase, IDialogAware
    {
        /// <summary>
        /// The selected inventory
        /// </summary>
        private Inventory _selectedInventory;
        /// <summary>
        /// The years
        /// </summary>
        private Years _years;

        /// <summary>
        /// Get set Selected Inventory
        /// </summary>
        /// <value>The selected inventory.</value>
        public Inventory SelectedInventory
        {
            get => _selectedInventory;
            set => SetProperty(ref _selectedInventory, value);
        }

        /// <summary>
        /// Gets or sets the years.
        /// </summary>
        /// <value>The years.</value>
        public Years Years
        {
            get => _years;
            set => SetProperty(ref _years, value);
        }
        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => CollectionConstant.OverallInformation;
        /// <summary>
        /// Event of Close Dialog Box
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }
        /// <summary>
        /// Gets the grid columns.
        /// </summary>
        /// <value>The grid columns.</value>
        public List<GridColumnDescription> GridColumns { get; private set; }

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// Initializes a new instance of the <see cref="InventoryDetailsControlViewModel" /> class.
        /// </summary>
        public InventoryDetailsControlViewModel()
        {
            CloseDialogCommand = new DelegateCommand<string>(OnCloseAction);
        }

        /// <summary>
        /// Called when [close action].
        /// </summary>
        /// <param name="obj">The object.</param>
        private void OnCloseAction(string obj)
        {
            RequestClose?.Invoke(new DialogResult(ButtonResult.Cancel));
        }

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {

        }

        /// <summary>
        /// Called when [dialog opened].
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            if (parameters.TryGetValue(CollectionConstant.InfoInventory, out Inventory inventory))
            {
                SelectedInventory = inventory;
            }

            if (parameters.TryGetValue(CollectionConstant.Columns, out List<GridColumnDescription> gridColumnDescriptions))
            {
                Years years = new Years()
                {
                    Year = gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == nameof(SelectedInventory.Year))
                        ?.Header,
                    Year1 =
                    gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == nameof(SelectedInventory.Year1))?.
                    Header,
                    Year2 =
                    gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == nameof(SelectedInventory.Year2))?.
                    Header,
                    Year3 =
                    gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == nameof(SelectedInventory.Year3))?.
                    Header,
                    Year4 =
                    gridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == nameof(SelectedInventory.Year4))?.
                    Header,
                };

                Years = years;
            }
        }

       
    }
}
