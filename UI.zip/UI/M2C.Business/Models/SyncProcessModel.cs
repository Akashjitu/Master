﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SyncProcessModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using SyncServiceLibrary.Model;

namespace M2C.Business.Models
{
    /// <summary>
    /// SyncProcessModel business model
    /// </summary>
    public class SyncProcessModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SyncProcessModel" /> class.
        /// </summary>
        /// <param name="resultModel">The result model.</param>
        public SyncProcessModel(SyncResultModel resultModel)
        {
            switch(resultModel.Status)
            {
                case SyncStatus.NONE: {
                        this.Status = ProcessStatus.NONE;
                        this.Message = $"{resultModel.Message}";
                    }break;
                case SyncStatus.IN_PROGRESS:
                    {
                        this.Status = ProcessStatus.IN_PROGRESS;
                        this.Message = $"{resultModel.Message} : in progress";
                    }
                    break;
                case SyncStatus.RETRYING:
                    {
                        this.Status = ProcessStatus.RETRYING;
                        this.Message = $"{resultModel.Message} : in retrying";
                    }
                    break;
                case SyncStatus.SUCCESS:
                    {
                        this.Status = ProcessStatus.SUCCESS;
                        this.Message = $"{resultModel.Message} : Successful";
                    }
                    break;
                case SyncStatus.FAILED:
                    {
                        this.Status = ProcessStatus.FAILED;
                        this.Message = $"{resultModel.Message} : Failed";
                    }
                    break;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SyncProcessModel" /> class.
        /// </summary>
        public SyncProcessModel()
        {

        }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>The status.</value>
        public ProcessStatus Status { get; set; }
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }
    }

    /// <summary>
    /// Enum ProcessStatus
    /// </summary>
    public enum ProcessStatus
    {
        /// <summary>
        /// The none
        /// </summary>
        NONE = 0,
        /// <summary>
        /// The in progress
        /// </summary>
        IN_PROGRESS,
        /// <summary>
        /// The retrying
        /// </summary>
        RETRYING,
        /// <summary>
        /// The success
        /// </summary>
        SUCCESS,
        /// <summary>
        /// The failed
        /// </summary>
        FAILED,
        /// <summary>
        /// The completed
        /// </summary>
        COMPLETED
    }
}