﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ContextItem.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Commands;
using Prism.Mvvm;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Class ContextItem.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ContextItem : BindableBase
    {
        /// <summary>
        /// The display name
        /// </summary>
        private string _displayName;
        /// <summary>
        /// The context menu command
        /// </summary>
        private DelegateCommand<string> _contextMenuCommand;
        /// <summary>
        /// The column
        /// </summary>
        private object _column;
        /// <summary>
        /// The menu item name
        /// </summary>
        private string _menuItemName;
        /// <summary>
        /// The is checked
        /// </summary>
        private bool _isChecked;
        /// <summary>
        /// The visibility
        /// </summary>
        private bool _visibility;

        /// <summary>
        /// Gets or sets the display name.
        /// </summary>
        /// <value>The display name.</value>
        public string DisplayName
        {
            get => _displayName;
            set => SetProperty(ref _displayName, value);
        }

        /// <summary>
        /// Gets or sets the context menu command.
        /// </summary>
        /// <value>The context menu command.</value>
        public DelegateCommand<string> ContextMenuCommand
        {
            get => _contextMenuCommand;
            set => SetProperty(ref _contextMenuCommand, value);
        }

        /// <summary>
        /// Gets or sets the column.
        /// </summary>
        /// <value>The column.</value>
        public object Column
        {
            get => _column;
            set => SetProperty(ref _column, value);
        }

        /// <summary>
        /// Gets or sets the name of the menu item.
        /// </summary>
        /// <value>The name of the menu item.</value>
        public string MenuItemName
        {
            get => _menuItemName;
            set => SetProperty(ref _menuItemName, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is checked.
        /// </summary>
        /// <value><c>true</c> if this instance is checked; otherwise, <c>false</c>.</value>
        public bool IsChecked
        {
            get => _isChecked;
            set => SetProperty(ref _isChecked, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ContextItem" /> is visibility.
        /// </summary>
        /// <value><c>true</c> if visibility; otherwise, <c>false</c>.</value>
        public bool Visibility
        {
            get => _visibility;
            set => SetProperty(ref _visibility, value);
        }
    }
}