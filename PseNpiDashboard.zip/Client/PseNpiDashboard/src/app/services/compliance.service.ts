import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/accoladeReducer';
import { Compliance } from '../model/compliance';
import * as ComplianceAction from './../store/compliance/complianceAction';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root'
})
export class ComplianceService {

  headers: any;

  constructor(private http: HttpClient, private store: Store<IAppState>, ) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
     'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
     withCredentials: 'true',
  });
   }

   reportDownload(date) {
    console.log(date);
    this.http.get('http://localhost:49855/compliance?date=' + date , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'TTI' + date + '.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }


  getCompliance(criteria) {
    // this.http.post<Compliance>('http://localhost:49855/api/compliance', criteria, {headers : this.headers})
    // .subscribe(FracaData => this.store.dispatch(new ComplianceAction.LoadCompliance(FracaData)),
    // err => {console.log(`ERROR: ${err}`)});
    // console.log(criteria);
    console.log('http://localhost:49855/api/compliance');
    this.http.get<any>('http://localhost:49855/api/Compliance?createDon='+ criteria)
      .subscribe(FracaData => this.store.dispatch(new ComplianceAction.LoadCompliance(FracaData),
      ),
        err => { console.log(`ERROR: ${err}`); });
  }


  saveCompliance(modifieditems){
    console.log('saveCompliance' + modifieditems)
    return this.http.post('http://localhost:49855/api/Compliance', modifieditems,  { headers: this.headers})
      .subscribe(infoData => console.log(infoData)      );
  }

 
}
