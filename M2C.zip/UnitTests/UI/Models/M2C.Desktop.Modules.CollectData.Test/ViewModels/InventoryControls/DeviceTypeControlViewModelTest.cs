﻿using M2C.Business.Contracts;
using M2C.Desktop.Modules.CollectData.Test.MOCK;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using System.Windows;
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls
{
    [TestClass]
    public class DeviceTypeControlViewModelTest
    {
        private DeviceTypeControlViewModel deviceTypeControlViewModel;
        private ICommonInventoryReference _commonInventoryReference;

        [TestInitialize]
        public void Setup()
        {
            _commonInventoryReference = Substitute.For<ICommonInventoryReference>();
            _commonInventoryReference.GetDeviceTypes(Arg.Any<string>()).Returns(MockProvider.GetDeviceTypes());
            _commonInventoryReference.GetProductsByDeviceIdAndRangeId(Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetProducts());
            _commonInventoryReference.GetRangeByDeviceTypeIds(Arg.Any<int>()).Returns(MockProvider.GetRanges());
            _commonInventoryReference.GetProducts(Arg.Any<int>(), Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetProducts()); ;
            _commonInventoryReference.GetRangeByBrandAndDeviceTypeIds(Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetRanges()); ;
            _commonInventoryReference.GetDeviceTypesByBrand(Arg.Any<int>()).Returns(MockProvider.GetDeviceTypes()); ;
            deviceTypeControlViewModel = new DeviceTypeControlViewModel(_commonInventoryReference);
        
        }

        [TestMethod]
        public void ShouldReturnProductBasedOnSelection()
        {
            var c = new RoutedEventArgs(null, new TextBox() { Text = "s" });
            deviceTypeControlViewModel.OnKeyUpPChangeCommand.Execute(c);
           deviceTypeControlViewModel.SelectedDeviceType = MockProvider.GetDeviceTypes()[0];

            deviceTypeControlViewModel.OnSelectionChangeCommand.Execute("DEVICE-TYPE");
            deviceTypeControlViewModel.SelectedRangeModels = MockProvider.GetRanges()[0];

            deviceTypeControlViewModel.OnSelectionChangeCommand.Execute("RANGE");
            deviceTypeControlViewModel.SelectedProduct = MockProvider.GetProducts()[0];

            Assert.IsNotNull(deviceTypeControlViewModel.OnKeyUpPChangeCommand);
            Assert.IsNotNull(deviceTypeControlViewModel.OnSelectionChangeCommand);

            
            Assert.IsNotNull(deviceTypeControlViewModel.SelectedDeviceType);
            Assert.IsNotNull(deviceTypeControlViewModel.SelectedRangeModels);
            Assert.IsNotNull(deviceTypeControlViewModel.SelectedProduct);
            Assert.IsTrue(deviceTypeControlViewModel.Products != null && deviceTypeControlViewModel.Products.Count > 0);
            Assert.IsTrue(deviceTypeControlViewModel.DeviceTypes != null && deviceTypeControlViewModel.DeviceTypes.Count > 0);
            Assert.IsTrue(deviceTypeControlViewModel.Ranges != null && deviceTypeControlViewModel.Ranges.Count > 0);


        }
    }
}