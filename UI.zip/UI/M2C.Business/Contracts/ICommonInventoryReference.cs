﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="ICommonInventoryReference.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using M2C.Business.Models;
using System.Collections.Generic;

namespace M2C.Business.Contracts
{
    /// <summary>
    /// Interface ICommonInventoryReference
    /// </summary>
    public interface ICommonInventoryReference
    {
        /// <summary>
        /// Get Products Start With Identifier
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        List<ProductModel> GetProductsStartWithIdentifier(string identifier);

        /// <summary>
        /// Gets the products Start With Identifier and Config Node
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <param name="configNodeType"></param>
        /// <param name="isSe"></param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        List<ProductModel> GetProductsStartWithIdentifierByNode(string identifier, string configNodeType,
            bool isSe = true);

        /// <summary>
        /// Gets the database products.
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> GetDbProducts(string identifier);

        /// <summary>
        /// Gets the brand models.
        /// </summary>
        /// <param name="brandName">Name of the brand.</param>
        /// <param name="isSe"></param>
        /// <returns>List&lt;BrandModel&gt;.</returns>
        List<BrandModel> GetBrandModels(string brandName, bool isSe = true);
        /// <summary>
        /// Gets the range by brand.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <returns>List&lt;RangeModel&gt;.</returns>
        List<RangeModel> GetRangeByBrand(int brandId);
        /// <summary>
        /// Gets the device types by brand and range identifier.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="rangeId">The range identifier.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        List<DeviceTypeModel> GetDeviceTypesByBrandAndRangeId(int brandId, int rangeId);
        /// <summary>
        /// Gets the range by brand and device type ids.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="deviceTypeId">The device type identifier.</param>
        /// <returns>List&lt;RangeModel&gt;.</returns>
        List<RangeModel> GetRangeByBrandAndDeviceTypeIds(int brandId, int deviceTypeId);
        /// <summary>
        /// Gets the device types by brand id.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        List<DeviceTypeModel> GetDeviceTypesByBrand(int id);


        /// <summary>
        /// Gets the device types by brand Id config Node Type.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="configNodeType">config node type</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        List<DeviceTypeModel> GetDeviceTypesByBrandIdAndNodeType(int brandId, string configNodeType);

        /// <summary>
        /// Gets the products.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="deviceTypeId">The device type identifier.</param>
        /// <param name="rangeId">The range identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        List<ProductModel> GetProducts(int brandId, int deviceTypeId, int rangeId);

        /// <summary>
        /// Get Products Only
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        List<ProductModel> GetOnlyProducts(string identifier);

        /// <summary>
        /// Get Products
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>ProductModel.</returns>
        ProductModel GetProductsByIdentifier(string identifier);

        /// <summary>
        /// Gets the device types.
        /// </summary>
        /// <param name="deviceName">Name of the device.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        List<DeviceTypeModel> GetDeviceTypes(string deviceName);

        /// <summary>
        /// Gets the device types with Config Node Type.
        /// </summary>
        /// <param name="configNodeType">Type of the configuration node.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        List<DeviceTypeModel> GetDeviceTypesByNodeType(string configNodeType);

        /// <summary>
        /// Gets the products by device identifier and range identifier.
        /// </summary>
        /// <param name="id1">The id1.</param>
        /// <param name="id2">The id2.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        List<ProductModel> GetProductsByDeviceIdAndRangeId(int id1, int id2);
        /// <summary>
        /// Gets the range by device type ids.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>List&lt;RangeModel&gt;.</returns>
        List<RangeModel> GetRangeByDeviceTypeIds(int id);
    }
}