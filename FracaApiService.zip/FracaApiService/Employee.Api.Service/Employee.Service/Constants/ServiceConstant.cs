﻿
namespace Fraca.Service.Constants
{
    public class ServiceConstant
    {
        public const string FRACA_ID_FROMAT = "FRACA_ID_FROMAT";
      
        
    }
}
