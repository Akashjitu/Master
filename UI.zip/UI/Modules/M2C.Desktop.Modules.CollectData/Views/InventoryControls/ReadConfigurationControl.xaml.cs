﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReadConfigurationControl.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Views.InventoryControls
{
    /// <summary>
    /// Interaction logic for ReadConfigurationControl.xaml
    /// </summary>
    public partial class ReadConfigurationControl : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReadConfigurationControl" /> class.
        /// </summary>
        public ReadConfigurationControl()
        {
            InitializeComponent();
        }
    }
}
