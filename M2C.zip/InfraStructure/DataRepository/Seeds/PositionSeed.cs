﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="PositionSeed.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.Common;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace DataRepository.Seeds
{
    /// <summary>
    /// Class PositionSeed.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    internal class PositionSeed
    {
        /// <summary>
        /// Seeds the specified model builder.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public void Seed(ModelBuilder modelBuilder)
        {
            List<Position> positions = new List<Position>
            {
                new Position {Id = 1, Name = "Project Manager"},
                new Position {Id = 2, Name = "Project Engineer"},
                new Position {Id = 3, Name = "Commercial Manager"}
            };
            modelBuilder.Entity<Position>().HasData(positions);
        }
    }
}