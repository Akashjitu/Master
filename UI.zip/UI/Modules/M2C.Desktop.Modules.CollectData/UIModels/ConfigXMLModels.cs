﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-29-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="ConfigXMLModels.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Configuration.Parsers.Model;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Root Node of configxml "configExchangeFile"
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configExchangeFile.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configExchangeFile.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configExchangeFile : ConfigXMLBase
    {
        /// <remarks/>
        /// <summary>
        /// Gets or sets the project.
        /// </summary>
        /// <value>The project.</value>
        /// <summary>
        /// Gets or sets the project.
        /// </summary>
        /// <value>The project.</value>
        [System.Xml.Serialization.XmlElementAttribute("project", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public configProject[] project { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>The version.</value>
        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>The version.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string version { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the date time.
        /// </summary>
        /// <value>The date time.</value>
        /// <summary>
        /// Gets or sets the date time.
        /// </summary>
        /// <value>The date time.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string dateTime { get; set; }

        /// <summary>
        /// Gets the Bill of materials.
        /// </summary>
        /// <returns></returns>
        /// <summary>
        /// Gets the bom.
        /// </summary>
        /// <returns>List&lt;BaseProduct&gt;.</returns>
        /// <summary>
        /// Gets the bom.
        /// </summary>
        /// <returns>List&lt;BaseProduct&gt;.</returns>
        public List<BaseProduct> GetBOM()
        {
            List<BaseProduct> list = new List<BaseProduct>();
            if (project != null)
            {
                foreach (configProject proj in project)
                {
                    list.AddRange(proj.GetBOM());
                }
            }

            return list;
        }
    }

    /// <summary>
    /// Project-node
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configProject.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configProject.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configProject : ConfigXMLBase
    {
        /// <remarks/>
        /// <summary>
        /// Gets or sets the PLC.
        /// </summary>
        /// <value>The PLC.</value>
        /// <summary>
        /// Gets or sets the PLC.
        /// </summary>
        /// <value>The PLC.</value>
        [System.Xml.Serialization.XmlElementAttribute("plc", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public configPlc[] plc { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>The name of the file.</value>
        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>The name of the file.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string fileName { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the type of the file.
        /// </summary>
        /// <value>The type of the file.</value>
        /// <summary>
        /// Gets or sets the type of the file.
        /// </summary>
        /// <value>The type of the file.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string fileType { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the vendor.
        /// </summary>
        /// <value>The vendor.</value>
        /// <summary>
        /// Gets or sets the vendor.
        /// </summary>
        /// <value>The vendor.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string vendor { get; set; }

        /// <summary>
        /// Gets the Bill of materials.
        /// </summary>
        /// <returns></returns>
        /// <summary>
        /// Gets the bom.
        /// </summary>
        /// <returns>List&lt;BaseProduct&gt;.</returns>
        /// <summary>
        /// Gets the bom.
        /// </summary>
        /// <returns>List&lt;BaseProduct&gt;.</returns>
        public List<BaseProduct> GetBOM()
        {
            List<BaseProduct> list = new List<BaseProduct>();
            if (plc != null)
            {
                foreach (configPlc p in plc)
                {
                    list.AddRange(p.GetBOM());
                }
            }

            return list;
        }
    }

    /// <summary>
    /// PLC node
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configPlc.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configPlc.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configPlc : ConfigXMLBase
    {
        /// <remarks/>
        /// <summary>
        /// Gets or sets the bus.
        /// </summary>
        /// <value>The bus.</value>
        /// <summary>
        /// Gets or sets the bus.
        /// </summary>
        /// <value>The bus.</value>
        [System.Xml.Serialization.XmlElementAttribute("bus", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public configBus[] bus { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string type { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the display part.
        /// </summary>
        /// <value>The display part.</value>
        /// <summary>
        /// Gets or sets the display part.
        /// </summary>
        /// <value>The display part.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string displayPart { get; set; }

        /// <remarks/>
        /// <summary>
        /// Gets or sets the name of the part.
        /// </summary>
        /// <value>The name of the part.</value>
        /// <summary>
        /// Gets or sets the name of the part.
        /// </summary>
        /// <value>The name of the part.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string partName { get; set; }

        /// <summary>
        /// Gets the Bill of materials.
        /// </summary>
        /// <returns></returns>
        /// <summary>
        /// Gets the bom.
        /// </summary>
        /// <returns>List&lt;BaseProduct&gt;.</returns>
        /// <summary>
        /// Gets the bom.
        /// </summary>
        /// <returns>List&lt;BaseProduct&gt;.</returns>
        public List<BaseProduct> GetBOM()
        {
            List<BaseProduct> list = new List<BaseProduct>();
            if (bus != null)
            {
                List<BaseProduct> _innerlist = new List<BaseProduct>();
                foreach (configBus busitem in bus)
                {
                    _innerlist.AddRange(busitem.GetBOM());
                }

                var q = _innerlist.GroupBy(x => x.name);

                foreach (var x in q)
                {
                    var item = x.First();

                    if (item.TypeName != "RACK")
                    {
                        item.Count = x.Count();
                        list.Add(item);
                    }
                    else
                    {
                        list.AddRange(x.Where(xi => xi.TypeName == "RACK"));
                    }
                }
            }

            return list;
        }
    }

    /// <summary>
    /// Bus Node
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configBus.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// <summary>
    /// Class configBus.
    /// Implements the <see cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configBus : ConfigXMLBase
    {
        /// <remarks/>
        /// <summary>
        /// Gets or sets the drop.
        /// </summary>
        /// <value>The drop.</value>
        /// <summary>
        /// Gets or sets the drop.
        /// </summary>
        /// <value>The drop.</value>
        [System.Xml.Serialization.XmlElementAttribute("drop", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public configDrop[] drop { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string type { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string position { get; set; }

        /// <summary>
        /// Gets or sets the topo address.
        /// </summary>
        /// <value>The topo address.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string topoAddress { get; set; }

        /// <summary>
        /// Gets the Bill of materials.
        /// </summary>
        /// <returns>IEnumerable&lt;BaseProduct&gt;.</returns>
        public IEnumerable<BaseProduct> GetBOM()
        {
            List<BaseProduct> list = new List<BaseProduct>();
            if (drop != null)
            {
                foreach (configDrop drop in drop)
                {
                    list.AddRange(drop.GetBOM());
                }
            }

            return list;
        }
    }

    /// <summary>
    /// Drop node
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configDrop : ConfigXMLBase
    {
        /// <summary>
        /// Gets or sets the rack.
        /// </summary>
        /// <value>The rack.</value>
        [System.Xml.Serialization.XmlElementAttribute("rack", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public configRack[] rack { get; set; }

        /// <summary>
        /// Gets or sets the family.
        /// </summary>
        /// <value>The family.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string family { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string type { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string position { get; set; }

        /// <summary>
        /// Gets or sets the topo address.
        /// </summary>
        /// <value>The topo address.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string topoAddress { get; set; }

        /// <summary>
        /// Gets the Bill of materials.
        /// </summary>
        /// <returns>IEnumerable&lt;BaseProduct&gt;.</returns>
        public IEnumerable<BaseProduct> GetBOM()
        {
            List<BaseProduct> list = new List<BaseProduct>();
            if (rack != null)
            {
                foreach (configRack rack in rack)
                {
                    list.Add(new BaseProduct()
                    {
                        name = rack.partName ?? "",
                        pickListItems = PickList(rack.pickList),
                        family = rack.displayPart,
                        TypeName = "RACK",
                        Count = 1
                    });

                    list.AddRange(rack.GetBOM());
                }
            }

            return list;
        }
    }

    /// <summary>
    /// Rack node
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configRack : ConfigXMLBase
    {
        /// <summary>
        /// Gets or sets the module.
        /// </summary>
        /// <value>The module.</value>
        [System.Xml.Serialization.XmlElementAttribute("module", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public configModule[] module { get; set; }

        /// <summary>
        /// Gets or sets the display part.
        /// </summary>
        /// <value>The display part.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string displayPart { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string position { get; set; }

        /// <summary>
        /// Gets or sets the topo address.
        /// </summary>
        /// <value>The topo address.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string topoAddress { get; set; }

        /// <summary>
        /// Gets or sets the name of the part.
        /// </summary>
        /// <value>The name of the part.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string partName { get; set; }

        /// <summary>
        /// Gets the Bill of materials.
        /// </summary>
        /// <returns>IEnumerable&lt;BaseProduct&gt;.</returns>
        public IEnumerable<BaseProduct> GetBOM()
        {
            List<BaseProduct> list = new List<BaseProduct>();
            if (module != null)
            {
                foreach (configModule module in module)
                {
                    if (module?.pickList?.Length > 0)
                    {
                        var partNumber = module.pickList[0].partNumber;
                        string replacementDetail= null;
                        if (partNumber != module.partName)
                        {
                            replacementDetail = partNumber + " module is added in place of " + module.partName +
                                                " module.";
                        }
                        list.Add(new BaseProduct()
                        {
                            name = partNumber,
                            TypeName = "MODULE",
                            Count = 1,
                            ReplacementDetail = replacementDetail
                        });
                    }
                    else
                    {
                        if (module != null)
                        {
                            list.Add(new BaseProduct()
                            {
                                name = module.partName,
                                TypeName = "MODULE",
                                Count = 1
                            });
                        }
                    }
                }
            }

            return list;
        }
    }

    /// <summary>
    /// Module node
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configModule : ConfigXMLBase
    {
        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>The type.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string type { get; set; }

        /// <summary>
        /// Gets or sets the display part.
        /// </summary>
        /// <value>The display part.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string displayPart { get; set; }

        /// <summary>
        /// Gets or sets the name of the part.
        /// </summary>
        /// <value>The name of the part.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string partName { get; set; }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string position { get; set; }

        /// <summary>
        /// Gets or sets the topo address.
        /// </summary>
        /// <value>The topo address.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string topoAddress { get; set; }
    }
}