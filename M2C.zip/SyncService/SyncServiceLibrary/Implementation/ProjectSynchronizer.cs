﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-15-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectSynchronizer.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using DataRepository.DBContracts;
using RestClientServices.Contracts;
using SyncServiceLibrary.Contracts;
using SyncServiceLibrary.Model;
using System;

namespace SyncServiceLibrary.Implementation
{
    /// <summary>
    /// Class ProjectSynchronizer.
    /// Implements the <see cref="SyncServiceLibrary.Contracts.IProjectSynchronizer" />
    /// </summary>
    /// <seealso cref="SyncServiceLibrary.Contracts.IProjectSynchronizer" />
    public class ProjectSynchronizer : IProjectSynchronizer
    {
        /// <summary>
        /// The synchronize service queries
        /// </summary>
        private readonly ISyncProjectQueries syncServiceQueries;

        /// <summary>
        /// The application configuration
        /// </summary>
        private readonly IAppConfigurations appConfiguration;

        /// <summary>
        /// The rest service factory
        /// </summary>
        private readonly IRestServicesFactory restServiceFactory;

        /// <summary>
        /// The project synchronize
        /// </summary>
        private readonly IProjectSyncService ProjectSync;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectSynchronizer"/> class.
        /// </summary>
        /// <param name="syncServiceQueries">The synchronize service queries.</param>
        /// <param name="appConfiguration">The application configuration.</param>
        /// <param name="restServiceFactory">The rest service factory.</param>
        public ProjectSynchronizer(ISyncProjectQueries syncServiceQueries,
            IAppConfigurations appConfiguration,
            IRestServicesFactory restServiceFactory)
        {
            this.syncServiceQueries = syncServiceQueries;
            this.appConfiguration = appConfiguration;
            this.restServiceFactory = restServiceFactory;

            ProjectSync = this.restServiceFactory.GetRestClientService<IProjectSyncService>(RestServiceTypes.PROJECT_SYNC_SERVICE);
        }

        /// <summary>
        /// Synchronizes to server.
        /// </summary>
        /// <param name="JsonData">The json data.</param>
        /// <param name="ProjectReferenceID">The project reference identifier.</param>
        /// <param name="LocalProjectID">The local project identifier.</param>
        /// <param name="EventCallback">The event callback.</param>
        public void SyncToServer(string JsonData, string ProjectReferenceID, int LocalProjectID, Action<SyncResultModel> EventCallback)
        {
            try
            {
                //POST: if not yet ProjectReferenceID generated
                if (string.IsNullOrEmpty(ProjectReferenceID))
                {
                    ProjectReferenceID = Guid.NewGuid().ToString();
                    if (ProjectSync.PostProjectDate(JsonData, ProjectReferenceID))
                    {
                        syncServiceQueries.UpdateLastSyncBy(LocalProjectID, ProjectReferenceID);
                    }
                }
                else
                {
                    //PUT: if ProjectReferenceID is present
                    if (ProjectSync.PutProjectDate(JsonData, ProjectReferenceID))
                    {
                        syncServiceQueries.UpdateLastSyncBy(LocalProjectID, ProjectReferenceID);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}