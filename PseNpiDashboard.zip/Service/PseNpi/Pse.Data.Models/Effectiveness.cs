﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class Effectiveness
    {

        [Columns("p_KEY_CODE")]
        public string KeyCode { get; set; }

        [Columns("p_PROGRAM_NAME")]
        public string ProgramName { get; set; }

        [Columns("p_PART_INDEX")]
        public string PartIndex { get; set; }

        [Columns("p_PART_NUMBER")]
        public string PartNumber { get; set; }

        [Columns("p_PART_NUM_DESCRIPTION")]
        public string PartDescription { get; set; }

        [Columns("p_MAKE_BUY")]
        public string MakeBuy { get; set; }

        [Columns("p_PRODUCTION_SITE")]
        public string ProductionSite { get; set; }

        [Columns("p_UPDATED_PART_NUMBER")]
        public string UpdatedPartNumber { get; set; }

        [Columns("p_OTL_GRADUATION")]
        public DateTime OtlGraduation { get; set; }

        [Columns("p_NOTES")]
        public string Notes { get; set; }

        [Columns("p_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("p_UPDATED_DATE")]
        public DateTime UpdatedDate { get; set; }

        [Columns("p_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("p_IS_ACTIVE")]
        public string IsActive { get; set; }

        [Columns("p_ID")]
        public int Id { get; set; }
    }
}