﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Pse.Services.Mappers
{
    public class EscapesMapper : IEscapesMapper
    {
        public DataTable GetMapDataTable(List<Escapes> escapes)
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("part");
            dt.Columns.Add("months_since");
            var escaps = escapes.Where(i => i.OriginalShipDate.Date > i.OtlGraduation.Date).ToList();

            foreach (var esc in escaps)
            {
                if (dt.Columns.Contains(esc.OtlGraduation.Year.ToString()))
                    dt.Columns.Add(esc.OtlGraduation.Year.ToString());
            }

            for (int i = 0; i <= 20; i++)
            {
                var row = dt.NewRow();
                row["months_since"] = i;
                dt.Rows.Add(row);
            }

            foreach (var esc in escaps)
            {
                var rows = dt.Select(string.Format("months_since = '{0}'", GetMonthDifference(esc.OtlGraduation.Date, esc.OriginalShipDate)));
                if (rows == null) continue;

                var row = rows[0];
                row["part"] = esc.Part;
                int count = 0;
                var rowCountValue = row[esc.OtlGraduation.Year.ToString()] == null ? string.Empty : row[esc.OtlGraduation.Year.ToString()].ToString();

                int.TryParse(rowCountValue, out count);
                if (count == 0)
                    row[esc.OtlGraduation.Year.ToString()] = 0;
                else
                    row[esc.OtlGraduation.Year.ToString()] = (count++);
            }

            
            dt.AcceptChanges();
            return dt;

        }

        public Dictionary<int, int[]> GetMapDictionary(List<Escapes> escapes)
        {

           


            Dictionary<int, int[]> returnYearAndCount = new Dictionary<int, int[]>();

            //var esp = escapes.Where(i => i.OriginalShipDate.Date > i.OtlGraduation.Date).GroupBy(k => k.OtlGraduation.Year).ToDictionary(i => i.Key,
            //    k => k.GroupBy(l => GetMonthDifference(l.OtlGraduation.Date, l.OriginalShipDate)).ToDictionary(p => p.Key, j => j.Count()));


            //var esp = escapes.Where(i => i.OriginalShipDate.Date > i.OtlGraduation.Date).GroupBy(k => k.OtlGraduation.Year).ToDictionary(i => i.Key,
            //     k => k.GroupBy(l =>  l.OriginalShipDate.Month).ToDictionary(p => p.Key, j => j.Count()));

            //var dicPartYearEscps = escapes.GroupBy(i => i.Part).ToDictionary(p => p.Key,
            //    y => y.GroupBy(l => l.OriginalShipDate.Year).ToDictionary(s => s.Key,
            //    j => j.GroupBy(m => m.OriginalShipDate.Month).ToDictionary(mo => mo.Key, yy => yy.Count())));

            //foreach (int year in esp.Keys)
            //{
            //    var monthsAndCount = esp[year];

            //    foreach (int month in monthsAndCount.Keys)
            //    {
            //        if (!returnYearAndCount.ContainsKey(year))
            //            returnYearAndCount.Add(year, new int[20]);

            //        returnYearAndCount[year][month] = monthsAndCount[month];


            //    }
            //}


            var sslok = escapes.ToLookup(i => i.Part, k => k.OtlGraduation.Year);

            foreach (var item in sslok)
            {

            }

            var escapesPart = escapes.Select(i => new EscapesInfo
            {

                Part = i.Part,
                OtlYear = i.OtlGraduation.Year,
                MonthPositionCount = GetMonthDifference(i.OtlGraduation, i.OriginalShipDate),
                MissedCount = GetMonthDifference(i.OtlGraduation, i.OriginalShipDate) == 0 ? 0 : 1
            }).ToList();

            //var d = escapesPart.GroupBy(i => i.Part).ToDictionary(part => part.Key, k => k.GroupBy(year => year.OtlYear).ToDictionary(year=>year.Key, ));

           var parts= escapesPart.GroupBy(i => i.Part).ToDictionary(i => i.Key, k => k.ToList());

            foreach (var part in parts.Keys)
            {
                var esp1 = new EscapesInfo();
              var otlyears=  parts[part].GroupBy(i => i.OtlYear).ToDictionary(i => i.Key, k => k.ToList());
                foreach (var year in otlyears.Keys)
                {
                    var month = otlyears[year].GroupBy(i => i.MonthPositionCount).ToDictionary(i => i.Key, k => k.Count());
                }
            }


            //foreach (var part in escapesPart)
            //{
            //    escapesPart.Where(i=> part.Part== i.Part)
            //}


            //var query = lst.GroupBy(x => x)
            //  .Where(g => g.Count() > 1)
            //  .ToDictionary(x => x.Key, y => y.Count());


            return returnYearAndCount;

        }


        public static int GetMonthDifference(DateTime startDate, DateTime endDate)
        {
            int monthsApart = 12 * (startDate.Year - endDate.Year) + startDate.Month - endDate.Month;
            return Math.Abs(monthsApart);
        }
    }


  public  class EscapesInfo
    {
        public string Part { get; set; }
        public int OtlYear { get; set; }

        public int MonthPositionCount { get; set; }

        public int MissedCount { get; set; }
    }

}