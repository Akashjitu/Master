﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-29-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ConfigXMLBase.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Configuration file Base Model
    /// </summary>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("xsd", "4.8.3928.0")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public class ConfigXMLBase
    {
        /// <summary>
        /// Gets or sets the pick list.
        /// </summary>
        /// <value>The pick list.</value>
        [System.Xml.Serialization.XmlElementAttribute("pickList", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public configPickList[] pickList { get; set; }

        /// <summary>
        /// Picks the list.
        /// </summary>
        /// <param name="picklist">The picklist.</param>
        /// <returns>List&lt;System.String&gt;.</returns>
        protected List<string> PickList(configPickList[] picklist)
        {
            List<string> items = new List<string>();
            if (picklist != null)
            {
                foreach (configPickList pick in picklist)
                {
                    items.Add(pick.partName ?? pick.partNumber);
                }
            }
            return items;
        }
    }

    /// <summary>
    /// Configuration file Pick list Model
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.CollectData.UIModels.ConfigXMLBase" />
    public partial class configPickList : ConfigXMLBase
    {
        /// <summary>
        /// Gets or sets the name of the part.
        /// </summary>
        /// <value>The name of the part.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string partName { get; set; }

        /// <summary>
        /// Gets or sets the part number.
        /// </summary>
        /// <value>The part number.</value>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string partNumber { get; set; }
    }
}