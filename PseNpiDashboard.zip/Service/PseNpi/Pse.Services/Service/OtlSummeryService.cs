﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pse.Data.Models;
using Pse.Services.Manager;

namespace Pse.Services.Service
{
    public class OtlSummeryService : IOtlSummeryService
    {

        private readonly IOtlSummeryManager _manager;

       public OtlSummeryService(IOtlSummeryManager manager)
        {
            _manager = manager;
        }

        public OtlSummery AddOtlSummery(OtlSummery otlSummery)
        {
            return _manager.AddOtlSummery(otlSummery);
        }

        public List<OtlSummery> LoadAllOtlSummery()
        {
            return _manager.LoadAllOtlSummery();
        }

        public List<OtlSummery> LoadOtlSummeryByBaseLine(DateTime baseLine)
        {
            return _manager.LoadOtlSummeryByBaseLine(baseLine);
        }

        public List<OtlSummery> LoadOtlSummeryByCreatedDate(DateTime created)
        {
            return _manager.LoadOtlSummeryByCreatedDate(created);
        }

        public List<OtlSummery> LoadOtlSummeryByID(int id)
        {
            return _manager.LoadOtlSummeryByID(id);
        }

        public List<OtlSummery> LoadOtlSummeryByKeyCode(string keycode)
        {
            return _manager.LoadOtlSummeryByKeyCode(keycode);

        }

        public OtlSummery UpdateOtlSummery(OtlSummery otlSummery)
        {
            return _manager.UpdateOtlSummery(otlSummery);
        }
    }
}
