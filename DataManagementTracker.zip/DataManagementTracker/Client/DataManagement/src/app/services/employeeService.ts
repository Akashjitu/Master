import { environment } from 'src/environments/environment';
import { IAppState } from '../store/dataManagement/dataManagementReducer';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
  })
export class EmployeeService{
    headers: any;

    url = environment.apiBaseUrl;
    fileBaseUrl = environment.fileBaseUrl;
  
    constructor(private http: HttpClient, private store: Store<IAppState>, private spinner: NgxSpinnerService) {
      this.headers = new HttpHeaders({
        Accept: 'application/json',
        'zumo-api-version': '2.0.0',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': 'true',
       'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
       withCredentials: 'true',
    });
     }

     getEmployeeById(id) {
       return this.http.get<any>(this.url+'Employee/'+id, {headers : this.headers});
    }
  
    getEmployeeBySearch(value, type) {
      return this.http.get<any>(this.url+'Employee/search?value='+value+'&type='+type, {headers : this.headers});
   }
}