﻿using DataRepository.DBContracts;
using M2C.Business.Implementations;
using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace M2C.Business.Test.Implementations
{
    [TestClass]
    public class BusinessUtilitiesTest
    {
        private BusinessUtilities businessUtilities;
        private IPositionQueries positionQueries;
        private ICountryQueries countryQueries;

        [TestInitialize]
        public void Setup()
        {
            positionQueries = Substitute.For<IPositionQueries>();
            countryQueries = Substitute.For<ICountryQueries>();
            businessUtilities = new BusinessUtilities(countryQueries, positionQueries);
            positionQueries.LoadPositions().Returns(MockProvider.GetPositions());
            countryQueries.LoadCountries().Returns(MockProvider.GetCountries());
        }

        [TestMethod]
        public void ShouldReturnAllPostion()
        {
            var positions = businessUtilities.getPositions();
            Assert.IsNotNull(positions);
            Assert.IsTrue(positions.Count > 0);
        }

        [TestMethod]
        public void ShouldReturnAllCountries()
        {
            var countryModels = businessUtilities.getCountries();
            Assert.IsNotNull(countryModels);
            Assert.IsTrue(countryModels.Count > 0);
        }
    }
}