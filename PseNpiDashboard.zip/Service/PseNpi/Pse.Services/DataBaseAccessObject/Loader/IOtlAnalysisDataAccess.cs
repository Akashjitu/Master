﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IOtlAnalysisDataAccess
    {
        List<OtlAnalysis> LoadOtlAnalysis();
        List<OtlAnalysis> LoadOtlAnalysisByDate(OtlAnalysis otl);
        List<OtlAnalysis> LoadOtlAnalysisById(OtlAnalysis otl);

        List<OtlAnalysis> LoadOtlAnalysisByKeyCode(OtlAnalysis otl);


        int UpdateOtlAnalysisById(OtlAnalysis otl);

        int AddOtlAnalysisById(OtlAnalysis otl);
    }
}