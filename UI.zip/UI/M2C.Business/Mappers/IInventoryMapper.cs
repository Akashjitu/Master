﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-27-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IInventoryMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using DomainModels.ProjectModels;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using Schneider.M2C.OpenExcel.Parser.Model;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Provide Inventory Mapping
    /// </summary>
    public interface IInventoryMapper
    {
        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="productModels">Collection of ProductModel</param>
        /// <param name="years">The years.</param>
        /// <returns>Collection of Inventory</returns>
        List<Inventory> Map(List<ProductModel> productModels, Years years);

        /// <summary>
        /// Get Mapped Inventory from  ProductModel
        /// </summary>
        /// <param name="productModel">ProductModel</param>
        /// <param name="years">The years.</param>
        /// <returns>Inventory</returns>
        Inventory Map(ProductModel productModel, Years years);


        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="productModels">Collection of ProductModel</param>
        /// <param name="parentNodeTypeAndName">Dictionary with node type with Parent Node Name</param>
        /// <param name="years">The years.</param>
        /// <returns>Collection of Inventory</returns>
        List<Inventory> Map(List<ProductModel> productModels, Dictionary<NodeType, string> parentNodeTypeAndName, Years years);


        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="productModels">Collection of ProductModel</param>
        /// <param name="node">Current Node</param>
        /// <param name="years">object of 5 Year</param>
        /// <returns>Collection of Inventory</returns>
        List<Inventory> Map(List<ProductModel> productModels,INode node , Years years);

        /// <summary>
        /// Get Mapped Inventory from  ProductModels
        /// </summary>
        /// <param name="productModel">Collection of ProductModel</param>
        /// <param name="node">Current Node</param>
        /// <param name="years">object of 5 Year</param>
        /// <returns>Collection of Inventory</returns>
        Inventory Map(ProductModel productModel, INode node, Years years);
        /// <summary>
        /// Get Mapped Inventory from  ProductModel
        /// </summary>
        /// <param name="productModel">ProductModel</param>
        /// <param name="parentNodeTypeAndName">Dictionary with node type with Parent Node Name</param>
        /// <param name="years">The years.</param>
        /// <returns>Inventory</returns>
        Inventory Map(ProductModel productModel,  Dictionary<NodeType, string> parentNodeTypeAndName, Years years);

        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="iBImportModels">The i b import models.</param>
        /// <returns>Collection of Inventory</returns>
        List<Inventory> Map(List<IBImportModel> iBImportModels);

        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="iBImportModels">The i b import models.</param>
        /// <param name="nodes">The nodes.</param>
        /// <returns>Collection of Inventory</returns>
        List<Inventory> Map(List<IBImportModel> iBImportModels, List<INode> nodes);

        /// <summary>
        /// Get Mapped Inventories from  ProductModels for technical resource
        /// </summary>
        /// <param name="trImportModels">The tr import models.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        List<Inventory> Map(List<TRImportModel> trImportModels);


        /// <summary>
        /// Get Mapped Inventories from  ProductModels
        /// </summary>
        /// <param name="iBImportModels">The i b import models.</param>
        /// <param name="nodes">The nodes.</param>
        /// <returns>Collection of Inventory</returns>
        List<Inventory> Map(List<TRImportModel> iBImportModels, List<INode> nodes);

        /// <summary>
        /// Get ObservableCollection Inventory collection of ProjectInventory
        /// </summary>
        /// <param name="projectInventories">The project inventories.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        ObservableCollection<Inventory> Map(ICollection<ProjectInventory> projectInventories);


        /// <summary>
        /// Get ObservableCollection Inventory collection of ProjectInventory
        /// </summary>
        /// <param name="projectInventories">The project inventories.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        ObservableCollection<Inventory> MapWithUpdateDatabase(ICollection<ProjectInventory> projectInventories);


        /// <summary>
        /// Get  ProjectInventory from ObservableCollection Inventory
        /// </summary>
        /// <param name="projectInventories">The project inventories.</param>
        /// <returns>List&lt;ProjectInventory&gt;.</returns>
        List<ProjectInventory> Map(ObservableCollection<Inventory> projectInventories);


        /// <summary>
        /// Most use while doing paste.
        /// Based on the Target Node Map Inventories
        /// </summary>
        /// <param name="targetNode">The target node.</param>
        /// <param name="cloneNode">The clone node.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        List<Inventory> TargetNodeMap(INode targetNode, INode cloneNode);

    }
}