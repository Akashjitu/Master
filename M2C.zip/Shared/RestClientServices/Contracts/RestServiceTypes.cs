﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="RestServiceTypes.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace RestClientServices.Contracts
{
    /// <summary>
    /// Enum RestServiceTypes
    /// </summary>
    public enum RestServiceTypes
    {
        /// <summary>
        /// The product synchronize service
        /// </summary>
        PRODUCT_SYNC_SERVICE = 0,
        /// <summary>
        /// The project synchronize service
        /// </summary>
        PROJECT_SYNC_SERVICE,
        /// <summary>
        /// The authentication service
        /// </summary>
        AUTH_SERVICE
    }
}