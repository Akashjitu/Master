﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pse.Data.Models;
using Oracle.Data.Access;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class OtlGraduatesDataAccess : IOtlGraduatesDataAccess
    {

        public OtlGraduate AddOtlGraduate(OtlGraduate otlGraduate)
        {

            using (var dao = new DataAccessObject<OtlGraduate>())
            {
                var count = dao.Put(otlGraduate, "PK_OTL_GRADUATION.SP_ADD_SP_ADD_GRADUATE");
                var data = dao.Load("PK_OTL_GRADUATION.SP_LOAD_LATEST_SCORE_CARD");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public List<OtlGraduate> LoadAllOtlGraduates()
        {
            using (var dao = new DataAccessObject<OtlGraduate>())
            {
                var data = dao.Load("PK_OTL_GRADUATION.SP_LOAD_OTL_GRADUATION");
                var returndata = new List<OtlGraduate>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlGraduate> LoadGraduatesByCreationDate(DateTime creationDate)
        {
            using (var dao = new DataAccessObject<OtlGraduate>())
            {
                var data = dao.LoadByInput(new OtlGraduate { CreatedDate = creationDate }, "PK_OTL_GRADUATION.SP_LOAD_BY_MO_YY");
                var returndata = new List<OtlGraduate>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlGraduate> LoadLatestOtlGraduates()
        {
            using (var dao = new DataAccessObject<OtlGraduate>())
            {
                var data = dao.Load("PK_OTL_GRADUATION.SP_LOAD_LATEST_OTL_GRADUATION");
                var returndata = new List<OtlGraduate>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlGraduate> LoadOtlGraduatesById(int Id)
        {
            using (var dao = new DataAccessObject<OtlGraduate>())
            {
                var data = dao.LoadByInput(new OtlGraduate { Id = Id }, "PK_OTL_GRADUATION.SP_LOAD_BY_ID");
                var returndata = new List<OtlGraduate>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlGraduate> LoadOtlGraduatesByKeyCode(string keycode)
        {
            using (var dao = new DataAccessObject<OtlGraduate>())
            {
                var data = dao.LoadByInput(new OtlGraduate { KeyCode = keycode }, "PK_OTL_GRADUATION.SP_LOAD_BY_KEY_CODE");
                var returndata = new List<OtlGraduate>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public OtlGraduate UpdateOtlGraduate(OtlGraduate otlGraduate)
        {
            {
                using (var dao = new DataAccessObject<OtlGraduate>())
                {
                    var count = dao.Put(otlGraduate, "PK_OTL_GRADUATION.SP_UPDATE_OTL_GRADUATION");
                    var data = dao.LoadByInput(otlGraduate, "PK_OTL_GRADUATION.SP_LOAD_BY_ID");
                    if (data == null || data.Count == 0)
                        return null;
                    return data[0];
                }
            }
        }
    }
}
