﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ContextControlViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.Enums;
using M2C.Desktop.Modules.CollectData.Events;
using Prism.Events;
using Prism.Mvvm;
using System.Collections.ObjectModel;
using System.Linq;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// View model for ContextControl
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ContextControlViewModel : BindableBase
    {
        /// <summary>
        /// Gets the event aggregator.
        /// </summary>
        /// <value>The event aggregator.</value>
        private IEventAggregator EventAggregator { get; }

        /// <summary>
        /// Gets the business utilities.
        /// </summary>
        /// <value>The business utilities.</value>
        public IBusinessUtilities BusinessUtilities { get; }

        /// <summary>
        /// The project context
        /// </summary>
        private ProjectContextModel _projectContext;

        /// <summary>
        /// The countries
        /// </summary>
        private ObservableCollection<CountryModel> countries;

        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService _sharedContextService;

        /// <summary>
        /// The context model
        /// </summary>
        private ProjectContextModel ContextModel;

        /// <summary>
        /// Gets or sets the project create mode.
        /// </summary>
        /// <value>The project create mode.</value>
        public ProjectCreateModes ProjectCreateMode
        {
            get => _projectCreateMode;

            set
            {
                SetProperty(ref _projectCreateMode, value);
                if (_projectCreateMode != ProjectCreateModes.NONE)
                {
                    ContextControlInit();
                }
            }
        }

        /// <summary>
        /// The project create mode
        /// </summary>
        private ProjectCreateModes _projectCreateMode;

        /// <summary>
        /// Gets or sets the project context.
        /// </summary>
        /// <value>The project context.</value>
        public ProjectContextModel ProjectContext
        {
            get => _projectContext;

            set
            {
                SetProperty(ref _projectContext, value);
            }
        }

        /// <summary>
        /// Gets or sets the countries.
        /// </summary>
        /// <value>The countries.</value>
        public ObservableCollection<CountryModel> Countries
        {
            get => countries; set => countries = value;
        }

        /// <summary>
        /// Handles the PropertyChanged event of the _projectContext control.
        /// Publish the value to CreateNewProjectDialogViewModel
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.ComponentModel.PropertyChangedEventArgs" /> instance containing the event data.</param>
        private void _projectContext_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            EventAggregator.GetEvent<ContextDataChangeEvent>().Publish(ProjectContext);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ContextControlViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator from prism.</param>
        /// <param name="businessUtilities">The business utilities.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        public ContextControlViewModel(IEventAggregator eventAggregator, IBusinessUtilities businessUtilities, ISharedContextService sharedContextService)
        {
            this._sharedContextService = sharedContextService;
            EventAggregator = eventAggregator;
            BusinessUtilities = businessUtilities;

            countries = new ObservableCollection<CountryModel>(BusinessUtilities.getCountries());
        }

        /// <summary>
        /// Contexts the control initialize.
        /// </summary>
        private void ContextControlInit()
        {
            if (ProjectCreateMode == ProjectCreateModes.EDIT)
            {
                ContextModel = this._sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
                if (ContextModel != null)
                {
                    ProjectContext = ContextModel;
                    ProjectContext.Customer.Country = countries.FirstOrDefault(x => x.Id == ProjectContext.Customer.Country.Id);
                }
            }
            else
            {
                ProjectContext = new ProjectContextModel();
                ProjectContext.Customer.Country = countries?[0];
            }

            ProjectContext.PropertyChanged += _projectContext_PropertyChanged;
            ProjectContext.Customer.PropertyChanged += _projectContext_PropertyChanged;
            EventAggregator.GetEvent<ContextDataChangeEvent>().Publish(ProjectContext);
        }
    }
}