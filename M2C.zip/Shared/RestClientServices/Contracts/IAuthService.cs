﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-15-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="IAuthService.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace RestClientServices.Contracts
{
    /// <summary>
    /// Authentication service M2c
    /// </summary>
    public interface IAuthService : IRestClientService
    {
    }
}