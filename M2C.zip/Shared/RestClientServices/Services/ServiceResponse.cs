﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ServiceResponse.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Net;

namespace RestClientServices.Services
{
    /// <summary>
    /// Class ServiceResponse.
    /// </summary>
    public class ServiceResponse
    {
        /// <summary>
        /// Gets or sets the content.
        /// </summary>
        /// <value>The content.</value>
        public string Content { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is success.
        /// </summary>
        /// <value><c>true</c> if this instance is success; otherwise, <c>false</c>.</value>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// Gets or sets the response code.
        /// </summary>
        /// <value>The response code.</value>
        public HttpStatusCode ResponseCode { get; set; }
    }
}