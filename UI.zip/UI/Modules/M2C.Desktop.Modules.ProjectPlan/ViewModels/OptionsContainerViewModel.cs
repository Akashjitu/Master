﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.ProjectPlan
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="OptionsContainerViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Desktop.Modules.ProjectPlan.Constants;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace M2C.Desktop.Modules.ProjectPlan.ViewModels
{
    /// <summary>
    /// Class OptionsContainerViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    public class OptionsContainerViewModel : BindableBase, IDialogAware
    {
        /// <summary>
        /// The countries
        /// </summary>
        private ObservableCollection<CountryModel> _countries = new ObservableCollection<CountryModel>();

        /// <summary>
        /// The positions
        /// </summary>
        private ObservableCollection<PositionModel> _positions = new ObservableCollection<PositionModel>();

        /// <summary>
        /// The profile
        /// </summary>
        private ProfileModel _profile;

        /// <summary>
        /// Gets my profile logic.
        /// </summary>
        /// <value>My profile logic.</value>
        private readonly IMyProfileLogic MyProfileLogic;

        /// <summary>
        /// Gets the business utilities.
        /// </summary>
        /// <value>The business utilities.</value>
        private readonly IBusinessUtilities BusinessUtilities;

        /// <summary>
        /// Gets or sets the profile.
        /// </summary>
        /// <value>The profile.</value>
        public ProfileModel Profile { get => _profile; set => SetProperty(ref _profile, value); }

        /// <summary>
        /// Initializes a new instance of the <see cref="OptionsContainerViewModel" /> class.
        /// </summary>
        /// <param name="myProfileLogic">My profile logic.</param>
        /// <param name="businessUtilities">The business utilities.</param>
        public OptionsContainerViewModel(IMyProfileLogic myProfileLogic, IBusinessUtilities businessUtilities)
        {
            this.MyProfileLogic = myProfileLogic;
            this.BusinessUtilities = businessUtilities;

            Countries.AddRange(BusinessUtilities.getCountries());
            Positions.AddRange(BusinessUtilities.getPositions());

            Profile = MyProfileLogic.GetProfile() ?? new ProfileModel();
            Profile.Country = Countries.FirstOrDefault(x => x.Id == (Profile.Country.Id == 0 ? 1 : Profile.Country.Id));
            Profile.Position = Positions.FirstOrDefault(x => x.Id == (Profile.Position.Id == 0 ? 1 : Profile.Position.Id));

            CloseDialogCommand = new DelegateCommand<string>(OnSaveAction, CanSave)
                .ObservesProperty(() => Profile.FirstName)
                .ObservesProperty(() => Profile.LastName)
                .ObservesProperty(() => Profile.Email);

            ResetDialogCommand = new DelegateCommand(ClearAllInput);
            SelectionChangedCommand = new DelegateCommand<string>(OnSelectionChanged);
        }

        /// <summary>
        /// Gets or sets the countries.
        /// </summary>
        /// <value>The countries.</value>
        public ObservableCollection<CountryModel> Countries
        {
            get => _countries;
            set => SetProperty(ref _countries, value);
        }

        /// <summary>
        /// Gets or sets the positions.
        /// </summary>
        /// <value>The positions.</value>
        public ObservableCollection<PositionModel> Positions
        {
            get => _positions;
            set => SetProperty(ref _positions, value);
        }

        /// <summary>
        /// Gets or sets the selection changed command.
        /// </summary>
        /// <value>The selection changed command.</value>
        public DelegateCommand<string> SelectionChangedCommand { get; set; }

        /// <summary>
        /// Gets or sets the close dialog command.
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }

        /// <summary>
        /// Gets or sets the reset dialog command.
        /// </summary>
        /// <value>The reset dialog command.</value>
        public DelegateCommand ResetDialogCommand { get; set; }

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => CommonConstant.OptionsTitle;

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
        }

        /// <summary>
        /// Called when the dialog is opened.
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
        }

        /// <summary>
        /// Called when [selection changed].
        /// </summary>
        /// <param name="countryId">The country identifier.</param>
        private void OnSelectionChanged(string countryId)
        {
            Profile.Region = Profile.Country.Region;
        }

        /// <summary>
        /// Clears all input.
        /// </summary>
        private void ClearAllInput()
        {
            try
            {
                if (Profile == null)
                {
                    return;
                }

                if (MessageBox.Show(CommonConstant.ResetProfileMessage, CommonConstant.Warning, MessageBoxButton.YesNo,
                        MessageBoxImage.Warning, MessageBoxResult.No) == MessageBoxResult.Yes)
                {
                    Profile = new ProfileModel { Id = Profile.Id };
                    Profile.Country = Countries.FirstOrDefault(x => x.Id == 1);
                    Profile.Position = Positions.FirstOrDefault(x => x.Id == 1);
                }
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// Determines whether this instance can save the specified command parameter.
        /// </summary>
        /// <param name="commandParam">The command parameter.</param>
        /// <returns><c>true</c> if this instance can save the specified command parameter; otherwise, <c>false</c>.</returns>
        private bool CanSave(string commandParam)
        {
            if (commandParam.ToUpper() == "OK")
            {
                return !string.IsNullOrEmpty(Profile.FirstName?.Trim()) &&
                       !string.IsNullOrEmpty(Profile.LastName?.Trim()) &&
                       !string.IsNullOrEmpty(Profile.Email?.Trim());
            }

            return true;
        }

        /// <summary>
        /// Called when [save action].
        /// </summary>
        /// <param name="commandParam">The command parameter.</param>
        private void OnSaveAction(string commandParam)
        {
            if (commandParam.ToUpper() == "OK")
            {
                if (!MyProfileLogic.SaveProfile(Profile))
                {
                    MessageBox.Show("Save Failed!", "ERROR", MessageBoxButton.OK, MessageBoxImage.Error,
                        MessageBoxResult.OK);
                }

                RaiseRequestClose(new DialogResult(ButtonResult.OK));
            }
            else
            {
                RaiseRequestClose(new DialogResult(ButtonResult.Cancel));
            }
        }

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }
    }
}