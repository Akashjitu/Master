﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ExportChart.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DevExpress.Xpf.Charts;
using DevExpress.Xpf.RichEdit;
using DevExpress.XtraPrinting;
using DevExpress.XtraPrinting.Native;
using DevExpress.XtraRichEdit;
using DevExpress.XtraRichEdit.API.Native;
using M2C.Business.Contracts;
using Microsoft.Win32;






namespace M2C.Desktop.Modules.Charts.ChartExports
{
    /// <summary>
    /// Enum ExportType
    /// </summary>
    public enum ExportType
    {
        /// <summary>
        /// The word
        /// </summary>
        Word = 0,
        /// <summary>
        /// The excel
        /// </summary>
        Excel,
        /// <summary>
        /// The PDF
        /// </summary>
        Pdf
    }
    /// <summary>
    /// Class ExportChart.
    /// Implements the <see cref="M2C.Desktop.Modules.Charts.ChartExports.IExportChart" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Modules.Charts.ChartExports.IExportChart" />
    public class ExportChart : IExportChart
    {
        /// <summary>
        /// The chart heading
        /// </summary>
        private const string ChartHeading = "<h3 style=\"font - family:Arial Rounded MT Bold; color:#33cc33;\">{0}</h3>";
        /// <summary>
        /// The save file dialog
        /// </summary>
        private SaveFileDialog _saveFileDialog = new SaveFileDialog();
        /// <summary>
        /// My profile
        /// </summary>
        private IMyProfileLogic _myProfile;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExportChart" /> class.
        /// </summary>
        /// <param name="myProfile">My profile.</param>
        public ExportChart(IMyProfileLogic myProfile)
        {
            _myProfile = myProfile;
        }
        /// <summary>
        /// Exports the specified chart control.
        /// </summary>
        /// <param name="chartControl">The chart control.</param>
        /// <param name="headingValue">The heading value.</param>
        /// <param name="exportType">Type of the export.</param>
        public void Export(ChartControl chartControl, string headingValue, ExportType exportType)
        {
            DevExpress.XtraRichEdit.DocumentFormat documentFormat = DevExpress.XtraRichEdit.DocumentFormat.Doc;
            _saveFileDialog.Filter = "Word Documents|*.doc";
            switch (exportType)
            {
                case ExportType.Word:
                    documentFormat = DevExpress.XtraRichEdit.DocumentFormat.OpenXml;
                    _saveFileDialog.Filter = "Word Documents|*.doc; *.docx";
                    break;
                case ExportType.Excel:
                    _saveFileDialog.Filter = "Excel Files| *.xls; *.xlsx; *.xlsm";
                    break;
                case ExportType.Pdf:
                    _saveFileDialog.Filter = "Pdf Files|*.pdf";
                    break;

            }

            if (_saveFileDialog.ShowDialog() == false)
                return;
            var fileSaveLocation = _saveFileDialog.FileName;

            var profile = _myProfile.GetProfile();


            using (var documentServer = new RichEditDocumentServer())
            {
                if (documentServer.LoadDocument("Templates\\Obsolescence report - proposition.doc"))
                {
                    var doc = documentServer.Document;
                    var bookmarkCollection = doc.Bookmarks;
                    foreach (var bookmark in bookmarkCollection)//database Binding
                    {
                        var property = profile.GetType().GetProperties().FirstOrDefault(i => i.Name == bookmark.Name);
                        if (property == null)
                            continue;
                        var propertyValue = property.GetValue(profile, null);
                        var range = bookmark.Range;
                        var bmStart = range.Start;
                        documentServer.Document.Delete(range);
                        documentServer.Document.InsertText(bmStart, propertyValue.ToString());
                    }

                    if (string.IsNullOrEmpty(headingValue) && chartControl.Titles.Count > 0)
                        headingValue = chartControl.Titles[0].Content.ToString();

                    var bmChartLabel = bookmarkCollection["ChartLabel"];
                    if (bmChartLabel != null && !string.IsNullOrEmpty(headingValue))
                    {
                        var rangeChartLabel = bmChartLabel.Range;
                        var bmRangeChartLabelStart = rangeChartLabel.Start;
                        documentServer.Document.Delete(rangeChartLabel);
                        documentServer.Document.InsertHtmlText(bmRangeChartLabelStart, string.Format(ChartHeading, headingValue));
                    }


                    var bmChart = bookmarkCollection["Chart"];
                    if (bmChart != null)
                    {
                        var chartRange = bmChart.Range;
                        var bmChartStart = chartRange.Start;
                        documentServer.Document.Delete(chartRange);
                        var image = GetChartImage1(chartControl);
                        doc.Images.Insert(bmChartStart, DocumentImageSource.FromImage(image));
                    }


                    var bmDateChart = bookmarkCollection["Date"];
                    if (bmDateChart != null)
                    {
                        var chartRange = bmDateChart.Range;
                        var bmChartStart = chartRange.Start;
                        documentServer.Document.Delete(chartRange);
                        documentServer.Document.InsertText(bmChartStart, DateTime.Today.ToString("dd MMMM yyyy"));
                    }

                    var bmPhoneChart = bookmarkCollection["Phone"];
                    if (bmDateChart != null)
                    {
                        var chartRange = bmPhoneChart.Range;
                        var bmChartStart = chartRange.Start;
                        documentServer.Document.Delete(chartRange);
                        documentServer.Document.InsertText(bmChartStart, profile.Telephone);
                    }
                }


                if (File.Exists(fileSaveLocation))
                    File.Delete(fileSaveLocation);


                switch (exportType)
                {
                    case ExportType.Word:
                        documentServer.SaveDocument(fileSaveLocation, documentFormat);
                        break;
                    case ExportType.Excel:

                        break;
                    case ExportType.Pdf:
                        documentServer.ExportToPdf(fileSaveLocation);
                        break;

                }

            }




        }

        /// <summary>
        /// Gets the chart image.
        /// </summary>
        /// <param name="chart">The chart.</param>
        /// <returns>Image.</returns>
        private Image GetChartImage(ChartControl chart)
        {
            // Create an image.  
            Image image = null;

            // ImageExportOptions im= new ImageExportOptions(ImageFormat.Emf);
            // Create an image of the chart.  
            using (var s = new MemoryStream())
            {
                chart.ExportToImage(s, PrintSizeMode.ProportionalZoom);
                image = Image.FromStream(s);
            }

            // Return the image.  
            return image;
        }


        /// <summary>
        /// Gets the chart image1.
        /// </summary>
        /// <param name="chartControl">The chart control.</param>
        /// <returns>Image.</returns>
        private Image GetChartImage1(ChartControl chartControl)
        {

            var imageExportOptions = new ImageExportOptions(ImageFormat.Jpeg);
            //var Height = chartControl.Height;
            //var Width = chartControl.Width;
            //chartControl.Height = 600;
            //chartControl.Width = 600;
            // Create an image.  
            Image image = null;

            // ImageExportOptions im= new ImageExportOptions(ImageFormat.Emf);
            // Create an image of the chart.  
            using (var memoryStream = new MemoryStream())
            {
                chartControl.ExportToImage(memoryStream, imageExportOptions);

                image = Image.FromStream(memoryStream);
                image = (new Bitmap(image, new Size(700,500)));
                return image;
                memoryStream.Seek(0, SeekOrigin.Begin);

                Metafile emf = new Metafile(memoryStream);
                var outputBmp = new Bitmap(emf.Width * 10, emf.Height * 10);
                Graphics graphics = Graphics.FromImage(outputBmp);
                graphics.DrawImage(emf, 0, 0, outputBmp.Width, outputBmp.Height);

                return outputBmp;

              //  image = Image.FromStream(outputBmp);
            }

            // Return the image.  
        //    return image;


            //using (MemoryStream emfStream = new MemoryStream())
            //{
            //    ImageExportOptions im = new ImageExportOptions(ImageFormat.Emf);
            //    chartControl.ExportToImage(emfStream, emfStream);

            //    emfStream.Seek(0, SeekOrigin.Begin);

            //    Metafile emf = new Metafile(emfStream);
            //    outputBmp = new Bitmap(emf.Width * scale, emf.Height * scale);
            //    Graphics g = Graphics.FromImage(outputBmp);
            //    g.DrawImage(emf, 0, 0, outputBmp.Width, outputBmp.Height);
            //}
        }
    }
}
