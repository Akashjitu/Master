﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CriticalityParametrs.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class CriticalityModel.
    /// </summary>
    public class CriticalityModel
    {
      
        /// <summary>
        /// Gets or sets the safety issue.
        /// </summary>
        /// <value>The safety issue.</value>
        private string _safetyIssue;
        public string SafetyIssue { get { return string.IsNullOrEmpty(_safetyIssue) ? CriticalitystringValues.LOW_RISK : _safetyIssue; } set { _safetyIssue = value; } }
        /// <summary>
        /// Gets or sets the quality issue.
        /// </summary>
        /// <value>The quality issue.</value>
        private string _qualityIssue;
        public string QualityIssue { get { return string.IsNullOrEmpty(_qualityIssue) ? CriticalitystringValues.LOW_IMPACT : _qualityIssue; } set { _qualityIssue = value; } }
        /// <summary>
        /// Gets or sets the lead time issue.
        /// </summary>
        /// <value>The lead time issue.</value>
        private string _leadTimeIssue;
        public string LeadTimeIssue { get { return string.IsNullOrEmpty(_leadTimeIssue) ? CriticalitystringValues.LOW_IMPACT : _leadTimeIssue; } set { _leadTimeIssue = value; } }
        /// <summary>
        /// Gets or sets the costs issue.
        /// </summary>
        /// <value>The costs issue.</value>
        private string _costIssue;
        public string CostsIssue { get { return string.IsNullOrEmpty(_costIssue) ? CriticalitystringValues.LOW_IMPACT : _costIssue; } set { _costIssue = value; } }
        /// <summary>
        /// Gets or sets the selected value.
        /// </summary>
        /// <value>The selected value.</value>
        private string _criticality;
        public string SelectedValue { get { return string.IsNullOrEmpty(_criticality) ? CriticalitystringValues.NotCritical : _criticality; } set { _criticality = value; } }
        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get; set; }
    }
}
