﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IRangeQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IRangeQueries
    /// </summary>
    public interface IRangeQueries
    {
        /// <summary>
        /// Saves the ranges.
        /// </summary>
        /// <param name="ranges">The ranges.</param>
        void SaveRanges(List<Range> ranges);

        /// <summary>
        /// Loads the ranges.
        /// </summary>
        /// <param name="range">The range.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        List<Range> LoadRanges(Range range);

        /// <summary>
        /// Gets the range by brand.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        List<Range> GetRangeByBrand(int brandId);

        /// <summary>
        /// Loads the ranges.
        /// </summary>
        /// <returns>List&lt;Range&gt;.</returns>
        List<Range> LoadRanges();

        /// <summary>
        /// Gets the range by brand and device type ids.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="deviceTypeId">The device type identifier.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        List<Range> GetRangeByBrandAndDeviceTypeIds(int brandId, int deviceTypeId);

        /// <summary>
        /// Gets the range by device identifier.
        /// </summary>
        /// <param name="deviceId">The device identifier.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        List<Range> GetRangeByDeviceId(int deviceId);
    }
}