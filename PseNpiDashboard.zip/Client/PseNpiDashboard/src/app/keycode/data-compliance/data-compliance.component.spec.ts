import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataComplianceComponent } from './data-compliance.component';

describe('DataComplianceComponent', () => {
  let component: DataComplianceComponent;
  let fixture: ComponentFixture<DataComplianceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataComplianceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataComplianceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
