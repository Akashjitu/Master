﻿// ***********************************************************************
// Assembly         : InputParserLibary
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="COMAppFactory.cs" company="InputParserLibary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using InputParserLibary.Contracts;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Text;

namespace InputParserLibary.Implementation
{
    /// <summary>
    /// function to return Excel Application class
    /// </summary>
    public class COMAppFactory : ICOMAppFactory
    {
        /// <summary>
        /// function to return Excel Application class
        /// </summary>
        /// <returns>Application.</returns>
        public Application getExcelApp()
        {
            return new Microsoft.Office.Interop.Excel.ApplicationClass();
        }
    }
}
