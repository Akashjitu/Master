﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="GridColumnDescription.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;
using System.Windows;
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Class GridColumnDescription.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class GridColumnDescription : BindableBase
    {
        /// <summary>
        /// The visibility
        /// </summary>
        private Visibility _visibility;
        /// <summary>
        /// Gets or sets the display member.
        /// </summary>
        /// <value>The display member.</value>
        public string DisplayMember { get; set; }


        /// <summary>
        /// Gets or sets the format.
        /// </summary>
        /// <value>The format.</value>
        public string Format { get; set; }

        /// <summary>
        /// Gets or sets the header.
        /// </summary>
        /// <value>The header.</value>
        public string Header { get; set; }

        /// <summary>
        /// Gets or sets the sort member.
        /// </summary>
        /// <value>The sort member.</value>
        public string SortMember { get; set; }

        /// <summary>
        /// Gets or sets the text alignment.
        /// </summary>
        /// <value>The text alignment.</value>
        public TextAlignment TextAlignment { get; set; }

        /// <summary>
        /// Gets or sets the text colour member.
        /// </summary>
        /// <value>The text colour member.</value>
        public string TextColourMember { get; set; }

        /// <summary>
        /// Gets or sets the width.
        /// </summary>
        /// <value>The width.</value>
        public DataGridLength Width { get; set; }


        /// <summary>
        /// Gets or sets the visibility.
        /// </summary>
        /// <value>The visibility.</value>
        public Visibility Visibility
        {
            get => _visibility;
            set => SetProperty(ref _visibility, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is checked.
        /// </summary>
        /// <value><c>true</c> if this instance is checked; otherwise, <c>false</c>.</value>
        public bool IsChecked { get; set; }

        /// <summary>
        /// Gets or sets the type of the column.
        /// </summary>
        /// <value>The type of the column.</value>
        public ColumnType ColumnType { get; set; }

        /// <summary>
        /// Gets or sets the display index position.
        /// </summary>
        /// <value>The display index position.</value>
        public int DisplayIndexPosition { get; set; }


        /// <summary>
        /// Gets or sets for ContextItems.
        /// </summary>
        /// <value>The display index position.</value>
        public bool IsContextItem { get; set; }

        /// <summary>
        /// Gets or sets for Max Width of Column
        /// </summary>
        /// <value>The maximum width.</value>
        public int MaxWidth { get;  set; }

        /// <summary>
        /// Gets or sets for Min Width of Column
        /// </summary>
        /// <value>The minimum width.</value>
        public int MinWidth { get;  set; }
    }

    /// <summary>
    /// Enum ColumnType
    /// </summary>
    public enum ColumnType
    {
        /// <summary>
        /// The text block
        /// </summary>
        TextBlock,
        /// <summary>
        /// The CheckBox
        /// </summary>
        CheckBox
    }
}