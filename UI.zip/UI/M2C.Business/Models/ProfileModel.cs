﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProfileModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.Common;
using M2C.Business.ModelValidators;
using Prism.Mvvm;
using System;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class ProfileModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ProfileModel : BindableBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProfileModel" /> class.
        /// </summary>
        public ProfileModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProfileModel" /> class.
        /// </summary>
        /// <param name="profile">The profile.</param>
        public ProfileModel(Profile profile)
        {
            try
            {
                Id = profile.Id;
                Country = profile.Country != null
                    ? new CountryModel
                    {
                        Name = profile.Country.Name,
                        Id = profile.Country.Id,
                        Code = profile.Country.Code,
                        Region = profile.Country.Region
                    }
                    : new CountryModel();

                Created = profile.Created;
                Email = string.IsNullOrEmpty(profile.Email) ? string.Empty : profile.Email;
                Fax = profile.Fax;
                FirstName = string.IsNullOrEmpty(profile.FirstName) ? string.Empty : profile.FirstName;
                LastName = string.IsNullOrEmpty(profile.LastName) ? string.Empty : profile.LastName;
                MobileNumber = profile.MobileNumber;
                Position = profile.Position != null
                    ? new PositionModel
                    {
                        Id = profile.Position.Id,
                        Name = profile.Position.Name
                    }
                    : new PositionModel();

                PostalCode = profile.PostalCode;
                Region = profile.Region;
                Street = profile.Street;
                Telephone = profile.Telephone;
                Town = profile.Town;
                Updated = profile.Updated;
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// The identifier
        /// </summary>
        private int id;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get => id; set => SetProperty(ref id, value); }

        /// <summary>
        /// The first name
        /// </summary>
        private string _firstName;

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>The first name.</value>
        public string FirstName
        {
            get => _firstName;
            set => SetProperty(ref _firstName, value);
        }

        /// <summary>
        /// The last name
        /// </summary>
        private string _lastName;

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>The last name.</value>
        public string LastName
        {
            get => _lastName;
            set => SetProperty(ref _lastName, value);
        }

        /// <summary>
        /// The email
        /// </summary>
        private string _email;

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        /// <exception cref="ApplicationException">Invalid Email format</exception>
        public string Email
        {
            get => _email;
            set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidEmail(value))
                {
                    SetProperty(ref _email, null);
                    throw new ApplicationException("Invalid Email format");
                }
                SetProperty(ref _email, value);
            }
        }

        /// <summary>
        /// The street
        /// </summary>
        private string _street;

        /// <summary>
        /// Gets or sets the street.
        /// </summary>
        /// <value>The street.</value>
        public string Street
        {
            get => _street;
            set => SetProperty(ref _street, value);
        }

        /// <summary>
        /// The town
        /// </summary>
        private string _town;

        /// <summary>
        /// Gets or sets the town.
        /// </summary>
        /// <value>The town.</value>
        public string Town
        {
            get => _town;
            set => SetProperty(ref _town, value);
        }

        /// <summary>
        /// The postal code
        /// </summary>
        private string _postalCode;

        /// <summary>
        /// Gets or sets the postal code.
        /// </summary>
        /// <value>The postal code.</value>
        /// <exception cref="ApplicationException">Invalid postal code format</exception>
        public string PostalCode
        {
            get => _postalCode;
            set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsvalidZipCode(value))
                {
                    SetProperty(ref _postalCode, null);
                    throw new ApplicationException("Invalid postal code format");
                }
                SetProperty(ref _postalCode, value);
            }
        }

        /// <summary>
        /// The region
        /// </summary>
        private string _region;

        /// <summary>
        /// Gets or sets the region.
        /// </summary>
        /// <value>The region.</value>
        public string Region
        {
            get => _region;
            set => SetProperty(ref _region, value);
        }

        /// <summary>
        /// The telephone
        /// </summary>
        private string _telephone;

        /// <summary>
        /// Gets or sets the telephone.
        /// </summary>
        /// <value>The telephone.</value>
        /// <exception cref="ApplicationException">Invalid TelePhone format</exception>
        public string Telephone
        {
            get => _telephone;
            set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidPhone(value))
                {
                    SetProperty(ref _telephone, null);
                    throw new ApplicationException("Invalid TelePhone format");
                }
                SetProperty(ref _telephone, value);
            }
        }

        /// <summary>
        /// The mobile number
        /// </summary>
        private string _mobileNumber;

        /// <summary>
        /// Gets or sets the mobile number.
        /// </summary>
        /// <value>The mobile number.</value>
        /// <exception cref="ApplicationException">Invalid MobilePhone format</exception>
        public string MobileNumber
        {
            get => _mobileNumber;
            set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidPhone(value))
                {
                    SetProperty(ref _mobileNumber, null);
                    throw new ApplicationException("Invalid MobilePhone format");
                }
                SetProperty(ref _mobileNumber, value);
            }
        }

        /// <summary>
        /// The fax
        /// </summary>
        private string _fax;

        /// <summary>
        /// Gets or sets the fax.
        /// </summary>
        /// <value>The fax.</value>
        /// <exception cref="ApplicationException">Invalid fax format</exception>
        public string Fax
        {
            get => _fax;
            set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidFax(value))
                {
                    SetProperty(ref _fax, null);
                    throw new ApplicationException("Invalid fax format");
                }
                SetProperty(ref _fax, value);
            }
        }

        /// <summary>
        /// Gets or sets the created.
        /// </summary>
        /// <value>The created.</value>
        public DateTime Created { get; set; } = DateTime.Now;

        /// <summary>
        /// Gets or sets the updated.
        /// </summary>
        /// <value>The updated.</value>
        public DateTime Updated { get; set; }

        /// <summary>
        /// The country model
        /// </summary>
        private CountryModel countryModel = new CountryModel();

        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>The country.</value>
        public CountryModel Country { get => countryModel; set => SetProperty(ref countryModel, value); }

        /// <summary>
        /// The position
        /// </summary>
        private PositionModel position = new PositionModel();

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        public PositionModel Position { get => position; set => SetProperty(ref position, value); }

        /// <summary>
        /// Gets the domain model.
        /// </summary>
        /// <returns>Profile.</returns>
        public Profile GetDomainModel()
        {
            return new Profile
            {
                Id = Id,
                Country = null, //to Avoid unintended insert in table
                CountryId = this.Country?.Id ?? 0,
                Created = Created,
                Email = Email,
                Fax = Fax,
                FirstName = FirstName,
                LastName = LastName,
                MobileNumber = MobileNumber,
                Position = null,//to Avoid unintended insert in table
                PositionId = this.Position?.Id ?? 0,
                PostalCode = PostalCode,
                Region = Region,
                Street = Street,
                Telephone = Telephone,
                Town = Town,
                Updated = Updated
            };
        }
    }
}