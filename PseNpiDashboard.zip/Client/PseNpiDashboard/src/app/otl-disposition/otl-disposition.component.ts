import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { OtlDispositionColumns } from './otl-disposition-columns';
import { HttpClient } from '@angular/common/http';
import { OtlDispositionService } from '../services/otl-disposition.service';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/otlDisposition/otlDispositionReducer';
@Component({
  selector: 'app-otl-disposition',
  templateUrl: './otl-disposition.component.html',
  styleUrls: ['./otl-disposition.component.sass']
})
export class OtlDispositionComponent implements OnInit {

  modalRef: BsModalRef;
  gridApi;
  gridColumnApi;
  isExportFilter = false;
  columnDefs;

  rowData: any;
  searchText;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  theme = 'ag-theme-balham';
  pliModel = {
    sbu: '',
    ipdsPhase: '',
    pliRating: '',
    gbe: '',
    otlDisposition: ''
  }
    
  defaultColDef =  {
    resizable: true,
    sortable: true,
    enableFilter: true,
    //width: 100,
    //editable: true,
    filter: true
  };


  constructor(private http: HttpClient, private service: OtlDispositionService, public store: Store<IAppState>, private modalService: BsModalService,) { 
    service.getOtlDisposition('17-APR-2019')
  }

  ngOnInit() {
    this.columnDefs = OtlDispositionColumns.columns;
  }

  onGridReady(params) {
   
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    
    this.store.select('otlDispositione').subscribe(data => {
      this.rowData = data;
    });
    this.initColumnsList();
  }


  autoSizeAll() {

   

    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  export() {
    if (this.isExportFilter == false) {
     // this.service.reportDownloadAll();
    } else {
      //this.service.reportDownloadByFilter(this.pliModel);
    }

  }

  
  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(this.searchText);
  }
  onItemSelect(item: any) {
    console.log(item);
    this.gridColumnApi.setColumnsVisible([item], true);

  }
  onDeSelect(item: any) {
    console.log(item);
    this.gridColumnApi.setColumnsVisible([item], false);

  }
  onSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], true);
    }
  }

  onDeSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], false);
    }
  }
  initColumnsList() {
    var allColumnIds = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'colId',
      textField: 'headerName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.gridColumnApi.getAllColumns().forEach(function (column) {
      console.log("colId :- " + column.colId);
      allColumnIds.push({ colId: column.colId, headerName: column.colId });

    });
    this.selectedItems = [
      { colId: 'heatmapKc', headerName: 'heatmapKc' },
      { colId: 'programName', headerName: 'programName' }
    ];

    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      if (allColumns[index].visible === true) {
        this.selectedItems.push({ colId: allColumns[index].colId, headerName: allColumns[index].colId })
      }

    }
    this.dropdownList = allColumnIds;

  }

  showTemplate(template: TemplateRef<any>) {
    //this.shareDataService.changeMessage( this.selectedRow ); loadPliByFilter
    this.modalRef = this.modalService.show(template);
  }

  onFilterSubmit() {
    //this.service.loadPliByFilter(this.pliModel);
    this.modalRef.hide();
  }
  

  onExportChange(value) {
    this.isExportFilter = value;
  }

  clearFilters() {
    console.log("clearFilters");
    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
}

}
