﻿//using Microsoft.Practices.Unity;
//using Data.Management.Services.DataBaseAccessObject.Loader;
//using Data.Management.Services.Manager;
//using Data.Management.Services;
//using Spea.Service.DataBaseAccessObject.Saver;
//using System.Web.Mvc;
//using Unity;
//using Unity.Mvc5;

//namespace PSENPI.App_Start
//{
//    public class IOCConfig
//    {
//        public static void RegisterComponents()
//        {
//            var container = new UnityContainer();

//            container.RegisterType<ISpeService, SpeService>();
//            container.RegisterType<ISpeServiceManage, SpeServiceManage>();
//            container.RegisterType<IServiceDataLoader, ServiceDataLoader>();
//            container.RegisterType<ISeviceDataSave, SeviceDataSave>();
//            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
//        }
//    }
//}