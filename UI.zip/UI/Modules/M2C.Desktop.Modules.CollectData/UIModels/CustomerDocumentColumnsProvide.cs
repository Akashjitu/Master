﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CustomerDocumentColumnsProvide.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using M2C.Desktop.Modules.CollectData.Constants;
using Newtonsoft.Json;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Class CustomerDocumentColumnsProvide.
    /// </summary>
    public class CustomerDocumentColumnsProvide
    {  /// <summary>
       /// The grid column 
       /// </summary>
        private static readonly List<GridColumnDescription> CustomerDocumentColumns;

        /// <summary>
        /// The customer document context items
        /// </summary>
        private static readonly List<ContextItem> CustomerDocumentContextItems;

        /// <summary>
        /// Initializes static members of the <see cref="CustomerDocumentColumnsProvide" /> class.
        /// </summary>
        static CustomerDocumentColumnsProvide()
        {

            CustomerDocumentContextItems = new List<ContextItem>();
            CustomerDocumentColumns = new List<GridColumnDescription>();
        }


        /// <summary>
        /// Gets the columns.
        /// </summary>
        /// <param name="contextItems">The context items.</param>
        /// <returns>IEnumerable&lt;GridColumnDescription&gt;.</returns>
        public static IEnumerable<GridColumnDescription> GetCustomerDocumentColumns(out List<ContextItem> contextItems)
        {
            AddCustomerDocumentGridColumns();
            contextItems = CustomerDocumentContextItems;
            return CustomerDocumentColumns;
        }

        /// <summary>
        /// Adds the customer document grid columns.
        /// </summary>
        private static void AddCustomerDocumentGridColumns()
        {
            CustomerDocumentColumns.Clear();
            CustomerDocumentContextItems.Clear();
            var customerDocumentColumnsPath = ConfigurationManager.AppSettings[CollectionConstant.CustomerDocumentColumns];
            if (string.IsNullOrEmpty(customerDocumentColumnsPath))
                return;

            var customerDocumentColumns = JsonConvert.DeserializeObject<List<GridColumnDescription>>(File.ReadAllText(customerDocumentColumnsPath));
            if (customerDocumentColumns != null)
                CustomerDocumentColumns.AddRange(customerDocumentColumns);

            if (CustomerDocumentColumns.Count <= 0) return;
            var contexts = CustomerDocumentColumns.Where(i => i.IsContextItem).Select(i => new ContextItem

            {
                DisplayName = i.Header,
                IsChecked = true,
                MenuItemName = $"itmBtn{i.DisplayMember}",
                Visibility = true,
            });
            CustomerDocumentContextItems.AddRange(contexts);

        }

    }
}
