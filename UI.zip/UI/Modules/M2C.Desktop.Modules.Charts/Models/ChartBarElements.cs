﻿using M2C.Business.Models.Chart;
using Prism.Mvvm;
using System.Collections.ObjectModel;

namespace M2C.Desktop.Modules.Charts.Models
{
    public class ChartBarElements : BindableBase
    {
        private ObservableCollection<ChartBarElement> _greenChartElements;
        private ObservableCollection<ChartBarElement> _yellowChartElements;
        private ObservableCollection<ChartBarElement> _redChartElements;
        private ObservableCollection<ChartBarElement> _chartElements;
        private ObservableCollection<ChartBarElement> _plcChartElements;
        private ObservableCollection<ChartBarElement> _hmiChartElements;
        private ObservableCollection<ChartBarElement> _openChartElements;
        private ObservableCollection<ChartBarElement> _motionChartElements;
        private ObservableCollection<ChartBarElement> _criticalitiesChartElements;

        public ChartBarElements()
        {
            _greenChartElements = new ObservableCollection<ChartBarElement>();
            _yellowChartElements = new ObservableCollection<ChartBarElement>();
            _redChartElements = new ObservableCollection<ChartBarElement>();
            _chartElements = new ObservableCollection<ChartBarElement>();
            _plcChartElements = new ObservableCollection<ChartBarElement>();
            _hmiChartElements = new ObservableCollection<ChartBarElement>();
            _openChartElements = new ObservableCollection<ChartBarElement>();
            _motionChartElements = new ObservableCollection<ChartBarElement>();
            _criticalitiesChartElements= new ObservableCollection<ChartBarElement>();
        }

        #region Simple Mapping

        /// <summary>
        /// Gets or sets the chart elements.
        /// </summary>
        /// <value>The chart elements.</value>
        public ObservableCollection<ChartBarElement> ChartElements { get => _chartElements; set => SetProperty(ref _chartElements, value); }


        /// <summary>
        /// Gets or sets the Criticalities elements.
        /// </summary>
        /// <value>The chart elements.</value>
        public ObservableCollection<ChartBarElement> CriticalitiesChartElements { get => _criticalitiesChartElements; set => SetProperty(ref _criticalitiesChartElements, value); }

        #endregion Simple Mapping

        #region Obsolescence Bar Element

        /// <summary>
        /// Gets or sets the red chart elements.
        /// </summary>
        /// <value>The red chart elements.</value>
        public ObservableCollection<ChartBarElement> RedChartElements { get => _redChartElements; set => SetProperty(ref _redChartElements, value); }

        /// <summary>
        /// Gets or sets the yellow chart elements.
        /// </summary>
        /// <value>The yellow chart elements.</value>
        public ObservableCollection<ChartBarElement> YellowChartElements { get => _yellowChartElements; set => SetProperty(ref _yellowChartElements, value); }

        /// <summary>
        /// Gets or sets the green chart elements.
        /// </summary>
        /// <value>The green chart elements.</value>
        public ObservableCollection<ChartBarElement> GreenChartElements { get => _greenChartElements; set => SetProperty(ref _greenChartElements, value); }

        #endregion Obsolescence Bar Element

        #region Configuration Mapping

        /// <summary>
        /// Gets or sets the PLC chart elements.
        /// </summary>
        /// <value>The red chart elements.</value>
        public ObservableCollection<ChartBarElement> PlcChartElements { get => _plcChartElements; set => SetProperty(ref _plcChartElements, value); }

        /// <summary>
        /// Gets or sets the HMI chart elements.
        /// </summary>
        /// <value>The yellow chart elements.</value>
        public ObservableCollection<ChartBarElement> HmiChartElements { get => _hmiChartElements; set => SetProperty(ref _hmiChartElements, value); }

        /// <summary>
        /// Gets or sets the Motion chart elements.
        /// </summary>
        /// <value>The green chart elements.</value>
        public ObservableCollection<ChartBarElement> MotionChartElements { get => _motionChartElements; set => SetProperty(ref _motionChartElements, value); }

        /// <summary>
        /// Gets or sets the green Open Configuration elements.
        /// </summary>
        /// <value>The green chart elements.</value>
        public ObservableCollection<ChartBarElement> OpenChartElements { get => _openChartElements; set => SetProperty(ref _openChartElements, value); }

        #endregion Configuration Mapping
    }
}