﻿using System.Collections.Generic;
using System.Data;

namespace Schneider.M2C.OpenExcel.Parser.Tests
{
    public class ExcelTestData
    {
        public static List<ExcelSampleClass> GetSampleData()
        {
            return new List<ExcelSampleClass>()
            {
                new ExcelSampleClass(){Column1="Column1",Column2="Column2",Column3="Column3", Column4="Column4" },
                new ExcelSampleClass(){Column1="Column1",Column2="Column2",Column3="Column3", Column4="Column4" },
            };
        }

        public static DataTable GetSampleDataTable()
        {
            return new DataTable()
            {
            };
        }
    }

    public class ExcelSampleClass
    {
        public string Column1 { get; set; }

        public string Column2 { get; set; }

        public string Column3 { get; set; }

        public string Column4 { get; set; }
    }
}