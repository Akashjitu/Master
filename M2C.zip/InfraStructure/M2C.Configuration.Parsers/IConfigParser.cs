﻿// ***********************************************************************
// Assembly         : M2C.Configuration.Parsers
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IConfigParser.cs" company="M2C.Configuration.Parsers">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

namespace M2C.Configuration.Parsers
{
    /// <summary>
    /// Interface for All Configuration Read parsers
    /// </summary>
    public interface IConfigParser
    {

        /// <summary>
        /// Read Configuration file
        /// </summary>
        /// <param name="filePath">Configuration File Path</param>
        /// <returns>System.Int32.</returns>
        int ReadSourceFile(string filePath);

        /// <summary>
        /// Get Converted XML
        /// </summary>
        /// <returns>System.String.</returns>
        string getXML();
        
    }
}
