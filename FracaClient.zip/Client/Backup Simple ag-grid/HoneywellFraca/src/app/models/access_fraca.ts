export interface AccessFraca {

    isReadonlyFracaNo : boolean;
    isReadonlyPartNo : boolean;
    isReadonlyOpenDate : boolean;
    isReadonlyCloseDate : boolean;
    isReadonlyFailedDate : boolean;
    isReadonlyProduct : boolean;
    isReadonlyProgram : boolean;
    isReadonlyCustomer : boolean;
    isReadonlyTestEnv : boolean;
    isReadonlyOriginator : boolean;
    isReadonlyRespEng : boolean;
    isReadonlySystem : boolean;
    isReadonlyElectrical : boolean;
    isReadonlyEmi : boolean;
    isReadonlyClosedBy : boolean;
    isReadonlyTestDoc : boolean;
    isReadonlyParagraph : boolean;
    isReadonlyTestType : boolean;
    isReadonlyFailureCode : boolean;
    isReadonlyEndUnit : boolean;
    isReadonlyLevel1 : boolean;
    isReadonlyLevel2 : boolean;
    isReadonlyNomenclature : boolean;
    isReadonlySerial : boolean;
    isReadonlyDesignator : boolean;
    isReadonlyInflightShutdown : boolean;
    isReadonlyInflightPowerLoss : boolean;
    isReadonlyChargeability : boolean;
    isReadonlySafetyAffected : boolean;
    isReadonlyFailureToStart : boolean;
    isReadonlyProblemDescription : boolean;
    isReadonlyFinding : boolean;
    isReadonlyAnalysis : boolean;
    
}
