﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProductModelMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using M2C.Business.Models;
using Schneider.M2C.OpenExcel.Parser.Model;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Class ProductModelMapper.
    /// Implements the <see cref="M2C.Business.Mappers.IProductModelMapper" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IProductModelMapper" />
    public class ProductModelMapper : IProductModelMapper
    {
        /// <summary>
        /// Maps the specified products.
        /// </summary>
        /// <param name="products">The products.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<ProductModel> Map(List<Product> products)
        {
            if (products == null)
                return new List<ProductModel>();
            return products.Select(Map).ToList();
        }

        /// <summary>
        /// Maps the specified products.
        /// </summary>
        /// <param name="product">The product.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public ProductModel Map(Product product)
        {
            if (product == null)
                return null;
            return new ProductModel
            {
                Id = product.Id,
                Identifier = product.Identifier,
                IdentifierCategory = product.IdentifierCategory,
                Description = product.Description,
                Serviceable = product.Serviceable,
                Traceable = product.Traceable,
                ServiceBusinessValue = product.ServiceBusinessValue,
                ObsolescenceYear = (product.ObsolescenceYear == 0) ? (int?)null : product.ObsolescenceYear,
                EndProductionOrPhaseOut = (product.EndProductionOrPhaseOut == 0) ? (int?)null : product.EndProductionOrPhaseOut,
                EndCommercialization = (product.EndCommercialization == 0) ? (int?)null : product.EndCommercialization,
                EndServicesWithdrawalSupport = (product.EndServicesWithdrawalSupport == 0) ? (int?)null : product.EndServicesWithdrawalSupport,
                DefaultUnitPrice = product.DefaultUnitPrice,
                LatestProductVersion = product.LatestProductVersion,
                LatestSoftwareVersion = product.LatestSoftwareVersion,
                LatestHardwareVersion = product.LatestHardwareVersion,
                IncludeInReport = product.IncludeInReport,
                IncludeInCalc = product.IncludeInCalc,
                Configuration = product.Configuration,
                CreatedDate = product.CreatedDate,
                UpdatedDate = product.UpdatedDate,
                BrandId = product.BrandId,
                Quantity = "1",
                DeviceTypeId = product.DeviceTypeId,
                RangeId = product.RangeId,
                Version = product.Version,
                Brand = product.Brand != null ? new BrandModel()
                {
                    CreatedDate = product.Brand.CreatedDate,
                    Id = product.Brand.Id,
                    Name = product.Brand.Name,
                    UpdatedDate = product.Brand.UpdatedDate,
                } : new BrandModel(),

                DeviceType = product.Brand != null ? new DeviceTypeModel()
                {
                    Id = product.DeviceType.Id,
                    Type = product.DeviceType.Type,
                    OpsTypeDescription = product.DeviceType.OpsTypeDescription,
                    CreatedDate = product.DeviceType.CreatedDate,
                    UpdatedDate = product.DeviceType.UpdatedDate
                } : new DeviceTypeModel(),
                Range = product.Range != null ? new RangeModel()
                {
                    Id = product.Range.Id,
                    Name = product.Range.Name,
                    OpsDescription = product.Range.OpsDescription,
                    CreatedDate = product.Range.CreatedDate,
                    UpdatedDate = product.Range.UpdatedDate,
                    SubRanges = product.Range.SubRanges.Select(k => new SubRangeModel
                    {
                        Id = k.Id,
                        Name = k.Name,
                        SdhCode = k.SdhCode,
                        SdhDescription = k.SdhDescription,
                        CreatedDate = k.CreatedDate,
                        UpdatedDate = k.UpdatedDate,
                        RangeId = k.RangeId,
                    }).ToList()
                    //Products { get; set; }
                } : new RangeModel(),
                ProductEntry = product.ProductEntries != null ? product.ProductEntries.Select(k => new ProductEntryModel
                {
                    Id = k.Id,
                    Currency = k.Currency,
                    ActualProductVersion = k.ActualProductVersion,
                    ActualSoftwareVersion = k.ActualSoftwareVersion,
                    Quantity = k.Quantity,
                    SerialNumber1 = k.SerialNumber1,
                    SerialNumber2 = k.SerialNumber2,
                    Note1 = k.Note1,
                    Note2 = k.Note2,
                    Comment = k.Comment,
                    Misc1 = k.Misc1,
                    Misc2 = k.Misc2,
                    CreatedDate = k.CreatedDate,
                    UpdatedDate = k.UpdatedDate,
                    ProductId = k.ProductId,
                    // Product = Product,
                }).ToList() : new List<ProductEntryModel>()
            };
        }

        /// <summary>
        /// Maps the specified one ib catalogs.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <param name="brands">The brands.</param>
        /// <param name="deviceTypes">The device types.</param>
        /// <param name="ranges">The ranges.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> Map(List<OneIbCatalog> oneIbCatalogs, List<Brand> brands, List<DeviceType> deviceTypes, List<Range> ranges)
        {
            if (oneIbCatalogs == null)
                return null;
            var brand = brands == null
                ? new Dictionary<string, int>()
                : brands.Where(i => !string.IsNullOrEmpty(i.Name))
                    .GroupBy(i => i.Name).ToDictionary(k => k.Key, l => l.FirstOrDefault(k => k != null).Id);

            var range = ranges == null ? new Dictionary<string, int>() : ranges.Where(i => !string.IsNullOrEmpty(i.Name))
                .GroupBy(i => i.Name).ToDictionary(k => k.Key, l => l.FirstOrDefault(k => k != null).Id);

            var deviceType = deviceTypes == null ? new Dictionary<string, int>() : deviceTypes.Where(i => !string.IsNullOrEmpty(i.Type))
                .GroupBy(i => i.Type).ToDictionary(k => k.Key, l => l.FirstOrDefault(k => k != null).Id);


            return oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.BrandLegacy) &&
                                           !string.IsNullOrEmpty(i.RangeLegacy) &&
                                           !string.IsNullOrEmpty(i.DeviceTypeLegacy))
                .Select(i => new Product
                {
                    Identifier = i.ProductIdentifier,
                    IdentifierCategory = i.ProductIdentifierCategory,
                    Description = i.ProductDescription,
                    Serviceable = i.Serviceable,
                    Traceable = i.Traceable,
                    ServiceBusinessValue = i.ServiceBusinessValue,
                    ObsolescenceYear = i.ObsolescenceYear,
                    EndProductionOrPhaseOut = i.EndOfProductionOrPhaseOut,
                    EndCommercialization = i.EndOfCommercialisation,
                    EndServicesWithdrawalSupport = i.EndOfServicesYearOrWithdrawalYearOrEndOfSupport,
                    BrandId = brand.ContainsKey(i.BrandLegacy) ? brand[i.BrandLegacy] : 0,
                    RangeId = range.ContainsKey(i.RangeLegacy) ? range[i.RangeLegacy] : 0,
                    DeviceTypeId = deviceType.ContainsKey(i.DeviceTypeLegacy) ? deviceType[i.DeviceTypeLegacy] : 0,
                    FullName = string.IsNullOrEmpty(i.ProductDescription) ? i.ProductIdentifier : $"{i.ProductIdentifier} ({i.ProductDescription})"
                }).ToList();
        }
    }
}