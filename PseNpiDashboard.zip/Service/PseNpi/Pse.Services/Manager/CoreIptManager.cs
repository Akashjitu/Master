﻿using Pse.Data.Models;
using Pse.Services.DataBaseAccessObject.Loader;
using System;
using System.Collections.Generic;

namespace Pse.Services.Manager
{
    public class CoreIptManager : ICoreIptManager
    {
        private readonly ICoreIptDataAccess _dataAcces;

        public CoreIptManager(ICoreIptDataAccess dataAcces)
        {
            _dataAcces = dataAcces;
        }

        public CoreIpt AddCoreIpt(CoreIpt CoreIpt)
        {
            return _dataAcces.AddCoreIpt(CoreIpt);
        }

        public List<CoreIpt> LoadAllCoreIpt()
        {
            return _dataAcces.LoadAllCoreIpt();
        }

        public List<CoreIpt> LoadCoreIptByCreationDate(DateTime creationDate)
        {
            return _dataAcces.LoadCoreIptByCreationDate(creationDate);
        }

        public List<CoreIpt> LoadCoreIptById(int Id)
        {
            return _dataAcces.LoadCoreIptById(Id);
        }

        public List<CoreIpt> LoadCoreIptByKeyCode(string keycode)
        {
            return _dataAcces.LoadCoreIptByKeyCode(keycode);
        }

        public CoreIpt UpdateCoreIpt(CoreIpt CoreIpt)
        {
            return _dataAcces.UpdateCoreIpt(CoreIpt);
        }

        public List<CoreIpt> LoadLatestCoreIpt()
        {
            return _dataAcces.LoadLatestCoreIpt();
        }
    }
}