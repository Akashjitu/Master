﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ICountryQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.Common;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface ICountryQueries
    /// </summary>
    public interface ICountryQueries
    {
        /// <summary>
        /// Loads the countries.
        /// </summary>
        /// <returns>List&lt;Country&gt;.</returns>
        List<Country> LoadCountries();
    }
}