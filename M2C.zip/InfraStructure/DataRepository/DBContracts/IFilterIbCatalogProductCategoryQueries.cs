﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IFilterIbCatalogProductCategoryQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogFilter;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IFilterIbCatalogProductCategoryQueries
    /// </summary>
    public interface IFilterIbCatalogProductCategoryQueries
    {
        /// <summary>
        /// Filters the ib catalog product categories.
        /// </summary>
        /// <param name="filterIbCatalogProductCategory">The filter ib catalog product category.</param>
        /// <returns>List&lt;FilterIbCatalogProductCategory&gt;.</returns>
        List<FilterIbCatalogProductCategory> FilterIbCatalogProductCategories(FilterIbCatalogProductCategory filterIbCatalogProductCategory);

        /// <summary>
        /// Filters the ib catalog product categories.
        /// </summary>
        /// <returns>List&lt;FilterIbCatalogProductCategory&gt;.</returns>
        List<FilterIbCatalogProductCategory> FilterIbCatalogProductCategories();
    }
}