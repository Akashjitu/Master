﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA529201
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="SideBarTreeViewModel.ContextMenu.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core.GlobalEvents;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using M2C.Business.GlobalFields;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class SideBarTreeViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="System.IDisposable" />
    public partial class SideBarTreeViewModel
    {
        /// <summary>
        /// The clipboard node
        /// </summary>
        private Node _clipboardNode;
        /// <summary>
        /// The selected node type changed
        /// </summary>
        private NodeType _selectedNodeTypeChanged;
        /// <summary>
        /// The is action cut
        /// </summary>
        private bool _isActionCut;
        /// <summary>
        /// The inventory mapper
        /// </summary>
        private IInventoryMapper _inventoryMapper;

        #region PROPERTISE

        /// <summary>
        /// Gets or sets the clip board node.
        /// </summary>
        /// <value>The clip board node.</value>
        private Node ClipBoardNode { get => _clipboardNode; set => SetProperty(ref _clipboardNode, value); }

        /// <summary>
        /// Gets or sets the selected node type changed.
        /// </summary>
        /// <value>The selected node type changed.</value>
        private NodeType SelectedNodeTypeChanged { get => _selectedNodeTypeChanged; set => SetProperty(ref _selectedNodeTypeChanged, value); }

        /// <summary>
        /// Gets or sets the clip board node reference.
        /// </summary>
        /// <value>The clip board node reference.</value>
        private Node ClipBoardNodeRef { get; set; }

        #endregion PROPERTISE

        #region COMMANDS

        /// <summary>
        /// Gets or sets the node rename command.
        /// </summary>
        /// <value>The node rename command.</value>
        public DelegateCommand NodeRenameCommand { get; set; }

        /// <summary>
        /// Gets or sets the node cut command.
        /// </summary>
        /// <value>The node cut command.</value>
        public DelegateCommand NodeCutCommand { get; set; }

        /// <summary>
        /// Gets or sets the node copy command.
        /// </summary>
        /// <value>The node copy command.</value>
        public DelegateCommand NodeCopyCommand { get; set; }

        /// <summary>
        /// Gets or sets the node paste command.
        /// </summary>
        /// <value>The node paste command.</value>
        public DelegateCommand NodePasteCommand { get; set; }

        /// <summary>
        /// Gets or sets the node delete command.
        /// </summary>
        /// <value>The node delete command.</value>
        public DelegateCommand NodeDeleteCommand { get; set; }

        #endregion COMMANDS

        /// <summary>
        /// Sides the bar TreeView model ext initialize.
        /// </summary>
        private void SideBarTreeViewModel_ContextMenu_init()
        {
            NodeRenameCommand = new DelegateCommand(OnNodeRename);

            NodeCutCommand = new DelegateCommand(OnNodeCutCommand, CanCutCommand).ObservesProperty(() => SelectedNodeTypeChanged);

            NodeCopyCommand = new DelegateCommand(OnNodeCopyCommand, CanCopyCommand).ObservesProperty(() => SelectedNodeTypeChanged);

            NodePasteCommand = new DelegateCommand(OnPasteCommand, CanPasteCommand)
                .ObservesProperty(() => SelectedNodeTypeChanged).ObservesProperty(() => ClipBoardNodeRef);

            NodeDeleteCommand = new DelegateCommand(OnDeleteCommand, CanDeleteCommand)
                .ObservesProperty(() => SelectedNodeTypeChanged);

            eventAggregator.GetEvent<IBTreeViewChangeEvent>().Subscribe(OnSelectedNodeChange);

            ClipBoardNodeRef = null;
        }

        #region PRIVATE FUNCTIONS

        /// <summary>
        /// Ons the node rename.
        /// </summary>
        private void OnNodeRename()
        {
            if (SelectedNode == null) return;
            if (SelectedNode is Node node) node.IsEditable = !node.IsEditable;
        }

        /// <summary>
        /// Determines whether this instance [can cut d command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can cut d command]; otherwise, <c>false</c>.</returns>
        private bool CanCutCommand()
        {
            return SelectedNode != null && SelectedNode is IDelete;
        }

        /// <summary>
        /// Ons the node cut command.
        /// </summary>
        private void OnNodeCutCommand()
        {
            ClipBoardNodeRef = SelectedNode;
            ClipBoardNode = (SelectedNode as ICloneable)?.Clone() as Node;
            _isActionCut = true;
        }

        /// <summary>
        /// Determines whether this instance [can copy command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can copy command]; otherwise, <c>false</c>.</returns>
        private bool CanCopyCommand()
        {
            if (SelectedNode != null && SelectedNode is ICloneable)
            {
                return true;
            }
            {
                return false;
            }
        }

        /// <summary>
        /// Ons the node copy command.
        /// </summary>
        private void OnNodeCopyCommand()
        {
            ClipBoardNodeRef = SelectedNode;
            ClipBoardNode = (SelectedNode as ICloneable)?.Clone() as Node;
            if (ClipBoardNode != null)
                ClipBoardNode.Name = $"Copy of {ClipBoardNode.Name}";
            _isActionCut = false;
        }

        /// <summary>
        /// Determines whether this instance [can paste command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can paste command]; otherwise, <c>false</c>.</returns>
        private bool CanPasteCommand()
        {
            if (ClipBoardNode == null || SelectedNode == null) return false;
            var node = ClipBoardNode;
            switch (node.NodeType)
            {
                case NodeType.PLC_CONFIG:
                case NodeType.MD_CONFIG:
                case NodeType.OPEN_CONFIG:
                case NodeType.SHMI_CONFIG:
                    return SelectedNodeTypeChanged == NodeType.MACHINE;

                case NodeType.MACHINE:
                    return (SelectedNodeTypeChanged == NodeType.WORKSHOP || SelectedNodeTypeChanged == NodeType.LINE);

                case NodeType.LINE:
                    return (SelectedNodeTypeChanged == NodeType.WORKSHOP);

                case NodeType.WORKSHOP:
                    return (SelectedNodeTypeChanged == NodeType.FACTORY);
            }
            {
                return false;
            }
        }

        /// <summary>
        /// Ons the paste command.
        /// </summary>
        private void OnPasteCommand()
        {
            var configNodes = new List<INode>();
            switch (ClipBoardNode.NodeType)
            {
                case NodeType.PLC_CONFIG:
                case NodeType.MD_CONFIG:
                case NodeType.OPEN_CONFIG:
                case NodeType.SHMI_CONFIG:
                    {
                        if (_selectedNode is MachineNode machineNode)
                        {
                            if (ClipBoardNode is ConfigNode configNod)
                            {
                                configNod.Id = GlobalFiled.GenerateRandomId();
                                configNod.ParentNode = machineNode;
                                machineNode.ConfigNodes.Add(configNod);
                                configNodes = new List<INode>() { configNod };
                            }
                        }
                    }
                    break;

                case NodeType.MACHINE:
                    {
                        if (ClipBoardNode is MachineNode machine)
                        {
                            machine.Id = GlobalFiled.GenerateRandomId();
                            machine.ParentNode = _selectedNode as INode;
                            switch (_selectedNode)
                            {
                                case WorkShopNode workShopNode:
                                    workShopNode.MachineNodes.Add(machine);
                                    break;
                                case LineNode lineNode:
                                    lineNode.MachineNodes.Add(ClipBoardNode as MachineNode);
                                    break;
                            }

                            configNodes = machine.ConfigNodes.Cast<INode>().ToList();
                        }
                    }
                    break;

                case NodeType.LINE:
                    {
                        if (_selectedNode is WorkShopNode workShopNode)
                        {
                            if (ClipBoardNode is LineNode lineNode)
                            {
                                lineNode.Id = GlobalFiled.GenerateRandomId();
                                lineNode.ParentNode = _selectedNode as INode;

                                workShopNode.LineNodes.Add(lineNode);
                                configNodes = lineNode.MachineNodes.SelectMany(i => i.ConfigNodes.Cast<INode>()).ToList();
                            }
                        }
                    }
                    break;

                case NodeType.WORKSHOP:
                    {
                        if (_selectedNode is FactoryNode factoryNode)
                        {
                            if (ClipBoardNode is WorkShopNode workShopNode)
                            {
                                workShopNode.Id = GlobalFiled.GenerateRandomId();
                                workShopNode.ParentNode = _selectedNode as INode;
                                factoryNode.WorkShopNodes.Add(workShopNode);
                                var machineConfig = workShopNode.MachineNodes.SelectMany(i => i.ConfigNodes.Cast<INode>())
                                      .ToList();
                                var lineConfigNode = workShopNode.LineNodes.SelectMany(i => i.MachineNodes.SelectMany(k => k.ConfigNodes.Cast<INode>())).ToList()
                                    .ToList();

                                configNodes.AddRange(machineConfig);
                                configNodes.AddRange(lineConfigNode);
                            }
                        }
                    }
                    break;
            }

            SetCopiedInventories(configNodes);

            if (_isActionCut)
            {
                if ((_selectedNode as Node)?.Id == ClipBoardNodeRef.ParentNode.Id)
                {
                    ClipBoardNodeRef.Name = $"Copy of {ClipBoardNodeRef.Name}";
                }
                else
                {
                    RemoveNode(ClipBoardNodeRef);
                }

                _isActionCut = false;
            }

            ClipBoardNode = (ClipBoardNode as ICloneable)?.Clone() as Node;
            if (ClipBoardNode != null && !ClipBoardNode.Name.Contains("Copy of"))
            {
                ClipBoardNode.Name = $"Copy of {ClipBoardNode.Name}";
            }
        }

        /// <summary>
        /// Sets the copied inventories.
        /// </summary>
        /// <param name="configNode">The configuration node.</param>
        private void SetCopiedInventories(List<INode> configNode)
        {
            if (!(_selectedNode is INode node)) return;
            foreach (var confNode in configNode)
            {
                node.MasterInventories.AddRange(_inventoryMapper.TargetNodeMap(confNode, confNode));

                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.MAINTENANCEZONE))
                    confNode.ParentNodeAndNodeType[NodeType.MAINTENANCEZONE].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.STOCK))
                    confNode.ParentNodeAndNodeType[NodeType.STOCK].MasterInventories = node.MasterInventories;

                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.FACTORY))
                    confNode.ParentNodeAndNodeType[NodeType.FACTORY].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.MACHINE))
                    confNode.ParentNodeAndNodeType[NodeType.MACHINE].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.WORKSHOP))
                    confNode.ParentNodeAndNodeType[NodeType.WORKSHOP].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.OPEN_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.OPEN_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.MD_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.MD_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.SHMI_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.SHMI_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.PLC_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.PLC_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.LINE))
                    confNode.ParentNodeAndNodeType[NodeType.LINE].MasterInventories = node.MasterInventories;
            }
            CollectionViewSource.GetDefaultView(node.MasterInventories).Refresh();
        }

        /// <summary>
        /// Ons the selected node change.
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnSelectedNodeChange(INode node)
        {
            if (node != null)
            {
                SelectedNodeTypeChanged = node.NodeType;
            }
        }

        /// <summary>
        /// Determines whether this instance [can delete command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can delete command]; otherwise, <c>false</c>.</returns>
        private bool CanDeleteCommand()
        {
            return (SelectedNode != null && SelectedNode is IDelete);
        }

        /// <summary>
        /// Ons the delete command.
        /// </summary>
        private void OnDeleteCommand()
        {
            if (MessageBox.Show($"Do you want to delete the {(SelectedNode as Node)?.Name} ?", "M2C Renewal", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                RemoveNode(SelectedNode);
        }

        /// <summary>
        /// Removes the node.
        /// </summary>
        /// <param name="node">The node.</param>
        private void RemoveNode(INode node)
        {
            var inventories = new List<Inventory>();
            switch (node.NodeType)
            {
                case NodeType.FACTORY:
                    inventories = node.MasterInventories.Where(i => i.FactoryId == node.Id).ToList();
                    break;

                case NodeType.WORKSHOP:
                    inventories = node.MasterInventories.Where(i =>
                        i.FactoryId == node.ParentNode.Id && //Factory
                        i.WorkshopId == node.Id).ToList();
                    break;

                case NodeType.LINE:
                    inventories = node.MasterInventories.Where(i =>
                        i.FactoryId == node.ParentNode.ParentNode.Id && //Factory
                        i.WorkshopId == node.ParentNode.Id && //Workshop
                        i.LineId == node.Id).ToList();
                    break;

                case NodeType.MACHINE:
                    if (node.ParentNode is LineNode)
                        inventories = node.MasterInventories.Where(i =>
                            i.FactoryId == node.ParentNode.ParentNode.ParentNode.Id && //Factory
                            i.WorkshopId == node.ParentNode.ParentNode.Id && //Workshop
                            i.LineId == node.ParentNode.Id && //Line
                            i.MachineId == node.Id).ToList();//machine
                    else
                        inventories = node.MasterInventories.Where(i =>
                            i.FactoryId == node.ParentNode.ParentNode.Id && //Factory
                            i.WorkshopId == node.ParentNode.Id && //Workshop
                            i.MachineId == node.Id).ToList();
                    break;

                case NodeType.PLC_CONFIG:
                case NodeType.MD_CONFIG:
                case NodeType.SHMI_CONFIG:
                case NodeType.OPEN_CONFIG:
                    if (node.ParentNode.ParentNode is WorkShopNode)
                        inventories = node.MasterInventories.Where(i =>
                            i.FactoryId == node.ParentNode.ParentNode.ParentNode.Id && //Factory
                            i.WorkshopId == node.ParentNode.ParentNode.Id && //Workshop
                            i.MachineId == node.ParentNode.Id &&//machine
                            i.ConfigurationId == node.Id).ToList();
                    else
                        inventories = node.MasterInventories.Where(i =>
                            i.FactoryId == node.ParentNode.ParentNode.ParentNode.ParentNode.Id && //Factory
                            i.WorkshopId == node.ParentNode.ParentNode.ParentNode.Id && //Workshop
                            i.LineId == node.ParentNode.ParentNode.Id && //Line
                            i.MachineId == node.ParentNode.Id && //machine
                            i.ConfigurationId == node.Id).ToList();
                    break;
            }

            foreach (var inventory in inventories)
                node.MasterInventories.Remove(inventory);

            CollectionViewSource.GetDefaultView(node.MasterInventories).Refresh();
            (node as IDelete)?.Delete();
        }

        #endregion PRIVATE FUNCTIONS
    }
}