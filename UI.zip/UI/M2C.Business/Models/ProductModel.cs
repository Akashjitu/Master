﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProductModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;
using System;
using System.Collections.Generic;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class ProductModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ProductModel : BindableBase
    {
        /// <summary>
        /// The description
        /// </summary>
        private string _description;
        /// <summary>
        /// The brand identifier
        /// </summary>
        private int _brandId;
        /// <summary>
        /// The device type identifier
        /// </summary>
        private int _deviceTypeId;
        /// <summary>
        /// The range identifier
        /// </summary>
        private int _rangeId;
        /// <summary>
        /// The identifier
        /// </summary>
        private string _identifier;
        /// <summary>
        /// The identifier
        /// </summary>
        private int _id;
        /// <summary>
        /// The brand
        /// </summary>
        private BrandModel _brand;
        /// <summary>
        /// The device type
        /// </summary>
        private DeviceTypeModel _deviceType;
        /// <summary>
        /// The range
        /// </summary>
        private RangeModel _range;
        /// <summary>
        /// The latest product version
        /// </summary>
        private double _latestProductVersion;
        /// <summary>
        /// The latest software version
        /// </summary>
        private double _latestSoftwareVersion;
        /// <summary>
        /// The comments
        /// </summary>
        private string _comments;
        /// <summary>
        /// The quantity
        /// </summary>
        private string _quantity;
        /// <summary>
        /// The sv number
        /// </summary>
        private string _svNumber;
        /// <summary>
        /// The pv number
        /// </summary>
        private string _pvNumber;

        /// <summary>
        /// The criticality
        /// </summary>
        private string _criticality;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get => _id; set => SetProperty(ref _id, value); }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public string Identifier { get => _identifier; set => SetProperty(ref _identifier, value); }

        /// <summary>
        /// Gets or sets the identifier category.
        /// </summary>
        /// <value>The identifier category.</value>
        public string IdentifierCategory { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        public string Description { get => _description; set => SetProperty(ref _description, value); }

        /// <summary>
        /// Gets or sets the serviceable.
        /// </summary>
        /// <value>The serviceable.</value>
        public string Serviceable { get; set; }

        /// <summary>
        /// Gets or sets the traceable.
        /// </summary>
        /// <value>The traceable.</value>
        public string Traceable { get; set; }

        /// <summary>
        /// Gets or sets the service business value.
        /// </summary>
        /// <value>The service business value.</value>
        public string ServiceBusinessValue { get; set; }

        /// <summary>
        /// Gets or sets the end ObsolescenceYear.
        /// </summary>
        /// <value>The end ObsolescenceYear.</value>
        public int? ObsolescenceYear { get; set; }
        /// <summary>
        /// Gets or sets the end production or phase out.
        /// </summary>
        /// <value>The end production or phase out.</value>
        public int? EndProductionOrPhaseOut { get; set; }
        /// <summary>
        /// Gets or sets the end commercialization.
        /// </summary>
        /// <value>The end commercialization.</value>
        public int? EndCommercialization { get; set; }
        /// <summary>
        /// Gets or sets the end services withdrawal support.
        /// </summary>
        /// <value>The end services withdrawal support.</value>
        public int? EndServicesWithdrawalSupport { get; set; }
        /// <summary>
        /// Gets or sets the default unit price.
        /// </summary>
        /// <value>The default unit price.</value>
        public double DefaultUnitPrice { get; set; }
        /// <summary>
        /// Gets or sets the latest product version.
        /// </summary>
        /// <value>The latest product version.</value>
        public double LatestProductVersion { get => _latestProductVersion; set => SetProperty(ref _latestProductVersion, value); }
        /// <summary>
        /// Gets or sets the latest software version.
        /// </summary>
        /// <value>The latest software version.</value>
        public double LatestSoftwareVersion { get => _latestSoftwareVersion; set => SetProperty(ref _latestSoftwareVersion, value); }
        /// <summary>
        /// Gets or sets the latest hardware version.
        /// </summary>
        /// <value>The latest hardware version.</value>
        public double LatestHardwareVersion { get; set; }
        /// <summary>
        /// Gets or sets the include in report.
        /// </summary>
        /// <value>The include in report.</value>
        public string IncludeInReport { get; set; }
        /// <summary>
        /// Gets or sets the include in calculate.
        /// </summary>
        /// <value>The include in calculate.</value>
        public string IncludeInCalc { get; set; }
        /// <summary>
        /// Gets or sets the configuration.
        /// </summary>
        /// <value>The configuration.</value>
        public string Configuration { get; set; }
        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>The created date.</value>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the updated date.
        /// </summary>
        /// <value>The updated date.</value>
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Gets or sets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int BrandId { get => _brandId; set => SetProperty(ref _brandId, value); }
        /// <summary>
        /// Gets or sets the device type identifier.
        /// </summary>
        /// <value>The device type identifier.</value>
        public int DeviceTypeId { get => _deviceTypeId; set => SetProperty(ref _deviceTypeId, value); }
        /// <summary>
        /// Gets or sets the range identifier.
        /// </summary>
        /// <value>The range identifier.</value>
        public int RangeId { get => _rangeId; set => SetProperty(ref _rangeId, value); }
        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public virtual BrandModel Brand { get => _brand; set => SetProperty(ref _brand, value); }
        /// <summary>
        /// Gets or sets the type of the device.
        /// </summary>
        /// <value>The type of the device.</value>
        public virtual DeviceTypeModel DeviceType { get => _deviceType; set => SetProperty(ref _deviceType, value); }
        /// <summary>
        /// Gets or sets the range.
        /// </summary>
        /// <value>The range.</value>
        public virtual RangeModel Range { get => _range; set => SetProperty(ref _range, value); }
        /// <summary>
        /// Gets or sets the product entry.
        /// </summary>
        /// <value>The product entry.</value>
        public virtual List<ProductEntryModel> ProductEntry { get; set; } = new List<ProductEntryModel>();
        /// <summary>
        /// Gets the full name.
        /// </summary>
        /// <value>The full name.</value>
        public string FullName => string.IsNullOrEmpty(Description) ? Identifier : $"{Identifier} ({Description})";

        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get => _comments; set => SetProperty(ref _comments, value); }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        public string Quantity
        {
            get => _quantity;
            set => SetProperty(ref _quantity, value);
        }

        /// <summary>
        /// Gets or sets the sv number.
        /// </summary>
        /// <value>The sv number.</value>
        public string SvNumber
        {
            get => _svNumber;
            set => SetProperty(ref _svNumber, value);
        }

        /// <summary>
        /// Gets or sets the pv number.
        /// </summary>
        /// <value>The pv number.</value>
        public string PvNumber
        {
            get => _pvNumber;
            set => SetProperty(ref _pvNumber, value);
        }

        /// <summary>
        /// Gets or sets the criticality.
        /// </summary>
        /// <value>The criticality.</value>
        public string Criticality
        {
            get => _criticality;
            set => SetProperty(ref _criticality, value);
        }

        /// <summary>
        /// Gets or sets the type of the configuration.
        /// </summary>
        /// <value>The type of the configuration.</value>
        public string ConfigType { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public int Version { get; set; }
    }
}