﻿using OfficeOpenXml.Drawing.Chart;
using System.Collections.Generic;
using System.Data;

namespace Pse.Services.Exports
{
    public interface ISimpleExport
    {
        byte[] Export<T>(List<T> entites, string sheetName, int pinedRightColumn);

        byte[] ExportChart(DataTable exportTable, string sheetName, string chartTitle, string xAxisTitle, string yAxisTitle, string xSeriePositionColumn, eChartType chartType);
    }
}
