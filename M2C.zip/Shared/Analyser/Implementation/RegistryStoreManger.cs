﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="RegistryStoreManger.cs" company="WinRegistryServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Microsoft.Win32;
using WinRegistryServices.Contracts;

namespace WinRegistryServices.Implementation
{
    /// <summary>
    /// Windows register read/write
    /// </summary>
    /// <seealso cref="M2C.Desktop.Core.Contracts.IRegistryStoreManger" />
    public class RegistryStoreManger : IRegistryStoreManger
    {
        /// <summary>
        /// The reg key
        /// </summary>
        private const string regKey = @"Software\Schneider Electric\M2C Renewal Application";

        /// <summary>
        /// Gets the value.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns>System.String.</returns>
        public string GetValue(string key)
        {
            //opening the subkey
            RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(regKey);
            //if it does exist, retrieve the stored values
            if (registryKey != null)
            {
                string val = registryKey.GetValue(key) as string;
                registryKey.Close();

                return val;
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Sets the value.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="value">The value.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool SetValue(string key, string value)
        {
            RegistryKey registryKey = Registry.CurrentUser.CreateSubKey(regKey);

            if (registryKey != null)
            {
                registryKey.SetValue(key, value);
                registryKey.Close();
            }
            return true;
        }

        /// <summary>
        /// Deletes the key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool DeleteKey(string key)
        {
            //opening the subkey
            RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(regKey, true);
            //if it does exist, retrieve the stored values
            if (registryKey != null && registryKey.GetValue(key) != null)
            {
                registryKey.DeleteValue(key);
                registryKey.Close();
            }
            return true;
        }
    }
}