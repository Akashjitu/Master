﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.ExcelExports
{
    public interface IEffectivenessExports
    {
        byte[] Export(List<Effectiveness> effectiveness);
    }
}