import { Action } from '@ngrx/store';
import { OtlScoreCard } from 'src/app/model/otlScoreCard';
export const ADD_OTL_SCORE_CARD = 'ADD_OTL_SCORE_CARD';
export const LOAD_OTL_SCORE_CARD  = 'LOAD_OTL_SCORE_CARD';
export const REMOVE_OTL_SCORE_CARD  = 'REMOVE_OTL_SCORE_CARD';
export const UPDATE_OTL_SCORE_CARD : string = 'UPDATE_OTL_SCORE_CARD';



export class LoadOtlScoreCard implements Action {
    readonly type = LOAD_OTL_SCORE_CARD;

    constructor(public payload: any) {
    }
}

export class AddOtlScoreCard implements Action {
    readonly type = ADD_OTL_SCORE_CARD;

    constructor(public payload: OtlScoreCard) { }
}

export class UpdateOtlScoreCard implements Action {
    readonly type = UPDATE_OTL_SCORE_CARD;

    constructor(public payload: OtlScoreCard) { }
}

export class RemoveOtlScoreCard implements Action {
    readonly type = REMOVE_OTL_SCORE_CARD;

    constructor(public payload: number) { }
}


export type Actions = AddOtlScoreCard | RemoveOtlScoreCard | LoadOtlScoreCard;
