﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="ReportExportToolsViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using DevExpress.Xpf.Charts;
using M2C.Business.Implementations;
using M2C.Business.Models;
using M2C.Business.Models.Chart;
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.Charts.ReportData.ChartExports;
using M2C.Desktop.Modules.Charts.ReportData.Views;
using Microsoft.Win32;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using DevExpress.XtraPrinting.Native;
using M2C.Desktop.Core.GlobalComands;
using System.Windows.Input;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;

namespace M2C.Desktop.Modules.Charts.ReportData.ViewModels
{
    /// <summary>
    /// Class ReportExportToolsViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ReportExportToolsViewModel : BindableBase
    {
        /// <summary>
        /// The ib inventory nodes
        /// </summary>
        private readonly List<InventoryNode> _ibInventoryNodes;
        /// <summary>
        /// The tr inventory nodes
        /// </summary>
        private readonly List<InventoryNode> _trInventoryNodes;

        /// <summary>
        /// The color provider
        /// </summary>
        private readonly IStatusColorProvider _colorProvider;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// The selected installed based node
        /// </summary>
        private INode _selectedInstalledBasedNode;

        /// <summary>
        /// The selected tr node
        /// </summary>
        private INode _selectedTrNode;

        /// <summary>
        /// The report export chart
        /// </summary>
        private readonly IReportExportChart _reportExportChart;

        /// <summary>
        /// The report data chart
        /// </summary>
        private readonly ReportDataChart _reportDataChart;

        /// <summary>
        /// The save file dialog
        /// </summary>
        private readonly SaveFileDialog _saveFileDialog = new SaveFileDialog();

        /// <summary>
        /// The ib mapping inventory node
        /// </summary>
        private ObservableCollection<InventoryNode> _ibMappingInventoryNode;

        /// <summary>
        /// The ib obsolescence mapping inventory node
        /// </summary>
        private ObservableCollection<InventoryNode> _ibObsolescenceMappingInventoryNode;

        /// <summary>
        /// The ib obsolescence criticality inventory node
        /// </summary>
        private ObservableCollection<InventoryNode> _ibObsolescenceCriticalityInventoryNode;

        /// <summary>
        /// The tr mapping inventory node
        /// </summary>
        private ObservableCollection<InventoryNode> _trMappingInventoryNode;

        /// <summary>
        /// The tr obsolescence mapping inventory node
        /// </summary>
        private ObservableCollection<InventoryNode> _trObsolescenceMappingInventoryNode;

        /// <summary>
        /// The tr obsolescence criticality inventory node
        /// </summary>
        private ObservableCollection<InventoryNode> _trObsolescenceCriticalityInventoryNode;

        /// <summary>
        /// The red chart elements
        /// </summary>
        private ObservableCollection<ChartBarElement> _redChartElements;

        /// <summary>
        /// The yellow chart elements
        /// </summary>
        private ObservableCollection<ChartBarElement> _yellowChartElements;

        /// <summary>
        /// The green chart elements
        /// </summary>
        private ObservableCollection<ChartBarElement> _greenChartElements;

        /// <summary>
        /// The dic critical
        /// </summary>
        private readonly Dictionary<string, CriticalityValue> _dicCritical = new Dictionary<string, CriticalityValue>();

        /// <summary>
        /// Get set Select all TR
        /// </summary>
        private bool? _isTrSelectedAll;

        /// <summary>
        /// Get set Select all Ib
        /// </summary>
        private bool? _isIbSelectedAll;

        /// <summary>
        /// Gets or sets the ib Device type Pi
        /// </summary>
        private ObservableCollection<InventoryNode> _ibDeviceTypePi;

        /// <summary>
        /// get set Tr DeviceType Pi
        /// </summary>
        private ObservableCollection<InventoryNode> _trDeviceTypePi;

        /// <summary>
        /// ExcelExportObsolescence object
        /// </summary>
        private IExcelExportObsolescence _excelExportObsolescence;

        /// <summary>
        /// Get set The project name
        /// </summary>
        private readonly string _projectName;

        /// <summary>
        /// Collection of mapping Items
        /// </summary>
        /// <value>The ib mapping inventory node.</value>
        public ObservableCollection<InventoryNode> IbMappingInventoryNode
        {
            get => _ibMappingInventoryNode;
            set => SetProperty(ref _ibMappingInventoryNode, value);
        }

        /// <summary>
        /// Get set Select all Ib
        /// </summary>
        /// <value><c>null</c> if [is ib selected all] contains no value, <c>true</c> if [is ib selected all]; otherwise, <c>false</c>.</value>
        public bool? IsIbSelectedAll
        {
            get => _isIbSelectedAll;
            set => SetProperty(ref _isIbSelectedAll, value);
        }

        /// <summary>
        /// Get set Select all TR
        /// </summary>
        /// <value><c>null</c> if [is tr selected all] contains no value, <c>true</c> if [is tr selected all]; otherwise, <c>false</c>.</value>
        public bool? IsTrSelectedAll
        {
            get => _isTrSelectedAll;
            set => SetProperty(ref _isTrSelectedAll, value);
        }

        /// <summary>
        /// Obsolescence Mapping
        /// </summary>
        /// <value>The ib obsolescence mapping inventory node.</value>
        public ObservableCollection<InventoryNode> IbObsolescenceMappingInventoryNode
        {
            get => _ibObsolescenceMappingInventoryNode;
            set => SetProperty(ref _ibObsolescenceMappingInventoryNode, value);
        }

        /// <summary>
        /// Obsolescence Criticality
        /// </summary>
        /// <value>The ib obsolescence criticality inventory node.</value>
        public ObservableCollection<InventoryNode> IbObsolescenceCriticalityInventoryNode
        {
            get => _ibObsolescenceCriticalityInventoryNode;
            set => SetProperty(ref _ibObsolescenceCriticalityInventoryNode, value);
        }

        /// <summary>
        /// get set Ib DeviceType Pi
        /// </summary>
        /// <value>The ib device type pi.</value>
        public ObservableCollection<InventoryNode> IbDeviceTypePi
        {
            get => _ibDeviceTypePi;
            set => SetProperty(ref _ibDeviceTypePi, value);
        }

        /// <summary>
        /// get set Tr DeviceType Pi
        /// </summary>
        /// <value>The tr device type pi.</value>
        public ObservableCollection<InventoryNode> TrDeviceTypePi
        {
            get => _trDeviceTypePi;
            set => SetProperty(ref _trDeviceTypePi, value);
        }


        /// <summary>
        /// Collection of mapping Items
        /// </summary>
        /// <value>The tr mapping inventory node.</value>
        public ObservableCollection<InventoryNode> TrMappingInventoryNode
        {
            get => _trMappingInventoryNode;
            set => SetProperty(ref _trMappingInventoryNode, value);
        }

        /// <summary>
        /// Obsolescence Mapping
        /// </summary>
        /// <value>The tr obsolescence mapping inventory node.</value>
        public ObservableCollection<InventoryNode> TrObsolescenceMappingInventoryNode
        {
            get => _trObsolescenceMappingInventoryNode;
            set => SetProperty(ref _trObsolescenceMappingInventoryNode, value);
        }

        /// <summary>
        /// Obsolescence Criticality
        /// </summary>
        /// <value>The tr obsolescence criticality inventory node.</value>
        public ObservableCollection<InventoryNode> TrObsolescenceCriticalityInventoryNode
        {
            get => _trObsolescenceCriticalityInventoryNode;
            set => SetProperty(ref _trObsolescenceCriticalityInventoryNode, value);
        }

        /// <summary>
        /// Collection of Obsolescence Red Chart Elements
        /// </summary>
        /// <value>The red chart elements.</value>
        public ObservableCollection<ChartBarElement> RedChartElements { get => _redChartElements; set => SetProperty(ref _redChartElements, value); }

        /// <summary>
        /// Collection of Obsolescence Yellow Chart Elements
        /// </summary>
        /// <value>The yellow chart elements.</value>
        public ObservableCollection<ChartBarElement> YellowChartElements { get => _yellowChartElements; set => SetProperty(ref _yellowChartElements, value); }

        /// <summary>
        /// Collection of Obsolescence Green Chart Elements
        /// </summary>
        /// <value>The green chart elements.</value>
        public ObservableCollection<ChartBarElement> GreenChartElements { get => _greenChartElements; set => SetProperty(ref _greenChartElements, value); }

        #region Command

        /// <summary>
        /// Command for generate report
        /// </summary>
        /// <value>The show result command.</value>
        public DelegateCommand<string> ShowResultCommand { get; set; }

        /// <summary>
        /// Reset All Selected
        /// </summary>
        /// <value>The reset command.</value>
        public DelegateCommand ResetCommand { get; set; }

        /// <summary>
        /// Command for Ib Checkbox change
        /// </summary>
        /// <value>The ib CheckBox command.</value>
        public DelegateCommand<bool?> IbCheckBoxCommand { get; set; }

        /// <summary>
        /// Command for Tr Checkbox change
        /// </summary>
        /// <value>The tr CheckBox command.</value>
        public DelegateCommand<bool?> TrCheckBoxCommand { get; set; }

        #endregion Command

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportExportToolsViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="colorProvider">The color provider.</param>
        /// <param name="reportExportChart">The report export chart.</param>
        /// <param name="excelExportObsolescence"></param>
        /// <param name="componentsCommand"></param>
        /// <param name="sharedContextService"></param>
        public ReportExportToolsViewModel(IEventAggregator eventAggregator, IStatusColorProvider colorProvider,
             IReportExportChart reportExportChart, IExcelExportObsolescence excelExportObsolescence,
             IGlobalIBComponentsCommand componentsCommand, ISharedContextService sharedContextService)
        {
            var projectModel = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
            _projectName = projectModel.Customer.ProjectName;
            _selectedInstalledBasedNode = projectModel.InstalledBase;
            _selectedTrNode = projectModel.TechnicalResources;
            _excelExportObsolescence = excelExportObsolescence;
            componentsCommand.ExportIBObsolescenceCommand.RegisterCommand(new DelegateCommand(OnExportObsolescenceExcel));
            IsIbSelectedAll = false;
            IsTrSelectedAll = false;
            TrDeviceTypePi = new ObservableCollection<InventoryNode>();
            IbDeviceTypePi = new ObservableCollection<InventoryNode>();
            IbCheckBoxCommand = new DelegateCommand<bool?>(OnIbChecked);
            TrCheckBoxCommand = new DelegateCommand<bool?>(OnTrChecked);
            _trInventoryNodes = new List<InventoryNode>();
            _ibInventoryNodes = new List<InventoryNode>();
            _reportDataChart = new ReportDataChart();
            _colorProvider = colorProvider;
            _eventAggregator = eventAggregator;
            _reportExportChart = reportExportChart;
            ResetCommand = new DelegateCommand(ResetSelection);
            IbMappingInventoryNode = new ObservableCollection<InventoryNode>();
            IbObsolescenceMappingInventoryNode = new ObservableCollection<InventoryNode>();
            IbObsolescenceCriticalityInventoryNode = new ObservableCollection<InventoryNode>();
            TrMappingInventoryNode = new ObservableCollection<InventoryNode>();
            TrObsolescenceMappingInventoryNode = new ObservableCollection<InventoryNode>();
            TrObsolescenceCriticalityInventoryNode = new ObservableCollection<InventoryNode>();
            RedChartElements = new ObservableCollection<ChartBarElement>();
            YellowChartElements = new ObservableCollection<ChartBarElement>();
            GreenChartElements = new ObservableCollection<ChartBarElement>();
            // ChartParameter = new ChartParameter();
            ShowResultCommand = new DelegateCommand<string>(OnShowResult);
            _eventAggregator.GetEvent<IBTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            _eventAggregator.GetEvent<TRTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            _dicCritical.Add("1. NOT CRITICAL", CriticalityValue.Not_Critical);
            _dicCritical.Add("NOT CRITICAL", CriticalityValue.Not_Critical);
            _dicCritical.Add("SOMEWHAT CRITICAL", CriticalityValue.Somewhat_Critical);
            _dicCritical.Add("2. SOMEWHAT CRITICAL", CriticalityValue.Somewhat_Critical);
            _dicCritical.Add("3. CRITICAL", CriticalityValue.Critical);
            _dicCritical.Add("CRITICAL", CriticalityValue.Critical);
            _dicCritical.Add("4. VERY CRITICAL", CriticalityValue.Very_Critical);
            _dicCritical.Add("VERY CRITICAL", CriticalityValue.Very_Critical);
            
        }

        /// <summary>
        /// On Ib Check box Check
        /// </summary>
        /// <param name="isIbSelected">if set to <c>true</c> [is ib selected].</param>
        private void OnIbChecked(bool? isIbSelected)
        {
            if (isIbSelected == null)
            {
                _ibInventoryNodes.ForEach(i => i.IsSelected = false);
                return;
            }
            _ibInventoryNodes.ForEach(i => i.IsSelected = isIbSelected.Value);
        }

        /// <summary>
        /// On Tr Check box Check
        /// </summary>
        /// <param name="isTrSelected">if set to <c>true</c> [is tr selected].</param>
        private void OnTrChecked(bool? isTrSelected)
        {
            if (isTrSelected == null)
            {
                _trInventoryNodes.ForEach(i => i.IsSelected = false);
                return;
            }
            _trInventoryNodes.ForEach(i => i.IsSelected = isTrSelected.Value);
        }

        /// <summary>
        /// Event Handler when Node Selection Change
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnNodeSelectionChanged(INode node)
        {
            if (node == null)
                return;
            if (node.ParentNodeAndNodeType.ContainsKey(NodeType.INSTALLEDBASE))
                _selectedInstalledBasedNode = node.ParentNodeAndNodeType[NodeType.INSTALLEDBASE];
            if (node.ParentNodeAndNodeType.ContainsKey(NodeType.TECHNICALRESOURCE))
                _selectedTrNode = node.ParentNodeAndNodeType[NodeType.TECHNICALRESOURCE];
            SetTreeNode();
        }

        /// <summary>
        /// Reset Selection
        /// </summary>
        private void ResetSelection()
        {
            IbObsolescenceMappingInventoryNode.ToList().ForEach(i => i.IsSelected = false);
            IbMappingInventoryNode.ToList().ForEach(i => i.IsSelected = false);
            IbObsolescenceCriticalityInventoryNode.ToList().ForEach(i => i.IsSelected = false);
            IbDeviceTypePi.ToList().ForEach(i => i.IsSelected = false);
            TrObsolescenceMappingInventoryNode.ToList().ForEach(i => i.IsSelected = false);
            TrMappingInventoryNode.ToList().ForEach(i => i.IsSelected = false);
            TrObsolescenceCriticalityInventoryNode.ToList().ForEach(i => i.IsSelected = false);
            TrDeviceTypePi.ToList().ForEach(i => i.IsSelected = false);
        }

        /// <summary>
        /// Checks the is selected.
        /// </summary>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool CheckIsSelected()
        {
            return (IbObsolescenceMappingInventoryNode.Any(i => i.IsSelected) ||
                    IbMappingInventoryNode.ToList().Any(i => i.IsSelected) ||
                    IbObsolescenceCriticalityInventoryNode.Any(i => i.IsSelected) ||
                    TrObsolescenceMappingInventoryNode.Any(i => i.IsSelected) ||
                    TrMappingInventoryNode.Any(i => i.IsSelected) ||
                    TrObsolescenceCriticalityInventoryNode.Any(i => i.IsSelected) ||
                    IbDeviceTypePi.Any(i => i.IsSelected) ||
                    TrDeviceTypePi.Any(i => i.IsSelected));
        }

        /// <summary>
        /// Set the Check box or tree with Parameter
        /// </summary>
        private void SetTreeNode()
        {

            _trInventoryNodes.Clear();
            _ibInventoryNodes.Clear();
            IbMappingInventoryNode.Clear();
            IbDeviceTypePi.Clear();
            TrDeviceTypePi.Clear();
            IbObsolescenceMappingInventoryNode.Clear();
            IbObsolescenceCriticalityInventoryNode.Clear();
            TrMappingInventoryNode.Clear();
            TrObsolescenceMappingInventoryNode.Clear();
            TrObsolescenceCriticalityInventoryNode.Clear();
            IsIbSelectedAll = false;
            IsTrSelectedAll = false;

            SetTrMappingAndObsolescence();
            SetIbMappingAndObsolescence();
            BindSelectionChangeEvent();

            _ibInventoryNodes.AddRange(IbMappingInventoryNode);
            _ibInventoryNodes.AddRange(IbObsolescenceMappingInventoryNode);
            _ibInventoryNodes.AddRange(IbObsolescenceCriticalityInventoryNode);
            _ibInventoryNodes.AddRange(IbDeviceTypePi);

            _trInventoryNodes.AddRange(TrMappingInventoryNode);
            _trInventoryNodes.AddRange(TrObsolescenceMappingInventoryNode);
            _trInventoryNodes.AddRange(TrObsolescenceCriticalityInventoryNode);
            _trInventoryNodes.AddRange(TrDeviceTypePi);
        }

        /// <summary>
        /// Event Binding for Inventories node selection Change
        /// </summary>
        private void BindSelectionChangeEvent()
        {
            IbMappingInventoryNode.ToList().ForEach(i => i.PropertyChanged += OnIbSelectionChange);
            IbObsolescenceMappingInventoryNode.ToList().ForEach(i => i.PropertyChanged += OnIbSelectionChange);
            IbObsolescenceCriticalityInventoryNode.ToList().ForEach(i => i.PropertyChanged += OnIbSelectionChange);
            IbDeviceTypePi.ToList().ToList().ForEach(i => i.PropertyChanged += OnIbSelectionChange);

            TrMappingInventoryNode.ToList().ForEach(i => i.PropertyChanged += OnTrSelectionChange);
            TrObsolescenceMappingInventoryNode.ToList().ForEach(i => i.PropertyChanged += OnTrSelectionChange);
            TrObsolescenceCriticalityInventoryNode.ToList().ForEach(i => i.PropertyChanged += OnTrSelectionChange);
            TrDeviceTypePi.ToList().ToList().ForEach(i => i.PropertyChanged += OnTrSelectionChange);
        }

        /// <summary>
        /// Event Handler on Inventory node Property change
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.ComponentModel.PropertyChangedEventArgs"/> instance containing the event data.</param>
        private void OnIbSelectionChange(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            IsIbSelectedAll = false;
            var count = _ibInventoryNodes.Count(i => i.IsSelected);
            IsIbSelectedAll = (count == _ibInventoryNodes.Count);
            if (count > 0 && count < _ibInventoryNodes.Count)
                IsIbSelectedAll = null;
        }

        /// <summary>
        /// Called when [export obsolescence excel].
        /// </summary>
        private void OnExportObsolescenceExcel()
        {
            var saveFilepath = "";
            if (!ShowSaveFileDialog(ExportType.Excel, ref saveFilepath)) return;

            try
            {               
                var taskExport = Task.Factory.StartNew(() =>
                   {
                       _excelExportObsolescence.Export(saveFilepath, "Installed Base Obsolescence",
                           _selectedInstalledBasedNode.MasterInventories.ToList(), 
                           "Technical Resources Obsolescene", _selectedTrNode.MasterInventories.ToList());

                   });
                taskExport.Wait();
                if (!File.Exists(saveFilepath)) return;
                if (MessageBox.Show("File generated successfully.\n Do want to open?", "File Generated",
                        MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    Process.Start(saveFilepath);

            }
            catch
            {

                MessageBox.Show("Sorry not able to Export.\n some internal error");
            }
        }

        /// <summary>
        /// Event Handler on Inventory node Property change
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.ComponentModel.PropertyChangedEventArgs"/> instance containing the event data.</param>
        private void OnTrSelectionChange(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            IsTrSelectedAll = false;
            var count = _trInventoryNodes.Count(i => i.IsSelected);
            IsTrSelectedAll = (count == _trInventoryNodes.Count);
            if (count > 0 && count < _trInventoryNodes.Count)
                IsTrSelectedAll = null;
        }

        /// <summary>
        /// Create Tree node for Installed Base
        /// </summary>
        private void SetIbMappingAndObsolescence()
        {
            var machines = new List<MachineNode>();
            if (!(_selectedInstalledBasedNode is InstalledBase installedBaseNode)) return;

            var deviceTypePi = new InventoryNode
            {
                NodeType = NodeType.OPEN_CONFIG,
                NodeHeader = $"Device Type {DateTime.Now.Year}",
                Nodes = new List<INode>() { installedBaseNode }
            };
            IbDeviceTypePi.Add(deviceTypePi);

            var factories = installedBaseNode.Factories.Cast<INode>().ToList();
            IbMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.FACTORY, NodeHeader = $"Factory ({factories.Select(i => i.Name).Distinct().Count()})", Nodes = factories });
            IbObsolescenceMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.FACTORY, NodeHeader = $"Factory ({factories.Select(i => i.Name).Distinct().Count()})", Nodes = factories });

            var workshops = installedBaseNode.Factories.SelectMany(i => i.WorkShopNodes).ToList();
            IbMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.WORKSHOP, NodeHeader = $"Workshop ({workshops.Select(i => i.Name).Distinct().Count()})", Nodes = workshops.Cast<INode>().ToList() });
            IbObsolescenceMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.WORKSHOP, NodeHeader = $"Workshop ({workshops.Select(i => i.Name).Distinct().Count()})", Nodes = workshops.Cast<INode>().ToList() });

            var line = workshops.SelectMany(i => i.LineNodes).ToList();
            IbMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.LINE, NodeHeader = $"Lines ({line.Select(i => i.Name).Distinct().Count()})", Nodes = line.Cast<INode>().ToList() });
            IbObsolescenceMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.LINE, NodeHeader = $"Lines ({line.Select(i => i.Name).Distinct().Count()})", Nodes = line.Cast<INode>().ToList() });
            var workshopsMachine = workshops.SelectMany(i => i.MachineNodes).ToList();
            var lineMachine = line.SelectMany(i => i.MachineNodes).ToList();
            var filterLineMachine = lineMachine.Where(i => workshopsMachine.All(k => k.Id != i.Id)).ToList();
            machines.AddRange(filterLineMachine);
            machines.AddRange(workshopsMachine);

            IbMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.MACHINE, NodeHeader = $"Machine ({machines.Select(i => i.Name).Distinct().Count()})", Nodes = machines.Cast<INode>().ToList() });
            IbObsolescenceMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.MACHINE, NodeHeader = $"Machine ({machines.Select(i => i.Name).Distinct().Count()})", Nodes = machines.Cast<INode>().ToList() });
            IbObsolescenceCriticalityInventoryNode.Add(new InventoryNode() { NodeType = NodeType.MACHINE, NodeHeader = $"Machine Criticality ({machines.Select(i => i.Name).Distinct().Count()})", Nodes = machines.Cast<INode>().ToList() });

            var config = machines.SelectMany(i => i.ConfigNodes).ToList();
            IbMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.OPEN_CONFIG, NodeHeader = $"Configuration ({config.Select(i => i.Name).Distinct().Count()})", Nodes = config.Cast<INode>().ToList() });
            IbObsolescenceMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.OPEN_CONFIG, NodeHeader = $"Configuration ({config.Select(i => i.Name).Distinct().Count()})", Nodes = config.Cast<INode>().ToList() });
            IbObsolescenceCriticalityInventoryNode.Add(new InventoryNode() { NodeType = NodeType.OPEN_CONFIG, NodeHeader = $"Obsolescence till {DateTime.Now.AddYears(9).Year}", Nodes = config.Cast<INode>().ToList() });
            //   ChartParameter.AllParameterNodes.AddRange(IbMappingInventoryNode.Distinct());
        }

        /// <summary>
        /// Create Tree node for Technical Resource
        /// </summary>
        private void SetTrMappingAndObsolescence()
        {
            if (!(_selectedTrNode is TRNode trNode)) return;

            var deviceTypePi = new InventoryNode
            {
                NodeType = NodeType.OPEN_CONFIG,
                NodeHeader = $"Device Type {DateTime.Now.Year}",
                Nodes = new List<INode>() { trNode }
            };
            TrDeviceTypePi.Add(deviceTypePi);

            var maintenanceNodes = trNode.MaintenanceNodes.ToList();
            TrMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.MAINTENANCEZONE, NodeHeader = $"Maintenance ({maintenanceNodes.Select(i => i.Name).Distinct().Count()})", Nodes = maintenanceNodes.Cast<INode>().ToList() });
            TrObsolescenceMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.MAINTENANCEZONE, NodeHeader = $"Maintenance ({maintenanceNodes.Select(i => i.Name).Distinct().Count()})", Nodes = maintenanceNodes.Cast<INode>().ToList() });

            var stock = maintenanceNodes.SelectMany(i => i.StockNodes).ToList();
            TrMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.STOCK, NodeHeader = $"Stock ({stock.Select(i => i.Name).Distinct().Count()})", Nodes = stock.Cast<INode>().ToList() });
            TrObsolescenceMappingInventoryNode.Add(new InventoryNode() { NodeType = NodeType.STOCK, NodeHeader = $"Stock ({stock.Select(i => i.Name).Distinct().Count()})", Nodes = stock.Cast<INode>().ToList() });

            TrObsolescenceCriticalityInventoryNode.Add(new InventoryNode() { NodeType = NodeType.STOCK, NodeHeader = $"Obsolescence till {DateTime.Now.AddYears(9).Year}", Nodes = stock.Cast<INode>().ToList() });
        }

        /// <summary>
        /// export the Result based on Command
        /// </summary>
        /// <param name="export">The export.</param>
        private void OnShowResult(string export)
        {
            if (!CheckIsSelected())
            {
                MessageBox.Show("Please select any Report type.", "File Selection",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (!Enum.TryParse(export, out ExportType exportType))
                return;
            var saveFilepath = string.Empty;
            if (!ShowSaveFileDialog(exportType, ref saveFilepath))
                return;
            GenerateReport(exportType, saveFilepath);
            if (!File.Exists(saveFilepath)) return;

            if (MessageBox.Show("File generated successfully.\n Do want to open?", "File Generated",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                System.Diagnostics.Process.Start(saveFilepath);
        }

        /// <summary>
        /// Generates the report.
        /// </summary>
        /// <param name="exportType">Type of the export.</param>
        /// <param name="saveFilepath">The save filepath.</param>
        public void GenerateReport(ExportType exportType, string saveFilepath)
        {
            try
            {
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage()
                { Message = "Pleas wait Generating File", status = OverlayStatus.VISIBLE });

                var images = new List<Image>();
                _reportExportChart.InstalledBaseNode = _selectedInstalledBasedNode;
                _reportExportChart.TrNode = _selectedTrNode;
                var installBaseChartImage = InstalledBaseExport();
                var trChartImage = TrExport();

                images.AddRange(installBaseChartImage);
                images.AddRange(trChartImage);
                _reportExportChart.Export(images, "Mapping, Obsolescence and Criticality assessment", exportType,
                    saveFilepath);

                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage()
                { Message = "File Generated", status = OverlayStatus.HIDDEN });
            }
            catch (Exception e)
            {
                //Console.WriteLine(e);
                var data = e.ToString();
            }
            finally
            {
                _eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage()
                { Message = "File Generated", status = OverlayStatus.HIDDEN });
            }
        }

        /// <summary>
        /// Export Technical Resource Inventories
        /// </summary>
        /// <returns>IEnumerable&lt;Image&gt;.</returns>
        private IEnumerable<Image> TrExport()
        {
            var chartImages = new List<Image>();
            foreach (var inventoryNode in TrMappingInventoryNode)
            {
                if (!inventoryNode.IsSelected)
                    continue;
                var header = inventoryNode.NodeType == NodeType.STOCK
                    ? "Mapping Technical Resource by STOCK"
                    : $"Mapping Technical Resource by {inventoryNode.NodeType}";
                var xlable = inventoryNode.NodeType == NodeType.OPEN_CONFIG
                    ? "STOCK"
                    : $"{inventoryNode.NodeType}";
                var mappingChartBarElement = CreateMappingChart(inventoryNode, TrMappingInventoryNode, NodeType.STOCK);
                _reportDataChart.rootAnalysisChart.DataSource = null;
                _reportDataChart.rootAnalysisChart.DataSource = mappingChartBarElement;
                _reportDataChart.HeaderLabel = header;
                _reportDataChart.XAxesLabel = xlable;
                _reportDataChart.YAxesLabel = "Quantity";
                var image = GetChartImage(_reportDataChart.rootAnalysisChart);
                if (image != null)
                    chartImages.Add(image);
            }
            foreach (var inventoryNode in TrObsolescenceMappingInventoryNode)
            {
                if (!inventoryNode.IsSelected)
                    continue;
                var header = inventoryNode.NodeType == NodeType.OPEN_CONFIG
                    ? "Obsolescence Mapping Technical Resource by STOCK"
                    : $"Obsolescence Mapping Technical Resource by {inventoryNode.NodeType}";
                var xLable = inventoryNode.NodeType == NodeType.OPEN_CONFIG
                    ? "STOCK"
                    : $"{inventoryNode.NodeType}";

                CreateObsolescenceMapping(inventoryNode, TrObsolescenceMappingInventoryNode, NodeType.STOCK);
                _reportDataChart.GreenChartElements.Clear();
                _reportDataChart.RedChartElements.Clear();
                _reportDataChart.YellowChartElements.Clear();

                _reportDataChart.GreenChartElements.AddRange(GreenChartElements);
                _reportDataChart.YellowChartElements.AddRange(YellowChartElements);
                _reportDataChart.RedChartElements.AddRange(RedChartElements);

                _reportDataChart.HeaderLabel = header;
                _reportDataChart.XAxesLabel = xLable;
                _reportDataChart.YAxesLabel = "Quantity";
                var image = GetChartImage(_reportDataChart.rootObsolescenceAnalysisChart);
                if (image != null)
                    chartImages.Add(image);
            }

            if (TrObsolescenceCriticalityInventoryNode.Any(conf => conf.NodeType == NodeType.STOCK && conf.IsSelected))
            {
                CreateObsolescenceChart(TrObsolescenceCriticalityInventoryNode, NodeType.STOCK);
                _reportDataChart.GreenChartElements.Clear();
                _reportDataChart.RedChartElements.Clear();
                _reportDataChart.YellowChartElements.Clear();
                var header = "Obsolescence Technical Resource by STOCK";
                var xlable = "STOCK";

                _reportDataChart.GreenChartElements.AddRange(GreenChartElements);
                _reportDataChart.YellowChartElements.AddRange(YellowChartElements);
                _reportDataChart.RedChartElements.AddRange(RedChartElements);

                _reportDataChart.HeaderLabel = header;
                _reportDataChart.XAxesLabel = xlable;
                _reportDataChart.YAxesLabel = "Quantity";
                var image = GetChartImage(_reportDataChart.rootObsolescenceAnalysisChart);
                if (image != null)
                    chartImages.Add(image);
            }

            foreach (var inventoryNode in TrDeviceTypePi)
            {
                if (!inventoryNode.IsSelected)
                    continue;

                var piChartBarElement = CreateDeviceTypePiChart(inventoryNode.Nodes[0]);
                _reportDataChart.rootAnalysisChart.DataSource = null;
                _reportDataChart.chartPiControl.DataSource = piChartBarElement;
                _reportDataChart.HeaderLabel = $"{DateTime.Today.Year} Technical Resource Devices";
                _reportDataChart.XAxesLabel = "";
                _reportDataChart.YAxesLabel = "";
                var image = GetChartImage(_reportDataChart.chartPiControl);
                if (image != null)
                    chartImages.Add(image);
            }
            return chartImages;
        }

        /// <summary>
        /// Export Installed Base Inventories
        /// </summary>
        /// <returns>IEnumerable&lt;Image&gt;.</returns>
        private IEnumerable<Image> InstalledBaseExport()
        {
            var chartImages = new List<Image>();

            foreach (var inventoryNode in IbMappingInventoryNode)
            {
                if (!inventoryNode.IsSelected)
                    continue;
                var header = inventoryNode.NodeType == NodeType.OPEN_CONFIG
                    ? "Mapping Installed Base by CONFIGURATION"
                    : $"Mapping Installed Base by {inventoryNode.NodeType}";
                var xlable = inventoryNode.NodeType == NodeType.OPEN_CONFIG
                    ? "CONFIGURATION"
                    : $"{inventoryNode.NodeType}";
                var mappingChartBarElement = CreateMappingChart(inventoryNode, IbMappingInventoryNode);
                _reportDataChart.rootAnalysisChart.DataSource = null;
                _reportDataChart.rootAnalysisChart.DataSource = mappingChartBarElement;
                _reportDataChart.HeaderLabel = header;
                _reportDataChart.XAxesLabel = xlable;
                _reportDataChart.YAxesLabel = "Quantity";
                var image = GetChartImage(_reportDataChart.rootAnalysisChart);
                if (image != null)
                    chartImages.Add(image);
            }

            foreach (var inventoryNode in IbObsolescenceMappingInventoryNode)
            {
                if (!inventoryNode.IsSelected)
                    continue;
                var header = inventoryNode.NodeType == NodeType.OPEN_CONFIG
                    ? $"({DateTime.Today.Year}) Obsolescence Mapping Installed Base by CONFIGURATION"
                    : $"({DateTime.Today.Year}) Obsolescence Mapping Installed Base by {inventoryNode.NodeType}";
                var xlable = inventoryNode.NodeType == NodeType.OPEN_CONFIG
                    ? "CONFIGURATION"
                    : $"{inventoryNode.NodeType}";

                CreateObsolescenceMapping(inventoryNode, IbObsolescenceMappingInventoryNode);
                _reportDataChart.GreenChartElements.Clear();
                _reportDataChart.RedChartElements.Clear();
                _reportDataChart.YellowChartElements.Clear();

                _reportDataChart.GreenChartElements.AddRange(GreenChartElements);
                _reportDataChart.YellowChartElements.AddRange(YellowChartElements);
                _reportDataChart.RedChartElements.AddRange(RedChartElements);

                _reportDataChart.HeaderLabel = header;
                _reportDataChart.XAxesLabel = xlable;
                _reportDataChart.YAxesLabel = "Quantity";
                var image = GetChartImage(_reportDataChart.rootObsolescenceAnalysisChart);
                if (image != null)
                    chartImages.Add(image);
            }

            var criticalityChartBarElement = CreateInstallBasedCriticalityChart();

            if (criticalityChartBarElement != null)
            {
                _reportDataChart.rootAnalysisChart.DataSource = criticalityChartBarElement;
                _reportDataChart.HeaderLabel = "Criticality Installed Base by Machine";
                _reportDataChart.XAxesLabel = "MACHINE (4 = Very Critical, 3 = Critical, 2 = Somewhat Critical, 1 = Not Critical)";
                _reportDataChart.YAxesLabel = "Process Criticality";
                var image = GetChartImage(_reportDataChart.rootAnalysisChart);
                if (image != null)
                    chartImages.Add(image);
            }

            if (IbObsolescenceCriticalityInventoryNode.Any(conf => conf.NodeType == NodeType.OPEN_CONFIG && conf.IsSelected))
            {
                CreateObsolescenceChart(IbObsolescenceCriticalityInventoryNode);
                _reportDataChart.GreenChartElements.Clear();
                _reportDataChart.RedChartElements.Clear();
                _reportDataChart.YellowChartElements.Clear();
                var header = "Obsolescence installed Base by CONFIGURATION";
                var xlable = "CONFIGURATION";

                _reportDataChart.GreenChartElements.AddRange(GreenChartElements);
                _reportDataChart.YellowChartElements.AddRange(YellowChartElements);
                _reportDataChart.RedChartElements.AddRange(RedChartElements);

                _reportDataChart.HeaderLabel = header;
                _reportDataChart.XAxesLabel = xlable;
                _reportDataChart.YAxesLabel = "Quantity";
                var image = GetChartImage(_reportDataChart.rootObsolescenceAnalysisChart);
                if (image != null)
                    chartImages.Add(image);
            }

            foreach (var inventoryNode in IbDeviceTypePi)
            {
                if (!inventoryNode.IsSelected)
                    continue;

                var piChartBarElement = CreateDeviceTypePiChart(inventoryNode.Nodes[0]);
                _reportDataChart.rootAnalysisChart.DataSource = null;
                _reportDataChart.chartPiControl.DataSource = piChartBarElement;
                _reportDataChart.HeaderLabel = $"{DateTime.Today.Year} Installed Base Devices";
                _reportDataChart.XAxesLabel = "";
                _reportDataChart.YAxesLabel = "";
                var image = GetChartImage(_reportDataChart.chartPiControl);
                if (image != null)
                    chartImages.Add(image);
            }

            return chartImages;
        }

        /// <summary>
        /// Create Pi Chart Elements
        /// </summary>
        /// <param name="node">The node.</param>
        /// <returns>List&lt;ChartBarElement&gt;.</returns>
        private List<ChartBarElement> CreateDeviceTypePiChart(INode node)
        {
            if (node == null)
                return new List<ChartBarElement>();
            return node.Inventories.GroupBy(i => i.DeviceType)
                 .ToDictionary(deviceType => deviceType.Key, inventories => inventories.Count()).Select(k =>
                     new ChartBarElement
                     {
                         Name = k.Key,
                         ConfigCount = k.Value
                     }).ToList();

        }

        /// <summary>
        /// Gets the chart image.
        /// </summary>
        /// <param name="chart">The chart.</param>
        /// <returns>Image.</returns>
        private Image GetChartImage(ChartControl chart)
        {
            Image image;
            using (var s = new MemoryStream())
            {
                chart.ExportToImage(s, PrintSizeMode.None);
                image = Image.FromStream(s);
            }

            // Return the image.
            return image;
        }

        /// <summary>
        /// Create Obsolescence Mapping
        /// </summary>
        /// <param name="inventoryNode">The inventory node.</param>
        /// <param name="inventoryNodes">The inventory nodes.</param>
        /// <param name="type">The type.</param>
        private void CreateObsolescenceMapping(InventoryNode inventoryNode, ObservableCollection<InventoryNode> inventoryNodes, NodeType type = NodeType.OPEN_CONFIG)
        {
            GreenChartElements.Clear();
            RedChartElements.Clear();
            YellowChartElements.Clear();
            if (!inventoryNode.IsSelected)
                return;
            var nodeType = inventoryNode.NodeType;
            var selectedNodes = inventoryNode.Nodes;
            var allConfigurationNodes = inventoryNodes.Where(conf => conf.NodeType == type).SelectMany(i => i.Nodes).ToList();

            // "#FFDC0A0A" //Red
            //"#FFFFD100" //Yellow
            //"#FF3DCD58" //Green

            if (nodeType == type)
            {
                foreach (var node in allConfigurationNodes)
                    BindObsolescenceMapping(node.Name, node.Inventories);
            }
            else
            {
                foreach (var node in selectedNodes)
                {
                    var inventories = allConfigurationNodes.Where(i =>
                          i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                          i.ParentNodeAndNodeType[nodeType].Id == node.Id).SelectMany(i => i.Inventories).ToList();
                    BindObsolescenceMapping(node.Name, inventories);
                }
            }
        }

        /// <summary>
        /// Bind Obsolescence Mapping
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="inventories">The inventories.</param>
        private void BindObsolescenceMapping(string name, ICollection<Inventory> inventories)
        {
            var redChartBarElement = new ChartBarElement()
            {
                ConfigCount = inventories.Where(i => i.Year == "#FFDC0A0A").Sum(i => i.Quantity),
                Name = name
            };
            var yellowChartBarElement = new ChartBarElement()
            {
                ConfigCount = inventories.Where(i => i.Year == "#FFFFD100").Sum(i => i.Quantity),
                Name = name
            };
            var greenChartBarElement = new ChartBarElement()
            {
                ConfigCount = inventories.Where(i => i.Year == "#FF3DCD58").Sum(i => i.Quantity),
                Name = name
            };
            var redElement = RedChartElements.FirstOrDefault(i => i.Name == redChartBarElement.Name);
            var yellowElement = YellowChartElements.FirstOrDefault(i => i.Name == yellowChartBarElement.Name);
            var greenElement = GreenChartElements.FirstOrDefault(i => i.Name == greenChartBarElement.Name);

            if (redElement == null)
                RedChartElements.Add(redChartBarElement);
            else
                redElement.ConfigCount += redChartBarElement.ConfigCount;

            if (yellowElement == null)
                YellowChartElements.Add(yellowChartBarElement);
            else
                yellowElement.ConfigCount += yellowChartBarElement.ConfigCount;

            if (greenElement == null)
                GreenChartElements.Add(greenChartBarElement);
            else
                greenElement.ConfigCount += greenChartBarElement.ConfigCount;
        }

        /// <summary>
        /// Create Mapping Chart
        /// </summary>
        /// <param name="inventoryNode">The inventory node.</param>
        /// <param name="inventoryNodes">The inventory nodes.</param>
        /// <param name="type">The type.</param>
        /// <returns>List&lt;ChartBarElement&gt;.</returns>
        private List<ChartBarElement> CreateMappingChart(InventoryNode inventoryNode, ObservableCollection<InventoryNode> inventoryNodes, NodeType type = NodeType.OPEN_CONFIG)
        {
            var chartElements = new List<ChartBarElement>();
            var nodeType = inventoryNode.NodeType;
            var selectedNodes = inventoryNode.Nodes;
            var allConfigurationNodes = inventoryNodes.Where(conf => conf.NodeType == type).SelectMany(i => i.Nodes).ToList();
            //  var allConfigurationNodes = IbMappingInventoryNode.Where(conf => conf.NodeType == type).SelectMany(i => i.Nodes).ToList();
            if (nodeType == type)
            {
                foreach (var node in allConfigurationNodes)
                {
                    var chartBarElement = new ChartBarElement()
                    {
                        ConfigCount = node.Inventories.Sum(k => k.Quantity),
                        Name = node.Name
                    };
                    var isChartBarElement = chartElements.FirstOrDefault(i => i.Name == chartBarElement.Name);
                    if (isChartBarElement == null)
                        chartElements.Add(chartBarElement);
                    else
                        isChartBarElement.ConfigCount += chartBarElement.ConfigCount;
                }
            }
            else
            {
                foreach (var node in selectedNodes)
                {
                    var chartBarElement = new ChartBarElement()
                    {
                        ConfigCount = allConfigurationNodes.Where(i =>
                            i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                            i.ParentNodeAndNodeType[nodeType].Id == node.Id).Sum(i =>
                            i.Inventories.Sum(k => k.Quantity)),
                        Name = node.Name
                    };
                    var isChartBarElement = chartElements.FirstOrDefault(i => i.Name == chartBarElement.Name);
                    if (isChartBarElement == null)
                        chartElements.Add(chartBarElement);
                    else
                        isChartBarElement.ConfigCount += chartBarElement.ConfigCount;
                }
            }

            return chartElements;
        }

        /// <summary>
        /// Create Install Based Criticality Chart
        /// </summary>
        /// <returns>List&lt;ChartBarElement&gt;.</returns>
        private List<ChartBarElement> CreateInstallBasedCriticalityChart()
        {
            var chartElements = new List<ChartBarElement>();
            var criticalitys = IbObsolescenceCriticalityInventoryNode.Where(i => i.NodeType == NodeType.MACHINE && i.IsSelected).SelectMany(i => i.Nodes.Cast<MachineNode>()).ToList();

            if (!criticalitys.Any())
                return null;

            var machineCriticalitys = criticalitys.Where(i => i.CriticalityParameters != null &&
                                                              !string.IsNullOrEmpty(i.CriticalityParameters.SelectedValue)).Select(i => new ChartBarElement
                                                              {
                                                                  ConfigCount = GetCriticalityLevel(i.CriticalityParameters.SelectedValue),
                                                                  Name = i.Name
                                                              }).ToList();
            // machineCriticalitys = machineCriticalitys.OrderByDescending(i => i.ConfigCount).ToList();// not required
            chartElements.AddRange(machineCriticalitys);
            return chartElements;
        }

        /// <summary>
        /// Get Criticality Level
        /// </summary>
        /// <param name="selectedCriticality">The selected criticality.</param>
        /// <returns>System.Int32.</returns>
        private int GetCriticalityLevel(string selectedCriticality)
        {
            if (!_dicCritical.ContainsKey(selectedCriticality.ToUpper()))
                return 0;
            var value = (int)_dicCritical[selectedCriticality.ToUpper()];
            return value;
        }

        /// <summary>
        /// Create Obsolescence Chart
        /// </summary>
        /// <param name="inventoryNodes">The inventory nodes.</param>
        /// <param name="type">The type.</param>
        private void CreateObsolescenceChart(ObservableCollection<InventoryNode> inventoryNodes,
            NodeType type = NodeType.OPEN_CONFIG)
        {
            var currentDate = DateTime.Today;
            GreenChartElements.Clear();
            RedChartElements.Clear();
            YellowChartElements.Clear();
            if (!inventoryNodes.Any(conf => conf.NodeType == type && conf.IsSelected))
                return;

            var yearGaps = DateTime.Now.AddYears(9).Year - currentDate.Year;
            var allConfigurationInventories = inventoryNodes
                .Where(conf => conf.NodeType == type && conf.IsSelected)
                .SelectMany(i => i.Nodes.SelectMany(k => k.Inventories)).ToList();

            if (yearGaps < 0)
            {
                for (int i = yearGaps; i <= 0; i++)
                    FillObsolescenceCollection(allConfigurationInventories, currentDate.AddYears(i).Year);
            }
            else
            {
                // for (var i = yearGaps; i >= 0; i--)
                for (var i = 0; i <= yearGaps; i++)
                    FillObsolescenceCollection(allConfigurationInventories, currentDate.AddYears(i).Year);
            }
        }

        /// <summary>
        /// Fill Obsolescence Collection
        /// </summary>
        /// <param name="allConfigurationInventories">All configuration inventories.</param>
        /// <param name="xYear">The x year.</param>
        private void FillObsolescenceCollection(IEnumerable<Inventory> allConfigurationInventories, int xYear)
        {
            foreach (var inventory in allConfigurationInventories)
            {
                var color = _colorProvider.GetYearColor(xYear,
                    int.TryParse(inventory.Dosa, out var dosa) ? dosa : (int?)null,
                    int.TryParse(inventory.DoS, out var dos) ? dos : (int?)null,
                    int.TryParse(inventory.EoS, out var eos) ? eos : (int?)null);

                var redElement = RedChartElements.FirstOrDefault(l => l.Name == xYear.ToString());
                if (redElement == null)
                {
                    redElement = new ChartBarElement() { Name = xYear.ToString() };
                    RedChartElements.Add(redElement);
                }
                var yellowElement = YellowChartElements.FirstOrDefault(l => l.Name == xYear.ToString());
                if (yellowElement == null)
                {
                    yellowElement = new ChartBarElement() { Name = xYear.ToString() };
                    YellowChartElements.Add(yellowElement);
                }

                var greenElement = GreenChartElements.FirstOrDefault(l => l.Name == xYear.ToString());
                if (greenElement == null)
                {
                    greenElement = new ChartBarElement() { Name = xYear.ToString() };
                    GreenChartElements.Add(greenElement);
                }

                if (color == "#FFDC0A0A") //Red
                    redElement.ConfigCount += inventory.Quantity;

                if (color == "#FFFFD100") //Yellow
                    yellowElement.ConfigCount += inventory.Quantity;

                if (color == "#FF3DCD58") //Green
                    greenElement.ConfigCount += inventory.Quantity;
            }
        }

        /// <summary>
        /// Show Save File Dialog
        /// </summary>
        /// <param name="exportType">Type of the export.</param>
        /// <param name="saveFilePath">The save file path.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ShowSaveFileDialog(ExportType exportType, ref string saveFilePath)
        {
            _saveFileDialog.FileName = _projectName;
            _saveFileDialog.Filter = "Word Documents|*.docx";
            switch (exportType)
            {
                case ExportType.Word:
                    _saveFileDialog.Filter = "Word Documents (*.docx)|*.docx|Word 97-2003 (*.doc)|*.doc";
                    break;

                case ExportType.Excel:
                    _saveFileDialog.Filter = "Excel Files (*.xlsx)|*.xlsx|Excel Files 97-2003 (*.xls)|*.xls|Excel (*.xlsm)|*.xlsm";
                    break;

                case ExportType.Pdf:
                    _saveFileDialog.Filter = "Pdf Files|*.pdf";
                    break;

                case ExportType.HTML:
                    _saveFileDialog.Filter = "HTML Files|*.html";
                    break;
            }

            if (_saveFileDialog.ShowDialog() == false) return false;
            saveFilePath = _saveFileDialog.FileName;
            return true;
        }
    }

    /// <summary>
    /// Inventory Node Parameter For Export
    /// </summary>
    public class InventoryNode : ChartParameterNode
    {
        /// <summary>
        /// The is selected
        /// </summary>
        private bool _isSelected;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value><c>true</c> if this instance is selected; otherwise, <c>false</c>.</value>
        public bool IsSelected { get => _isSelected; set => SetProperty(ref _isSelected, value); }
    }
}