

import { Action } from '@ngrx/store';
import * as CreIptAction from './corIptAction';

import { CoreIpt } from 'src/app/model/coreIpt';




export interface IAppState {
    readonly compliance: CoreIpt[];
}


export function coreIptReducer(state: CoreIpt[] = [], action: CreIptAction.Actions) {

    switch (action.type) {

        case CreIptAction.ADD_CORE_IPT: {
            return [...state, action.payload]

        }

        case CreIptAction.LOAD_CORE_IPT: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case CreIptAction.UPDATE_CORE_IPT: {
            const tti = (action.payload as CoreIpt);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            //return Object.assign([], state);
            return state.slice();
        }



        default:
            return state;
    }
}