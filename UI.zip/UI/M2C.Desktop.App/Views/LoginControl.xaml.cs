﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="LoginControl.xaml.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.App.Views
{
    /// <summary>
    /// Interaction logic for LoginControl
    /// </summary>
    public partial class LoginControl : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoginControl" /> class.
        /// </summary>
        public LoginControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Navigating event of the loginWeb control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Navigation.NavigatingCancelEventArgs" /> instance containing the event data.</param>
        private void loginWeb_Navigating(object sender, System.Windows.Navigation.NavigatingCancelEventArgs e)
        {

        }
    }
}