﻿using Fraca.Data.Models;
using Fraca.Service.Service;
using Fraca.Service.Validator;
using FracaServiceHost.Authorizes;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Fraca.Api.Service.Host.Controllers
{
    public class FilterController : ApiController
    {
        private IFracaService _FracaService;
        private readonly IUserValidator _userValidator;
        public FilterController(IFracaService FracaService, IUserValidator userValidator)
        {
            _FracaService = FracaService;
            _userValidator = userValidator;
        }


        [HttpPost]
        public HttpResponseMessage GetFracaByFilter(FracaCriteria criteria)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            var fracaData = _FracaService.GetFracaByFilter(criteria);
            fracaData.UserName = eid;
            fracaData.FracaInfo = _userValidator.MapAccess(eid, fracaData.FracaInfo);

          
            return Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);

        }
    }
}
