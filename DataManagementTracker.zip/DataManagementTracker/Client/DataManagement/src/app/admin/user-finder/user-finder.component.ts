import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-finder',
  templateUrl: './user-finder.component.html',
  styleUrls: ['./user-finder.component.sass']
})
export class UserFinderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
