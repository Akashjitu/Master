﻿// ***********************************************************************
// Assembly         : M2C.Configuration.Parsers
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="BaseProduct.cs" company="M2C.Configuration.Parsers">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;

namespace M2C.Configuration.Parsers.Model
{
    /// <summary>
    /// Class BaseProduct.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class BaseProduct
    {
        /// <summary>
        /// Gets or sets the name of the type.
        /// </summary>
        /// <value>The name of the type.</value>
        public string TypeName
        {
            get; set;
        }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string name { get; set; }
        /// <summary>
        /// Gets or sets the family.
        /// </summary>
        /// <value>The family.</value>
        public string family { get; set; }

        /// <summary>
        /// Gets or sets the pick list items.
        /// </summary>
        /// <value>The pick list items.</value>
        public List<string> pickListItems
        {
            get; set;

        } = new List<string>();

        /// <summary>
        /// Gets or sets the count.
        /// </summary>
        /// <value>The count.</value>
        public int Count { get; set; }
        /// <summary>
        /// Gets or sets the replacement detail.
        /// </summary>
        /// <value>The replacement detail.</value>
        public string ReplacementDetail { get; set; }
    }
}
