﻿using System;

using System.Collections.Generic;
using Data.Management.Services.Manager;
using DataManagement.Data.Models;

namespace Data.Management.Services
{
    public class DataManagementServices : IDataManagementServices
    {
        private readonly IDataManagementManage _dataManagementManage;

        public DataManagementServices(IDataManagementManage dataManagementManage)
        {
            _dataManagementManage = dataManagementManage;
        }
        public DataManagementTrack AddNew(DataManagementTrack dataManagement)
        {
            return _dataManagementManage.AddNew(dataManagement);
        }

        public List<DataManagementTrack> LoadAllDataManagements()
        {
            return _dataManagementManage.LoadAllDataManagements();
        }

        public List<DataManagementTrack> LoadByDate(DateTime created)
        {
            return _dataManagementManage.LoadByDate(created);
        }

        public List<DataManagementTrack> LoadById(int id)
        {
            return _dataManagementManage.LoadById(id);
        }

        public DataManagementTrack UpdateData(DataManagementTrack dataManagement)
        {
            return _dataManagementManage.UpdateData(dataManagement);
        }
    }
}