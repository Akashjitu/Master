﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;
using System;
using OfficeOpenXml;
using System.IO;
using System.Linq;
namespace Pse.Services.ExcelExports
{
    public class TtiExports : ITtiExports
    {
        public byte[] Export(List<TtiPartAlignment> ttiPartAlignment)
        {
            throw new NotImplementedException();
        }



        string[] _properties;


        public byte[] Export<T>(List<T> ttiPartAlignment, string sheetName, int pinedRightColumn)
        {
            FileInfo targetFile = new FileInfo(@"C:\Users\H332364\Desktop\EXPT\test.xlsx");

            using (var excelFile = new ExcelPackage(targetFile))
            {
                var worksheet = excelFile.Workbook.Worksheets.Add(sheetName);
                worksheet.Cells["A1"].LoadFromCollection(Collection: ttiPartAlignment, PrintHeaders: true);

                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].Style.Font.Bold = true;
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].Style.Font.Size = 14;
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].Style.Font.Color.SetColor(System.Drawing.Color.Blue);
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].AutoFilter = true;
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].AutoFitColumns();

                if (pinedRightColumn > 0)
                    worksheet.View.FreezePanes(1, pinedRightColumn);

                excelFile.Save();
                return excelFile.GetAsByteArray();
            }




            //using (ExcelPackage excel = new ExcelPackage())
            //{



            //    ExcelWorksheet ttiExcelWorksheet = excel.Workbook.Worksheets.Add("TTI_Part_Alignment ");


            //    var entityType = typeof(T);
            //    _properties = entityType.GetProperties().Select(i => i.Name).ToArray();

            //    var headerRow = new List<string[]>() { _properties };

            //    string headerRange = "A1:" + Char.ConvertFromUtf32(headerRow[0].Length + 64) + "1";

            //    ttiExcelWorksheet.Cells[headerRange].LoadFromArrays(headerRow);
            //    ttiExcelWorksheet.Cells[headerRange].Style.Font.Bold = true;
            //    ttiExcelWorksheet.Cells[headerRange].Style.Font.Size = 14;
            //    ttiExcelWorksheet.Cells[headerRange].Style.Font.Color.SetColor(System.Drawing.Color.Blue);
            //    ttiExcelWorksheet.Cells[headerRange].AutoFilter = true;





            //    var cellData = GetCellValue<T>(ttiPartAlignment);

            //    if (cellData != null)
            //        ttiExcelWorksheet.Cells[2, 1].LoadFromArrays(cellData);



            //    // return excel.GetAsByteArray();

            //    FileInfo excelFile = new FileInfo(@"C:\Users\H332364\Desktop\EXPT\test.xlsx");
            //    excel.SaveAs(excelFile);
            //}

            return null;
        }



        public string[] GetHeaderColumns(ExcelWorksheet sheet)
        {
            return sheet.Cells[sheet.Dimension.Start.Row, sheet.Dimension.Start.Column, 1, sheet.Dimension.End.Column]
                .Select(firstRowCell => firstRowCell.Text).ToArray();
        }


        private List<object[]> GetCellValue<T>(List<T> entities)
        {

            object[] values = null;
            var cellData = new List<object[]>();
            foreach (var entity in entities)
            {
                values = new object[_properties.Length];
                for (int i = 0; i < _properties.Length; i++)
                {
                    var propertyValue = entity.GetType().GetProperty(_properties[i]).GetValue(entity, null);
                    values[i] = propertyValue;
                }
                cellData.Add(values);
            }



            //var cellData = new List<object[]>()
            //                            {
            //                              new object[] {"TEST", 0, 0, 1},
            //                              new object[] {10,7.32,7.42,1},
            //                              new object[] {20,5.01,5.24,1},
            //                              new object[] {30,3.97,4.16,1},
            //                              new object[] {40,3.97,4.16,1},
            //                              new object[] {50,3.97,4.16,1},
            //                              new object[] {60,3.97,4.16,1},
            //                              new object[] {70,3.97,4.16,1},
            //                              new object[] {80,3.97,4.16,1},
            //                              new object[] {90,3.97,4.16,1},
            //                              new object[] {100,3.97,4.16,1}
            //                            };


            return cellData;
        }
    }
}