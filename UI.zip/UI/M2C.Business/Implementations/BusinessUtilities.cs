﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="BusinessUtilities.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using M2C.Business.Contracts;
using M2C.Business.Models;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class BusinessUtilities.
    /// Implements the <see cref="M2C.Business.Contracts.IBusinessUtilities" />
    /// </summary>
    /// <seealso cref="M2C.Business.Contracts.IBusinessUtilities" />
    public class BusinessUtilities : IBusinessUtilities
    {
        /// <summary>
        /// Gets the country queries.
        /// </summary>
        /// <value>The country queries.</value>
        private ICountryQueries _countryQueries { get; }
        /// <summary>
        /// Gets the position queries.
        /// </summary>
        /// <value>The position queries.</value>
        private IPositionQueries _positionQueries { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessUtilities" /> class.
        /// </summary>
        /// <param name="countryQueries">The country queries.</param>
        /// <param name="positionQueries">The position queries.</param>
        public BusinessUtilities(ICountryQueries countryQueries, IPositionQueries positionQueries)
        {
            _countryQueries = countryQueries;
            _positionQueries = positionQueries;
        }

        /// <summary>
        /// Gets the countries.
        /// </summary>
        /// <returns>List&lt;CountryModel&gt;.</returns>
        public List<CountryModel> getCountries()
        {
            List<DomainModels.Common.Country> countries = _countryQueries.LoadCountries();
            return countries?.Where(country => !string.IsNullOrEmpty(country.Name)).Select(country => new CountryModel()
            {
                Code = country.Code,
                Id = country.Id,
                Name = country.Name,
                Region = country.Region
            }).ToList();
        }

        /// <summary>
        /// Gets the positions.
        /// </summary>
        /// <returns>List&lt;PositionModel&gt;.</returns>
        public List<PositionModel> getPositions()
        {
            List<DomainModels.Common.Position> positions = _positionQueries.LoadPositions();
            return positions?.Where(i => !string.IsNullOrEmpty(i.Name)).Select(i => new PositionModel()
            {
                Id = i.Id,
                Name = i.Name
            }).ToList();
        }
    }
}