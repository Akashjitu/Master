﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class OtlAnalysis
    {
        [Columns("P_KEY_CODE")]
        public string KeyCode { get; set; }

        [Columns("P_SBU")]
        public string Sbu { get; set; }

        [Columns("P_GBE")]
        public string Gbe { get; set; }

        [Columns("P_PM")]
        public string Pm { get; set; }

        [Columns("P_PROGRAM_NAME")]
        public string ProgramName { get; set; }

        [Columns("P_IPDS_PHASE")]
        public string IpdsPhase { get; set; }

        [Columns("P_PROGRAM_OTL_DISPOSITION")]
        public string ProgramOtlDisposition { get; set; }

        [Columns("P_IPDS_EARLY_LATE_PHASE")]
        public string IpdsEarlyLatePhase { get; set; }

        [Columns("P_REPORTING_MILESTONES")]
        public string ReportingMilestones { get; set; }

        [Columns("P_OTL_MS")]
        public string OtlMs { get; set; }

        [Columns("P_PSE_LAUNCH_ENG")]
        public string PseLaunchEng { get; set; }

        [Columns("P_BASELINE_DATES")]
        public string BaseLineDates { get; set; }

        [Columns("P_NOTES")]
        public string Notes { get; set; }

        [Columns("P_CREATED_BY")]
        public string CreatedBy { get; set; }

        [Columns("P_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("P_UPDATED_DATE")]
        public DateTime UpdatedDate { get; set; }

        [Columns("P_ACTIVE")]
        public string Active { get; set; }

        [Columns("P_ID")]
        public int Id { get; set; }
    }
}