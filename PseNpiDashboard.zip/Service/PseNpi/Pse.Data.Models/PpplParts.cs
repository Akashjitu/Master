//using Oracle.Data.Access;

//namespace Pse.Data.Models
//{
//    internal class PpplParts
//    {
//        [Columns("Keycode")]
//        public string Keycode { get; set; }

//        [Columns("IPDS_Current_Phase")]
//        public string IPDS_Current_Phase { get; set; }

//        [Columns("Index_Record_ID")]
//        public string Index_Record_ID { get; set; }

//        [Columns("Honeywell_Part_Number")]
//        public string Honeywell_Part_Number { get; set; }

//        [Columns("Part_Description")]
//        public string Part_Description { get; set; }

//        [Columns("End_Item_LRU")]
//        public string End_Item_LRU { get; set; }

//        [Columns("Make_Buy")]
//        public string Make_Buy { get; set; }

//        [Columns("Production_Site")]
//        public string Production_Site { get; set; }

//        [Columns("Qty_Per_Shipset;")]
//        public string Qty_Per_Shipset { get; set; }

//        [Columns("AME_NPD_Engineer")]
//        public string AME_NPD_Engineer { get; set; }

//        [Columns("Sourcing")]
//        public string Sourcing { get; set; }

//        [Columns("G_S_UPC_FRP_Target")]
//        public string G_S_UPC_FRP_Target { get; set; }

//        [Columns("UPC_FRP_Predict")]
//        public string UPC_FRP_Predict { get; set; }

//        [Columns("UPC_Index")]
//        public string UPC_Index { get; set; }

//        [Columns("UPC_Index_Health")]
//        public string UPC_Index_Health { get; set; }

//        [Columns("UPC_5YR_FI_M")]
//        public string UPC_5YR_FI_M { get; set; }

//        [Columns("UPC_5YR_FI_M_Health")]
//        public string UPC_5YR_FI_M_Health { get; set; }

//        [Columns("APQP_Level")]
//        public string APQP_Level { get; set; }

//        [Columns("RTY_Validation_Method")]
//        public string RTY_Validation_Method { get; set; }

//        [Columns("RTY_FRP_Target_")]
//        public string RTY_FRP_Target_ { get; set; }

//        [Columns("RTY_Predicted")]
//        public string RTY_Predicted { get; set; }

//        [Columns("RTY_Demonstrated")]
//        public string RTY_Demonstrated { get; set; }

//        [Columns("RTY_Health")]
//        public string RTY_Health { get; set; }

//        [Columns("MRL_Score")]
//        public string MRL_Score { get; set; }

//        [Columns("MRL_Health")]
//        public string MRL_Health { get; set; }

//        [Columns("MRL_Risk")]
//        public string MRL_Risk { get; set; }

//        [Columns("Transition")]
//        public string New_Factory_Transition { get; set; }

//        [Columns("Transition_Health")]
//        public string New_Factory_Transition_Health { get; set; }

//        [Columns("Process")]
//        public string New_Alt_Process { get; set; }

//        [Columns("Process_Health")]
//        public string New_Alt_Process_Health { get; set; }

//        [Columns("New_Parts")]
//        public string New_Parts { get; set; }

//        [Columns("Parts_on_Contract")]
//        public string New_Parts_on_Contract { get; set; }

//        [Columns("Parts_ESE_Feedback")]
//        public string of_New_Parts_with_ESE_Feedback { get; set; }

//        [Columns("Contract_Report")]
//        public string New_Parts_on_Contract_Report { get; set; }

//        [Columns("ESE_Feedback_Report")]
//        public string New_Parts_with_ESE_Feedback_Report { get; set; }

//        [Columns("Edited_by")]
//        public string Edited_by { get; set; }
//    }
//}