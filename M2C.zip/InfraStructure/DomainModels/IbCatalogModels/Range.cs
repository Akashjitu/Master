﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Range.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.IbCatalogModels
{
    /// <summary>
    /// Class Range.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Range
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the ops description.
        /// </summary>
        /// <value>The ops description.</value>
        public string OpsDescription { get; set; }

        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>The created date.</value>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the updated date.
        /// </summary>
        /// <value>The updated date.</value>
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Gets or sets the sub ranges.
        /// </summary>
        /// <value>The sub ranges.</value>
        public List<SubRange> SubRanges { get; set; } = new List<SubRange>();
        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        public List<Product> Products { get; set; } = new List<Product>();

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public static void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Range>()
             .HasMany(s => s.SubRanges).WithOne(i => i.Range).HasForeignKey(oi => oi.RangeId);
            modelBuilder.Entity<Range>()
            .HasMany(s => s.Products).WithOne(i => i.Range).HasForeignKey(oi => oi.RangeId);
            modelBuilder.Entity<Range>().Property(a => a.Id).ValueGeneratedOnAdd();
        }
    }
}