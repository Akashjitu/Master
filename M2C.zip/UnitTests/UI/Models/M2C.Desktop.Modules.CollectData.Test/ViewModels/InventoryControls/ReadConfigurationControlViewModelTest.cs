using System.Collections.Generic;
using System.Linq;
using M2C.Business.Contracts;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.Test.MOCK;
using M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Prism.Events;

namespace M2C.Desktop.Modules.CollectData.Test.ViewModels.InventoryControls
{
    [TestClass]
    public class ReadConfigurationControlViewModelTest
    {
        private ReadConfigurationControlViewModel _readConfigurationControlViewModel;
        private ICommonInventoryReference _commonInventoryReference;
        private IEventAggregator _ieventAggregator;
        [TestInitialize]
        public void Setup()
        {
            _commonInventoryReference = Substitute.For<ICommonInventoryReference>();
            _ieventAggregator = Substitute.For<IEventAggregator>();
            _readConfigurationControlViewModel = new ReadConfigurationControlViewModel(_commonInventoryReference, _ieventAggregator);
            _commonInventoryReference.GetProductsStartWithIdentifier(Arg.Any<string>()).Returns(MockProvider.GetProducts());

        }

        [TestMethod]
        public void ShouldReturnListOfProductModelsWhenProvideConfigFile()
        {
            var missingProduct= new List<string>();
            var products = _readConfigurationControlViewModel.GetProductModelByConfigParser(@"MOCK\7793new.FEF", ref missingProduct);
            Assert.IsNotNull(products);
            Assert.IsTrue(products.Any());
            Assert.IsTrue(products.Any(i=>i.Identifier == "TSXP57302M"));
            Assert.IsTrue(products.Any(i => i.Quantity == "1"));
        }

        [TestMethod]
        public void ShouldReturnEmptyListOfProductModelsWhenProvideConfigFileEmpty()
        {
            var missingProduct = new List<string>();
            var products = _readConfigurationControlViewModel.GetProductModelByConfigParser(null, ref missingProduct);
            Assert.IsNotNull(products);
            Assert.IsTrue(products!=null);
            Assert.IsTrue(!products.Any());
        }

        [TestMethod]
        public void ShouldReturnEmptyListOfProductModelsWhenFileNotExist()
        {
            var missingProduct = new List<string>();
            var products = _readConfigurationControlViewModel.GetProductModelByConfigParser("7793new.FEF", ref missingProduct);
            Assert.IsNotNull(products);
            Assert.IsTrue(products != null);
            Assert.IsTrue(!products.Any());
        }

        [TestMethod]
        public void ShouldShowValidConfigMessageWhenFileIsCorruptedOrNotConfigFile()
        {
            var missingProduct = new List<string>();
            var products = _readConfigurationControlViewModel.GetProductModelByConfigParser(@"MOCK\diagwrn.xml", ref missingProduct);
           
            Assert.IsTrue(products == null);
            Assert.IsTrue(_readConfigurationControlViewModel.ValidConfigMessage ==
                          CollectionConstant.MessageCorruptedFile);
        }



        [TestMethod]
        public void ShouldReturnProductswithMissingProducts()
        {
            var missingProduct = new List<string>();
            var products = _readConfigurationControlViewModel.GetProductModelByConfigParser(@"MOCK\7793new.FEF", ref missingProduct);
            Assert.IsNotNull(products);
            Assert.IsTrue(products.Any());
            Assert.IsTrue(products.Any(i => i.Identifier == "TSXP57302M"));
            Assert.IsTrue(products.Any(i => i.Quantity == "1"));
            Assert.IsTrue(missingProduct.Count == 7);
            Assert.IsTrue(_readConfigurationControlViewModel.ValidConfigMessage == string.Format(CollectionConstant.MessageParameterProductNotFound, string.Join("\n", missingProduct)));
        }

    }
}