﻿// ***********************************************************************
// Assembly         : AuthMiddleWare
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="TokenJsonModel.cs" company="Schneider Electric">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace AuthMiddleWare.Models
{
    /// <summary>
    /// Class TokenJsonModel.
    /// </summary>
    public class TokenJsonModel
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        public string Email { get; set; }
    }
}