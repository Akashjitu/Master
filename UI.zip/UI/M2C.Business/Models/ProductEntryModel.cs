﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProductEntryModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class ProductEntryModel.
    /// </summary>
    public class ProductEntryModel
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>The currency.</value>
        public string Currency { get; set; }
        /// <summary>
        /// Gets or sets the actual product version.
        /// </summary>
        /// <value>The actual product version.</value>
        public string ActualProductVersion { get; set; }
        /// <summary>
        /// Gets or sets the actual software version.
        /// </summary>
        /// <value>The actual software version.</value>
        public string ActualSoftwareVersion { get; set; }
        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        public double Quantity { get; set; }
        /// <summary>
        /// Gets or sets the serial number1.
        /// </summary>
        /// <value>The serial number1.</value>
        public int SerialNumber1 { get; set; }
        /// <summary>
        /// Gets or sets the serial number2.
        /// </summary>
        /// <value>The serial number2.</value>
        public int SerialNumber2 { get; set; }
        /// <summary>
        /// Gets or sets the note1.
        /// </summary>
        /// <value>The note1.</value>
        public string Note1 { get; set; }
        /// <summary>
        /// Gets or sets the note2.
        /// </summary>
        /// <value>The note2.</value>
        public string Note2 { get; set; }
        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        public string Comment { get; set; }
        /// <summary>
        /// Gets or sets the misc1.
        /// </summary>
        /// <value>The misc1.</value>
        public string Misc1 { get; set; }
        /// <summary>
        /// Gets or sets the misc2.
        /// </summary>
        /// <value>The misc2.</value>
        public string Misc2 { get; set; }
        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>The created date.</value>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the updated date.
        /// </summary>
        /// <value>The updated date.</value>
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        public Nullable<int> ProductId { get; set; }
        /// <summary>
        /// Gets or sets the product.
        /// </summary>
        /// <value>The product.</value>
        public virtual ProductModel Product { get; set; }
    }
}
