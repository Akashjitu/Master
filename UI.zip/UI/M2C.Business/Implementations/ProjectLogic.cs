﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectLogic.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Mappers.ProjectMap;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using Microsoft.Data.Sqlite;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class ProjectLogic.
    /// Implements the <see cref="M2C.Business.Contracts.IProjectLogic" />
    /// </summary>
    /// <seealso cref="M2C.Business.Contracts.IProjectLogic" />
    public class ProjectLogic : IProjectLogic
    {
        /// <summary>
        /// The database context factory
        /// </summary>
        private readonly IDbContextFactory _dbContextFactory;

        /// <summary>
        /// The project queries
        /// </summary>
        private readonly IProjectQueries _projectQueries;

        /// <summary>
        /// The project business model
        /// </summary>
        private readonly IProjectBusinessModelBuilder _projectBusinessModel;

        /// <summary>
        /// The project database model builder
        /// </summary>
        private readonly IProjectDbModelBuilder _projectDbModelBuilder;

        /// <summary>
        /// The synchronize service queries
        /// </summary>
        private readonly ISyncServiceQueries _syncServiceQueries;

        /// <summary>
        /// The inventory mapper
        /// </summary>
        private IInventoryMapper _inventoryMapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectLogic" /> class.
        /// </summary>
        /// <param name="dbContextFactory">The database context factory.</param>
        /// <param name="projectQueries">The project queries.</param>
        /// <param name="projectBusinessModel">The project business model.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        /// <param name="projectDbModelBuilder">The project database model builder.</param>
        public ProjectLogic(IDbContextFactory dbContextFactory,
            IProjectQueries projectQueries,
            IProjectBusinessModelBuilder projectBusinessModel,
            IInventoryMapper inventoryMapper,
            IProjectDbModelBuilder projectDbModelBuilder,
            ISyncServiceQueries syncServiceQueries)
        {
            _inventoryMapper = inventoryMapper;
            _projectDbModelBuilder = projectDbModelBuilder;
            this._syncServiceQueries = syncServiceQueries;
            _projectBusinessModel = projectBusinessModel;
            _dbContextFactory = dbContextFactory;
            _projectQueries = projectQueries;
        }

        /// <summary>
        /// Gets all project ids.
        /// </summary>
        /// <returns>List&lt;System.Int32&gt;.</returns>
        /// <exception cref="NotImplementedException"></exception>
        public List<ProjectContextModel> GetAllProjects()
        {
            var projects = _projectQueries.GetOnlyProjects();
            return projects.Select(project => _projectBusinessModel.GetProjectContextModel(project)).Where(projectContextModel => projectContextModel != null).ToList();
        }

        /// <summary>
        /// Get Projects With Customers
        /// </summary>
        /// <returns>List&lt;ProjectContextModel&gt;.</returns>
        public List<ProjectContextModel> GetProjectsWithCustomers()
        {
            var projects = _projectQueries.GetOnlyProjects();
            var contextModel = projects.Select(project => _projectBusinessModel.LoadProjectsWithCustomers(project)).Where(projectContextModel => projectContextModel != null).ToList();
            return contextModel;
        }

        /// <summary>
        /// Gets the project.
        /// </summary>
        /// <param name="projectId">The project identifier.</param>
        /// <returns>ProjectContextModel.</returns>
        /// <exception cref="NotImplementedException"></exception>
        public ProjectContextModel GetProject(int projectId)
        {
            DomainModels.ProjectModels.Project project = _projectQueries.GetProject(projectId);
            _projectBusinessModel.UpdateInventoryBuilderCallback = this.UpdateInventoryCallback;
            return project == null ? null : _projectBusinessModel.GetProjectContextModel(project);
        }

        /// <summary>
        /// Reads the Project.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <returns>ProjectContextModel.</returns>
        public ProjectContextModel ReadProject(string filePath)
        {
            var inventories = new ObservableCollection<Inventory>();
            var projectContextModel = JsonConvert.DeserializeObject<ProjectContextModel>(File.ReadAllText(filePath));
            bool IsUpdateNeeded = false;

            if (projectContextModel.InstalledBase?.MasterInventories != null)
            {
                inventories.AddRange(projectContextModel.InstalledBase.MasterInventories);
            }
            if (projectContextModel.TechnicalResources?.MasterInventories != null)
            {
                inventories.AddRange(projectContextModel.TechnicalResources.MasterInventories);
            }
            if (!CheckProjectIsUpdated(projectContextModel))
            {
                if (MessageBox.Show("New Product updates are available. Do you want to Proceed ? ", "Project Update",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    _projectBusinessModel.UpdateInventoryBuilderCallback = (IReadOnlyCollection<string> messages) =>
                    {
                        IsUpdateNeeded = this.UpdateInventoryCallback(messages);
                        return IsUpdateNeeded;
                    };
                    IsUpdateNeeded = true;
                }
                else
                {
                    _projectBusinessModel.UpdateInventoryBuilderCallback = null;
                    IsUpdateNeeded = false;
                }
            }
            inventories = _projectBusinessModel.UpdateInventoriesWithDatabase(_inventoryMapper.Map(inventories));
            projectContextModel.TechnicalResources?.MasterInventories?.Clear();
            projectContextModel.InstalledBase?.MasterInventories?.Clear();

            var technicalResourcesInventories = inventories.Where(i => !string.IsNullOrEmpty(i.MaintenanceZone)).ToList();
            var installBasedInventories = inventories.Where(i => string.IsNullOrEmpty(i.MaintenanceZone)).ToList();

            projectContextModel.TechnicalResources?.MasterInventories?.AddRange(technicalResourcesInventories);
            projectContextModel.InstalledBase?.MasterInventories?.AddRange(installBasedInventories);

            //updating the Master inventories reference
            var nodes = projectContextModel.InstalledBase?.GetAllNodes();
            if (projectContextModel.InstalledBase?.MasterInventories != null)
            {
                if (nodes != null)
                    nodes.ForEach(
                        i => i.MasterInventories = projectContextModel?.InstalledBase?.MasterInventories);
            }

            var trNodes = projectContextModel.TechnicalResources?.GetAllNodes();
            if (projectContextModel.TechnicalResources?.MasterInventories != null)
            {
                if (trNodes != null)
                    trNodes.ForEach(i =>
                        i.MasterInventories = projectContextModel?.TechnicalResources?.MasterInventories);
            }

            if (IsUpdateNeeded)
            {
                projectContextModel.Version = getSyncHistoryLatestVersion();
            }

            return projectContextModel;
        }

        /// <summary>
        /// Saves the specified project model.
        /// </summary>
        /// <param name="projectModel">The project model.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        /// <exception cref="Exception">Save Failed! Error({error.Message})</exception>
        public bool Save(ref ProjectContextModel projectModel)
        {
            try
            {
                using (var projectDbContext = _dbContextFactory.Create<IProjectDbContext>())
                {
                    var dbProject = _projectDbModelBuilder.GetProject(projectModel, projectDbContext);

                    //Insert version on Create
                    //Update version on user demand
                    if (dbProject.ProjectID == 0 && projectModel.isOpenedFromFile == false)
                    {
                        DomainModels.IbCatalogModels.SyncHistory latestVersion = _syncServiceQueries.GetAllSyncHistory(3)?.FirstOrDefault();
                        if (latestVersion != null)
                        {
                            dbProject.Version = Convert.ToInt32(latestVersion.Version);
                        }
                    }

                    projectDbContext.SaveChanges();
                    projectModel.ProjectId = dbProject.ProjectID;
                    projectModel.Version = dbProject.Version;
                }
            }
            catch (Exception ex)
            {
                if (ex.GetBaseException().GetType() == typeof(SqliteException))
                {
                    var error = ((SqliteException)ex.InnerException);
                    if (error != null)
                    {
                        throw new Exception($"Save Failed! Error({error.Message})");
                    }
                }
                return false;
            }

            return true;
        }

        /// <summary>
        /// Checks the project is updated.
        /// </summary>
        /// <param name="projectModel">The project model.</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public bool CheckProjectIsUpdated(ProjectContextModel projectModel)
        {
            return projectModel.Version >= getSyncHistoryLatestVersion();
        }

        public int getSyncHistoryLatestVersion()
        {
            DomainModels.IbCatalogModels.SyncHistory latestVersion = _syncServiceQueries.GetAllSyncHistory(3)?.FirstOrDefault();
            if (latestVersion != null)
            {
                return Convert.ToInt32(latestVersion.Version);
            }
            else
            {
                return 0;
            }
        }

        /// <summary>
        /// Gets or sets the update inventory callback.
        /// </summary>
        /// <value>
        /// The update inventory callback.
        /// </value>
        public Predicate<IReadOnlyCollection<string>> UpdateInventoryCallback { get; set; }
    }
}