﻿using M2C.Business.Models;
using M2C.Business.Models.Chart;
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    /// <summary>
    /// Provide Simple Mapping Elements
    /// </summary>
    public class MappingElementProvider : IMappingElementProvider
    {
        /// <summary>
        /// Get Mapping Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetMappingBarElements(ChartParameter chartParameter, NodeType type = NodeType.OPEN_CONFIG)
        {
            var elements = new ChartBarElements();
            var nodeType = chartParameter.SelectedParameterNode.NodeType;
            var selectedNodes = chartParameter.SelectedParameterNode.Nodes;

            var allConfigurationNodes = chartParameter.AllParameterNodes
                .Where(conf => conf.NodeType == type).SelectMany(i => i.Nodes).ToList();

            var numberString = chartParameter.SelectedElementNumber; // total number selected by user...
            if (numberString == "All")
            {
                if (nodeType == type)
                {
                    foreach (var node in allConfigurationNodes)
                        BindNormalMapping(node.Name, node.Inventories, elements);
                }
                else
                {
                    foreach (var node in selectedNodes)
                    {
                        var inventories = allConfigurationNodes.Where(i =>
                            i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                            i.ParentNodeAndNodeType[nodeType].Id == node.Id).SelectMany(i => i.Inventories).ToList();
                        BindNormalMapping(node.Name, inventories, elements);
                    }
                }
            }
            else // find the user selection and loop till selection & rest added on Others
            {
                int.TryParse(numberString, out var num);
                int tempNum = 1;
                if (nodeType == type)
                {
                    foreach (var node in allConfigurationNodes)
                    {
                        BindNormalMapping(tempNum < num ? node.Name : "Others", node.Inventories, elements);
                        tempNum++;
                    }
                }
                else
                {
                    foreach (var node in selectedNodes)
                    {
                        var inventories = allConfigurationNodes.Where(i =>
                            i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                            i.ParentNodeAndNodeType[nodeType].Id == node.Id).SelectMany(i => i.Inventories).ToList();
                        BindNormalMapping(tempNum < num ? node.Name : "Others", inventories, elements);
                        tempNum++;
                    }
                }
            }

            return elements;
        }

        /// <summary>
        /// Binds the normal mapping.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="inventories">The inventories.</param>
        private static void BindNormalMapping(string name, ICollection<Inventory> inventories, ChartBarElements chartBarElements)
        {
            var chartBarElement = new ChartBarElement()
            {
                ConfigCount = inventories.Sum(k => k.Quantity),
                Name = name
            };
            var isChartBarElement = chartBarElements.ChartElements.FirstOrDefault(i => i.Name == chartBarElement.Name);
            if (isChartBarElement == null)
                chartBarElements.ChartElements.Add(chartBarElement);
            else
                isChartBarElement.ConfigCount += chartBarElement.ConfigCount;
        }
    }
}