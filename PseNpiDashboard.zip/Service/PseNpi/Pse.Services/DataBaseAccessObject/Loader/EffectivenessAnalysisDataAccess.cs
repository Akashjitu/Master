﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class EffectivenessAnalysisDataAccess : IEffectivenessAnalysisDataAccess
    {
        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisByPart(EffectivenessAnalysis effectivenessAnalysis)
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysis>())
            {
                var data = dao.LoadByInput(effectivenessAnalysis, "PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EFFECT_ANSIS_BY_PART");
                var returndata = new List<EffectivenessAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisById(EffectivenessAnalysis effectivenessAnalysis)
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysis>())
            {
                var data = dao.LoadByInput(effectivenessAnalysis, "PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EFFECT_ANSIS_BY_ID");
                var returndata = new List<EffectivenessAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisByCreationDate(EffectivenessAnalysis effectivenessAnalysis)
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysis>())
            {
                var data = dao.LoadByInput(effectivenessAnalysis, "PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EF_ANSIS_BY_MO_YY");
                var returndata = new List<EffectivenessAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<EffectivenessAnalysis> LoadEffectivenesAnalysis()
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysis>())
            {
                var data = dao.Load("PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EFFECT_ANSIS");
                var returndata = new List<EffectivenessAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }
    }
}