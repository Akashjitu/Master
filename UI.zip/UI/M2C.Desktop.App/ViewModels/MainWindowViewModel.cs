﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="MainWindowViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using AuthMiddleWare.Models;
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Core.Utils;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Windows;
using WinRegistryServices.Contracts;

namespace M2C.Desktop.App.ViewModels
{
    /// <summary>
    /// Class MainWindowViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class MainWindowViewModel : BindableBase
    {
        /// <summary>
        /// The title
        /// </summary>
        private string _title = "M2C Application";

        /// <summary>
        /// The loggedin user
        /// </summary>
        private string _loggedinUser;

        /// <summary>
        /// The busy overlay is busy
        /// </summary>
        private bool busyOverlayIsBusy = false;

        /// <summary>
        /// The busy overlay busy message
        /// </summary>
        private string busyOverlayBusyMessage = "Loading...";

        /// <summary>
        /// The is notification visible
        /// </summary>
        private bool isNotificationVisible = false;

        /// <summary>
        /// The notification text
        /// </summary>
        private string notificationText;

        /// <summary>
        /// The project synchronize command
        /// </summary>
        private DelegateCommand _projectSyncCommand;

        /// <summary>
        /// The dialog service
        /// </summary>
        private readonly IDialogService _dialogService;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator eventAggregator;

        /// <summary>
        /// The shared context
        /// </summary>
        private readonly ISharedContextService sharedContext;

        /// <summary>
        /// The global menu comands
        /// </summary>
        private readonly IGlobalMenuComands globalMenuComands;

        /// <summary>
        /// The application configurations
        /// </summary>
        private readonly IAppConfigurations appConfigurations;

        /// <summary>
        /// The registry store
        /// </summary>
        private readonly IRegistryStoreManger registryStore;

        /// <summary>
        /// The product synchronize
        /// </summary>
        private readonly IProductSync productSync;

        /// <summary>
        /// The project logic
        /// </summary>
        private readonly IProjectLogic projectLogic;

        /// <summary>
        /// My profile
        /// </summary>
        private readonly IMyProfileLogic _myProfile;

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>The title.</value>
        public string Title
        {
            get => _title;
            set => SetProperty(ref _title, value);
        }

        /// <summary>
        /// Gets or sets the loggedin user.
        /// </summary>
        /// <value>The loggedin user.</value>
        public string LoggedinUser
        {
            get => _loggedinUser; set => SetProperty(ref _loggedinUser, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is notification visible.
        /// </summary>
        /// <value><c>true</c> if this instance is notification visible; otherwise, <c>false</c>.</value>
        public bool IsNotificationVisible { get => isNotificationVisible; set => SetProperty(ref isNotificationVisible, value); }

        /// <summary>
        /// Gets or sets the notification text.
        /// </summary>
        /// <value>The notification text.</value>
        public string NotificationText { get => notificationText; set => SetProperty(ref notificationText, value); }

        /// <summary>
        /// Gets or sets the window loaded.
        /// </summary>
        /// <value>The window loaded.</value>
        public DelegateCommand WindowLoaded { get; set; }

        /// <summary>
        /// Gets the shared context.
        /// </summary>
        /// <value>The shared context.</value>
        public ISharedContextService SharedContext => sharedContext;

        /// <summary>
        /// Gets the global menu comands.
        /// </summary>
        /// <value>The global menu comands.</value>
        public IGlobalMenuComands GlobalMenuComands => globalMenuComands;

        /// <summary>
        /// Occurs when [loading window state change].
        /// </summary>
        public event EventHandler<bool> LoadingWindowStateChange;

        /// <summary>
        /// Gets the project synchronize command.
        /// </summary>
        /// <value>The project synchronize command.</value>
        private DelegateCommand ProjectSyncCommand => _projectSyncCommand ?? (_projectSyncCommand = new DelegateCommand(onProjectSync));

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindowViewModel" /> class.
        /// </summary>
        /// <param name="myProfile">My profile.</param>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="sharedContext">The shared context.</param>
        /// <param name="globalMenuComands">The global menu comands.</param>
        /// <param name="appConfigurations">The application configurations.</param>
        /// <param name="registryStore">The registry store.</param>
        /// <param name="productSync">The product synchronize.</param>
        /// <param name="projectLogic">The project logic.</param>
        /// <exception cref="ArgumentNullException">dialogService</exception>
        /// <exception cref="ArgumentNullException">eventAggregator</exception>
        /// <exception cref="ArgumentNullException">sharedContext</exception>
        /// <exception cref="ArgumentNullException">globalMenuComands</exception>
        /// <exception cref="ArgumentNullException">appConfigurations</exception>
        /// <exception cref="ArgumentNullException">registryStore</exception>
        /// <exception cref="ArgumentNullException">productSync</exception>
        /// <exception cref="ArgumentNullException">projectLogic</exception>
        /// <exception cref="ArgumentNullException">myProfile</exception>
        /// <exception cref="ArgumentNullException">dialogService</exception>
        /// <exception cref="ArgumentNullException">eventAggregator</exception>
        /// <exception cref="ArgumentNullException">sharedContext</exception>
        /// <exception cref="ArgumentNullException">globalMenuComands</exception>
        /// <exception cref="ArgumentNullException">appConfigurations</exception>
        /// <exception cref="ArgumentNullException">registryStore</exception>
        /// <exception cref="ArgumentNullException">productSync</exception>
        public MainWindowViewModel(IMyProfileLogic myProfile, IDialogService dialogService,
            IEventAggregator eventAggregator, ISharedContextService sharedContext,
            IGlobalMenuComands globalMenuComands, IAppConfigurations appConfigurations,
            IRegistryStoreManger registryStore,
            IProductSync productSync, IProjectLogic projectLogic)
        {
            WindowLoaded = new DelegateCommand(ExecuteWindowLoaded);
            _dialogService = dialogService ?? throw new ArgumentNullException(nameof(dialogService));
            this.eventAggregator = eventAggregator ?? throw new ArgumentNullException(nameof(eventAggregator));
            this.sharedContext = sharedContext ?? throw new ArgumentNullException(nameof(sharedContext));
            this.globalMenuComands = globalMenuComands ?? throw new ArgumentNullException(nameof(globalMenuComands));
            this.appConfigurations = appConfigurations ?? throw new ArgumentNullException(nameof(appConfigurations));
            this.registryStore = registryStore ?? throw new ArgumentNullException(nameof(registryStore));
            this.productSync = productSync ?? throw new ArgumentNullException(nameof(productSync));
            this.projectLogic = projectLogic ?? throw new ArgumentNullException(nameof(projectLogic)); ;
            _myProfile = myProfile ?? throw new ArgumentNullException(nameof(myProfile));

            this.globalMenuComands.ProjectSyncCommand.RegisterCommand(ProjectSyncCommand);

            this.eventAggregator.GetEvent<ProjectChangeEvent>().Subscribe(ProjectChange);
            this.eventAggregator.GetEvent<BusyOverlayEvent>().Subscribe(BusyOverlayChange);
        }

        /// <summary>
        /// Executes the window loaded.
        /// </summary>
        public void ExecuteWindowLoaded()
        {
            LoggedinUser = "Guest";

            _dialogService.ShowDialog("LoginDialog", null, (result) =>
            {
                if (result.Result == ButtonResult.Abort || result.Result == ButtonResult.None)
                {
                    Application.Current.Shutdown();
                }
                else
                {
                    var data = result.Parameters.GetValue<TokenJsonModel>("TokenData");
                    LoggedinUser = data.Name;
                }
            });

            if (string.IsNullOrEmpty(_myProfile.GetProfile()?.FirstName))
            {
                _dialogService.ShowDialog("MyProfileDialog", null, null);
            }

            initiateProductSync();
        }

        /// <summary>
        /// Subscribe call back for ProjectContextModel changes from child VM
        /// </summary>
        /// <param name="contextModel">Project context model.</param>
        public void ProjectChange(ProjectContextModel contextModel)
        {
            if (contextModel == null)
            {
                Title = $"M2C Application";
            }
            else
            {
                if (string.IsNullOrEmpty(contextModel?.Customer?.ProjectName))
                {
                    Title = $"M2C Application";
                }
                else
                {
                    Title = $"M2C Application ({contextModel?.Customer?.ProjectName})";
                    this.sharedContext.IsSavePending = true;
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [busy overlay is busy].
        /// </summary>
        /// <value><c>true</c> if [busy overlay is busy]; otherwise, <c>false</c>.</value>
        public bool BusyOverlayIsBusy { get => busyOverlayIsBusy; set => SetProperty(ref busyOverlayIsBusy, value); }

        /// <summary>
        /// Gets or sets the busy overlay busy message.
        /// </summary>
        /// <value>The busy overlay busy message.</value>
        public string BusyOverlayBusyMessage { get => busyOverlayBusyMessage; set => SetProperty(ref busyOverlayBusyMessage, value); }

        /// <summary>
        /// Busies the overlay change.
        /// </summary>
        /// <param name="msg">The MSG.</param>
        public void BusyOverlayChange(OverlayMessage msg)
        {
            if (!string.IsNullOrWhiteSpace(msg.Message))
            {
                BusyOverlayBusyMessage = msg.Message;
            }

            if (BusyOverlayIsBusy && msg.status == OverlayStatus.HIDDEN)
            {
                BusyOverlayIsBusy = false;
                LoadingWindowStateChange?.Invoke(this, false);
            }
            else if (!BusyOverlayIsBusy && msg.status == OverlayStatus.VISIBLE)
            {
                BusyOverlayIsBusy = true;
                LoadingWindowStateChange?.Invoke(this, true);
            }
        }

        /// <summary>
        /// Initiates the product synchronize.
        /// </summary>
        private void initiateProductSync()
        {
            System.Threading.ThreadPool.QueueUserWorkItem(
             o =>
             {
                 productSync.SyncProduct((SyncProcessModel model) =>
                 {
                     if (model.Status == ProcessStatus.COMPLETED)
                     {
                         IsNotificationVisible = false;
                         NotificationText = "";
                         this.eventAggregator.GetEvent<ServerSyncEvent>().Publish("ProductSync_completed");
                     }
                     else
                     {
                         IsNotificationVisible = true;
                         NotificationText = model.Message;
                     }
                 });
             });
        }

        /// <summary>
        /// Initiates the project synchronize.
        /// </summary>
        private void onProjectSync()
        {
            if (!NetworkHelper.IsConnectedToInternet())
            {
                MessageBox.Show("Need Internet connection for sync projects, (retry after enabling Internet.)", "Network Error",
                    MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            else
            {
                System.Threading.ThreadPool.QueueUserWorkItem(
                o =>
                {
                    productSync.SyncProjects((SyncProcessModel model) =>
                    {
                        if (model.Status == ProcessStatus.COMPLETED)
                        {
                            IsNotificationVisible = false;
                            NotificationText = "";
                            this.eventAggregator.GetEvent<ServerSyncEvent>().Publish("ProjectSync");
                        }
                        else
                        {
                            IsNotificationVisible = true;
                            NotificationText = model.Message;
                        }
                    });
                });
            }
        }
    }
}
