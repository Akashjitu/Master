﻿using Pse.Data.Models;
using Pse.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class PliSummaryController : ApiController
    {
        ISpeService _service;
        public PliSummaryController(ISpeService service)
        {
            _service = service;

        }

        [HttpGet]
        public HttpResponseMessage GetPliSummary()
        {
            var cp = _service.LoadPli();
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        [Route("api/PliSummary/loadbycriteria")]
        public HttpResponseMessage GetByCriteria(Pli criteria)
        {
            var allData = _service.LoadPli();

            if (!string.IsNullOrEmpty(criteria.SBU))
                allData = allData.Where(i => string.Compare(i.SBU, criteria.SBU, StringComparison.OrdinalIgnoreCase) == 0).ToList();

            if (!string.IsNullOrEmpty(criteria.GBE))
                allData = allData.Where(i => string.Compare(i.GBE, criteria.GBE, StringComparison.OrdinalIgnoreCase) == 0).ToList();


            if (!string.IsNullOrEmpty(criteria.IpdsPhase))
                allData = allData.Where(i => string.Compare(i.IpdsPhase, criteria.IpdsPhase, StringComparison.OrdinalIgnoreCase) == 0).ToList();


            if (!string.IsNullOrEmpty(criteria.PliRating))
                allData = allData.Where(i => string.Compare(i.PliRating, criteria.PliRating, StringComparison.OrdinalIgnoreCase) == 0).ToList();

            return Request.CreateResponse(HttpStatusCode.OK, allData, JsonMediaTypeFormatter.DefaultMediaType);
        }


    }
}
