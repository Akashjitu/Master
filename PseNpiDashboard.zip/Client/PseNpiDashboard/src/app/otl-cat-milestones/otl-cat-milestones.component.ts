import { Component, OnInit, TemplateRef } from '@angular/core';
import { otlCatMilestonesColumns } from './otlCatMilestonesColumns';
import { HttpClient } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { otlCatMilestonesService } from '../services/otlCatMilestones.service';
import { IAppState } from '../store/otlCatMilestones/otlCatMilestonesReducer';

@Component({
  selector: 'app-otl-cat-milestones',
  templateUrl: './otl-cat-milestones.component.html',
  styleUrls: ['./otl-cat-milestones.component.sass']
})
export class OtlCatMilestonesComponent implements OnInit {

  modalRef: BsModalRef;
  gridApi;
  gridColumnApi;
  isExportFilter = false;
  columnDefs;
  defaultColDef;
  rowData: any;
  searchText;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  theme = 'ag-theme-balham';
  pliModel = {
    sbu: '',
    ipdsPhase: '',
    pliRating: '',
    gbe: '',
    programName:''
  }


  ngOnInit() {
  }
  constructor(private http: HttpClient, private service: otlCatMilestonesService, public store: Store<IAppState>, private modalService: BsModalService, ) {
    this.initColumns();

    this.defaultColDef = {
      resizable: true,
      sortable: true,
      enableFilter: true,
      //width: 100,
      //editable: true,
      filter: true
    };
    service.getAllEffectivenessParts();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    this.store.select('otlCatMilestonesReducer').subscribe(data => {
      this.rowData = data;
    });
    this.initColumnsList();
  }

  initColumns() {
    this.columnDefs = otlCatMilestonesColumns.columns;
  }

  autoSizeAll() {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  export() {
    if (this.isExportFilter == false) {
      this.service.reportDownloadAll();
    } else {
      this.service.reportDownloadByFilter(this.pliModel);
    }

  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(this.searchText);
  }
  onItemSelect(item: any) {
   
    this.gridColumnApi.setColumnsVisible([item], true);

  }
  onDeSelect(item: any) {
    
    this.gridColumnApi.setColumnsVisible([item], false);

  }
  onSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], true);
    }
  }

  onDeSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], false);
    }
  }
  initColumnsList() {
    var allColumnIds = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'colId',
      textField: 'headerName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.gridColumnApi.getAllColumns().forEach(function (column) {
      
      allColumnIds.push({ colId: column.colId, headerName: column.colId });

    });
    this.selectedItems = [
      { colId: 'keyCode', headerName: 'keyCode' },
      { colId: 'programName', headerName: 'programName' }
    ];

    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      if (allColumns[index].visible === true) {
        this.selectedItems.push({ colId: allColumns[index].colId, headerName: allColumns[index].colId })
      }

    }
    this.dropdownList = allColumnIds;

  }

  showTemplate(template: TemplateRef<any>) {
      this.modalRef = this.modalService.show(template);
  }

  onFilterSubmit() {
    this.service.loadByFilter(this.pliModel);
    this.modalRef.hide();
  }

  onExportChange(value) {
    this.isExportFilter = value;
  }

  clearFilters() {

    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }
}

