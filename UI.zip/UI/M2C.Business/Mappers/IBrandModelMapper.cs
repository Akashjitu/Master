﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IBrandModelMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using DomainModels.IbCatalogModels;
using M2C.Business.Models;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Interface IBrandModelMapper
    /// </summary>
    public interface IBrandModelMapper
    {
        /// <summary>
        /// Maps the specified brands.
        /// </summary>
        /// <param name="brands">The brands.</param>
        /// <returns>List&lt;BrandModel&gt;.</returns>
        List<BrandModel> Map(List<Brand> brands);
    }
}