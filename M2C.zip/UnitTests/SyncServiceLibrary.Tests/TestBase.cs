﻿using Moq;
using System;
using System.Collections.Generic;
using System.Text;

namespace SyncServiceLibrary.Tests
{
    public class TestBase
    {
        protected MockRepository MockRepo;

        public TestBase()
        {
            MockRepo = new MockRepository(MockBehavior.Loose);
        }
    }
}
