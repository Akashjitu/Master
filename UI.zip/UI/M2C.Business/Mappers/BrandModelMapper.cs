﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="BrandModelMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using DomainModels.IbCatalogModels;
using M2C.Business.Models;
using Schneider.M2C.OpenExcel.Parser.Model;
using System.Collections.Generic;
using System.Linq;
using M2C.Business.GlobalFields;
using Microsoft.EntityFrameworkCore.Internal;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Class BrandModelMapper.
    /// Implements the <see cref="M2C.Business.Mappers.IBrandModelMapper" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IBrandModelMapper" />
    public class BrandModelMapper : IBrandModelMapper
    {
        /// <summary>
        /// Maps the specified brands.
        /// </summary>
        /// <param name="brands">The brands.</param>
        /// <returns>List&lt;BrandModel&gt;.</returns>
        public List<BrandModel> Map(List<Brand> brands)
        {
            return brands.Select(i => new BrandModel()
            {
                CreatedDate = i.CreatedDate,
                Id = i.Id,
                Name = i.Name,
                UpdatedDate = i.UpdatedDate,
            }).ToList();
        }

        /// <summary>
        /// Maps the specified one ib catalogs.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;Brand&gt;.</returns>
        public List<Brand> Map(params OneIbCatalog[] oneIbCatalogs)
        {
            return oneIbCatalogs.DistinctBy(i => i.BrandLegacy).Select(i => new Brand
            {
                IsSeBrand = i.IsSeBrand,
                Name = i.BrandLegacy
            }).ToList();
        }

    }

}