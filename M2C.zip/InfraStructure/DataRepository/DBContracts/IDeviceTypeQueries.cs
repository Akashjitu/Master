﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="IDeviceTypeQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IDeviceTypeQueries
    /// </summary>
    public interface IDeviceTypeQueries
    {
        /// <summary>
        /// Saves the device types.
        /// </summary>
        /// <param name="deviceTypes">The device types.</param>
        void SaveDeviceTypes(List<DeviceType> deviceTypes);

        /// <summary>
        /// Loads the device types.
        /// </summary>
        /// <param name="deviceType">Type of the device.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        List<DeviceType> LoadDeviceTypes(DeviceType deviceType);

        /// <summary>
        /// Loads the device types.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        List<DeviceType> LoadDeviceTypes(string type);

        /// <summary>
        /// Gets the device types by brand and range identifier.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="rangId">The rang identifier.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        List<DeviceType> GetDeviceTypesByBrandAndRangeId(int brandId, int rangId);

        /// <summary>
        /// Loads the device types.
        /// </summary>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        List<DeviceType> LoadDeviceTypes();

        /// <summary>
        /// Gets the device types by brand identifier.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        List<DeviceType> GetDeviceTypesByBrandId(int brandId);

        /// <summary>
        /// Gets the device types by brand Id config Node Type.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="nodeType">config node type</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        List<DeviceType> GetDeviceTypesByBrandIdAndNodeType(int brandId, string nodeType);

        /// <summary>
        /// Gets the device types with Config Node Type.
        /// </summary>
        /// <param name="configNodeType">Type of the configuration node.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        List<DeviceType> GetDeviceTypesByNodeType(string configNodeType);
    }
}