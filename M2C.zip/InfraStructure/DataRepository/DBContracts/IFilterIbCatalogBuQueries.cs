﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IFilterIbCatalogBuQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogFilter;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IFilterIbCatalogBuQueries
    /// </summary>
    public interface IFilterIbCatalogBuQueries
    {
        /// <summary>
        /// Filters the ib catalog bu.
        /// </summary>
        /// <param name="filterIbCatalogBu">The filter ib catalog bu.</param>
        /// <returns>List&lt;FilterIbCatalogBu&gt;.</returns>
        List<FilterIbCatalogBu> FilterIbCatalogBu(FilterIbCatalogBu filterIbCatalogBu);

        /// <summary>
        /// Filters the ib catalog bu.
        /// </summary>
        /// <returns>List&lt;FilterIbCatalogBu&gt;.</returns>
        List<FilterIbCatalogBu> FilterIbCatalogBu();
    }
}