﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ISyncServiceQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using System;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// ISyncServiceQueries
    /// </summary>
    public interface ISyncServiceQueries
    {
        /// <summary>
        /// Gets the last synchronize date.
        /// </summary>
        /// <returns>System.Nullable&lt;DateTime&gt;.</returns>
        DateTime? GetLastSyncDate();

        /// <summary>
        /// Saves the synchronize history.
        /// </summary>
        /// <param name="syncData">The synchronize data.</param>
        /// <returns>SyncHistory.</returns>
        SyncHistory SaveSyncHistory(SyncHistory syncData);

        /// <summary>
        /// Updates the synchronize history.
        /// </summary>
        /// <param name="syncData">The synchronize data.</param>
        /// <returns>SyncHistory.</returns>
        SyncHistory UpdateSyncHistory(SyncHistory syncData);

        /// <summary>
        /// Gets all synchronize history.
        /// </summary>
        /// <returns></returns>
        List<SyncHistory> GetAllSyncHistory(int? StatusFilter);
    }
}