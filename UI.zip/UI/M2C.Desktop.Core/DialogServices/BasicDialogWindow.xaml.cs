﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="BasicDialogWindow.xaml.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Services.Dialogs;

namespace M2C.Desktop.Core.DialogServices
{
    /// <summary>
    /// Interaction logic for BasicDialogWindow.xaml
    /// </summary>
    public partial class BasicDialogWindow : IDialogWindow
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BasicDialogWindow" /> class.
        /// </summary>
        public BasicDialogWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Gets or sets the result.
        /// </summary>
        /// <value>The result.</value>
        public IDialogResult Result { get; set; }
    }
}
