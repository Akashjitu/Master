import { FracaInfo } from './fraca-info';

export interface FracaData {
    FracaInfo: FracaInfo[]
    UserName: string;
}
