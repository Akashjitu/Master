

import { Action } from '@ngrx/store'
import { FracaInfo } from './../models/fraca-info'
import * as FracaAction from './fracaAction'
import { FracaData } from '../models/fraca-data';

export interface IAppState {
    readonly fracaInfo: FracaInfo[];
}


const initialState: FracaInfo = {
    FracaNo: '',
    PartNo: '',
    OpenDate: new Date(),
    CloseDate: new Date(),
    FailedDate: new Date(),
    Product: '',
    Program: '',
    Customer: '',
    TestEnv: '',
    Originator: '',
    RespEng: '',
    System: '',
    Electrical: '',
    Emi: '',
    ClosedBy: '',
    TestDoc: '',
    Paragraph: '',
    TestType: '',
    FailureCode: '',
    EndUnit: '',
    Level1: '',
    Level2: '',
    Nomenclature: ' ',
    SerialNumber: '',
    Designator: '',
    InflightShutdown: false,
    InflightPowerLoss: false,
    Chargeability: false,
    SafetyAffected: false,
    FailureToStart: false,
    ProblemDescription: ' ',
    Finding: '',
    Analysis: '',
    AccessType : 0,
    Status: 'InProgress'

}

export function reducer(state: FracaInfo[] = [initialState], action: FracaAction.Actions) {

    switch (action.type) {

        case FracaAction.ADD_FRACA: {
            return [...state, action.payload]

        }

        case FracaAction.LOAD_FRACA: {
            state = action.payload.FracaInfo;
            console.log("user Name :" + action.payload.UserName)
            // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case FracaAction.UPDATE_FRACA: {
            let fracaInfo = (<FracaInfo>action.payload);
            var todo = state.find(t => t.FracaNo == fracaInfo.FracaNo);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                todo.PartNo = fracaInfo.PartNo;
                todo.OpenDate = fracaInfo.OpenDate;
                todo.CloseDate = fracaInfo.CloseDate;
                todo.FailedDate = fracaInfo.FailedDate;
                todo.Product = fracaInfo.Product;
                todo.Program = fracaInfo.Program;
                todo.Customer = fracaInfo.Customer;
                todo.TestEnv = fracaInfo.TestEnv;
                todo.Originator = fracaInfo.Originator;
                todo.RespEng = fracaInfo.RespEng;
                todo.System = fracaInfo.System;
                todo.Electrical = fracaInfo.Electrical;
                todo.Emi = fracaInfo.Emi;
                todo.ClosedBy = fracaInfo.ClosedBy;
                todo.TestDoc = fracaInfo.TestDoc;
                todo.Paragraph = fracaInfo.Paragraph;
                todo.TestType = fracaInfo.TestType;
                todo.FailureCode = fracaInfo.FailureCode;
                todo.EndUnit = fracaInfo.EndUnit;
                todo.Level1 = fracaInfo.Level1;
                todo.Level2 = fracaInfo.Level2;
                todo.Nomenclature = fracaInfo.Nomenclature;
                todo.SerialNumber = fracaInfo.SerialNumber;
                todo.Designator = fracaInfo.Designator;
                todo.InflightShutdown = fracaInfo.InflightShutdown;
                todo.InflightPowerLoss = fracaInfo.InflightPowerLoss;
                todo.Chargeability = fracaInfo.Chargeability;
                todo.SafetyAffected = fracaInfo.SafetyAffected;
                todo.FailureToStart = fracaInfo.FailureToStart;
                todo.ProblemDescription = fracaInfo.ProblemDescription;
                todo.Finding = fracaInfo.Finding;
                todo.Analysis = fracaInfo.Analysis;
                todo.Status= fracaInfo.Status;
                todo.AccessType = fracaInfo.AccessType;

                let sliceArray = state.splice(index, 1, todo);
         
            }
            //return Object.assign([], state);
            return state.slice();
         
        }



        default:
            return state;
    }
}