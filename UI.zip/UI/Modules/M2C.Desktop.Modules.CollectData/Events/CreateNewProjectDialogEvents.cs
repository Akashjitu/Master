﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CreateNewProjectDialogEvents.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project;
using Prism.Events;
using System.Collections.Generic;

namespace M2C.Desktop.Modules.CollectData.Events
{
    /// <summary>
    /// Class ContextDataChangeEvent.
    /// Implements the <see cref="Prism.Events.PubSubEvent{M2C.Business.Models.Project.ProjectContextModel}" />
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{M2C.Business.Models.Project.ProjectContextModel}" />
    public class ContextDataChangeEvent : PubSubEvent<ProjectContextModel>
    {
    }

    /// <summary>
    /// Class ContactDataChangeEvent.
    /// Implements the <see cref="Prism.Events.PubSubEvent{System.Collections.Generic.List{M2C.Business.Models.Project.ContactModel}}" />
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{System.Collections.Generic.List{M2C.Business.Models.Project.ContactModel}}" />
    public class ContactDataChangeEvent : PubSubEvent<List<ContactModel>>
    {
    }
}