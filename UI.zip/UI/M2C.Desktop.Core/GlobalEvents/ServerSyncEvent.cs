﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 04-15-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ServerSyncEvent.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2C.Desktop.Core.GlobalEvents
{
    /// <summary>
    /// ServerSyncEvent for sending out server events
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{System.String}" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ServerSyncEvent: PubSubEvent<string>
    {
    }
}
