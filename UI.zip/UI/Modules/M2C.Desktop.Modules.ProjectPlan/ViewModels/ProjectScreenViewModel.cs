﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.ProjectPlan
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectScreenViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Helpers;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using Microsoft.Win32;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.IO;
using System.Windows;

namespace M2C.Desktop.Modules.ProjectPane.ViewModels
{
    /// <summary>
    /// ProjectScreen ViewModel
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="System.IDisposable" />
    public class ProjectScreenViewModel : BindableBase, IDisposable
    {
        /// <summary>
        /// The export project command
        /// </summary>
        private DelegateCommand _exportProjectCommand;

        /// <summary>
        /// The save command
        /// </summary>
        private DelegateCommand _saveCommand;

        /// <summary>
        /// The global menu commands
        /// </summary>
        private readonly IGlobalMenuComands _globalMenuCommands;

        /// <summary>
        /// The region manager
        /// </summary>
        private readonly IRegionManager _regionManager;

        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService _sharedContextService;

        /// <summary>
        /// The project logic
        /// </summary>
        private readonly IProjectLogic _projectLogic;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator eventAggregator;

        /// <summary>
        /// The project model
        /// </summary>
        private ProjectContextModel _projectModel;

        /// <summary>
        /// Gets or sets the project model.
        /// </summary>
        /// <value>The project model.</value>
        private ProjectContextModel ProjectModel
        {
            get => _projectModel;
            set
            {
                SetProperty(ref _projectModel, value);
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectScreenViewModel" /> class.
        /// </summary>
        /// <param name="globalMenuComands">The global menu comands.</param>
        /// <param name="regionManager">The region manager.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        /// <param name="projectLogic">The project logic.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        public ProjectScreenViewModel(IGlobalMenuComands globalMenuComands, IRegionManager regionManager,
            ISharedContextService sharedContextService, IProjectLogic projectLogic, IEventAggregator eventAggregator)
        {
            _projectModel = new ProjectContextModel();
            this._globalMenuCommands = globalMenuComands;
            _regionManager = regionManager;
            this._sharedContextService = sharedContextService;
            this._projectLogic = projectLogic;
            this.eventAggregator = eventAggregator;
            ProjectModel = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);

            globalMenuComands.ExportProjectCommand.RegisterCommand(ExportProjectCommand);
            globalMenuComands.SaveCommand.RegisterCommand(SaveCommand);
        }

        /// <summary>
        /// Gets the export project command.
        /// </summary>
        /// <value>The export project command.</value>
        public DelegateCommand ExportProjectCommand => _exportProjectCommand ?? (_exportProjectCommand = new DelegateCommand(ExecuteExportProject, CanExecuteExport));

        /// <summary>
        /// Executes the exportproject.
        /// </summary>
        private void ExecuteExportProject()
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "M2C file (*.m2c)|*.m2c",
                    AddExtension = true,
                    FileName = ProjectModel?.Customer?.ProjectName
                };
                if (saveFileDialog.ShowDialog() == true)
                {
                    string filePath = saveFileDialog.FileName;
                    //MasterInventories
                    string json = JsonConvert.SerializeObject(ProjectModel, Formatting.Indented,
                                   new JsonSerializerSettings { ContractResolver = new DynamicContractResolver("MasterInventories") });
                    File.WriteAllText(filePath, json);
                    MessageBox.Show($"{saveFileDialog.SafeFileName} saved successfully.", "Save Message", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Save failed : {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Determines whether this instance [can execute export].
        /// </summary>
        /// <returns><c>true</c> if this instance [can execute export]; otherwise, <c>false</c>.</returns>
        private bool CanExecuteExport()
        {
            return true;
        }

        /// <summary>
        /// Gets the save command.
        /// </summary>
        /// <value>The save command.</value>
        public DelegateCommand SaveCommand => _saveCommand ?? (_saveCommand = new DelegateCommand(ExecuteSaveproject, CanExecuteSave));

        /// <summary>
        /// Executes the saveproject.
        /// </summary>
        private void ExecuteSaveproject()
        {
            try
            {
                var contextModel = this._sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);

                if (_projectLogic.Save(ref contextModel))
                {
                    this._sharedContextService.IsSavePending = false;
                    MessageBox.Show($"Saved to local storage successfully.", "Save Message", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.eventAggregator.GetEvent<ServerSyncEvent>().Publish("ProjectSync");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Save failed : {ex.Message}.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Determines whether this instance [can execute save].
        /// </summary>
        /// <returns><c>true</c> if this instance [can execute save]; otherwise, <c>false</c>.</returns>
        private bool CanExecuteSave()
        {
            return true;
        }

        /// <summary>
        /// Disposes this instance.
        /// </summary>
        public void Dispose()
        {
            _globalMenuCommands.ExportProjectCommand.UnregisterCommand(ExportProjectCommand);
            _globalMenuCommands.SaveCommand.UnregisterCommand(SaveCommand);
        }
    }
}