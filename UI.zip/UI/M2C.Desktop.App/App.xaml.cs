﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="App.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using AuthMiddleWare.Contracts;
using AuthMiddleWare.Implementations;
using M2C.Business;
using M2C.Desktop.App.Behaviors;
using M2C.Desktop.App.Core.Splash;
using M2C.Desktop.App.ViewModels;
using M2C.Desktop.App.Views;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.DialogServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.Resources;
using M2C.Desktop.Modules.AnalyseData;
using M2C.Desktop.Modules.Charts.ReportData;
using M2C.Desktop.Modules.CollectData;
using M2C.Desktop.Modules.Navigation;
using M2C.Desktop.Modules.ProjectPane;
using M2C.Desktop.Modules.ReportData;
using Microsoft.Win32;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using Prism.Services.Dialogs;
using RestSharp;
using SchneiderElectric.BrandIdentity.AboutBox;
using SchneiderElectric.BrandIdentity.Controls.Extensions;
using System;
using System.Windows;
using WinRegistryServices.Contracts;
using WinRegistryServices.Implementation;

namespace M2C.Desktop.App
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        /// <summary>
        /// Creates the shell or main window of the application.
        /// </summary>
        /// <returns>The shell of the application.</returns>
        protected override Window CreateShell()
        {
            return Container.Resolve<MainWindow>();
        }

        /// <summary>
        /// Used to register types with the container that will be used by your application.
        /// </summary>
        /// <param name="containerRegistry">The container registry.</param>
        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<AppSplashScreen>();
            SoftwareInfo softwareInfo = new SoftwareInfo(AppResource.GetResourceString("M2C"),
                   typeof(App).Assembly.GetName().Version.ToString(),
                   new Uri("pack://application:,,,/Resources/img/M2c.png"),
                   new CopyrightInfo(AppResource.GetResourceString("Schneider-Electric"),
                   AppResource.GetResourceString("CopyrightYear")))
            {
                Description = AppResource.GetResourceString("M2C_Description")
            };
            SchneiderElectric.BrandIdentity.Windows.SplashScreen screen = new SchneiderElectric.BrandIdentity.Windows.SplashScreen(softwareInfo);
            containerRegistry.RegisterInstance(screen);

            containerRegistry.RegisterSingleton<IGlobalMenuComands, GlobalMenuComands>();
            containerRegistry.RegisterSingleton<IGlobalIBComponentsCommand, GlobalIBComponentsCommand>();
            containerRegistry.RegisterDialogWindow<BasicDialogWindow>();
            containerRegistry.RegisterSingleton<ISharedContextService, AppSharedContextService>();
            containerRegistry.RegisterSingleton<IGlobalTRCommands, GlobalTRCommands>();
            containerRegistry.Register<FileDialog, OpenFileDialog>();
            containerRegistry.Register<IDialogService, DialogService>();
            containerRegistry.Register<IFileOpenDialogue, FileOpenDialogue>();
            containerRegistry.RegisterDialog<LoginControl, LoginControlViewModel>("LoginDialog");
            containerRegistry.RegisterSingleton<IAppConfigurations, M2CAppConfiguration>();
            containerRegistry.RegisterSingleton<IRegistryStoreManger, RegistryStoreManger>();
            containerRegistry.RegisterInstance<IRestClient>(new RestClient());
            containerRegistry.RegisterSingleton<IAuthentication, IDMSAuthentication>();
            containerRegistry.RegisterSingleton<IAuthorization, IDMSAuthorization>();

            BusinessService.RegisterTypes(containerRegistry);
        }

        /// <summary>
        /// Initializes the modules.
        /// </summary>
        protected override void InitializeModules()
        {
            AppSplashScreen splashScreen = Container.Resolve<AppSplashScreen>();
            ControlExtensions.DisableAllAnimations = true;
            splashScreen.Show(false);
            try
            {
                splashScreen.ProgressInfo.UpdateProgress(0, "Modules Initializing");
                base.InitializeModules();
                splashScreen.ProgressInfo.UpdateProgress(10, "Modules Initialized");

                splashScreen.ProgressInfo.UpdateProgress(20, "DB Migrating");
                BusinessService.Migrate();
                splashScreen.ProgressInfo.UpdateProgress(20, "DB Migration done");
            }
            finally
            {
                splashScreen.ProgressInfo.UpdateProgress(100, "Done..");
                splashScreen.Close(TimeSpan.Zero);
            }
        }

        /// <summary>
        /// Catalog for Modules
        /// </summary>
        /// <param name="moduleCatalog">The module catalog.</param>
        protected override void ConfigureModuleCatalog(IModuleCatalog moduleCatalog)
        {
            moduleCatalog.AddModule<CollectDataModule>();
            moduleCatalog.AddModule<AnalyseDataModule>();
            moduleCatalog.AddModule<ReportDataModule>();
            moduleCatalog.AddModule<ExportReportDataModule>();
            moduleCatalog.AddModule<ChartDataModule>();
            moduleCatalog.AddModule<ProjectPaneModule>();
            moduleCatalog.AddModule<NavigationModule>();
        }

        /// <summary>
        /// Configures the default region behaviors.
        /// </summary>
        /// <param name="regionBehaviors">The region behaviors.</param>
        protected override void ConfigureDefaultRegionBehaviors(IRegionBehaviorFactory regionBehaviors)
        {
            regionBehaviors.AddIfMissing(UIConstants.DISPOSABLEREGIONBEHAVIOR, typeof(DisposableRegionBehavior));

            base.ConfigureDefaultRegionBehaviors(regionBehaviors);
        }
    }
}