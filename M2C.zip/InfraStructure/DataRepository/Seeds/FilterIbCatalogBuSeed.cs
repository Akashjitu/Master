﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="FilterIbCatalogBuSeed.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogFilter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace DataRepository.Seeds
{
    /// <summary>
    /// Class FilterIbCatalogBuSeed.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    internal class FilterIbCatalogBuSeed
    {
        /// <summary>
        /// Seeds the specified model builder.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public void Seed(ModelBuilder modelBuilder)
        {
            var recurrentTime = DateTime.Today;
            var filterIbCatalogBus = new List<FilterIbCatalogBu>
            {
                new FilterIbCatalogBu {Name = "IND OEM BIC", Id = 1, CreatedDate = recurrentTime},
                new FilterIbCatalogBu {Name = "IND PROCESS AUTOMATION", Id = 2, CreatedDate = recurrentTime},
                new FilterIbCatalogBu {Name = "IND AUT SOFTWARE", Id = 3, CreatedDate = recurrentTime},
                new FilterIbCatalogBu {Name = "IND AUTOMATION OPS", Id = 4, CreatedDate = recurrentTime},
                new FilterIbCatalogBu {Name = "IND SOFTWARE", Id = 5, CreatedDate = recurrentTime},
                new FilterIbCatalogBu {Name = "SCE IND AUT. SERVICES", Id = 6, CreatedDate = recurrentTime},
            };

            modelBuilder.Entity<FilterIbCatalogBu>().HasData(filterIbCatalogBus);
        }
    }
}