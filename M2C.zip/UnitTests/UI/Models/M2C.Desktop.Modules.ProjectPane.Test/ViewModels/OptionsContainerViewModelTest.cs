﻿using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Desktop.Modules.ProjectPane.Test.Mock;
using M2C.Desktop.Modules.ProjectPlan.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace M2C.Desktop.Modules.ProjectPane.Test.ViewModels
{
    [TestClass]
    public class OptionsContainerViewModelTest
    {
        private OptionsContainerViewModel _optionsContainerViewModel;
        private IMyProfileLogic _myProfileLogic;
        private IBusinessUtilities _businessUtilities;
        private ProfileModel _profileModel;

        [TestInitialize]
        public void Setup()
        {
            _myProfileLogic = Substitute.For<IMyProfileLogic>();
            _businessUtilities = Substitute.For<IBusinessUtilities>();
            _profileModel = MockProvider.GetProfile();
            _businessUtilities.getCountries().Returns(MockProvider.GetCountries());
            _businessUtilities.getPositions().Returns(MockProvider.GetPositions());
            _myProfileLogic.GetProfile().Returns(_profileModel);

            _optionsContainerViewModel = new OptionsContainerViewModel(_myProfileLogic, _businessUtilities);           
        }

        [TestMethod]
        public void ShouldReturnCountriesWithProfile()
        {
            var profile = _optionsContainerViewModel.Profile;
            var countries = _optionsContainerViewModel.Countries;
            var positions = _optionsContainerViewModel.Positions;

            var closeDialogCommand = _optionsContainerViewModel.CloseDialogCommand;
            var resetDialogCommand = _optionsContainerViewModel.ResetDialogCommand;
            var selectionChangedCommand = _optionsContainerViewModel.SelectionChangedCommand;

            Assert.IsTrue(!string.IsNullOrEmpty(_optionsContainerViewModel.Title));
            Assert.IsNotNull(closeDialogCommand);
            Assert.IsNotNull(resetDialogCommand);
            Assert.IsNotNull(selectionChangedCommand);

            Assert.IsNotNull(profile);
            Assert.IsNotNull(countries);            
            Assert.AreEqual(profile, _profileModel);
        }

        [TestMethod]
        public void ShouldReturnPositionsWithProfile()
        {
            var profile = _optionsContainerViewModel.Profile;
            var countries = _optionsContainerViewModel.Countries;
            var positions = _optionsContainerViewModel.Positions;

            var closeDialogCommand = _optionsContainerViewModel.CloseDialogCommand;
            var resetDialogCommand = _optionsContainerViewModel.ResetDialogCommand;
            var selectionChangedCommand = _optionsContainerViewModel.SelectionChangedCommand;

            Assert.IsTrue(!string.IsNullOrEmpty(_optionsContainerViewModel.Title));
            Assert.IsNotNull(closeDialogCommand);
            Assert.IsNotNull(resetDialogCommand);
            Assert.IsNotNull(selectionChangedCommand);

            Assert.IsNotNull(profile);           
            Assert.IsNotNull(positions);
            Assert.AreEqual(profile, _profileModel);
        }
    }
}