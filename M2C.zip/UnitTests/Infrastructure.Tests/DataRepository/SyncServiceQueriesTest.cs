﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class SyncServiceQueriesTest : TestBase
    {

        private IQueryable<SyncHistory> syncHistoryList;
        private Mock<DbSet<SyncHistory>> syncHistoryMock;
        private Mock<DbSet<SyncHistory>> syncHistoryInvalidMock;
        private Mock<DbSet<SyncHistory>> syncHistoryNullMock;
        private IQueryable<SyncHistory> syncHistoryListInvalid;
        private IQueryable<SyncHistory> syncHistoryListNull;
        [TestInitialize]
        public void TestIniTialize()
        {
            List<SyncHistory> syncHistory = new List<SyncHistory>() { new SyncHistory() { SyncId = "123", ID = 1, RetryCount = 0, SyncDate = Convert.ToDateTime("2020-04-15 10:00:54.1355708"), Status = 3, Version = 1 } };
            syncHistoryList = syncHistory.AsQueryable();
            syncHistoryMock = MockRepo.Create<DbSet<SyncHistory>>();
            syncHistoryMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(syncHistoryList.Provider);
            syncHistoryMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(syncHistoryList.Expression);
            syncHistoryMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(syncHistoryList.ElementType);
            syncHistoryMock.As<IQueryable<SyncHistory>>().Setup(m => m.GetEnumerator()).Returns(syncHistoryList.GetEnumerator());
            //IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryMock.Object);
            //IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);


            List<SyncHistory> syncHistoryInvalid = new List<SyncHistory>() { new SyncHistory() { ID = 1, RetryCount = 0, SyncDate = Convert.ToDateTime("2020-04-15 10:00:54.1355708"), Status = 3, Version = 1 } };
            syncHistoryListInvalid = syncHistoryInvalid.AsQueryable();
            syncHistoryInvalidMock = MockRepo.Create<DbSet<SyncHistory>>();
            syncHistoryInvalidMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(syncHistoryListInvalid.Provider);
            syncHistoryInvalidMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(syncHistoryListInvalid.Expression);
            syncHistoryInvalidMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(syncHistoryListInvalid.ElementType);
            syncHistoryInvalidMock.As<IQueryable<SyncHistory>>().Setup(m => m.GetEnumerator()).Returns(syncHistoryListInvalid.GetEnumerator());


            List<SyncHistory> syncHistoryNull = new List<SyncHistory>();
            syncHistoryListNull = syncHistoryNull.AsQueryable();
            syncHistoryNullMock = MockRepo.Create<DbSet<SyncHistory>>();
            syncHistoryNullMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(syncHistoryListNull.Provider);
            syncHistoryNullMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(syncHistoryListNull.Expression);
            syncHistoryNullMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(syncHistoryListNull.ElementType);
            syncHistoryNullMock.As<IQueryable<SyncHistory>>().Setup(m => m.GetEnumerator()).Returns(syncHistoryListNull.GetEnumerator());
            //IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryMock.Object);
            //IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);

        }

        [TestMethod]
        public void ProductQueriesConstructorTest()
        {
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            product.Should().NotBeNull();
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void GetLastSyncDateTest()
        {
            IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
            ISyncServiceQueries syncHistory = new ProductQueries(IDbContextFactoryMock.Object);
            DateTime? syncDateRes = syncHistory.GetLastSyncDate();
            syncDateRes.Should().NotBeNull();
            ((IDisposable)syncHistory).Dispose();
        }

        [TestMethod]
        public void GetLastSyncDateNegativeTest()
        {
            IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryInvalidMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);

            ISyncServiceQueries syncHistory = new ProductQueries(IDbContextFactoryMock.Object);
            DateTime? syncDateRes = syncHistory.GetLastSyncDate();
            syncDateRes.Should().BeNull();
            ((IDisposable)syncHistory).Dispose();
        }


        [TestMethod]
        public void GetAllSyncHistoryTest()
        {
            IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
            ISyncServiceQueries syncHistory = new ProductQueries(IDbContextFactoryMock.Object);
            var syncHistoryRes = syncHistory.GetAllSyncHistory(3);
            syncHistoryRes.Should().NotBeNull();

            syncHistoryRes = syncHistory.GetAllSyncHistory(null);
            syncHistoryRes.Should().NotBeNull();

            ((IDisposable)syncHistory).Dispose();
        }




        [TestMethod]
        public void GetAllSyncHistoryNegativeTest()
        {
            IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryInvalidMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
            ISyncServiceQueries syncHistory = new ProductQueries(IDbContextFactoryMock.Object);
            var syncHistoryRes = syncHistory.GetAllSyncHistory(1);
            syncHistoryRes.Should().BeNull();

            ((IDisposable)syncHistory).Dispose();
        }

        [TestMethod]
        public void SaveSyncHistoryTest()
        {

            IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);

            SyncHistory syncHistoryAdd = new SyncHistory() { SyncId = "345", ID = 2, RetryCount = 0, SyncDate = Convert.ToDateTime("2020-04-15 10:00:54.1355708"), Status = 3, Version = 1 };

            ISyncServiceQueries syncHistoryObj = new ProductQueries(IDbContextFactoryMock.Object);

            SyncHistory syncHistryRes = syncHistoryObj.SaveSyncHistory(syncHistoryAdd);
            syncHistryRes.Should().NotBeNull();

            syncHistryRes = syncHistoryObj.SaveSyncHistory(null);
            syncHistryRes.Should().BeNull();

            ((IDisposable)syncHistoryObj).Dispose();
        }


        [TestMethod]
        public void savetoEmptySyncHistoryTest()
        {
            IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryNullMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
            ISyncServiceQueries syncHistory = new ProductQueries(IDbContextFactoryMock.Object);
            SyncHistory syncHistoryAdd = new SyncHistory() { SyncId = "345", ID = 2, RetryCount = 0, SyncDate = Convert.ToDateTime("2020-04-15 10:00:54.1355708"), Status = 3, Version = 1 };
            SyncHistory syncHistryRes = syncHistory.SaveSyncHistory(syncHistoryAdd);
            syncHistryRes.Should().NotBeNull();

            ((IDisposable)syncHistory).Dispose();

        }


        [TestMethod]
        public void UpdateSyncHistoryTest()
        {
            IProductDbContextMock.Setup(x => x.SyncHistories).Returns(syncHistoryMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);

            SyncHistory syncHistoryUpdate = new SyncHistory() { SyncId = "123", ID = 1, RetryCount = 0, SyncDate = Convert.ToDateTime("2020-04-15 10:00:54.1355708"), Status = 3, Version = 1 };
            ISyncServiceQueries syncHistoryObj = new ProductQueries(IDbContextFactoryMock.Object);
            SyncHistory syncHistryRes = syncHistoryObj.UpdateSyncHistory(syncHistoryUpdate);
            syncHistryRes.Should().NotBeNull();

            syncHistoryUpdate = new SyncHistory() { SyncId = "345", ID = 1, RetryCount = 0, SyncDate = Convert.ToDateTime("2020-04-15 10:00:54.1355708"), Status = 3, Version = 1 };
            syncHistryRes = syncHistoryObj.UpdateSyncHistory(syncHistoryUpdate);
            syncHistryRes.Should().BeNull();

            ((IDisposable)syncHistoryObj).Dispose();
        }
    }
}
