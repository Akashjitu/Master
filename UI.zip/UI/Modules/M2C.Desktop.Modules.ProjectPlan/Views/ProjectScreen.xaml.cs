﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.ProjectPlan
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProjectScreen.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.ProjectPane.Views
{
    /// <summary>
    /// Interaction logic for ProjectScreen.xaml
    /// </summary>
    public partial class ProjectScreen : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectScreen" /> class.
        /// </summary>
        public ProjectScreen()
        {
            InitializeComponent();
        }
    }
}
