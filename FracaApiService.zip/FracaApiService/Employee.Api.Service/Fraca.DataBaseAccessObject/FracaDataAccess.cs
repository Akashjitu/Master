﻿using Fraca.Data.Models;
using Fraca.DataBaseAccessObject.Constants;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

namespace Fraca.DataBaseAccessObject
{
    public class FracaDataAccess: IDisposable
    {

        OracleConnection _oracleConnection;
       public FracaDataAccess()
        {
            string oradb = ConfigurationManager.AppSettings[DataAccessConstant.CONNECTION_STRING].ToString();
            _oracleConnection = new OracleConnection(oradb);
            _oracleConnection.Open();
        }

        public int AddNewFraca(FracaInfo fracaInfo)
        {
         
            try
            {

                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_ADD_FRACA;
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("i_FracaNo", OracleDbType.Varchar2, fracaInfo.FracaNo.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_PartNo", OracleDbType.Varchar2, fracaInfo.PartNo.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_OpenDate", OracleDbType.Date, string.IsNullOrEmpty(fracaInfo.OpenDate) ? new DateTime() : DateTime.Parse(fracaInfo.OpenDate), ParameterDirection.Input);
                    command.Parameters.Add("i_CloseDate", OracleDbType.Date, string.IsNullOrEmpty(fracaInfo.CloseDate) ? new DateTime() : DateTime.Parse(fracaInfo.CloseDate), ParameterDirection.Input);
                    command.Parameters.Add("i_FailedDate", OracleDbType.Date, string.IsNullOrEmpty(fracaInfo.FailedDate) ? new DateTime() : DateTime.Parse(fracaInfo.FailedDate), ParameterDirection.Input);
                    command.Parameters.Add("i_Product", OracleDbType.Varchar2, fracaInfo.Product.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Program", OracleDbType.Varchar2, fracaInfo.Program.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Customer", OracleDbType.Varchar2, fracaInfo.Customer.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_TestEnv", OracleDbType.Varchar2, fracaInfo.TestEnv.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Originator", OracleDbType.Varchar2, fracaInfo.Originator.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_RespEng", OracleDbType.Varchar2, fracaInfo.RespEng.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_System", OracleDbType.Varchar2, fracaInfo.System.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Electrical", OracleDbType.Varchar2, fracaInfo.Electrical.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Emi", OracleDbType.Varchar2, fracaInfo.Emi, ParameterDirection.Input);
                    command.Parameters.Add("i_ClosedBy", OracleDbType.Varchar2, fracaInfo.ClosedBy.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_TestDoc", OracleDbType.Varchar2, fracaInfo.TestDoc.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Paragraph", OracleDbType.Varchar2, fracaInfo.Paragraph.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_TestType", OracleDbType.Varchar2, fracaInfo.TestType.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_FailureCode", OracleDbType.Varchar2, fracaInfo.FailureCode.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_EndUnit", OracleDbType.Varchar2, fracaInfo.EndUnit.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Level1", OracleDbType.Varchar2, fracaInfo.Level1.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Level2", OracleDbType.Varchar2, fracaInfo.Level2.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_NcmendAture", OracleDbType.Varchar2, fracaInfo.Nomenclature.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_SerialNumber", OracleDbType.Varchar2, fracaInfo.SerialNumber.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Designator", OracleDbType.Varchar2, fracaInfo.Designator.Trim(), ParameterDirection.Input);

                    command.Parameters.Add("i_InflightShutdown"     ,  OracleDbType.Varchar2, fracaInfo.InflightShutdown.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_InflightPowerLoss"    ,  OracleDbType.Varchar2, fracaInfo.InflightPowerLoss.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_Chargeability"        ,  OracleDbType.Varchar2, fracaInfo.Chargeability.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_SafetyAffected"       ,  OracleDbType.Varchar2, fracaInfo.SafetyAffected.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_FailureToStart"       ,  OracleDbType.Varchar2, fracaInfo.FailureToStart.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_ProblemDescription"   ,  OracleDbType.Varchar2, fracaInfo.ProblemDescription.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Finding"              ,  OracleDbType.Varchar2, fracaInfo.Finding.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Analysis"             ,  OracleDbType.Varchar2, fracaInfo.Analysis.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_LAST_UPDATE_BY"       ,  OracleDbType.Varchar2, (fracaInfo.LAST_UPDATE_BY==null)?"":fracaInfo.LAST_UPDATE_BY.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_LAST_UPDATE",         OracleDbType.Date, fracaInfo.LAST_UPDATE, ParameterDirection.Input);



                    return command.ExecuteNonQuery();
                }
            }
            catch(Exception)
            {
                throw;
            }
        }

        public List<FracaInfo> GetFracaByPartNo(string partNo)
        {
            string sqlCommand = string.Empty;
            List<FracaInfo> fracaInfoCollection = new List<FracaInfo>();
            try
            {
                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_LOAD_By_PART;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("i_PartNo", OracleDbType.Varchar2, partNo.Trim(), ParameterDirection.Input);

                    command.Parameters.Add("o_frace_data", OracleDbType.RefCursor, ParameterDirection.Output).Value = null;

                    var dr = command.ExecuteReader();
                    var dt = new DataTable();

                    while (dr.Read())
                    {
                        FracaInfo fracaInfo = GetFracIinfo(dr);
                        fracaInfoCollection.Add(fracaInfo);
                    }
                    return fracaInfoCollection;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<FracaInfo> GetFracaByFilter(string fracaNo, string partNo)
        {
            string sqlCommand = string.Empty;
            List<FracaInfo> fracaInfoCollection = new List<FracaInfo>();
            try
            {
                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_LOAD_By_Filter;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("i_PartNo", OracleDbType.Varchar2, partNo.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_FracaNo", OracleDbType.Varchar2, fracaNo.Trim(), ParameterDirection.Input);

                    command.Parameters.Add("o_frace_data", OracleDbType.RefCursor, ParameterDirection.Output).Value = null;

                    var dr = command.ExecuteReader();
                    var dt = new DataTable();

                    while (dr.Read())
                    {
                        FracaInfo fracaInfo = GetFracIinfo(dr);
                        fracaInfoCollection.Add(fracaInfo);
                    }
                    return fracaInfoCollection;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<FracaInfo> GetFracaById(string fracaid)
        {
            string sqlCommand = string.Empty;
            List<FracaInfo> fracaInfoCollection = new List<FracaInfo>();
            try
            {
                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_LOAD_By_ID;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("i_FracaNo", OracleDbType.Varchar2, fracaid.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("o_frace_data", OracleDbType.RefCursor, ParameterDirection.Output).Value = null;

                    var dr = command.ExecuteReader();
                    var dt = new DataTable();

                    while (dr.Read())
                    {
                        FracaInfo fracaInfo = GetFracIinfo(dr);

                        fracaInfoCollection.Add(fracaInfo);
                    }
                    return fracaInfoCollection;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    

        public List<FracaInfo> GetFracaByDate(DateTime fromDate, DateTime toDate)
        {
            string sqlCommand = string.Empty;
            List<FracaInfo> fracaInfoCollection = new List<FracaInfo>();
            try
            {
                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_LOAD_By_DATE;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("i_fromDate", OracleDbType.Date, fromDate, ParameterDirection.Input);
                    command.Parameters.Add("i_ToDate", OracleDbType.Date, toDate, ParameterDirection.Input);

                    command.Parameters.Add("o_frace_data", OracleDbType.RefCursor, ParameterDirection.Output).Value = null;

                    var dr = command.ExecuteReader();
                    var dt = new DataTable();

                    while (dr.Read())
                    {
                        FracaInfo fracaInfo = GetFracIinfo(dr);

                        fracaInfoCollection.Add(fracaInfo);
                    }
                    return fracaInfoCollection;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public int DeleteFraca(string fracaid)
        {
            try
            {

                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_Delete_FRACA;
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("i_FracaNo", OracleDbType.Varchar2, fracaid, ParameterDirection.Input);

                    return command.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public int UpdateFraca(string fracaid, FracaInfo fracaInfo)
        {
            try
            {

                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_UPDATE_FRACA;
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("i_FracaNo", OracleDbType.Varchar2, fracaInfo.FracaNo.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_PartNo", OracleDbType.Varchar2, fracaInfo.PartNo.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_OpenDate", OracleDbType.Date, string.IsNullOrEmpty(fracaInfo.OpenDate)? new DateTime(): DateTime.Parse(fracaInfo.OpenDate), ParameterDirection.Input);
                    command.Parameters.Add("i_CloseDate", OracleDbType.Date, string.IsNullOrEmpty(fracaInfo.CloseDate) ? new DateTime() : DateTime.Parse(fracaInfo.CloseDate), ParameterDirection.Input);
                    command.Parameters.Add("i_FailedDate", OracleDbType.Date, string.IsNullOrEmpty(fracaInfo.FailedDate) ? new DateTime() : DateTime.Parse(fracaInfo.FailedDate), ParameterDirection.Input);
                    command.Parameters.Add("i_Product", OracleDbType.Varchar2, fracaInfo.Product.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Program", OracleDbType.Varchar2, fracaInfo.Program.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Customer", OracleDbType.Varchar2, fracaInfo.Customer.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_TestEnv", OracleDbType.Varchar2, fracaInfo.TestEnv.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Originator", OracleDbType.Varchar2, fracaInfo.Originator.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_RespEng", OracleDbType.Varchar2, fracaInfo.RespEng.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_System", OracleDbType.Varchar2, fracaInfo.System.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Electrical", OracleDbType.Varchar2, fracaInfo.Electrical.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Emi", OracleDbType.Varchar2, fracaInfo.Emi, ParameterDirection.Input);
                    command.Parameters.Add("i_ClosedBy", OracleDbType.Varchar2, fracaInfo.ClosedBy.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_TestDoc", OracleDbType.Varchar2, fracaInfo.TestDoc.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Paragraph", OracleDbType.Varchar2, fracaInfo.Paragraph.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_TestType", OracleDbType.Varchar2, fracaInfo.TestType.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_FailureCode", OracleDbType.Varchar2, fracaInfo.FailureCode.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_EndUnit", OracleDbType.Varchar2, fracaInfo.EndUnit.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Level1", OracleDbType.Varchar2, fracaInfo.Level1.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Level2", OracleDbType.Varchar2, fracaInfo.Level2.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_NcmendAture", OracleDbType.Varchar2, fracaInfo.Nomenclature.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_SerialNumber", OracleDbType.Varchar2, fracaInfo.SerialNumber.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Designator", OracleDbType.Varchar2, fracaInfo.Designator.Trim(), ParameterDirection.Input);

                    command.Parameters.Add("i_InflightShutdown", OracleDbType.Varchar2, fracaInfo.InflightShutdown.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_InflightPowerLoss", OracleDbType.Varchar2, fracaInfo.InflightPowerLoss.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_Chargeability", OracleDbType.Varchar2, fracaInfo.Chargeability.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_SafetyAffected", OracleDbType.Varchar2, fracaInfo.SafetyAffected.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_FailureToStart", OracleDbType.Varchar2, fracaInfo.FailureToStart.ToString(), ParameterDirection.Input);
                    command.Parameters.Add("i_ProblemDescription", OracleDbType.Varchar2, fracaInfo.ProblemDescription.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Finding", OracleDbType.Varchar2, fracaInfo.Finding.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_Analysis", OracleDbType.Varchar2, fracaInfo.Analysis.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_LAST_UPDATE_BY", OracleDbType.Varchar2, (fracaInfo.LAST_UPDATE_BY==null)?"": fracaInfo.LAST_UPDATE_BY.Trim(), ParameterDirection.Input);
                    command.Parameters.Add("i_LAST_UPDATE", OracleDbType.Date, fracaInfo.LAST_UPDATE, ParameterDirection.Input);

                    return command.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<FracaInfo> LoadAllFraca()
        {
            string sqlCommand = string.Empty;
            List<FracaInfo> fracaInfoCollection = new List<FracaInfo>();
            try
            {
                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = DataAccessConstant.SP_LOAD_ALL_FRACA;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("o_frace_data", OracleDbType.RefCursor, ParameterDirection.Output).Value = null;

                    var dr = command.ExecuteReader();
                    var dt = new DataTable();
                    while (dr.Read())
                    {
                       FracaInfo fracaInfo = GetFracIinfo(dr);
                        fracaInfoCollection.Add(fracaInfo);
                    }
                    return fracaInfoCollection;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }



        private static FracaInfo GetFracIinfo(OracleDataReader dr)
        {
            var fracaInfo = new FracaInfo();
            fracaInfo.FracaNo = dr["FRACANO"].ToString().Trim();
            fracaInfo.FailedDate = dr["FAILEDDATE"].ToString().Trim();
            fracaInfo.OpenDate = dr["OPENDATE"].ToString().Trim();
            fracaInfo.CloseDate = dr["CLOSEDATE"].ToString().Trim();
            fracaInfo.Product = dr["PRODUCT"].ToString().Trim();
            fracaInfo.Program = dr["PROGRAM"].ToString().Trim();
            fracaInfo.Customer = dr["CUSTOMER"].ToString().Trim();
            fracaInfo.TestEnv = dr["TESTENV"].ToString().Trim();
            fracaInfo.Originator = dr["ORIGINATOR"].ToString().Trim();
            fracaInfo.RespEng = dr["RESPENG"].ToString().Trim();
            fracaInfo.Electrical = dr["ELECTRICAL"].ToString().Trim();
            fracaInfo.System = dr["SYSTEM"].ToString().Trim();
            fracaInfo.Emi = dr["EMI"].ToString().Trim();
            fracaInfo.ClosedBy = dr["CLOSEDBY"].ToString().Trim();
            fracaInfo.TestDoc = dr["TESTDOC"].ToString().Trim();
            fracaInfo.Paragraph = dr["PARAGRAPH"].ToString().Trim();
            fracaInfo.TestType = dr["TESTTYPE"].ToString();
            fracaInfo.FailureCode = dr["FAILURECODE"].ToString().Trim();
            fracaInfo.LAST_UPDATE_BY = dr["LAST_UPDATE_BY"].ToString().Trim();
            fracaInfo.LAST_UPDATE = DateTime.Parse(dr["LAST_UPDATE"].ToString());
            fracaInfo.PartNo = dr["PART_NO"].ToString().Trim();
            fracaInfo.Nomenclature = dr["NOMENCLATURE"].ToString().Trim();
            fracaInfo.SerialNumber = dr["SERIAL_NO"].ToString().Trim();
            fracaInfo.Designator = dr["DESIGNATOR"].ToString().Trim();
            fracaInfo.Level1 = dr["LEVEL1"].ToString().Trim();
            fracaInfo.Level2 = dr["LEVEL2"].ToString().Trim();
            fracaInfo.EndUnit = dr["END_UNIT"].ToString().Trim();
            fracaInfo.InflightShutdown = bool.Parse(dr["INFLIGHT_SHUTDOWN"].ToString());
            fracaInfo.InflightPowerLoss = bool.Parse(dr["INFLIGHT_POWER_LOSS"].ToString());
            fracaInfo.Chargeability = bool.Parse(dr["CHARGEABILITY"].ToString());
            fracaInfo.SafetyAffected = bool.Parse(dr["SAFETY_AFFECTED"].ToString());
            fracaInfo.FailureToStart = bool.Parse( dr["FAILURE_TO_START"].ToString());
            fracaInfo.ProblemDescription = dr["PROBLEM"].ToString();
            fracaInfo.Finding = dr["FINDING"].ToString().Trim();
            fracaInfo.Analysis = dr["ANALYSIST"].ToString().Trim();
            return fracaInfo;
        }
        public void Dispose()
        {
            if (_oracleConnection.State == ConnectionState.Open)
                _oracleConnection.Close();
        }
    }
}
