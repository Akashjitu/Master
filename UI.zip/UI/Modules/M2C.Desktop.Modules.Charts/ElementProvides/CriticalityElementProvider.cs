﻿using M2C.Business.Models;
using M2C.Business.Models.Chart;
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    /// <summary>
    /// Provide Criticality Bar Elements.
    /// </summary>

    public class CriticalityElementProvider : ICriticalityElementProvider
    {
        private readonly Dictionary<string, CriticalityValue> _dicCritical;

        public CriticalityElementProvider()
        {
            _dicCritical = new Dictionary<string, CriticalityValue>
            {
                {"1. NOT CRITICAL", CriticalityValue.Not_Critical},
                {"NOT CRITICAL", CriticalityValue.Not_Critical},
                {"SOMEWHAT CRITICAL", CriticalityValue.Somewhat_Critical},
                {"2. SOMEWHAT CRITICAL", CriticalityValue.Somewhat_Critical},
                {"3. CRITICAL", CriticalityValue.Critical},
                {"CRITICAL", CriticalityValue.Critical},
                {"4. VERY CRITICAL", CriticalityValue.Very_Critical},
                {"VERY CRITICAL", CriticalityValue.Very_Critical}
            };
        }

        /// <summary>
        /// Get Criticality Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        public ChartBarElements GetCriticalityBarElements(ChartParameter chartParameter)
        {
            var elements = new ChartBarElements();
            var criticalitys = chartParameter.AllParameterNodes
                .Where(conf => conf.NodeType == NodeType.MACHINE).SelectMany(i => i.Nodes.Cast<MachineNode>()).ToList();

            var machineCriticalitys = criticalitys.Where(i => i.CriticalityParameters != null &&
                                                              !string.IsNullOrEmpty(i.CriticalityParameters.SelectedValue)).Select(i => new ChartBarElement
                                                              {
                                                                  ConfigCount = GetCriticalityLevel(i.CriticalityParameters.SelectedValue),
                                                                  Name = i.Name
                                                              }).ToList();
            //not required. show machine data as  present
            //machineCriticalitys = machineCriticalitys.OrderByDescending(i => i.ConfigCount).ToList();
            elements.CriticalitiesChartElements.AddRange(machineCriticalitys);
            return elements;
        }

        /// <summary>
        /// Gets the criticality level.
        /// </summary>
        /// <param name="selectedCriticality">The selected criticality.</param>
        /// <returns>System.Int32.</returns>
        private int GetCriticalityLevel(string selectedCriticality)
        {
            if (!_dicCritical.ContainsKey(selectedCriticality.ToUpper()))
                return 0;
            var value = (int)_dicCritical[selectedCriticality.ToUpper()];
            return value;
        }
    }
}