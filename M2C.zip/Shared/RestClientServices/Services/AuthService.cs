﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="AuthService.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using Newtonsoft.Json;
using RestClientServices.Contracts;
using RestClientServices.Helper;
using RestSharp;
using System;

namespace RestClientServices.Services
{
    /// <summary>
    /// Class AuthService.
    /// Implements the <see cref="RestClientServices.Contracts.IRestClientService" />
    /// </summary>
    /// <seealso cref="RestClientServices.Contracts.IRestClientService" />
    internal class AuthService : IAuthService
    {
        /// <summary>
        /// The application configurations
        /// </summary>
        private readonly IAppConfigurations appConfigurations;
        /// <summary>
        /// The rest sharp helper
        /// </summary>
        private readonly RestSharpHelper restSharpHelper;
        /// <summary>
        /// The rest client
        /// </summary>
        private readonly IRestClient restClient;

        /// <summary>
        /// Gets the service base path.
        /// </summary>
        /// <value>The service base path.</value>
        public string ServiceBasePath { get => appConfigurations.AuthServicePath; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthService" /> class.
        /// </summary>
        /// <param name="appConfigurations">The application configurations.</param>
        /// <param name="restClient">The rest client.</param>
        public AuthService(IAppConfigurations appConfigurations, IRestClient restClient)
        {
            this.appConfigurations = appConfigurations;

            restClient.BaseUrl = new Uri(this.ServiceBasePath);
            this.restSharpHelper = new RestSharpHelper(restClient);
        }

        /// <summary>
        /// Executes the specified request.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request">The request.</param>
        /// <returns>T.</returns>
        public T Execute<T>(IRestServiceRequest request)
        {
            ServiceResponse response = restSharpHelper.ExecuteRequest(request);
            if (response != null && response.IsSuccess)
            {
                return JsonConvert.DeserializeObject<T>(response.Content);
            }
            else if(response != null && response.ResponseCode == System.Net.HttpStatusCode.BadRequest)
            {
                return (T)Convert.ChangeType(response.Content, typeof(T)); ;
            }
            else
            {
                return (T)Convert.ChangeType(null, typeof(T)); ;
            }
        }
    }
}