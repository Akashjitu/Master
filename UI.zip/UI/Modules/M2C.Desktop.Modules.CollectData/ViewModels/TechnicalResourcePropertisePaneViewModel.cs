﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="TechnicalResourcePropertisePaneViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************

using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.Events;
using M2C.Desktop.Modules.CollectData.UIModels;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class TechnicalResourcePropertisePaneViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class TechnicalResourcePropertisePaneViewModel : BindableBase
    {
        #region Fields

        /// <summary>
        /// The inventories
        /// </summary>
        private ObservableCollection<Inventory> _inventories;

        /// <summary>
        /// The is BTN information visible
        /// </summary>
        private bool _isBtnInfoVisible;

        /// <summary>
        /// The is BTN delete visible
        /// </summary>
        private bool _isBtnDeleteVisible;

        /// <summary>
        /// The is BTN edit visible
        /// </summary>
        private bool _isBtnEditVisible;

        /// <summary>
        /// The row count
        /// </summary>
        private int _rowCount;

        /// <summary>
        /// The quantity count
        /// </summary>
        private int _quantityCount;

        /// <summary>
        /// The reference count
        /// </summary>
        private int _referenceCount;

        /// <summary>
        /// The filter text
        /// </summary>
        private string _filterText = string.Empty;

        /// <summary>
        /// The source inventories
        /// </summary>
        private ObservableCollection<Inventory> _sourceInventories;

        /// <summary>
        /// The selected node
        /// </summary>
        private static INode _selectedNode;

        /// <summary>
        /// The is BTN add inventory visible
        /// </summary>
        private bool _isBtnAddInventoryVisible;

        /// <summary>
        /// The node comments
        /// </summary>
        private string _nodeComments;

        /// <summary>
        /// The is first tab selected
        /// </summary>
        private bool _isFirstTabSelected;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private IEventAggregator _eventAggregator;

        private readonly ISharedContextService sharedContextService;

        #endregion Fields

        #region Commands

        /// <summary>
        /// Gets or sets the node comments.
        /// </summary>
        /// <value>The node comments.</value>
        public string NodeComments
        {
            get => _nodeComments;
            set => SetProperty(ref _nodeComments, value, OnCommentTextChangeed);
        }

        /// <summary>
        /// Open Add Inventory dialog box.
        /// </summary>
        /// <value>The show add resource command.</value>
        public DelegateCommand ShowAddResourceCommand { get; set; }

        /// <summary>
        /// Provide action to Container buttons.
        /// Like Edit. view Info, delete
        /// </summary>
        /// <value>The action command.</value>
        public DelegateCommand<string> ActionCommand { get; set; }

        /// <summary>
        /// Provide action to Container buttons.
        /// Like Edit. view Info, delete
        /// </summary>
        /// <value>The action command.</value>
        public DelegateCommand<object> MouseActionCommand { get; set; }

        #endregion Commands

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether this instance is first tab selected.
        /// </summary>
        /// <value><c>true</c> if this instance is first tab selected; otherwise, <c>false</c>.</value>
        public bool IsFirstTabSelected
        {
            get => _isFirstTabSelected;
            set => SetProperty(ref _isFirstTabSelected, value);
        }

        /// <summary>
        /// Provide Open Dialogbox Service
        /// </summary>
        /// <value>The dialog service.</value>
        public IDialogService DialogService { get; }

        /// <summary>
        /// Search Data from Grid based on resource
        /// </summary>
        /// <value>The filter text.</value>
        public string FilterText
        {
            get => _filterText;
            set => SetProperty(ref _filterText, value, OnFilterChange);
        }

        /// <summary>
        /// Get total numbers row in Grid
        /// </summary>
        /// <value>The row count.</value>
        public int RowCount
        {
            get => _rowCount;
            set => SetProperty(ref _rowCount, value);
        }

        /// <summary>
        /// Get total product quantity count
        /// </summary>
        /// <value>The quantity count.</value>
        public int QuantityCount
        {
            get => _quantityCount;
            set => SetProperty(ref _quantityCount, value);
        }

        /// <summary>
        /// Get total numbers of Reference count
        /// </summary>
        /// <value>The reference count.</value>
        public int ReferenceCount
        {
            get => _referenceCount;
            set => SetProperty(ref _referenceCount, value);
        }

        /// <summary>
        /// Collection of Inventory which are exist in Grid.
        /// </summary>
        /// <value>The inventories.</value>
        public ObservableCollection<Inventory> Inventories
        {
            get => _inventories;
            set => SetProperty(ref _inventories, value);
        }

        /// <summary>
        /// use for hide and show the Delete button on Container
        /// </summary>
        /// <value><c>true</c> if this instance is BTN delete visible; otherwise, <c>false</c>.</value>
        public bool IsBtnDeleteVisible
        {
            get => _isBtnDeleteVisible;
            set => SetProperty(ref _isBtnDeleteVisible, value);
        }

        /// <summary>
        /// use for hide and show the Edit button on Container
        /// </summary>
        /// <value><c>true</c> if this instance is BTN edit visible; otherwise, <c>false</c>.</value>
        public bool IsBtnEditVisible
        {
            get => _isBtnEditVisible;
            set => SetProperty(ref _isBtnEditVisible, value);
        }

        /// <summary>
        /// use for hide and show the Addd Inventory button on Container
        /// </summary>
        /// <value><c>true</c> if this instance is BTN add inventory visible; otherwise, <c>false</c>.</value>
        public bool IsBtnAddInventoryVisible
        {
            get => _isBtnAddInventoryVisible;
            set => SetProperty(ref _isBtnAddInventoryVisible, value);
        }

        /// <summary>
        /// use for hide and show the Info button on Container
        /// </summary>
        /// <value><c>true</c> if this instance is BTN information visible; otherwise, <c>false</c>.</value>
        public bool IsBtnInfoVisible
        {
            get => _isBtnInfoVisible;
            set => SetProperty(ref _isBtnInfoVisible, value);
        }

        /// <summary>
        /// Get Collection ContextItems.
        /// It is use for show all the Column name in Context-Menu.
        /// </summary>
        /// <value>The context items.</value>
        public static ObservableCollection<ContextItem> ContextItems { get; set; }

        /// <summary>
        /// Get Collection of All Grid Columns.
        /// </summary>
        /// <value>The grid column descriptions.</value>
        public ObservableCollection<GridColumnDescription> GridColumnDescriptions { get; set; }

        #endregion Properties

        /// <summary>
        /// Initialize class object and Event
        /// </summary>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        public TechnicalResourcePropertisePaneViewModel(IDialogService dialogService, IEventAggregator eventAggregator, ISharedContextService sharedContextService)
        {
            ShowAddResourceCommand = new DelegateCommand(ShowAddInventoryDialog);
            ActionCommand = new DelegateCommand<string>(OnButtonAction);
            MouseActionCommand = new DelegateCommand<object>(OnMouseAction);
            Inventories = new ObservableCollection<Inventory>();
            // SourceInventories = new ObservableCollection<Inventory>();
            DialogService = dialogService;
            GridColumnDescriptions = new ObservableCollection<GridColumnDescription>();
            IsBtnEditVisible = IsBtnInfoVisible = IsBtnDeleteVisible = false;
            ContextItems = new ObservableCollection<ContextItem>();
            GridColumnDescriptions.AddRange(ColumnsContextProvider.GetTechnicalResourceColumns(out var contextItems));
            if (contextItems == null) return;
            contextItems.ForEach(i => i.PropertyChanged += ContextItems_PropertyChanged);
            ContextItems.AddRange(contextItems);
            eventAggregator.GetEvent<TRTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            eventAggregator.GetEvent<InventoryModelEvent>().Subscribe(OnAddInventories);
            _eventAggregator = eventAggregator;
            this.sharedContextService = sharedContextService;
        }

        /// <summary>
        /// event Handler for Change Master Inventories
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void MasterInventories_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            ProjectContextModel ProjectModel = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
            if (ProjectModel == null)
            {
                ProjectModel = new ProjectContextModel();
            }
            _eventAggregator.GetEvent<ProjectChangeEvent>().Publish(ProjectModel);
        }

        /// <summary>
        /// Called when [comment text changeed].
        /// </summary>
        private void OnCommentTextChangeed()
        {
            _selectedNode.Comment = string.Empty;
            if (string.IsNullOrEmpty(NodeComments)) return;
            _selectedNode.Comment = NodeComments;
        }

        /// <summary>
        /// Called when [add inventories].
        /// </summary>
        /// <param name="inventories">The inventories.</param>
        private void OnAddInventories(List<Inventory> inventories)
        {
            foreach (var inventory in inventories)
                AddInventory(inventory);
            RefreshInventories();
        }

        /// <summary>
        /// Event Handler when Node Selection Change
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnNodeSelectionChanged(INode node)
        {
            IsFirstTabSelected = false;
            Inventories.Clear();
            IsBtnAddInventoryVisible = false;
            if (node == null)
                return;
            _selectedNode = node;
            FilterText = string.Empty;
            NodeComments = _selectedNode.Comment;
            IsFirstTabSelected = true;
            _selectedNode.MasterInventories.CollectionChanged += MasterInventories_CollectionChanged;
            _selectedNode.MasterInventories.ToList().ForEach(i =>
            {
                i.IsSelected = false;
                i.PropertyChanged -= Inventory_PropertyChanged;
            });
            Inventories.AddRange(_selectedNode.Inventories);
            Inventories.ToList().ForEach(i => i.PropertyChanged += Inventory_PropertyChanged);
            ColumnsContextProvider.HideTechnicalResourceColumnByNode(node.NodeType, out var contextItems);
            ContextItems.Clear();
            ContextItems.AddRange(contextItems);
            CollectionViewSource.GetDefaultView(ContextItems).Refresh();

            switch (node.NodeType)
            {
                case NodeType.STOCK:
                case NodeType.COMPETENCIES:
                    IsBtnAddInventoryVisible = true;
                    break;
            }
            RefreshInventories();
        }

        /// <summary>
        /// Event Handler when Filter text value Change.
        /// </summary>
        private void OnFilterChange()
        {
            Inventories.Clear();

            if (FilterText == null || string.IsNullOrEmpty(FilterText))
            {
                Inventories.AddRange(_selectedNode.Inventories);
                return;
            }
            SearchInventories(_selectedNode.Inventories);
        }

        /// <summary>
        /// Search and Add inventories on Ui Collection
        /// </summary>
        /// <param name="inventories">The inventories.</param>
        private async void SearchInventories(IEnumerable<Inventory> inventories)
        {
            var result = await Task.FromResult(inventories.Where(i =>
                i.GetType().GetProperties().Any(k =>
                    k.GetValue(i) != null &&
                    k.GetValue(i).ToString().ToLower()
                        .Contains(FilterText.ToLower().Trim())
                )).ToList());
            Inventories.AddRange(result);
        }

        /// <summary>
        /// Event Handler when ContextItem Property Changed.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="PropertyChangedEventArgs" /> instance containing the event data.</param>
        private void ContextItems_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (!(sender is ContextItem gridColumn)) return;
            var first = GridColumnDescriptions.FirstOrDefault(i => i.Header == gridColumn.DisplayName);
            if (first != null) first.Visibility = gridColumn.IsChecked ? Visibility.Visible : Visibility.Hidden;
        }

        /// <summary>
        /// Remove Selected Inventories
        /// </summary>
        /// <param name="inventories">The inventories.</param>
        private void RemoveInventories(List<Inventory> inventories)
        {
            foreach (var inventory in inventories)
            {
                _selectedNode.MasterInventories.Remove(inventory);
                Inventories.Remove(inventory);
            }

            RowCount = Inventories.Count;
            QuantityCount = Inventories.Sum(i => i.Quantity);
            ReferenceCount = Inventories.Count;
            Inventory_PropertyChanged(null, null);
        }

        /// <summary>
        /// Edit Selected Inventory
        /// </summary>
        /// <param name="inventory">The inventory.</param>
        private void EditInventory(Inventory inventory)
        {
            var parameters = new DialogParameters { { CollectionConstant.Edit, inventory } };
            DialogService.ShowDialog(CollectionConstant.EditInventoryControl, parameters, CloseDialogCallback);
        }

        /// <summary>
        /// Get Selected Inventories Information
        /// </summary>
        /// <param name="inventory">The inventory.</param>
        private void InfoInventory(Inventory inventory)
        {
            var parameters = new DialogParameters
            {
                {CollectionConstant.Edit, inventory},
                {CollectionConstant.InfoInventory, inventory},
                {CollectionConstant.Columns, GridColumnDescriptions.ToList()}
            };
            DialogService.ShowDialog(CollectionConstant.InventoryDetailsControl, parameters, CloseDialogCallback); ;
        }

        /// <summary>
        /// Event Handler for container action on mouse button .
        /// </summary>
        /// <param name="action">The action.</param>
        private void OnMouseAction(object action)
        {
            var inventories = new List<Inventory>();
            if (!(action is RoutedEventArgs mouseEvent)) return;
            if (!(mouseEvent.Source is System.Windows.Controls.MenuItem menuItem)) return;
            if (!(menuItem.Tag is FocusAction focusAction)) return;
            if (focusAction.Inventory == null) return;
            inventories.Add(focusAction.Inventory);//Added focus Inventory

            if (!string.IsNullOrEmpty(focusAction.Action) &&
                focusAction.Action.ToUpper() == CollectionConstant.Delete)
            {
                var selectedItems = _selectedNode.Inventories.ToList().Where(i => i.IsSelected).ToList();// Get selected Inventories
                if (selectedItems.Count > 0)
                {
                    inventories.Clear();
                    inventories.AddRange(selectedItems);
                }
            }
            OnAction(focusAction.Action, inventories);
        }

        /// <summary>
        /// Event Handler for container action button .
        /// </summary>
        /// <param name="actionType">Type of the action.</param>
        private void OnButtonAction(string actionType)
        {
            if (_selectedNode == null)
                return;
            var selectedItems = _selectedNode.Inventories.ToList().Where(i => i.IsSelected).ToList();

            if (!selectedItems.Any())
                return;

            OnAction(actionType, selectedItems);
        }

        /// <summary>
        /// Use for On grid  Action button
        /// </summary>
        /// <param name="actionType">Type of the action.</param>
        /// <param name="selectedItems">The selected items.</param>
        private void OnAction(string actionType, List<Inventory> selectedItems)
        {
            if (string.IsNullOrEmpty(actionType) || (selectedItems == null || selectedItems.Count == 0))
                return;
            switch (actionType.ToUpper())
            {
                case CollectionConstant.Delete:
                    if (ShowMessages(selectedItems.Select(i => i.Reference).ToList()))
                        RemoveInventories(selectedItems);
                    break;

                case CollectionConstant.Edit:
                    if (selectedItems.Count() > 1)
                        return;
                    EditInventory(selectedItems.FirstOrDefault());
                    break;

                case CollectionConstant.ViewDetails:
                case CollectionConstant.Info:
                    if (selectedItems.Count > 1)
                        return;
                    InfoInventory(selectedItems.FirstOrDefault());

                    break;
            }
        }

        /// <summary>
        /// Show Message Box Dialog
        /// </summary>
        /// <param name="messages">The messages.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ShowMessages(IReadOnlyCollection<string> messages)
        {
            var returnValue = false;
            if (messages == null || !messages.Any())
                return false;

            var parameters = new DialogParameters
            {
                {CollectionConstant.MessageLabel,string.Format(CollectionConstant.MessageDeleteInventory, messages.Count())},
                {CollectionConstant.MessageCollection, messages},
                {CollectionConstant.Title, CollectionConstant.DeleteInventories},
                {CollectionConstant.IsCancelVisible, true}// set if require Cancel button
            };

            DialogService.ShowDialog("CustomMessageCollectionDialog", parameters,
                result => returnValue = result.Result == ButtonResult.OK);
            return returnValue;
        }

        /// <summary>
        /// Add new inventory,. if inventory is already exist it will update the Quantity
        /// </summary>
        /// <param name="inventory">The inventory.</param>
        private void AddInventory(Inventory inventory)
        {
            if (inventory == null) return;

            var existInventoryItem = GetExistingInventory(inventory);
            if (existInventoryItem != null)
            {
                existInventoryItem.Quantity = (existInventoryItem.Quantity + inventory.Quantity);
                return;
            }
            _selectedNode.MasterInventories.Add(inventory);
            Inventories.Add(inventory);
            inventory.PropertyChanged += Inventory_PropertyChanged;
            RefreshInventories();
        }

        /// <summary>
        /// Get the Existing Inventory
        /// </summary>
        /// <param name="inventory">The inventory.</param>
        /// <returns>Inventory.</returns>
        private static Inventory GetExistingInventory(Inventory inventory)
        {
            return _selectedNode.MasterInventories.FirstOrDefault(i =>
                i.Reference == inventory.Reference &&
                i.SvNumber == inventory.SvNumber &&
                i.PvNumber == inventory.PvNumber &&
                i.Configuration == inventory.Configuration &&
                i.Comment == inventory.Comment &&

                i.FactoryId == inventory.FactoryId &&
                i.WorkshopId == inventory.WorkshopId &&
                i.MachineId == inventory.MachineId &&
                i.LineId == inventory.LineId &&
                i.ConfigurationId == inventory.ConfigurationId);
        }

        /// <summary>
        /// Handles the PropertyChanged event of the Inventory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="PropertyChangedEventArgs" /> instance containing the event data.</param>
        private void Inventory_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            IsBtnEditVisible = IsBtnInfoVisible = IsBtnDeleteVisible = false;
            IsBtnEditVisible = IsBtnInfoVisible = IsBtnDeleteVisible = (Inventories.Count(i => i.IsSelected) == 1);
            if (Inventories.Count(i => i.IsSelected) > 1)
            {
                IsBtnEditVisible = IsBtnInfoVisible = false;
                IsBtnDeleteVisible = true;
            }
        }

        /// <summary>
        /// Open Add Inventory Dialog box
        /// </summary>
        private void ShowAddInventoryDialog()
        {
            var parameters = new DialogParameters
            {
                { CollectionConstant.TechnicalResource, _selectedNode },
                {  CollectionConstant.Years, new Years()
                {
                    Year  = GridColumnDescriptions.FirstOrDefault(i=>i.DisplayMember==CollectionConstant.Year)?.Header,
                    Year1 = GridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year1)?.Header,
                    Year2 = GridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year2)?.Header,
                    Year3 = GridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year3)?.Header,
                    Year4 = GridColumnDescriptions.FirstOrDefault(i => i.DisplayMember == CollectionConstant.Year4)?.Header
                } }
            };
            DialogService.ShowDialog(CollectionConstant.AddInventoryDialog, parameters, CloseDialogCallback);
        }

        /// <summary>
        /// Closes the dialog callback.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        private void CloseDialogCallback(IDialogResult dialogResult)
        {
            if (dialogResult.Result != ButtonResult.OK)
                return;

            if (dialogResult.Parameters.TryGetValue(CollectionConstant.Edit, out Inventory editInventory))
                RefreshInventories();
            else if (dialogResult.Parameters.TryGetValue(CollectionConstant.Add, out Inventory addInventory))
                AddInventory(addInventory);
            else if (dialogResult.Parameters.TryGetValue(CollectionConstant.AddConfig, out List<Inventory> inventories))
            {
                foreach (var inventory in inventories)
                    AddInventory(inventory);
            }

            RefreshInventories();
        }

        /// <summary>
        /// Refreshes the inventories.
        /// </summary>
        private void RefreshInventories()
        {
            CollectionViewSource.GetDefaultView(Inventories).Refresh();
            RowCount = Inventories.Count;
            QuantityCount = Inventories.Sum(i => i.Quantity);
            ReferenceCount = Inventories.Count;
            Inventory_PropertyChanged(null, null);
        }
    }
}