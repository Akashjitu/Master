# Angular-Routing
Materials for the ["Angular Routing"](http://bit.ly/Angular-routing) course on Pluralsight.

`APM-Start`: The starter files. **Use this to code along with the course**. (Updated for <i>Angular version 7 or higher</i>)

`APM-Final`: The completed files. Use this to see the completed solution from the course. (Updated for <i>Angular version 7 or higher</i>)

See the `README.md` file under each folder for details on installing and running the application.
