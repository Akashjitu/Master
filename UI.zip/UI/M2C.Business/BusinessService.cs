﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="BusinessService.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository;
using DataRepository.DBContracts;
using DataRepository.Queries;
using InputParserLibary.Contracts;
using InputParserLibary.Implementation;
using M2C.Business.Contracts;
using M2C.Business.Filters;
using M2C.Business.Implementations;
using M2C.Business.Mappers;
using M2C.Business.Mappers.ProjectMap;
using Prism.Ioc;
using RestClientServices;
using RestClientServices.Contracts;
using Schneider.M2C.OpenExcel.Parser;
using SyncServiceLibrary.Contracts;
using SyncServiceLibrary.Implementation;
using SyncServiceLibrary.Mapper;

namespace M2C.Business
{
    /// <summary>
    /// Class BusinessService.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class BusinessService
    {
        /// <summary>
        /// Registers the types.
        /// </summary>
        /// <param name="containerRegistry">The container registry.</param>
        public static void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterSingleton<IBusinessUtilities, BusinessUtilities>();
            containerRegistry.RegisterSingleton<IMyProfileLogic, MyProfileLogic>();
            containerRegistry.RegisterSingleton<ICommonInventoryReference, CommonInventoryReference>();
            containerRegistry.RegisterSingleton<IBrandModelMapper, BrandModelMapper>();
            containerRegistry.RegisterSingleton<IRangeModelMapper, RangeModelMapper>();
            containerRegistry.RegisterSingleton<IDeviceTypeModelMapper, DeviceTypeModelMapper>();
            containerRegistry.RegisterSingleton<IProductModelMapper, ProductModelMapper>();
            containerRegistry.RegisterSingleton<IProjectLogic, ProjectLogic>();
            containerRegistry.RegisterSingleton<IProjectBusinessModelBuilder, ProjectBusinessModelBuilder>();
            containerRegistry.RegisterSingleton<IBrandQueries, ProductQueries>();
            containerRegistry.RegisterSingleton<IFilterIbCatalogProductCategoryQueries, ProductQueries>();
            containerRegistry.RegisterSingleton<IFilterIbCatalogStatusIpCreationQueries, ProductQueries>();
            containerRegistry.RegisterSingleton<IFilterIbCatalogBuQueries, ProductQueries>();
            containerRegistry.RegisterSingleton<IPositionQueries, ProjectQueries>();
            containerRegistry.RegisterSingleton<ICountryQueries, ProjectQueries>();
            containerRegistry.RegisterSingleton<IProfileQueries, ProjectQueries>();
            containerRegistry.RegisterSingleton<IRangeQueries, ProductQueries>();
            containerRegistry.RegisterSingleton<IProjectDbModelBuilder, ProjectDbModelBuilder>();
            containerRegistry.RegisterSingleton<IDeviceTypeQueries, ProductQueries>();
            containerRegistry.RegisterSingleton<IStatusColorProvider, StatusColorProvider>();
            containerRegistry.RegisterSingleton<ISubRangeQueries, ProductQueries>();
            containerRegistry.RegisterSingleton<IProductQueries, ProductQueries>();
            containerRegistry.Register<ISyncServiceQueries, ProductQueries>();
            containerRegistry.Register<ISyncProjectQueries, SyncProjectQueries>();

            containerRegistry.Register<IDbContextFactory, ApplicationDbContextFactory>();
            containerRegistry.RegisterSingleton<IExcelParser, ExcelParser>();
            containerRegistry.RegisterSingleton<ICriticalityLogic, CriticalityLogic>();
            containerRegistry.RegisterSingleton<IExcelImport, ExcelImport>();
            containerRegistry.RegisterSingleton<IExcelExport, ExcelExport>();
            containerRegistry.RegisterSingleton<IInventoryMapper, InventoryMapper>();
            containerRegistry.RegisterSingleton<IFilterNodeInventory, FilterNodeInventory>();
            containerRegistry.RegisterSingleton<IExcelExport, ExcelExport>();
            containerRegistry.RegisterSingleton<ICriticalityLogic, CriticalityLogic>();
            containerRegistry.Register<IExcelWriter, OpenXMLWriter>();
            containerRegistry.Register<ICOMAppFactory, COMAppFactory>();
            containerRegistry.Register<IOperationModeLogic, OperationModeLogic>();
            containerRegistry.Register<IProductSync, ProductSync>();

            //DB layer
            containerRegistry.Register<IProjectQueries, ProjectQueries>();
            containerRegistry.Register<IDbContextFactory, ApplicationDbContextFactory>();

            containerRegistry.Register<ITemplateDownloadLogic, TemplateDownloadLogic>();
            containerRegistry.Register<IExcelReader, InterOpExcelReader>();

            //Shared Library
            containerRegistry.Register<IRestServicesFactory, RestServicesFactory>();

            //SyncServices Library
            containerRegistry.Register<IProductSynchronizer, ProductSynchronizer>();
            containerRegistry.Register<ISyncServiceDataMapper, SyncServiceDataMapper>();
            containerRegistry.Register<IProjectSynchronizer, ProjectSynchronizer>();
            containerRegistry.Register<IProjectMapper, ProjectMapper>();
        }

        /// <summary>
        /// Migrates this instance.
        /// </summary>
        public static void Migrate()
        {
            using (IDbContext db = new ProjectDbContext())
            {
                db.Migrate();
            }

            using (IDbContext db = new ProductDbContext())
            {
                db.Migrate();
            }

            //Excel based migration code disabled because
            //needed only when pre-populated DB creation required
            //new ProductSync(new ProductQueries(new ApplicationDbContextFactory()))
            //    .SyncProductDataAsync();
        }
    }
}