import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DropdownDirective } from './directive/dropdown.directive';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TranslateModule } from '@ngx-translate/core';
import { StoreModule } from '@ngrx/store';
import { reducer } from './store/accoladeReducer';
import { AccoladeService } from './services/accolade-service.service';

import { DpDatePickerModule } from 'ng2-date-picker';
import { complianceReducer } from './store/compliance/complianceReducer';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MainDashBoardComponent } from './main-dash-board/main-dash-board.component';
import { GridsterModule } from 'angular-gridster2';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { CommonDetailsComponent } from './keycode/common-details/common-details.component';
import { ProgramOverviewComponent } from './keycode/program-overview/program-overview.component';
import { PliComponent } from './keycode/pli/pli.component';
import { HeatMapComponent } from './keycode/heat-map/heat-map.component';
import { DataComplianceComponent } from './keycode/data-compliance/data-compliance.component';

import { OtlScoreCardComponent } from './keycode/otl-score-card/otl-score-card.component';
import { OtlScoreCardInfoComponent } from './otl-score-card/otl-score-card.component';

import { KeyMainViewComponent } from './keycode/key-main-view/key-main-view.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AgGridModule } from 'ag-grid-angular';
import { AgTtiComponent } from './ag-tti/ag-tti.component';
import { otlDispositioneReducer } from './store/otlDisposition/otlDispositionReducer';
import { effectivenessReducer } from './store/effectiveness/effectivenessReducer';
import { pliSummaryReducer } from './store/pliSummary/pliSummaryReducer';
import { effectivenessAnalysisReducer } from './store/effectivenessAnalysis/effectivenessAnalysisReducer';
import { AngularEditorModule } from '@kolkov/angular-editor';
import {AccordionModule} from 'primeng/accordion';

import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule,
} from '@angular/material';
import { PliSummaryComponent } from './pli-summary/pli-summary.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { EffectivenessAnalysisComponent } from './effectiveness-analysis/effectiveness-analysis.component';
import { ChartModule } from 'primeng/chart';
import { MessageService } from 'primeng/components/common/messageservice';
import { UiSwitchModule } from 'ngx-ui-switch';
import { UserControlComponent } from './admin/user-control/user-control.component';
import { OtlHealthComponent } from './otl-health/otl-health.component';
import { UserInfoComponent } from './admin/user-info/user-info.component';
import { OtlDispositionComponent } from './otl-disposition/otl-disposition.component';
import { PpmFutureComponent } from './ppm-future/ppm-future.component';
import { OtlCatMilestonesComponent } from './otl-cat-milestones/otl-cat-milestones.component';
import { OtlMorNotesComponent } from './otl-mor-notes/otl-mor-notes.component';
import { EffectivenessPartsListComponent } from './effectiveness-parts-list/effectiveness-parts-list.component';
import { OtlGraduatesComponent } from './otl-graduates/otl-graduates.component';
import { CoreIptMemberListComponent } from './core-ipt-member-list/core-ipt-member-list.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { NotifierModule, NotifierOptions } from 'angular-notifier';
import {DatePipe} from '@angular/common';
import { OtlSummaryGridComponent } from './otl-summary-grid/otl-summary-grid.component';
import { otlGridSummaryReducer } from './store/otlSummery/otlSummaryReducer';
import { otlScoreCardReducer } from './store/otlScoreCard/otlScoreCardReducer';
import { otlGraduatesReducer } from './store/otlGraduates/otlGraduatesReducer';
import { coreIptReducer } from './store/coreIpt/corIptReducer';
//import { otlSummaryReducer, otlGridSummaryReducer } from './store/otlSummery/otlSummaryReducer';

const customNotifierOptions: NotifierOptions = {
  position: {
		horizontal: {
			position: 'right',
			distance: 12
		},
		vertical: {
			position: 'top',
			distance: 12,
			gap: 10
		}
	},
  theme: 'material',
  behaviour: {
    autoHide: 5000,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 4
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 300,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 300,
      easing: 'ease',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};

@NgModule({
  declarations: [
    OtlScoreCardInfoComponent,
    AppComponent,
    HeaderComponent,
    DropdownDirective,
    AgTtiComponent,
    FeedbackComponent,
    //AngularFontAwesomeModule,
    CommonDetailsComponent,
    ProgramOverviewComponent,
    MainDashBoardComponent,
    PliComponent,
    HeatMapComponent,
    DataComplianceComponent,
    OtlScoreCardComponent,
    KeyMainViewComponent,
    PliSummaryComponent,
    EffectivenessAnalysisComponent,
    UserControlComponent,
    OtlHealthComponent,
    UserInfoComponent,
    OtlDispositionComponent,
    PpmFutureComponent,
    OtlCatMilestonesComponent,
    OtlMorNotesComponent,
    EffectivenessPartsListComponent,
    OtlGraduatesComponent,
    CoreIptMemberListComponent,
    OtlSummaryGridComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    DpDatePickerModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    AccordionModule,
    GridsterModule,
    NgxSpinnerModule,
    AngularEditorModule,
    TranslateModule.forRoot(),
    ChartModule,
    NgMultiSelectDropDownModule.forRoot(),
    AgGridModule.withComponents([]),
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    ModalModule.forRoot(),
    StoreModule.forRoot({
      accoladeReducer: reducer,
      compliance: complianceReducer,
      otlDispositione: otlDispositioneReducer,
      effectiveness: effectivenessReducer,
      effectivenessAnalysis: effectivenessAnalysisReducer,
      pliSummaryReducer: pliSummaryReducer,
      otlSummaryReducer: otlGridSummaryReducer,
      otlScoreCardReducer: otlScoreCardReducer,
      otlGraduatesReducer: otlGraduatesReducer,
      coreIptReducer: coreIptReducer
    }),
    NotifierModule.withConfig(customNotifierOptions),
    UiSwitchModule
  ],
  providers: [AccoladeService,MessageService,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
