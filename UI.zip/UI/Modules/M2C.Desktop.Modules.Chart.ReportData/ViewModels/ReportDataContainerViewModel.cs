﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReportDataContainerViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Desktop.Modules.Charts.ReportData.ViewModels
{
    /// <summary>
    /// Class ChartContainerViewModel.
    /// </summary>
    public class ChartContainerViewModel
    {
    }
}
