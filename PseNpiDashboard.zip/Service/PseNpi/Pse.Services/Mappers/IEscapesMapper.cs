﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;
using System.Data;

namespace Pse.Services.Mappers
{
    public interface IEscapesMapper
    {
        Dictionary<int, int[]> GetMapDictionary(List<Escapes> escapes);

        DataTable GetMapDataTable(List<Escapes> escapes);
    }
}