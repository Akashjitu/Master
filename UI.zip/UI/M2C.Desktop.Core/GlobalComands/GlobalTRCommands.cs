﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="GlobalTRCommands.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Commands;

namespace M2C.Desktop.Core.GlobalComands
{
    /// <summary>
    /// Technical Resource command Interface
    /// </summary>
    public interface IGlobalTRCommands
    {
        /// <summary>
        /// Gets the add tr node command.
        /// </summary>
        /// <value>The add tr node command.</value>
        CompositeCommand AddTRNodeCommand { get; }
        /// <summary>
        /// Gets the import tr component command.
        /// </summary>
        /// <value>The import tr component command.</value>
        CompositeCommand ImportTRComponentCommand { get; }
        /// <summary>
        /// Gets the export TR command
        /// </summary>
        /// <value>The export tr componenet command.</value>
        CompositeCommand ExportTRComponenetCommand { get; }
    }

    /// <summary>
    /// Technical Resource command Implementation
    /// </summary>
    /// <seealso cref="M2C.Desktop.Core.GlobalComands.IGlobalTRCommands" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class GlobalTRCommands : IGlobalTRCommands
    {
        /// <summary>
        /// Gets the add tr node command.
        /// </summary>
        /// <value>The add tr node command.</value>
        public CompositeCommand AddTRNodeCommand { get; } = new CompositeCommand();
        /// <summary>
        /// Gets the import tr component command.
        /// </summary>
        /// <value>The import tr component command.</value>
        public CompositeCommand ImportTRComponentCommand { get; } = new CompositeCommand();
        /// <summary>
        /// Gets the export TR command
        /// </summary>
        /// <value>The export tr componenet command.</value>
        public CompositeCommand ExportTRComponenetCommand { get; } = new CompositeCommand();
    }
}