﻿// ***********************************************************************
// Assembly         : InputParserLibary
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ExcelDataColumn.cs" company="InputParserLibary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace InputParserLibary.DataModels
{
    /// <summary>
    /// Class ExcelDataColumn.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ExcelDataColumn
    {
        /// <summary>
        /// Gets or sets the name of the header.
        /// </summary>
        /// <value>The name of the header.</value>
        public string HeaderName { get; set; }
    }
}
