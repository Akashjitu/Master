﻿namespace M2C.Desktop.Modules.Charts.ViewModels
{
    public class ChartContainerViewModelTest
    {
    }
}