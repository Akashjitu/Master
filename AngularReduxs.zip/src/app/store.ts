import { ITodo } from "./todo";

import {ADD_TODO, REMOVE_ALL_TODO, REMOVE_TODO, TOGGLE_TODO } from './action';

export interface IAppSate {
todos: ITodo[];
lastUpdate: Date;
}

export const INITIAL_STATE: IAppSate = {
    todos: [],
    lastUpdate: null
}

export function rootReducer(state, action) {

    switch (action.type) {
        case ADD_TODO:
        action.todo.id = state.todos.length + 1;
        return  Object.assign({}, state,{
            todos: state.todos.concat(Object.assign({}, action.todo)),
            lastUpate: new Date()
        }) 
        

        case REMOVE_ALL_TODO:
        return Object.assign({}, state, {
            todos: [],
            lastUpate: new Date()
        })
        break;

        case REMOVE_TODO:
         return Object.assign({}, state, {
             todos: state.todos.filter(t=> t.id != action.id ),
             lastUpate: new Date()
         })

        case TOGGLE_TODO:
        var todo= state.find(t=>t.id==action.id);
        var index = state.todos.indexOf(todo);
        return Object.assign({}, state, {
            todos: [
                ...state.todos.slice(0, index),
                Object.assign({}, todo,{isCompleted: !todo.isCompleted}),
                ...state.todos.slice(index+1)
            ],
            lastUpate: new Date()
        })
       
       
    }
    return state 
}