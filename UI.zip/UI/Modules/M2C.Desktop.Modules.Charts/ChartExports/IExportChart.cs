﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IExportChart.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using DevExpress.Xpf.Charts;

namespace M2C.Desktop.Modules.Charts.ChartExports
{
    /// <summary>
    /// Interface IExportChart
    /// </summary>
    public interface IExportChart
    {
        /// <summary>
        /// Exports the specified chart control.
        /// </summary>
        /// <param name="chartControl">The chart control.</param>
        /// <param name="headingValue">The heading value.</param>
        /// <param name="exportType">Type of the export.</param>
        void Export(ChartControl chartControl, string headingValue , ExportType exportType);
    }
}