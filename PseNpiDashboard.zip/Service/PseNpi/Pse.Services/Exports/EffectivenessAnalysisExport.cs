﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;
using System;

namespace Pse.Services.ExcelExports
{
    public class EffectivenessAnalysisExports : IEffectivenessAnalysisExports
    {
        public byte[] Export(List<EffectivenessAnalysis> eEffectivenessAnalysis)
        {
            throw new NotImplementedException();
        }
    }
}