﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="RestServicesFactory.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using RestClientServices.Contracts;
using RestClientServices.Services;
using RestSharp;
using WinRegistryServices.Contracts;

namespace RestClientServices
{
    /// <summary>
    /// Class RestServicesFactory.
    /// Implements the <see cref="RestClientServices.Contracts.IRestServicesFactory" />
    /// </summary>
    /// <seealso cref="RestClientServices.Contracts.IRestServicesFactory" />
    public class RestServicesFactory : IRestServicesFactory
    {
        /// <summary>
        /// The application configurations
        /// </summary>
        private readonly IAppConfigurations appConfigurations;

        /// <summary>
        /// The rest client
        /// </summary>
        private readonly IRestClient restClient;
        /// <summary>
        /// The registry store manger
        /// </summary>
        private readonly IRegistryStoreManger registryStoreManger;

        /// <summary>
        /// Initializes a new instance of the <see cref="RestServicesFactory" /> class.
        /// </summary>
        /// <param name="appConfigurations">The application configurations.</param>
        /// <param name="restClient">The rest client.</param>
        /// <param name="registryStoreManger">The registry store manger.</param>
        public RestServicesFactory(IAppConfigurations appConfigurations, IRestClient restClient, IRegistryStoreManger registryStoreManger)
        {
            this.appConfigurations = appConfigurations;
            this.restClient = restClient;
            this.registryStoreManger = registryStoreManger;
        }

        /// <summary>
        /// Gets the rest client service.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="serviceType">Type of the service.</param>
        /// <returns>IRestClientService.</returns>
        public T GetRestClientService<T>(RestServiceTypes serviceType) where T : IRestClientService
        {
            T restClientService = default(T);

            switch (serviceType)
            {
                case RestServiceTypes.PROJECT_SYNC_SERVICE:
                    {
                        restClientService = (T)(new ProjectSyncService(appConfigurations, restClient, registryStoreManger) as object);
                    }
                    break;

                case RestServiceTypes.PRODUCT_SYNC_SERVICE:
                    {
                        restClientService = (T)(new ProductSyncService(appConfigurations, restClient, registryStoreManger) as object);
                    }
                    break;

                case RestServiceTypes.AUTH_SERVICE:
                    {
                        restClientService = (T)(new AuthService(appConfigurations, restClient) as object);
                    }
                    break;
            }

            return restClientService;
        }
    }
}