import { Component, OnInit } from '@angular/core';
import { GridsterConfig, GridsterItem, GridsterItemComponent, CompactType, GridType, GridsterPush, DisplayGrid } from 'angular-gridster2';
import { Element } from '@angular/compiler/src/render3/r3_ast';
import { Router } from '@angular/router';
@Component({
  selector: 'app-main-dash-board',
  templateUrl: './main-dash-board.component.html',
  styleUrls: ['./main-dash-board.component.css']
})
export class MainDashBoardComponent implements OnInit {

  constructor(private router: Router) { }

  options: GridsterConfig;
  dashboard: Array<GridsterItem>;
  itemToPush: GridsterItemComponent;

  ngOnInit() {
    this.options = {
      gridType: GridType.Fit,
      compactType: CompactType.None,
      margin: 5,
      outerMargin: true,
      outerMarginTop: null,
      outerMarginRight: null,
      outerMarginBottom: null,
      outerMarginLeft: null,
      useTransformPositioning: true,
      mobileBreakpoint: 640,
      minCols: 1,
      maxCols: 100,
      minRows: 1,
      maxRows: 100,
      maxItemCols: 100,
      minItemCols: 1,
      maxItemRows: 100,
      minItemRows: 1,
      maxItemArea: 2500,
      minItemArea: 1,
      defaultItemCols: 1,
      defaultItemRows: 1,
      fixedColWidth: 105,
      fixedRowHeight: 105,
      keepFixedHeightInMobile: false,
      keepFixedWidthInMobile: false,
      scrollSensitivity: 10,
      scrollSpeed: 20,
      enableEmptyCellClick: false,
      enableEmptyCellContextMenu: false,
      enableEmptyCellDrop: false,
      enableEmptyCellDrag: false,
      emptyCellDragMaxCols: 50,
      emptyCellDragMaxRows: 50,
      ignoreMarginInRow: false,
      draggable: {
        enabled: true,
      },
      resizable: {
        enabled: true,
      },
      swap: true,
      pushItems: true,
      disablePushOnDrag: false,
      disablePushOnResize: false,
      pushDirections: { north: true, east: true, south: true, west: true },
      pushResizeItems: false,
      displayGrid: DisplayGrid.None,
      disableWindowResize: false,
      disableWarnings: false,
      scrollToNewItems: false
    };

    this.dashboard = [
      {
        summary: 'Program details  and dashboard of producibility content by Key Code: Scope and Performance.',
        key: 'keycode', icon: 'fa fa-key', text: 'FL Program Details', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },

      {
        summary: 'Summary & Notes prep file required for monthly OTL MOR.',
        key: 'notes', icon: 'fa fa-sticky-note', text: 'OTL MOR Prep – Summary & Notes', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },


      {
        summary: 'NPD BI assessment of Program OTL Health (on a 12 month rolling look-ahead).',
        key: 'otlhealth', icon: 'fa fa-stethoscope', text: 'OTL Health', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },


      {
        summary: 'Risk rating for each Producibility Leading Indicator for each program: ESE, CRF, IRF, RTY, UPC, APQP.',
        key: 'pli', icon: 'fa fa-sitemap', text: 'PLI Summary', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },

      {
        summary: 'List of programs outlining the disposition decision of Flawless Launch and OTL applicability by Key Code.',
        key: 'disposition', icon: 'fa fa-file-text', text: 'OTL Disposition', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },

      {
        summary: 'Summary of current Heatmap Key Codes by SBU.',
        key: 'ppmFuture', icon: 'fa fa-table', text: 'PPM - Future', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },

      {
        summary: 'All HMR CAT1, flagged On Time Launch  and Early Supplier Engagement  milestones by Key Code.',
        key: 'otlmilestones', icon: 'fa fa-line-chart', text: 'OTL & ESE CAT 1 Milestones', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },


      {
        summary: 'List of part details by Key Code that have graduated OTL.',
        key: 'parts', icon: 'fa fa-plane', text: 'Effectiveness Parts List', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },
    
      

      {
        summary: 'Graphical representation of month over month effectiveness of escapes manufactured after OTL.',
        key: 'analysis', icon: 'fa fa-pie-chart', text: 'Effectiveness Analysis', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },

      {
        summary: 'List of key codes that have graduated OTL', key: 'graduates', icon: 'fa fa-graduation-cap',
        text: 'OTL Graduates', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },
      {
        summary: 'Name of each IPT member within each program team by Key Code.',
        key: 'ipt', icon: 'fa fa-user-circle-o', text: 'Core IPT Member List', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },

      {
        summary: '', key: 'otlscorecard', icon: 'glyphicon glyphicon-credit-card',
        text: 'OTL Score Card', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },


      {
        summary: 'Target to complete master parts list summary by year: ESE, OTL, RTY',
        key: 'tti', icon: 'fa fa-users', text: 'TTI Master PL Summary', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this)
      },

      { summary: '', key: 'otlsummerygrid', icon: 'glyphicon glyphicon-inbox', text: 'OTL Summery', cols: 1, rows: 1, y: 0, x: 0, initCallback: this.initItem.bind(this) },
    ];
  }

  changedOptions() {
    if (this.options.api && this.options.api.optionsChanged) {
      this.options.api.optionsChanged();
    }
  }

  removeItem($event, item) {
    $event.preventDefault();
    $event.stopPropagation();
    this.dashboard.splice(this.dashboard.indexOf(item), 1);
  }

  addItem() {
    this.dashboard.push({ x: 0, y: 0, cols: 1, rows: 1 });
  }

  initItem(item: GridsterItem, itemComponent: GridsterItemComponent) {
    this.itemToPush = itemComponent;
  }

  pushItem() {
    const push = new GridsterPush(this.itemToPush); // init the service
    this.itemToPush.$item.rows += 2; // move/resize your item
    if (push.pushItems(push.fromNorth)) { // push items from a direction
      push.checkPushBack(); // check for items can restore to original position
      push.setPushedItems(); // save the items pushed
      this.itemToPush.setSize();
      this.itemToPush.checkItemChanges(this.itemToPush.$item, this.itemToPush.item);
    } else {
      this.itemToPush.$item.rows -= 4;
      push.restoreItems(); // restore to initial state the pushed items
    }
    push.destroy(); // destroy push instance
    // similar for GridsterPushResize and GridsterSwap
  }
  test(event) {
    //  (event as Element);
    //["../Dashboard"]
    this.router.navigate([event.key]);
    console.log('Clicked ' + JSON.stringify(event));
  }
}
