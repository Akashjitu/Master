﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CustomerDocuments.xaml.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Desktop.Modules.CollectData.UIModels;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for CustomerDocuments.xaml
    /// </summary>
    public partial class CustomerDocuments : UserControl
    {
        /// <summary>
        /// The customer document
        /// </summary>
        private CustomerDocument _customerDocument;
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerDocuments" /> class.
        /// </summary>
        public CustomerDocuments()
        {
            InitializeComponent();
            GdrContextMenu.IsOpen = false;
            GdrContextMenu.Visibility = Visibility.Hidden;
        }

        /// <summary>
        /// Handles the Opened event of the ContextMenu control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.RoutedEventArgs" /> instance containing the event data.</param>
        private void ContextMenu_Opened(object sender, RoutedEventArgs e)
        {
            GdrContextMenu.DataContext = this.DataContext;
        }

        /// <summary>
        /// Handles the OnContextMenuOpening event of the FrameworkElement control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ContextMenuEventArgs" /> instance containing the event data.</param>
        private void FrameworkElement_OnContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            GdrContextMenu.Visibility = _customerDocument == null ? Visibility.Hidden : Visibility.Visible;
        }

        /// <summary>
        /// Handles the OnPreviewMouseDown event of the UIElement control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="MouseButtonEventArgs" /> instance containing the event data.</param>
        private void UIElement_OnPreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            _customerDocument = GetFocusInventroy(e);
        }

        /// <summary>
        /// Gets the focus inventroy.
        /// </summary>
        /// <param name="e">The <see cref="MouseButtonEventArgs" /> instance containing the event data.</param>
        /// <returns>CustomerDocument.</returns>
        private CustomerDocument GetFocusInventroy(MouseButtonEventArgs e)
        {
            var hitTestResult = VisualTreeHelper.HitTest(dgDocItems, e.GetPosition(dgDocItems));
            var dataGridRow = hitTestResult.VisualHit.GetParentOfType<DataGridRow>();
            if (dataGridRow != null && dgDocItems.Items.Count > 0)
                return (CustomerDocument)dgDocItems.Items[dataGridRow.GetIndex()];
            return null;
        }

        /// <summary>
        /// Handles the OnMouseDown event of the MenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="MouseButtonEventArgs" /> instance containing the event data.</param>
        private void MenuItem_OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is MenuItem item)
                item.Tag = new FocusAction { CustomerDocument = _customerDocument, Action = item.Header.ToString() };
            e.Handled = true;
        }
    }
}
