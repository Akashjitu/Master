﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SyncService_Constants.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace SyncServiceLibrary
{
    /// <summary>
    /// SyncService Constants
    /// </summary>
    public class SyncService_Constants
    {
        /// <summary>
        /// The PLC configuration
        /// </summary>
        public const string PLC_CONFIG = "PLC_CONFIG";
        /// <summary>
        /// The md configuration
        /// </summary>
        public const string MD_CONFIG = "MD_CONFIG";
        /// <summary>
        /// The shmi configuration
        /// </summary>
        public const string SHMI_CONFIG = "SHMI_CONFIG";
        /// <summary>
        /// The open configuration
        /// </summary>
        public const string OPEN_CONFIG = "OPEN_CONFIG";
        /// <summary>
        /// The none
        /// </summary>
        public const string NONE = "NONE";
    }
}
