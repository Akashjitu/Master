﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="CriticalityDialogViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Models;
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.ObjectModel;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class CriticalityDialogViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <summary>
    /// Class CriticalityDialogViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    internal class CriticalityDialogViewModel : BindableBase, IDialogAware
    {
        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => "Add Criticality";

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// The event aggregator
        /// </summary>
        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator _eventAggregator;
        /// <summary>
        /// The inventory mapper
        /// </summary>
        /// <summary>
        /// The inventory mapper
        /// </summary>
        private readonly IInventoryMapper _inventoryMapper;

        /// <summary>
        /// The safety issue model
        /// </summary>
        /// <summary>
        /// The safety issue model
        /// </summary>
        private SafetyIssue _safetyIssueModel;
        /// <summary>
        /// The criticality
        /// </summary>
        /// <summary>
        /// The criticality
        /// </summary>
        private CriticalityValue _criticality;
        /// <summary>
        /// The criticality suggested
        /// </summary>
        /// <summary>
        /// The criticality suggested
        /// </summary>
        private CriticalityValue _criticalitySuggested;
        /// <summary>
        /// The quality
        /// </summary>
        /// <summary>
        /// The quality
        /// </summary>
        private ObservableCollection<string> _quality;
        /// <summary>
        /// The current command parameter
        /// </summary>
        /// <summary>
        /// The current command parameter
        /// </summary>
        private string currentCommandParam = string.Empty;
        /// <summary>
        /// The safety selected
        /// </summary>
        private CriticalityKV<SafetyIssue> safetySelected;
        /// <summary>
        /// The criticality selected
        /// </summary>
        private CriticalityKV<CriticalityValue> criticalitySelected;
        /// <summary>
        /// The criticality suggested
        /// </summary>
        private CriticalityKV<CriticalityValue> criticalitySuggested;
        /// <summary>
        /// The selected quality
        /// </summary>
        private string _selectedQuality;
        /// <summary>
        /// The selected lead time
        /// </summary>
        private string _selectedLeadTime;
        /// <summary>
        /// The selected costs issue
        /// </summary>
        private string _selectedCostsIssue;
        /// <summary>
        /// The comments
        /// </summary>
        private string _comments;

        /// <summary>
        /// Gets the critical logic.
        /// </summary>
        /// <value>The critical logic.</value>
        private ICriticalityLogic criticalLogic { get; }
        /// <summary>
        /// Gets or sets the selected safety issue.
        /// </summary>
        /// <value>The selected safety issue.</value>
        public SafetyIssue SelectedSafetyIssue { get => _safetyIssueModel; set => SetProperty(ref _safetyIssueModel, value); }

        /// <summary>
        /// Gets or sets the selected criticality.
        /// </summary>
        /// <value>The selected criticality.</value>
        public CriticalityValue SelectedCriticality { get => _criticality; set => SetProperty(ref _criticality, value); }
        /// <summary>
        /// Gets or sets the suggested criticality.
        /// </summary>
        /// <value>The suggested criticality.</value>
        public CriticalityValue SuggestedCriticality { get => _criticalitySuggested; set => SetProperty(ref _criticalitySuggested, value); }

        /// <summary>
        /// Gets or sets the on selection change command.
        /// </summary>
        /// <value>The on selection change command.</value>
        public DelegateCommand<string> OnSelectionChangeCommand { get; set; }

        /// <summary>
        /// Gets or sets the on criticality change command.
        /// </summary>
        /// <value>The on criticality change command.</value>
        public DelegateCommand<string> OnCriticalityChangeCommand { get; set; }
        /// <summary>
        /// Gets or sets the close dialog command.
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }

        /// <summary>
        /// Gets or sets the quality.
        /// </summary>
        /// <value>The quality.</value>
        public ObservableCollection<string> Quality
        {
            get => _quality;
            set => _quality = value;
        }

        /// <summary>
        /// Gets or sets the selected quality.
        /// </summary>
        /// <value>The selected quality.</value>
        public string SelectedQuality { get => _selectedQuality; set => SetProperty(ref _selectedQuality, value); }
        /// <summary>
        /// Gets or sets the selected lead time.
        /// </summary>
        /// <value>The selected lead time.</value>
        public string SelectedLeadTime { get => _selectedLeadTime; set => SetProperty(ref _selectedLeadTime, value); }
        /// <summary>
        /// Gets or sets the selected costs issue.
        /// </summary>
        /// <value>The selected costs issue.</value>
        public string SelectedCostsIssue { get => _selectedCostsIssue; set => SetProperty(ref _selectedCostsIssue, value); }
        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get => _comments; set => SetProperty(ref _comments, value); }

        /// <summary>
        /// Gets or sets the safty.
        /// </summary>
        /// <value>The safty.</value>
        public ObservableCollection<CriticalityKV<SafetyIssue>> Safty { get; set; } = new ObservableCollection<CriticalityKV<SafetyIssue>>();
        /// <summary>
        /// Gets or sets the criticality values.
        /// </summary>
        /// <value>The criticality values.</value>
        public ObservableCollection<CriticalityKV<CriticalityValue>> CriticalityValues { get; set; } = new ObservableCollection<CriticalityKV<CriticalityValue>>();

        /// <summary>
        /// Gets or sets the safety selected.
        /// </summary>
        /// <value>The safety selected.</value>
        public CriticalityKV<SafetyIssue> SafetySelected { get => safetySelected; set => SetProperty(ref safetySelected, value); }
        /// <summary>
        /// Gets or sets the criticality selected.
        /// </summary>
        /// <value>The criticality selected.</value>
        public CriticalityKV<CriticalityValue> CriticalitySelected { get => criticalitySelected; set => SetProperty(ref criticalitySelected, value); }
        /// <summary>
        /// Gets or sets the criticality suggested.
        /// </summary>
        /// <value>The criticality suggested.</value>
        public CriticalityKV<CriticalityValue> CriticalitySuggested { get => criticalitySuggested; set => SetProperty(ref criticalitySuggested, value); }

        /// <summary>
        /// Initializes a new instance of the <see cref="CriticalityDialogViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        /// <param name="_criticalLogic">The critical logic.</param>
        public CriticalityDialogViewModel(IEventAggregator eventAggregator, IInventoryMapper inventoryMapper, ICriticalityLogic _criticalLogic)
        {
            _eventAggregator = eventAggregator;
            _inventoryMapper = inventoryMapper;
            criticalLogic = _criticalLogic;
            _quality = new ObservableCollection<string>(_criticalLogic.GetCriticalityParameters());
            OnSelectionChangeCommand = new DelegateCommand<string>(OnSelectionChange);
            OnCriticalityChangeCommand = new DelegateCommand<string>(OnCriticalityChange);
            CloseDialogCommand = new DelegateCommand<string>(OnAddAction);
            AddCriticalityParametr();
            InitializeComboBox();
        }
        /// <summary>
        /// Initializing the combobox with default value
        /// </summary>
        private void InitializeComboBox()
        {
            SelectedLeadTime = CriticalitystringValues.LOW_IMPACT;
            SelectedCostsIssue = CriticalitystringValues.LOW_IMPACT;
            SelectedQuality = CriticalitystringValues.LOW_IMPACT;
            CriticalitySuggested = CriticalityValues[0];
            CriticalitySelected = CriticalityValues[0];
            SuggestedCriticality = CriticalityValue.Not_Critical;
            SafetySelected = Safty[1];
           
        }

        /// <summary>
        /// Adding the values for criticality
        /// </summary>
        private void AddCriticalityParametr()
        {
            Safty.Add(new CriticalityKV<SafetyIssue>() { Key = "High Risk", value = SafetyIssue.High_Risk });
            Safty.Add(new CriticalityKV<SafetyIssue>() { Key = "Low Risk", value = SafetyIssue.Low_Risk });

            CriticalityValues.Add(new CriticalityKV<CriticalityValue>() { Key = "Not Critical", value = CriticalityValue.Not_Critical });
            CriticalityValues.Add(new CriticalityKV<CriticalityValue>() { Key = "Somewhat Critical", value = CriticalityValue.Somewhat_Critical });
            CriticalityValues.Add(new CriticalityKV<CriticalityValue>() { Key = "Critical", value = CriticalityValue.Critical });
            CriticalityValues.Add(new CriticalityKV<CriticalityValue>() { Key = "Very Critical", value = CriticalityValue.Very_Critical });
        }

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }
        /// <summary>
        /// passing the parametr to the grid on Add click
        /// </summary>
        /// <param name="commParam">The comm parameter.</param>
        private void OnAddAction(string commParam)
        {
            var parameters = new DialogParameters();
            if (string.Compare(commParam, CollectionConstant.Add, StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                CriticalityModel criticalityValues = new CriticalityModel() { QualityIssue = SelectedQuality, LeadTimeIssue = SelectedLeadTime, SafetyIssue = SafetySelected.Key, CostsIssue = SelectedCostsIssue, SelectedValue = CriticalitySelected.Key, Comments = Comments };

                parameters.Add(CollectionConstant.Add, criticalityValues);
                RequestClose?.Invoke(new DialogResult(ButtonResult.OK, parameters));
            }
            else
                RaiseRequestClose(new DialogResult(ButtonResult.Cancel));
        }

        /// <summary>
        /// Called when [criticality change].
        /// </summary>
        /// <param name="obj">The object.</param>
        private void OnCriticalityChange(string obj)
        {
          
        }

        /// <summary>
        /// combobox change handler
        /// </summary>
        /// <param name="obj">The object.</param>
        private void OnSelectionChange(string obj)
        {
           
            if (SafetySelected.value == SafetyIssue.High_Risk)
            {
                CriticalitySelected = CriticalityValues[3];
                CriticalitySuggested = CriticalityValues[3];
            }
            else
            {
                var criticalRes = criticalLogic.CalculateCriticality((int)SafetySelected.value, SelectedQuality, SelectedLeadTime, SelectedCostsIssue);
                foreach (var item in CriticalityValues)
                {
                    if (item.value == criticalRes)
                        CriticalitySuggested = item;
                }
                CriticalitySelected = CriticalitySuggested;
            }
        }

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
        }
        /// <summary>
        /// Updating the popup box with the grid data
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            if (parameters.TryGetValue("Criticality", out ObservableCollection<CriticalityModel> criticalParam))
            {
                foreach (var param in criticalParam)
                {
                    if (param != null)
                    {
                        for (int index = 0; index <= 1; ++index)
                        {
                            if (Safty[index].Key == param.SafetyIssue)
                                SafetySelected = Safty[index];
                        }

                        foreach (var item in CriticalityValues)
                        {
                            if (item.Key == param.SelectedValue)
                                CriticalitySuggested = item;
                        }
                        CriticalitySelected = CriticalitySuggested;
                        SelectedLeadTime = string.IsNullOrEmpty(param.LeadTimeIssue) ? SelectedLeadTime : param.LeadTimeIssue;
                        SelectedCostsIssue = string.IsNullOrEmpty(param.CostsIssue) ? SelectedCostsIssue : param.CostsIssue;
                        SelectedQuality = string.IsNullOrEmpty(param.QualityIssue) ? SelectedQuality : param.QualityIssue;
                        Comments = param.Comments;
                    }
                }
            }
        }
    }
}