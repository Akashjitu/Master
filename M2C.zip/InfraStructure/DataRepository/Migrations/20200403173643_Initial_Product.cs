﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace DataRepository.Migrations
{
    public partial class Initial_Product : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Brands",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Brands", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DeviceTypes",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Type = table.Column<string>(nullable: true),
                    OpsTypeDescription = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ConfigType = table.Column<string>(nullable: true),
                    UpdatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DeviceTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FilterIbCatalogBus",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilterIbCatalogBus", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FilterIbCatalogProductCategories",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilterIbCatalogProductCategories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FilterIbCatalogStatusIpCreations",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FilterIbCatalogStatusIpCreations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Ranges",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true),
                    OpsDescription = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ranges", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SyncHistories",
                columns: table => new
                {
                    SyncId = table.Column<string>(nullable: false),
                    ID = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    SyncDate = table.Column<DateTime>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    RetryCount = table.Column<int>(nullable: false),
                    Version = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SyncHistories", x => x.SyncId);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Identifier = table.Column<string>(nullable: true),
                    IdentifierCategory = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    Serviceable = table.Column<string>(nullable: true),
                    Traceable = table.Column<string>(nullable: true),
                    ServiceBusinessValue = table.Column<string>(nullable: true),
                    EndProductionOrPhaseOut = table.Column<int>(nullable: false),
                    EndCommercialization = table.Column<int>(nullable: false),
                    ObsolescenceYear = table.Column<int>(nullable: false),
                    EndServicesWithdrawalSupport = table.Column<int>(nullable: false),
                    DefaultUnitPrice = table.Column<double>(nullable: false),
                    LatestProductVersion = table.Column<double>(nullable: false),
                    LatestSoftwareVersion = table.Column<double>(nullable: false),
                    LatestHardwareVersion = table.Column<double>(nullable: false),
                    IncludeInReport = table.Column<string>(nullable: true),
                    IncludeInCalc = table.Column<string>(nullable: true),
                    Configuration = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false),
                    BrandId = table.Column<int>(nullable: false),
                    DeviceTypeId = table.Column<int>(nullable: false),
                    RangeId = table.Column<int>(nullable: false),
                    FullName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Products_Brands_BrandId",
                        column: x => x.BrandId,
                        principalTable: "Brands",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Products_DeviceTypes_DeviceTypeId",
                        column: x => x.DeviceTypeId,
                        principalTable: "DeviceTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Products_Ranges_RangeId",
                        column: x => x.RangeId,
                        principalTable: "Ranges",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SubRanges",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: true),
                    SdhCode = table.Column<string>(nullable: true),
                    SdhDescription = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false),
                    RangeId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubRanges", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SubRanges_Ranges_RangeId",
                        column: x => x.RangeId,
                        principalTable: "Ranges",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductEntries",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Currency = table.Column<string>(nullable: true),
                    ActualProductVersion = table.Column<string>(nullable: true),
                    ActualSoftwareVersion = table.Column<string>(nullable: true),
                    Quantity = table.Column<double>(nullable: false),
                    SerialNumber1 = table.Column<int>(nullable: false),
                    SerialNumber2 = table.Column<int>(nullable: false),
                    Note1 = table.Column<string>(nullable: true),
                    Note2 = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    Misc1 = table.Column<string>(nullable: true),
                    Misc2 = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false),
                    ProductId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductEntries", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductEntries_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogBus",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 1, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "IND OEM BIC", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogBus",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 2, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "IND PROCESS AUTOMATION", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogBus",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 3, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "IND AUT SOFTWARE", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogBus",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 4, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "IND AUTOMATION OPS", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogBus",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 5, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "IND SOFTWARE", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogBus",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 8, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "SCE IND AUT. SERVICES", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogProductCategories",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 1, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "MACRO REFERENCE", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogProductCategories",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 2, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "COMMERCIAL REFERENCE", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "FilterIbCatalogStatusIpCreations",
                columns: new[] { "Id", "CreatedDate", "Name", "UpdatedDate" },
                values: new object[] { 1, new DateTime(2020, 4, 3, 0, 0, 0, 0, DateTimeKind.Local), "YES", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "SyncHistories",
                columns: new[] { "SyncId", "ID", "RetryCount", "Status", "SyncDate", "Version" },
                values: new object[] { "e25de8de-3a0c-4a4e-9bfe-a36436f6b810", 1, 0, 3, new DateTime(2020, 3, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), 0.0 });

            migrationBuilder.CreateIndex(
                name: "IX_ProductEntries_ProductId",
                table: "ProductEntries",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_BrandId",
                table: "Products",
                column: "BrandId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_DeviceTypeId",
                table: "Products",
                column: "DeviceTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Products_RangeId",
                table: "Products",
                column: "RangeId");

            migrationBuilder.CreateIndex(
                name: "IX_SubRanges_RangeId",
                table: "SubRanges",
                column: "RangeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FilterIbCatalogBus");

            migrationBuilder.DropTable(
                name: "FilterIbCatalogProductCategories");

            migrationBuilder.DropTable(
                name: "FilterIbCatalogStatusIpCreations");

            migrationBuilder.DropTable(
                name: "ProductEntries");

            migrationBuilder.DropTable(
                name: "SubRanges");

            migrationBuilder.DropTable(
                name: "SyncHistories");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Brands");

            migrationBuilder.DropTable(
                name: "DeviceTypes");

            migrationBuilder.DropTable(
                name: "Ranges");
        }
    }
}
