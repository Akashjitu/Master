﻿using M2C.Desktop.Core.GlobalComands;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Prism.Ioc;
using Prism.Regions;
using System;

namespace M2C.Desktop.Modules.ProjectPane.Test
{
    [TestClass]
    public class ProjectPlanModuleTest
    {
        private ProjectPaneModule _projectScreenViewModel;
        private IGlobalMenuComands _globalMenuComands;
        private IRegionManager _regionManager;

        private IContainerRegistry _containerRegistry;

        [TestInitialize]
        public void Setup()
        {
            _regionManager = Substitute.For<IRegionManager>();
            _globalMenuComands = Substitute.For<IGlobalMenuComands>();
            _projectScreenViewModel = new ProjectPaneModule(_regionManager);
            _containerRegistry = Substitute.For<IContainerRegistry>();
            _regionManager.RegisterViewWithRegion(Arg.Any<string>(), Arg.Any<Type>()).Returns(new RegionManager());
        }

        [TestMethod]
        public void ShouldCallInitializedRegisterViewWithRegionReturnRegionManager()
        {
            _projectScreenViewModel.OnInitialized(null);
        }

        [TestMethod]
        public void ShouldCallRegisterTypesToRegisterNavigationAndDialog()
        {
            _projectScreenViewModel.RegisterTypes(_containerRegistry);
        }
    }
}