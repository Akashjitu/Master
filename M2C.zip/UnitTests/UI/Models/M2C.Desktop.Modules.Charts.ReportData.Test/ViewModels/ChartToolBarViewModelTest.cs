﻿using System.IO;
using System.Linq;
using M2C.Business.Contracts;
using M2C.Business.Implementations;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.Charts.ReportData.ChartExports;
using M2C.Desktop.Modules.Charts.ReportData.Test.Mock;
using M2C.Desktop.Modules.Charts.ReportData.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Prism.Events;

namespace M2C.Desktop.Modules.Charts.ReportData.Test.ViewModels
{
    /// <summary>
    /// Interaction logic for ChartToolBar
    /// </summary>
    [TestClass]
    public class ReportExportToolsViewModelTest
    {
        private ReportExportToolsViewModel _reportExportToolsViewModel;
        private IEventAggregator _eventAggregator;
        private IStatusColorProvider _colorProvider;
        private IReportExportChart _reportExportChart;
        private IMyProfileLogic _myProfile;
        private ISharedContextService _sharedContextService;
        private IGlobalIBComponentsCommand _globalIBCommand;
        private IExcelExportObsolescence _excelExportObsolescence;
        private ISharedContextService sharedContextService;
        [TestInitialize]
        public void Setup()
        {
            _myProfile = Substitute.For<IMyProfileLogic>();
            _myProfile.GetProfile().Returns(new ProfileModel()
            {
                Id = 1,
                FirstName = "User First Name",
                LastName = "User Last Name",
                Telephone = "8080880",
            });
            _sharedContextService = Substitute.For<ISharedContextService>();
            _colorProvider = new StatusColorProvider();

            _sharedContextService.Get<ProjectContextModel>(Arg.Any<string>()).Returns(new ProjectContextModel()
            {
                Customer = new CustomerModel()
                {
                    Comment = "Schneider"
                }
            });
            _excelExportObsolescence= new ExcelExportObsolescence(_colorProvider);
            _globalIBCommand = new GlobalIBComponentsCommand(); //Substitute.For<GlobalIBComponentsCommand>();
            _reportExportChart = new ReportExportChart(_colorProvider, _myProfile, _sharedContextService);
            _eventAggregator = new EventAggregator();
            _reportExportToolsViewModel = new ReportExportToolsViewModel(_eventAggregator, _colorProvider, _reportExportChart, _excelExportObsolescence,_globalIBCommand, sharedContextService);
            _reportExportToolsViewModel = new ReportExportToolsViewModel(_eventAggregator, _colorProvider, _reportExportChart, _excelExportObsolescence, _globalIBCommand, sharedContextService);
            _reportExportToolsViewModel = new ReportExportToolsViewModel(_eventAggregator, _colorProvider, _reportExportChart, _excelExportObsolescence, _globalIBCommand, sharedContextService);
            _reportExportToolsViewModel = new ReportExportToolsViewModel(_eventAggregator, _colorProvider, _reportExportChart, _excelExportObsolescence, _globalIBCommand, sharedContextService);
        }

        [TestMethod]
        public void ShouldCallInventoryChangeEvent()
        {
            _eventAggregator.GetEvent<IBTreeViewChangeEvent>().Publish(ChartMockProvide.GetInstalledBasedNodeTree());
            _eventAggregator.GetEvent<TRTreeViewChangeEvent>().Publish(ChartMockProvide.GetTechnicalResourceNodeTree());
            Assert.IsNotNull(_reportExportToolsViewModel.IbObsolescenceMappingInventoryNode);
            Assert.IsNotNull(_reportExportToolsViewModel.IbMappingInventoryNode);
            Assert.IsNotNull(_reportExportToolsViewModel.IbObsolescenceCriticalityInventoryNode);

            Assert.IsTrue(_reportExportToolsViewModel.IbObsolescenceMappingInventoryNode.Count > 0);
            Assert.IsTrue(_reportExportToolsViewModel.IbMappingInventoryNode.Count > 0);
            Assert.IsTrue(_reportExportToolsViewModel.IbObsolescenceCriticalityInventoryNode.Count > 0);

            Assert.IsNotNull(_reportExportToolsViewModel.TrObsolescenceMappingInventoryNode);
            Assert.IsNotNull(_reportExportToolsViewModel.TrMappingInventoryNode);
            Assert.IsNotNull(_reportExportToolsViewModel.TrObsolescenceCriticalityInventoryNode);

            Assert.IsTrue(_reportExportToolsViewModel.TrObsolescenceMappingInventoryNode.Count > 0);
            Assert.IsTrue(_reportExportToolsViewModel.TrMappingInventoryNode.Count > 0);
            Assert.IsTrue(_reportExportToolsViewModel.TrObsolescenceCriticalityInventoryNode.Count > 0);
        }

        [TestMethod]
        public void ShouldGenerateReport()
        {
            _eventAggregator.GetEvent<IBTreeViewChangeEvent>().Publish(ChartMockProvide.GetInstalledBasedNodeTree());
            _eventAggregator.GetEvent<TRTreeViewChangeEvent>().Publish(ChartMockProvide.GetTechnicalResourceNodeTree());

            _reportExportToolsViewModel.TrObsolescenceMappingInventoryNode.ToList().ForEach(i => i.IsSelected = true);
            _reportExportToolsViewModel.TrMappingInventoryNode.ToList().ForEach(i => i.IsSelected = true);
            _reportExportToolsViewModel.TrObsolescenceCriticalityInventoryNode.ToList().ForEach(i => i.IsSelected = true);
            _reportExportToolsViewModel.IbObsolescenceMappingInventoryNode.ToList().ForEach(i => i.IsSelected = true);
            _reportExportToolsViewModel.IbMappingInventoryNode.ToList().ForEach(i => i.IsSelected = true);
            _reportExportToolsViewModel.IbObsolescenceCriticalityInventoryNode.ToList().ForEach(i => i.IsSelected = true);

            var path = Path.Combine(Path.GetTempPath(), "tempM2C.docx"); ;
            _reportExportToolsViewModel.GenerateReport(ExportType.Word, path);

            Assert.IsTrue(File.Exists(path));
            if (File.Exists(path))
                File.Delete(path);
        }
    }
}