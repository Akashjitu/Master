import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/accoladeReducer';
import { environment } from 'src/environments/environment';
import { TtiPartAlignment } from '../model/ttiPartAlignment';
import * as AccoladeAction from './../store/accoladeAction';
import { saveAs } from 'file-saver';
import { NgxSpinnerService } from 'ngx-spinner';
@Injectable({
  providedIn: 'root'
})
export class AccoladeService {

  url = environment.apiBaseUrl;
  fileBaseUrl = environment.fileBaseUrl;
  headers;
  constructor(private http: HttpClient, private store: Store<IAppState>, private spinner: NgxSpinnerService) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
      withCredentials: 'true',
    });
  }


  reportDownload(date) {
    this.spinner.show();
    this.http.get(this.fileBaseUrl +'tti?date=' + date, { responseType: 'blob', headers: this.headers })
      .subscribe(response => {
        this.spinner.hide();
        saveAs(response, 'TTI' + date + '.xlsx',
          { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
      },
        err => {
          this.spinner.hide();
          console.log(`ERROR: ${err}`),
          console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service');
        });
  }


  getAllTti() {
    this.spinner.show();
    this.http.get<any>(this.url + 'Accolade')
      .subscribe(res => {
        this.spinner.hide();
        this.store.dispatch(new AccoladeAction.LoadAccolade(res)
        )
      }, err => {
        this.spinner.hide();
      });
  }


  searchByDate(date, type) {
    this.spinner.show();
    this.http.get<any>(this.url + 'tti?infoCreatedDate=' + date +'&filertType='+type)
      .subscribe(res => {
        this.spinner.hide();
        this.store.dispatch(new AccoladeAction.LoadAccolade(res)
        )
      }, err => {
        this.spinner.hide();
      });
  }

  saveTti(modifieditems) {
    console.log('saveCompliance' + modifieditems)
    return this.http.post(this.url + 'tti', modifieditems, { headers: this.headers })
      .subscribe(infoData => console.log(infoData));
  }
}

