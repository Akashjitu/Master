﻿using M2C.Business.Models.CommonChartParameters;
using M2C.Desktop.Modules.Charts.Models;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    /// <summary>
    /// Provide Criticality Bar Elements.
    /// </summary>
    public interface ICriticalityElementProvider
    {
        /// <summary>
        /// Get Criticality Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        ChartBarElements GetCriticalityBarElements(ChartParameter chartParameter);
    }
}