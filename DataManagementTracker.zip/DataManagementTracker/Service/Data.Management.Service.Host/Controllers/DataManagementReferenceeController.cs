﻿
using Data.Management.Service.Host.ExceptionFilters;
using Data.Management.Service.Host.Providers;
using Data.Management.Services.Service;
using Hts.Logger;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Data.Management.Service.Host.Controllers
{
    [LogExceptionFilterAttribute]
    public class DataManagementReferenceController : ApiController
    {
        private readonly IReferenceService _reference;

        public DataManagementReferenceController(IReferenceService reference)
        {
            _reference = reference;
        }

        [HttpGet]
        public HttpResponseMessage LoadAllDataManagements()
        {

           
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //if (string.IsNullOrEmpty(eid))
           ////eid = "H161961";
            var data = _reference.LoadReference(eid);

            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}