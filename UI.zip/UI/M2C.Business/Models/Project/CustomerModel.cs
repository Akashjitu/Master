﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-08-2020
// ***********************************************************************
// <copyright file="CustomerModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.ModelValidators;
using Newtonsoft.Json;
using Prism.Mvvm;
using System;

namespace M2C.Business.Models.Project
{
    /// <summary>
    /// Class CustomerModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class CustomerModel : BindableBase
    {
        /// <summary>
        /// The customer identifier
        /// </summary>
        private int? customerId;

        /// <summary>
        /// Gets or sets the customer identifier.
        /// </summary>
        /// <value>The customer identifier.</value>
        [JsonIgnore]
        public int? CustomerID { get => customerId; set => SetProperty(ref customerId, value); }

        /// <summary>
        /// The company name
        /// </summary>
        private string companyName;

        /// <summary>
        /// Gets or sets the name of the company.
        /// </summary>
        /// <value>The name of the company.</value>
        public string CompanyName { get => companyName; set => SetProperty(ref companyName, value); }

        /// <summary>
        /// The bfo identifier value
        /// </summary>
        /// <value>The bfo identifier value.</value>
        private int? bfoIdValue;

        /// <summary>
        /// Gets the bfo identifier value.
        /// </summary>
        /// <value>The bfo identifier value.</value>
        public int? BfoIdValue { get => bfoIdValue; }

        /// <summary>
        /// Gets or sets the bfo identifier.
        /// </summary>
        /// <value>The bfo identifier.</value>
        /// <exception cref="ApplicationException">Invalid integer number</exception>
        public string BfoId
        {
            get => BfoIdValue.ToString();
            set
            {
                int i;
                if (!Int32.TryParse(value, out i))
                {
                    SetProperty(ref bfoIdValue, null);
                    throw new ApplicationException("Invalid integer number");
                }

                SetProperty(ref bfoIdValue, i == 0 ? 0 : i);
            }
        }

        /// <summary>
        /// The street
        /// </summary>
        private string street;

        /// <summary>
        /// Gets or sets the street.
        /// </summary>
        /// <value>The street.</value>
        public string Street { get => street; set => SetProperty(ref street, value); }

        /// <summary>
        /// The city
        /// </summary>
        private string city;

        /// <summary>
        /// Gets or sets the city.
        /// </summary>
        /// <value>The city.</value>
        public string City { get => city; set => SetProperty(ref city, value); }

        /// <summary>
        /// The postalcode
        /// </summary>
        private string postalcode;

        /// <summary>
        /// Gets or sets the postal code.
        /// </summary>
        /// <value>The postal code.</value>
        /// <exception cref="ApplicationException">Invalid postal code</exception>
        public string PostalCode
        {
            get => postalcode; set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsvalidZipCode(value))
                {
                    SetProperty(ref postalcode, value);
                    throw new ApplicationException("Invalid postal code");
                }
                SetProperty(ref postalcode, value);
            }
        }

        /// <summary>
        /// The region
        /// </summary>
        private string region;

        /// <summary>
        /// Gets or sets the region.
        /// </summary>
        /// <value>The region.</value>
        public string Region { get => region; set => SetProperty(ref region, value); }

        /// <summary>
        /// The country
        /// </summary>
        private CountryModel country = new CountryModel() { Id = 1 };

        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>The country.</value>
        public CountryModel Country { get => country; set => SetProperty(ref country, value); }

        /// <summary>
        /// The project name
        /// </summary>
        private string projectName;

        /// <summary>
        /// Gets or sets the name of the project.
        /// </summary>
        /// <value>The name of the project.</value>
        public string ProjectName { get => projectName; set => SetProperty(ref projectName, value); }

        /// <summary>
        /// The comment
        /// </summary>
        private string comment;

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        public string Comment { get => comment; set => SetProperty(ref comment, value); }
    }
}