﻿using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace M2C.Business.Mappers
{
    [TestClass]
    public class DeviceTypeModelMapperTest
    {
        private DeviceTypeModelMapper deviceTypeModelMapper;

        [TestInitialize]
        public void Setup()
        {
            deviceTypeModelMapper = new DeviceTypeModelMapper();
        }

        [TestMethod]
        public void ShouldReturnDeviceTypeModel()
        {
            var deviceTypeModels = deviceTypeModelMapper.Map(MockProvider.GetDeviceTypes());
            Assert.IsNotNull(deviceTypeModels);
            Assert.IsTrue(deviceTypeModels.Count > 0);
        }
    }
}