﻿using DevExpress.Xpf.Charts;
using M2C.Business.Models.Chart;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Media;
using M2C.Business.Models.Project;
using Color = System.Windows.Media.Color;

namespace M2C.Desktop.Modules.Charts.ReportData.Exports
{
    public class ExportChartProvider
    {
        private ChartControl _analysisChart;
        private XYDiagram2D _analysisXyDiagram2D;
        private XYDiagram2D _obsolescenceXyDiagram2D;
        private ChartControl _obsolescenceChart;
        private BarStackedSeries2D _greenSeries2D;
        private BarStackedSeries2D _yellowSeries2D;
        private BarStackedSeries2D _redSeries2D;

     

        public ExportChartProvider()
        {
            InitializeAnalysisChart();
            InitializeObsolescenceChart();
        }

        private void InitializeAnalysisChart()
        {
            if (_analysisChart != null)
                return;
            _analysisChart = new ChartControl
            {
                Name = "AnalysisChart",
                AutoLayout = false,
                Height = 600,
                MaxHeight = 800,
                Width = 750,
                CrosshairOptions = new CrosshairOptions
                {
                    ShowArgumentLabels = false,
                    ShowValueLine = false,
                    ShowArgumentLine = false,
                    HighlightPoints = false,
                    GroupHeaderPattern = "Group : {A}"
                }
            };
            _analysisChart.Titles.Add(
                new Title
                {
                    Content = string.Empty
                });

            var series2D = new BarStackedSeries2D
            {
                DisplayName = "Configuration",
                LabelsVisibility = false,
                ArgumentDataMember = "Name",
                ValueDataMember = "ConfigCount",
                ValueScaleType = ScaleType.Numerical,
            };

            _analysisXyDiagram2D = new XYDiagram2D
            {
                BarDistance = 0.04,
                DefaultPane = new Pane
                {
                    MirrorHeight = 20.0,

                },
                AxisY = new AxisY2D { Title = new AxisTitle() { Content = string.Empty } },
                AxisX = new AxisX2D
                {
                    QualitativeScaleOptions = new QualitativeScaleOptions()
                    {
                        AutoGrid = false,
                        AggregateFunction = AggregateFunction.Maximum

                    },
                    Label = new AxisLabel()
                    {
                        FontSize = 14,
                        Angle = -30,
                    },
                    Title = new AxisTitle() { Content = string.Empty }
                }
            };
           // _analysisXyDiagram2D.AxisX.Label

            series2D.Label = new SeriesLabel
            {

                // TextPattern = "{}Total&#xA;{ConfigCount}",
                ResolveOverlappingMode = ResolveOverlappingMode.Default
            };

            // Detect overlapping of series labels.

            _analysisChart.Diagram = _analysisXyDiagram2D;
            _analysisChart.Diagram.Series.Add(series2D);
            var serie = (BarStackedSeries2D)_analysisChart.Diagram.Series[0];
            //serie.Label.TextPattern = "{}Total&#xA;{ConfigCount}";
            serie.Label.ResolveOverlappingMode = ResolveOverlappingMode.Default;
            serie.LabelsVisibility = true;
        }

        private void InitializeObsolescenceChart()
        {
            if (_obsolescenceChart != null)
                return;

            var greenColor = new Color();
            var yellowColor = new Color();
            var redColor = new Color();
            var green = System.Windows.Media.ColorConverter.ConvertFromString("#FF3DCD58");//Green
            if (green != null)
                greenColor = (Color)green;
            var yellow = System.Windows.Media.ColorConverter.ConvertFromString("#FFFFD100");//Yellow
            if (yellow != null)
                yellowColor = (Color)yellow;
            var red = System.Windows.Media.ColorConverter.ConvertFromString("#FFDC0A0A");//Red
            if (red != null)
                redColor = (Color)red;


            _obsolescenceChart = new ChartControl
            {
                Name = "ObsolescenceChart",
                AutoLayout = false,
                Height = 600,
                Width = 700,
                CrosshairOptions = new CrosshairOptions
                {
                    ShowArgumentLabels = false,
                    ShowValueLine = false,
                    ShowArgumentLine = false,
                    HighlightPoints = false,
                    GroupHeaderPattern = "Group : {A}"
                }
            };
            _obsolescenceChart.Titles.Add(
                new Title
                {
                    Content = string.Empty
                });

            var customPalette = new CustomPalette();
            _obsolescenceChart.Palette = customPalette;

            customPalette.Colors.Add(greenColor);
            customPalette.Colors.Add(yellowColor);
            customPalette.Colors.Add(redColor);

            _greenSeries2D = new BarStackedSeries2D
            {
                DisplayName = "Not Started",
                LabelsVisibility = true,
                ArgumentDataMember = "Name",
                ValueDataMember = "ConfigCount",
                ValueScaleType = ScaleType.Numerical,
            };
            _yellowSeries2D = new BarStackedSeries2D
            {
                DisplayName = "On Going",
                LabelsVisibility = true,
                ArgumentDataMember = "Name",
                ValueDataMember = "ConfigCount",
                ValueScaleType = ScaleType.Numerical,
            };
            _redSeries2D = new BarStackedSeries2D
            {
                DisplayName = "Service End",
                LabelsVisibility = true,
                ArgumentDataMember = "Name",
                ValueDataMember = "ConfigCount",
                ValueScaleType = ScaleType.Numerical,
            };

            _obsolescenceXyDiagram2D = new XYDiagram2D
            {
                BarDistance = 0.04,
                DefaultPane = new Pane { MirrorHeight = 20.0, },
                AxisY = new AxisY2D { Title = new AxisTitle() { Content = string.Empty } },
                AxisX = new AxisX2D
                {
                    QualitativeScaleOptions = new QualitativeScaleOptions()
                    { AutoGrid = false },
                    Label = new AxisLabel()
                    {
                        FontSize = 14,
                        Angle = -30,
                    },
                    Title = new AxisTitle() { Content = string.Empty }
                }
            };
            _obsolescenceChart.Diagram = _obsolescenceXyDiagram2D;

            _obsolescenceChart.Diagram.Series.Add(_greenSeries2D);
            _obsolescenceChart.Diagram.Series.Add(_yellowSeries2D);
            _obsolescenceChart.Diagram.Series.Add(_redSeries2D);
        }

        public Image ExportAnalysisChartImage(List<ChartBarElement> chartBarElements, string headerLabel, string yAxesLabel, string xAxesLabel)
        {
            _analysisChart.DataSource = null;
            _analysisXyDiagram2D.AxisY.Title.Content = yAxesLabel;
            _analysisXyDiagram2D.AxisX.Title.Content = xAxesLabel;
            _analysisChart.Titles[0].Content = headerLabel;
            _analysisChart.DataSource = chartBarElements;
            return GetChartImage(_analysisChart);
            //  PrintableControlLink link = new PrintableControlLink(_analysisChart);
            // link.ExportToImage()
            // PrintableControlLink link = new PrintableControlLink(chartControl);
            // link.ExportToImage(@"C:\TEMP\Chart1.png", System.Drawing.Imaging.ImageFormat.Png);

            // return null;
        }

        public Image ExportObsolescenceChartImage(List<ChartBarElement> greenChartBarElements,
            List<ChartBarElement> yellowChartBarElements,
            List<ChartBarElement> redChartBarElements,
            string headerLabel, string yAxesLabel, string xAxesLabel)
        {
            _greenSeries2D.DataSource = null;
            _yellowSeries2D.DataSource = null;
            _redSeries2D.DataSource = null;

            _obsolescenceXyDiagram2D.AxisY.Title.Content = yAxesLabel;
            _obsolescenceXyDiagram2D.AxisX.Title.Content = xAxesLabel;
            _obsolescenceChart.Titles[0].Content = headerLabel;
            _greenSeries2D.DataSource = greenChartBarElements;
            _yellowSeries2D.DataSource = yellowChartBarElements;
            _redSeries2D.DataSource = redChartBarElements;

            return GetChartImage(_obsolescenceChart);

        }



        private Image GetChartImage(ChartControl chart)
        {

            Image image = null;
            using (var s = new MemoryStream())
            {
                chart.ExportToImage(s, PrintSizeMode.ProportionalZoom);
                image = Image.FromStream(s);
            }

            // Return the image.
            return image;
        }
    }
}