﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class BrandQueriesTest : TestBase
    {
        private IQueryable<Brand> brandList;
        private Mock<DbSet<Brand>> brandMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            Brand brandObj = new Brand() { Id = 1, Name = "Name1" };

            List<Brand> brand = new List<Brand>() { brandObj };
            brandList = brand.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();
            brandMock = MockRepo.Create<DbSet<Brand>>();

            brandMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(brandList.Provider);
            brandMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(brandList.Expression);
            brandMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(brandList.ElementType);
            brandMock.As<IQueryable<Brand>>().Setup(m => m.GetEnumerator()).Returns(brandList.GetEnumerator());

            IProductDbContextMock.Setup(x => x.Brands).Returns(brandMock.Object);
            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void BrandQueriesConstructorTest()
        {
            IBrandQueries brand = new ProductQueries(IDbContextFactoryMock.Object);
            brand.Should().NotBeNull();
            ((IDisposable)brand).Dispose();
        }

        [TestMethod]
        public void BrandQueriesSaveBrandsTest()
        {
            Brand brandObject = new Brand() { Id = 1, Name = "Name1" };
            List<Brand> brandLists = new List<Brand>() { brandObject };
            IBrandQueries brand = new ProductQueries(IDbContextFactoryMock.Object);
            Action action = () => brand.SaveBrands(null);
            action.Should().NotThrow();
            action = () => brand.SaveBrands(brandLists);
            action.Should().NotThrow();
            brandObject.Id = 0;
            brandObject.Name = "Name2";
            action.Should().NotThrow();
            action = () => brand.SaveBrands(brandLists);
            action.Should().NotThrow();
            ((IDisposable)brand).Dispose();
        }

        [TestMethod]
        public void BrandQueriesLoadBrandsTest()
        {
            IBrandQueries brands = new ProductQueries(IDbContextFactoryMock.Object);
            List<Brand> brandResult = brands.LoadBrands();
            brandResult.Should().HaveCount(1);
            ((IDisposable)brands).Dispose();
        }

        [TestMethod]
        public void BrandQueriesLoadBrandswithBrandTest()
        {
            Brand brand = null;

            IBrandQueries brands = new ProductQueries(IDbContextFactoryMock.Object);
            List<Brand> brandRes = brands.LoadBrands(brand);
            brandRes.Should().BeNull();
            brand = new Brand() { Id = 1, Name = "name1" };
            brandRes = brands.LoadBrands(brand);
            brandRes.Should().HaveCount(1);
            ((IDisposable)brands).Dispose();
        }

        [TestMethod]
        public void BrandQueriesLoadBrandswithNameTest()
        {
            string name = null;
            IBrandQueries brands = new ProductQueries(IDbContextFactoryMock.Object);
            name = "N";
            List<Brand> brandRes = brands.LoadBrands(name);
            brandRes.Should().HaveCount(1);
            ((IDisposable)brands).Dispose();
        }

        [TestMethod]
        public void DisposeTest()
        {
            IDisposable disposeObject = new ProductQueries(IDbContextFactoryMock.Object);            
            Action action = () => disposeObject.Dispose();
            action.Should().NotThrow();
            disposeObject.Dispose();
        }
    }
}