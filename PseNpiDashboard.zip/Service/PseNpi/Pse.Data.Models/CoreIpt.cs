﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class CoreIpt
    {
        [Columns("P_KEY_CODE")]
        public string KeyCode { get; set; }

        [Columns("P_IPDS_CURRENT_PHASE")]
        public string IpdsCurrentPhase { get; set; }

        [Columns("P_COUPLED_DECOUPLED")]
        public string CoupledDeCoupled { get; set; }

        [Columns("P_HW_DEVELOPMENT_SCOP")]
        public string HwDevelopmentScop { get; set; }

        [Columns("P_SW_DEVELOPMENT_SCOP")]
        public string SwDevelopmentScop { get; set; }

        [Columns("P_PRODUCT_MANAGER")]
        public string ProductManager { get; set; }

        [Columns("P_PROGRAM_MANAGER")]
        public string ProgramManager { get; set; }

        [Columns("P_PPC")]
        public string PpC { get; set; }

        [Columns("P_PROJECT_ENGINEER")]
        public string ProjectEngineer { get; set; }

        [Columns("P_ADVANCE_MF_ENGINEER")]
        public string AdvanceManufacturingEngineer { get; set; }

        [Columns("P_PSE_LAUNCH_ENGINEER")]
        public string PseLaunchEngineer { get; set; }

        [Columns("P_APQP_ENGINEER")]
        public string ApqpEngineer { get; set; }

        [Columns("P_SOURCING_PM")]
        public string SourcingPm { get; set; }

        [Columns("P_CONTRACTS")]
        public string Contracts { get; set; }

        [Columns("P_SUPPLIER_APQP")]
        public string SupplierApqp { get; set; }

        [Columns("P_PM_CHIEF")]
        public string PmChief { get; set; }

        [Columns("P_CPS")]
        public string Cps { get; set; }

        [Columns("P_ISACTIVE")]
        public string Isactive { get; set; }

        [Columns("P_UPDATED_DATE")]
        public DateTime Updated_Date { get; set; }

        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("P_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("P_CREATED_BY")]
        public string CreatedBy { get; set; }

        [Columns("P_ID")]
        public int Id { get; set; }
    }
}