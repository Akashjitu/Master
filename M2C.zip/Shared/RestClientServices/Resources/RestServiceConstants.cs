﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="RestServiceConstants.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace RestClientServices.Resources
{
    /// <summary>
    /// Class RestServiceConstants.
    /// </summary>
    public class RestServiceConstants
    {
        /// <summary>
        /// The add event type
        /// </summary>
        public const string ADD_EVENT_TYPE = "Added";
        /// <summary>
        /// The modified event type
        /// </summary>
        public const string MODIFIED_EVENT_TYPE = "Modified";
        /// <summary>
        /// The delete event type
        /// </summary>
        public const string DELETE_EVENT_TYPE = "Deleted";
    }
}
