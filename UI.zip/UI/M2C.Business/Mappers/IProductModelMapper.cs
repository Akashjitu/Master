﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProductModelMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using M2C.Business.Models;
using System.Collections.Generic;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Interface IProductModelMapper
    /// </summary>
    public interface IProductModelMapper
    {
        /// <summary>
        /// Maps the specified products.
        /// </summary>
        /// <param name="products">The products.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        List<ProductModel> Map(List<Product> products);

        /// <summary>
        /// Maps the specified products.
        /// </summary>
        /// <param name="product">The product.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        ProductModel Map(Product product);
    }
}