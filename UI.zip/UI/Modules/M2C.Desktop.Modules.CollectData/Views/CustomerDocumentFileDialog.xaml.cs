﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CustomerDocumentFileDialog.xaml.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Regions;
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for CustomerDocumentFileDialog.xaml
    /// </summary>
    public partial class CustomerDocumentFileDialog : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        /// <param name="regionManager">The region manager.</param>
        public CustomerDocumentFileDialog(IRegionManager regionManager)
        {
            InitializeComponent();
            RegionManager.SetRegionManager(this, regionManager);
        }
    }
}