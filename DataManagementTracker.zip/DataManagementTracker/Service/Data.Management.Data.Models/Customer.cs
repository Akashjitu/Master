﻿using Oracle.Data.Access;

namespace Data.Management.Data.Models
{
    public class Customer
    {
        [Columns("P_CUSTOMER_ID")]
        public int ID { get; set; }

        [Columns("P_CUSTOMER_NAME")]
        public string Name { get; set; }
    }
}