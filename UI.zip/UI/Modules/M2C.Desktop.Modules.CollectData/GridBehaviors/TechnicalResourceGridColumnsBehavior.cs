﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="TechnicalResourceGridColumnsBehavior.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.UIModels;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace M2C.Desktop.Modules.CollectData.GridBehaviors
{
    /// <summary>
    /// Class TechnicalResourceGridColumnsBehavior.
    /// </summary>
    /// <summary>
    /// Class TechnicalResourceGridColumnsBehavior.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TechnicalResourceGridColumnsBehavior
    {
        /// <summary>
        /// Set Bind Columns  as ObservableCollection of GridColumnDescription
        /// </summary>
        public static readonly DependencyProperty BindableColumnsProperty;

        /// <summary>
        /// get the current object of grid
        /// </summary>
        private static DataGrid _dataGrid;

        /// <summary>
        /// Initializes static members of the <see cref="TechnicalResourceGridColumnsBehavior" /> class.
        /// </summary>
        static TechnicalResourceGridColumnsBehavior()
        {
            BindableColumnsProperty = DependencyProperty.RegisterAttached("TechnicalResourceBindableColumns",
                typeof(ObservableCollection<GridColumnDescription>),
                typeof(TechnicalResourceGridColumnsBehavior),
                new UIPropertyMetadata(null, BindableColumnsPropertyChanged));
        }

        /// <summary>
        /// Bindables the columns property changed.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void BindableColumnsPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            _dataGrid = source as DataGrid;

            if (!(e.NewValue is ObservableCollection<GridColumnDescription> columnHeaderDescriptors) || columnHeaderDescriptors.Count == 0)
                return;

            var oldColumns = e.OldValue as ObservableCollection<GridColumnDescription>;
            ColumnsSourceChanged(columnHeaderDescriptors);

                // if (_dataGrid != null) _dataGrid.Columns[0].Width = DataGridLength.Auto;
        }

        /// <summary>
        /// Handler when Source Change
        /// </summary>
        /// <param name="columnDescriptions">The column descriptions.</param>
        private static void ColumnsSourceChanged(ObservableCollection<GridColumnDescription> columnDescriptions)
        {
            if (_dataGrid == null) return;
            _dataGrid.Columns.Clear();

            if (columnDescriptions == null) return;
            CreateColumns(columnDescriptions);
        }

        /// <summary>
        /// Create Columns
        /// </summary>
        /// <param name="collectionView">The collection view.</param>
        private static void CreateColumns(ObservableCollection<GridColumnDescription> collectionView)
        {
            foreach (var item in collectionView)
            {
                var column = CreateColumn(item);
                if (IsColumnsExist(column)) continue;

                _dataGrid.Columns.Add(column);
                item.PropertyChanged += ColumnHeaderDescriptor_PropertyChanged;
            }
        }

        /// <summary>
        /// Create Column from  GridColumnDescription
        /// </summary>
        /// <param name="columnHeaderDescriptor">The column header descriptor.</param>
        /// <returns>DataGridColumn.</returns>
        private static DataGridColumn CreateColumn(GridColumnDescription columnHeaderDescriptor)
        {
            if (columnHeaderDescriptor == null)
                return null;
            DataGridColumn column = new DataGridTemplateColumn()
            {
                MinWidth = columnHeaderDescriptor.MinWidth == 0 ? 100 : columnHeaderDescriptor.MinWidth,
                MaxWidth = columnHeaderDescriptor.MaxWidth == 0 ? 200 : columnHeaderDescriptor.MaxWidth,
                Width = columnHeaderDescriptor.Width,
                SortMemberPath = !string.IsNullOrWhiteSpace(columnHeaderDescriptor.SortMember)
                    ? columnHeaderDescriptor.SortMember
                    : columnHeaderDescriptor.DisplayMember,
                Visibility = columnHeaderDescriptor.Visibility,
                DisplayIndex = columnHeaderDescriptor.DisplayIndexPosition,
                Header = !string.IsNullOrWhiteSpace(columnHeaderDescriptor.Header) ? columnHeaderDescriptor.Header : columnHeaderDescriptor.DisplayMember,
            };

            return columnHeaderDescriptor.ColumnType == ColumnType.CheckBox ? GetCheckBoxColumn(column) : GetTextBlockColumn(column, columnHeaderDescriptor);
        }

        /// <summary>
        /// Handles the PropertyChanged event of the ColumnHeaderDescriptor control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="PropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void ColumnHeaderDescriptor_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (sender is GridColumnDescription columnHeaderDescriptor)
            {
                var column = _dataGrid.Columns.FirstOrDefault(i => i.Header is string &&
                    string.Compare(i.Header.ToString(), columnHeaderDescriptor.Header, StringComparison.OrdinalIgnoreCase) == 0);
                if (column != null) column.Visibility = columnHeaderDescriptor.Visibility;
            }
        }

        /// <summary>
        /// Sets the technical resource bindable columns.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <param name="value">The value.</param>
        public static void SetTechnicalResourceBindableColumns(DependencyObject element, ObservableCollection<DataGridColumn> value)
        {
            element.SetValue(BindableColumnsProperty, value);
        }

        /// <summary>
        /// Gets the technical resource bindable columns.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>ObservableCollection&lt;DataGridColumn&gt;.</returns>
        public static ObservableCollection<DataGridColumn> GetTechnicalResourceBindableColumns(DependencyObject element)
        {
            return (ObservableCollection<DataGridColumn>)element.GetValue(BindableColumnsProperty);
        }

        /// <summary>
        /// Create column for Check box.
        /// </summary>
        /// <param name="column">The column.</param>
        /// <returns>DataGridColumn.</returns>
        private static DataGridColumn GetCheckBoxColumn(DataGridColumn column)
        {
            var cellControl = new FrameworkElementFactory(typeof(CheckBox));

            ((DataGridTemplateColumn)column).CellTemplate = new DataTemplate { VisualTree = cellControl };

            cellControl.SetValue(TextBlock.MarginProperty, new Thickness(3));
           // cellControl.SetBinding(CheckBox.WidthProperty, new Binding(column.Width.Value.ToString(CultureInfo.InvariantCulture)));
            var binding = new Binding("IsSelected")
            {
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            };
            cellControl.SetBinding(CheckBox.IsCheckedProperty, binding);
            return column;
        }

        /// <summary>
        /// Create Column for Cell TextBlock
        /// </summary>
        /// <param name="column">The column.</param>
        /// <param name="columnHeaderDescriptor">The column header descriptor.</param>
        /// <returns>DataGridColumn.</returns>
        private static DataGridColumn GetTextBlockColumn(DataGridColumn column, GridColumnDescription columnHeaderDescriptor)
        {
            var cellControl = new FrameworkElementFactory(typeof(TextBlock));
            ((DataGridTemplateColumn)column).CellTemplate = new DataTemplate { VisualTree = cellControl };

            cellControl.SetValue(FrameworkElement.MarginProperty, new Thickness(3));
            //  cellControl.SetValue(TextBlock.FontWeightProperty, columnHeaderDescriptor.FontWeight);
            cellControl.SetValue(TextBlock.TextAlignmentProperty, columnHeaderDescriptor.TextAlignment);
            cellControl.SetValue(UIElement.VisibilityProperty, columnHeaderDescriptor.Visibility);
            cellControl.SetValue(TextBlock.TextTrimmingProperty, TextTrimming.WordEllipsis);
            if (!string.IsNullOrEmpty(columnHeaderDescriptor.DisplayMember))
            {
                var propertyName = columnHeaderDescriptor.DisplayMember;
                var format = columnHeaderDescriptor.Format;
                if (string.IsNullOrEmpty(format))
                    format = "{0}";

                cellControl.SetBinding(TextBlock.ToolTipProperty,
                    new Binding(propertyName) { StringFormat = format, Mode = BindingMode.TwoWay });

                cellControl.SetBinding(TextBlock.TextProperty,
                    new Binding(propertyName) { StringFormat = format, Mode = BindingMode.TwoWay });

                if (string.IsNullOrWhiteSpace(column.SortMemberPath))
                    column.SortMemberPath = propertyName;
            }

            if (!string.IsNullOrWhiteSpace(columnHeaderDescriptor.TextColourMember))
                cellControl.SetBinding(TextBlock.ForegroundProperty, new Binding(columnHeaderDescriptor.TextColourMember));

            if (columnHeaderDescriptor.DisplayMember.StartsWith(CollectionConstant.Year))
            {
                cellControl.SetBinding(TextBlock.BackgroundProperty, new Binding(columnHeaderDescriptor.DisplayMember));
                cellControl.SetBinding(TextBlock.ForegroundProperty, new Binding(columnHeaderDescriptor.DisplayMember));
               // cellControl.SetBinding(FrameworkElement.WidthProperty, new Binding(columnHeaderDescriptor.Width.Value.ToString(CultureInfo.InvariantCulture)));

                var cellStyle = new Style(typeof(DataGridCell));
                cellStyle.Setters.Add(new Setter(Control.BackgroundProperty,
                    new Binding(columnHeaderDescriptor.DisplayMember)));
                column.CellStyle = cellStyle;
            }
            return column;
        }

        /// <summary>
        /// Determines whether [is columns exist] [the specified column].
        /// </summary>
        /// <param name="column">The column.</param>
        /// <returns><c>true</c> if [is columns exist] [the specified column]; otherwise, <c>false</c>.</returns>
        private static bool IsColumnsExist(DataGridColumn column)
        {
            return _dataGrid.Columns.Any(i => i.SortMemberPath == column.SortMemberPath);
        }
    }
}