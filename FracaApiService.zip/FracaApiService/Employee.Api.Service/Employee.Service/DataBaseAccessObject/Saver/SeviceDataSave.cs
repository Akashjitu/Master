﻿using System;
using Fraca.Data.Models;
using Fraca.DataBaseAccessObject;
using System.Configuration;
using Fraca.Service.Constants;

namespace Fraca.Service.DataBaseAccessObject.Saver
{
    public class SeviceDataSave : ISeviceDataSave
    {
        public FracaInfo SaveFraca(FracaInfo fracaInfo)
        {
            var fracIdFormate =  ConfigurationManager.AppSettings[ServiceConstant.FRACA_ID_FROMAT].ToString();

            using (var frc = new FracaDataAccess())
            {
                fracaInfo.FracaNo = string.Format("{0} {1}", fracIdFormate, new Random().Next(0, 999999).ToString("D7"));
                frc.AddNewFraca(fracaInfo);
            }

            return fracaInfo;
        }

        public FracaInfo UpdateFraca(string fracaid, FracaInfo fracaInfo)
        {
            using (var frc = new FracaDataAccess())
            {
                frc.UpdateFraca(fracaid, fracaInfo);
                return fracaInfo;
            }

        }


        public void DeleteFraca(string fracaid)
        {
            using (var frc = new FracaDataAccess())
            {
                frc.DeleteFraca(fracaid);
            }
        }
    }
}