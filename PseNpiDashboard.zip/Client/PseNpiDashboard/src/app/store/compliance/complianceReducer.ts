

import { Action } from '@ngrx/store';
import * as ComplianceAction from './complianceAction';
import { Compliance } from 'src/app/model/compliance';


export interface IAppState {
    readonly compliance: Compliance[];
}


export function complianceReducer(state: Compliance[] = [], action: ComplianceAction.Actions) {

    switch (action.type) {

        case ComplianceAction.ADD_COMPLIANCE: {
            return [...state, action.payload]

        }

        case ComplianceAction.LOAD_COMPLIANCE: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case ComplianceAction.UPDATE_COMPLIANCE: {
            const tti = (action.payload as Compliance);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            //return Object.assign([], state);
            return state.slice();
        }



        default:
            return state;
    }
}