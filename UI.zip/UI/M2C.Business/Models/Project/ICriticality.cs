﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ICriticality.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2C.Business.Models.Project
{
    /// <summary>
    /// Interface ICriticality
    /// </summary>
    public interface ICriticality
    {
        /// <summary>
        /// criticalityParameters
        /// </summary>
        /// <value>The criticality parameters.</value>
        CriticalityModel CriticalityParameters { get; set; }

    }
}
