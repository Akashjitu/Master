﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IFilterNodeInventory.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using M2C.Business.Models.Project;
using System.Collections.ObjectModel;

namespace M2C.Business.Filters
{
    /// <summary>
    /// Interface IFilterNodeInventory
    /// </summary>
    public interface IFilterNodeInventory
    {
        /// <summary>
        /// Gets the name of the filter node inventories by.
        /// </summary>
        /// <param name="currentNode">The current node.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        ObservableCollection<Inventory> GetFilterNodeInventoriesByName(INode currentNode);

        /// <summary>
        /// Gets the filter node inventories by identifier.
        /// </summary>
        /// <param name="currentNode">The current node.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        ObservableCollection<Inventory> GetFilterNodeInventoriesById(INode currentNode);
    }
}