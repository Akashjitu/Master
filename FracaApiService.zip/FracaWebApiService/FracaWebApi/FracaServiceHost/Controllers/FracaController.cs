﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using Fraca.Service.Service;
using System.Net.Http.Formatting;
using Fraca.Data.Models;
using System.Web.Http.Cors;
using FracaServiceHost.Authorizes;
using Fraca.Service.Validator;
using System.Collections.Generic;
using System;

namespace Fraca.Api.Service.Host.Controllers
{
    public class FracaController : ApiController
    {
        private readonly IFracaService _FracaService;
        private readonly IUserValidator _userValidator;
        public FracaController(IFracaService FracaService, IUserValidator userValidator)
        {
            _FracaService = FracaService;
            _userValidator = userValidator;
        }

        [HttpGet]
        public HttpResponseMessage GetAllFraca()
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            //"GLOBAL\H332364";

            var fracaData = _FracaService.GetAllFracaData();

            fracaData.UserName = eid;
            fracaData.FracaInfo = _userValidator.MapAccess(eid, fracaData.FracaInfo);

            var res = Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);
            return res;
        }


        [HttpPost]
        public HttpResponseMessage AddNewFraca(FracaInfo fracaInfo)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            fracaInfo.LAST_UPDATE = DateTime.Today;
            fracaInfo.LAST_UPDATE_BY = eid;
            var fracaData = _FracaService.AddNewFraca(fracaInfo);
            fracaData = _userValidator.MapAccess(eid, new List<FracaInfo>() { fracaData })[0];
            var res = Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);
            return res;
        }

        [HttpPut]
        public HttpResponseMessage UpdateFraca(string fracaNo, FracaInfo fracaInfo)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);

            fracaInfo.LAST_UPDATE = DateTime.Today;
            fracaInfo.LAST_UPDATE_BY = eid;
            if (_userValidator.IsValidForUpdate(fracaNo, fracaInfo, eid))
            {
                var fracaData = _FracaService.UpdateFraca(fracaNo, fracaInfo);

                fracaData = _userValidator.MapAccess(eid, new List<FracaInfo>() { fracaData })[0];

                return Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);
            }

            return Request.CreateResponse(HttpStatusCode.Unauthorized, "User not Authorized to change report", JsonMediaTypeFormatter.DefaultMediaType);
        }



        [HttpDelete]
        public HttpResponseMessage DeleteFraca(string id)
        {
            var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);
            if (_userValidator.IsValidForDelete(id, eid))
            {
                _FracaService.DeleteFraca(id);
                Request.CreateResponse(HttpStatusCode.OK, "Report Deleted", JsonMediaTypeFormatter.DefaultMediaType);
            }
            return Request.CreateResponse(HttpStatusCode.Unauthorized, "User not Authorized to Delete report", JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}