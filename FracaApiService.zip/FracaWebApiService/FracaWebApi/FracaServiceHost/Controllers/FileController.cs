﻿using Fraca.Service.Service;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Web.Http;

namespace Fraca.Api.Service.Host.Controllers
{
    public class FileController : ApiController
    {
        private IFracaService _FracaService;
        public FileController(IFracaService FracaService)
        {
            _FracaService = FracaService;
        }

        [HttpGet]
        public HttpResponseMessage GetFracaPdfReport(string fracaId)
        {
            var fracaData = _FracaService.GetFracaPdfReport(fracaId);

        
            var dataStream = new MemoryStream(fracaData);

            var response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StreamContent(dataStream)
            };

            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = "Fraca_Report_" + fracaId
            };
            response.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");

            return response;



        }
    }
}



