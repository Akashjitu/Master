﻿using System;
using Pse.Data.Models;
using System.Collections.Generic;
using Pse.Services.Manager;

namespace Pse.Services.Service
{
    public class SpeService : ISpeService
    {

        private readonly ISpeServiceManage _manager;
        public SpeService(ISpeServiceManage manager)
        {
            _manager = manager;
        }
    
        public List<TtiPartAlignment> LoadTti()
        {
            return _manager.LoadTti();
        }

        public List<Compliance> LoadCompliance()
        {
            return _manager.LoadCompliance();
        }

        public int AddCompliance(Compliance compliance)
        {
            return _manager.AddCompliance(compliance);
        }

        public int SubmitCompliances(List<Compliance> compliances)
        {
            return _manager.SubmitCompliances(compliances);
        }

        public int UpdateCompliance(Compliance compliance)
        {
            return _manager.UpdateCompliance(compliance);
        }

        public int DeleteCompliance(Compliance compliance)
        {
            return _manager.DeleteCompliance(compliance);
        }

        public List<TtiPartAlignment> LoadTtiByParameter(TtiPartAlignment ttiPartAlignment)
        {
            return _manager.LoadTtiByParameter(ttiPartAlignment);
        }

        public int AddTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            return _manager.AddTTiInfo(ttiPartAlignment);
        }

        public int UpdateTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            return _manager.UpdateTTiInfo(ttiPartAlignment);
        }

        public List<TtiPartAlignment> LoadTtiByDate(TtiPartAlignment ttiPartAlignment)
        {
            return _manager.LoadTtiByDate(ttiPartAlignment);
        }


        public int SubmitTti(List<TtiPartAlignment> tti)
        {
            return _manager.SubmitTTi(tti);
        }

        public List<Effectiveness> LoadEffectivenesByDate(Effectiveness effectiveness)
        {
            return _manager.LoadEffectivenesByDate(effectiveness);
        }

        public List<Effectiveness> LoadEffectivenesById(Effectiveness effectiveness)
        {
            return _manager.LoadEffectivenesById(effectiveness);
        }

        public List<Effectiveness> LoadEffectivenesByPart(Effectiveness effectiveness)
        {
            return _manager.LoadEffectivenesByPart(effectiveness);
        }

        public List<Effectiveness> LoadPppPartInfo(Effectiveness effectiveness)
        {
            return _manager.LoadPppPartInfo(effectiveness);
        }

        public int SubmitEffectivenes(List<Effectiveness> effectiveness)
        {
            return _manager.SubmitEffectivenes(effectiveness);
        }



        public List<OtlDispositionDetails> LoadOtlDispositionById(OtlDispositionDetails otlDisposition)
        {
            return _manager.LoadOtlDispositionById(otlDisposition);
        }

        public List<OtlDispositionDetails> LoadOtlDispositionByDate(OtlDispositionDetails otlDisposition)
        {
            return _manager.LoadOtlDispositionByDate(otlDisposition);
        }

        public List<OtlDispositionDetails> LoadOtlDispositionByKeyCode(OtlDispositionDetails otlDisposition)
        {
            return _manager.LoadOtlDispositionByKeyCode(otlDisposition);
        }

        public int UpdateOtlDispositionByID(OtlDispositionDetails otlDisposition)
        {
            return _manager.UpdateOtlDispositionByID(otlDisposition);
        }


        public List<EffectivenessAnalysis> LoadEffectivenesAnalysis()
        {
            return _manager.LoadEffectivenesAnalysis();
        }
        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisByCreationDate(EffectivenessAnalysis effectivenessAnalysis)
        {
            return _manager.LoadEffectivenessAnalysisByCreationDate(effectivenessAnalysis);
        }
        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisById(EffectivenessAnalysis effectivenessAnalysis)
        {
            return _manager.LoadEffectivenessAnalysisById(effectivenessAnalysis);
        }
        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisByPart(EffectivenessAnalysis effectivenessAnalysis)
        {
            return _manager.LoadEffectivenessAnalysisByPart(effectivenessAnalysis);
        }


        public byte[] ExportEffectivenesAnalysis(EffectivenessAnalysis effectivenessAnalysis)
        {
            return _manager.ExportEffectivenesAnalysis(effectivenessAnalysis);
        }

        public byte[] ExportOtlDisposition(OtlDispositionDetails otlDisposition)
        {
            return _manager.ExportOtlDisposition(otlDisposition);
        }

        public byte[] ExportEffectivene(Effectiveness effectiveness)
        {
            return _manager.ExportEffectivene(effectiveness);
        }

        public byte[] ExportTti(TtiPartAlignment tti)
        {
            
            return _manager.ExportTti(tti);
        }

        public byte[] ExportCompliance(Compliance compliance)
        {
            return _manager.ExportCompliance(compliance);
        }

        public int SubmitOtlDisposition(List<OtlDispositionDetails> lstOTL)
        {
            return _manager.SubmitOtlDisposition(lstOTL);
        }

        public byte[] ExportPliByDate(Pli pli) { 
        
            return _manager.ExportPliByDate(pli);
        }

        public List<Pli> LoadPli()
        {
            return _manager.LoadPli();
        }

        public List<Pli> LoadPliByDate(Pli pli)
        {
            return _manager.LoadPliByDate(pli);
        }

        public List<Pli> LoadPliById(Pli pli)
        {
            return _manager.LoadPliById(pli);
        }

        public List<Pli> LoadPliByKeyCode(Pli pli)
        {
            return _manager.LoadPliByKeyCode(pli);
        }

        public List<OtlAnalysis> LoadOtlAnalysis()
        {
            return _manager.LoadOtlAnalysis();
        }

        public List<OtlAnalysis> LoadOtlAnalysisByDate(OtlAnalysis otl)
        {
            return _manager.LoadOtlAnalysisByDate(otl);
        }

        public List<OtlAnalysis> LoadOtlAnalysisById(OtlAnalysis otl)
        {
            return _manager.LoadOtlAnalysisById(otl);
        }

        public List<OtlAnalysis> LoadOtlAnalysisByKeyCode(OtlAnalysis otl)
        {
            return _manager.LoadOtlAnalysisByKeyCode(otl);
        }

        public int SubmitOtlAnalysisById(List<OtlAnalysis> otls)
        {
            return _manager.SubmitOtlAnalysisById(otls);
        }

        public byte[] ExportOtlAnalysisByDate(OtlAnalysis otlAnalysis)
        {
            return _manager.ExportOtlAnalysisByDate(otlAnalysis);
        }

        public EscapesManufacturedOtl GetEscapesManufacturedOtl(DateTime fromdate, int subtractMonth)
        {
            return _manager.EscapesManufacturedOtl(fromdate, subtractMonth);
        }

        public byte[] ExportAllPli()
        {
            return _manager.ExportAllPli();
        }

        public byte[] ExportPliByFilter(Pli filter)
        {
            return _manager.ExportPliByFilter(filter);
        }
    }
}