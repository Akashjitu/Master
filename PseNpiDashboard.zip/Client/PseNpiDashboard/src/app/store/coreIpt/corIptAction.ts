import { Action } from '@ngrx/store';
import { OtlGraduates } from 'src/app/model/otlGraduates';
import { CoreIpt } from 'src/app/model/coreIpt';


export const ADD_CORE_IPT = 'ADD_CORE_IPT';
export const LOAD_CORE_IPT  = 'LOAD_CORE_IPT';
export const REMOVE_CORE_IPT  = 'REMOVE_CORE_IPT';
export const UPDATE_CORE_IPT : string = 'UPDATE_CORE_IPT';



export class LoadCoreIpt implements Action {
    readonly type = LOAD_CORE_IPT;

    constructor(public payload: any) {
    }
}

export class AddCoreIpt implements Action {
    readonly type = ADD_CORE_IPT;

    constructor(public payload: OtlGraduates) { }
}

export class UpdateCoreIpt implements Action {
    readonly type = UPDATE_CORE_IPT;

    constructor(public payload: OtlGraduates) { }
}

export class RemoveCoreIpt implements Action {
    readonly type = REMOVE_CORE_IPT;

    constructor(public payload: number) { }
}


export type Actions = AddCoreIpt | RemoveCoreIpt | LoadCoreIpt;
