﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="TemplateDownloadLogic.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using InputParserLibary.Contracts;
using M2C.Business.Contracts;
using Microsoft.Win32;
using System;
using System.IO;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class TemplateDownloadLogic.
    /// Implements the <see cref="M2C.Business.Contracts.ITemplateDownloadLogic" />
    /// </summary>
    /// <seealso cref="M2C.Business.Contracts.ITemplateDownloadLogic" />
    public class TemplateDownloadLogic : ITemplateDownloadLogic
    {
        /// <summary>
        /// The excel reader
        /// </summary>
        private readonly IExcelReader _excelReader;

        /// <summary>
        /// The save file dialog
        /// </summary>
        private readonly SaveFileDialog _saveFileDialog;

        /// <summary>
        /// Initializes a new instance of the <see cref="TemplateDownloadLogic" /> class.
        /// </summary>
        /// <param name="excelReader">The excel reader.</param>
        public TemplateDownloadLogic(IExcelReader excelReader)
        {
            this._excelReader = excelReader;
            _saveFileDialog = new SaveFileDialog();
        }

        /// <summary>
        /// call the function to open file
        /// </summary>
        /// <param name="sourceFilePath">The source file path.</param>
        public void ExcelTemplateDownload(string sourceFilePath)
        {
            Type officeType = Type.GetTypeFromProgID("Excel.Application");
            if (officeType == null)
            {
                string saveFilepath = string.Empty;
                if (ShowSaveFileDialog(ref saveFilepath))
                {
                    File.Copy(sourceFilePath, saveFilepath, true); 
                }
                if (saveFilepath != null)
                {
                    System.Diagnostics.Process.Start(saveFilepath);
                }
                else
                {
                    new Exception("Error  in template download");
                }
            }
            else
            {
                _excelReader.openAsNewFile(sourceFilePath);
            }
        }

        /// <summary>
        /// Function for save file location
        /// </summary>
        /// <param name="saveFilepath">The save filepath.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ShowSaveFileDialog(ref string saveFilepath)
        {
            _saveFileDialog.FileName = string.Empty;
            _saveFileDialog.Filter = "Excel Template Files| *.xlt;";
            if (_saveFileDialog.ShowDialog() == false)
            {
                return false;
            }
            saveFilepath=_saveFileDialog.FileName;
            return true;
        }
    }
}