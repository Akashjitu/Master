

import { Action } from '@ngrx/store';
import * as EffectivenessAnalysisAction from './effectivenessAnalysisAction';
import { Compliance } from 'src/app/model/compliance';
import { EffectivenessAnalysis } from 'src/app/model/effectivenessAnalysis';


export interface IAppState {
    readonly compliance: Compliance[];
}

export function effectivenessAnalysisReducer(state: EffectivenessAnalysis[] = [], action: EffectivenessAnalysisAction.Actions) {

    switch (action.type) {

        case EffectivenessAnalysisAction.ADD_EFFECTIVENESS_ANALYSIS: {
            return [...state, action.payload]

        }

        case EffectivenessAnalysisAction.LOAD_EFFECTIVENESS_ANALYSIS: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case EffectivenessAnalysisAction.UPDATE_EFFECTIVENESS_ANALYSIS: {
            const tti = (action.payload as EffectivenessAnalysis);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            //return Object.assign([], state);
            return state.slice();
        }



        default:
            return state;
    }
}