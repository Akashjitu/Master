﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.ProjectPlan
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CommonConstant.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Desktop.Modules.ProjectPlan.Constants
{
    /// <summary>
    /// Class CommonConstant.
    /// </summary>
    public class CommonConstant
    {
        /// <summary>
        /// The reset profile message
        /// </summary>
        public const string ResetProfileMessage = "Do you want to set default value?";
        /// <summary>
        /// The warning
        /// </summary>
        public const string Warning = "Warning";
        /// <summary>
        /// The options title
        /// </summary>
        public const string OptionsTitle = "Options";
    }
}