import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlMorNotesComponent } from './otl-mor-notes.component';

describe('OtlMorNotesComponent', () => {
  let component: OtlMorNotesComponent;
  let fixture: ComponentFixture<OtlMorNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlMorNotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlMorNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
