﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Metadata.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class Metadata.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Metadata
    {
        /// <summary>
        /// Gets or sets the metadata identifier.
        /// </summary>
        /// <value>The metadata identifier.</value>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int MetadataID { get; set; }

        /// <summary>
        /// Gets or sets the key.
        /// </summary>
        /// <value>The key.</value>
        [Required]
        public string Key { get; set; }
        /// <summary>
        /// Gets or sets the content.
        /// </summary>
        /// <value>The content.</value>
        public byte[] Content { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        public virtual IBProjectComponent IBProjectComponent { get; set; }
    }
}