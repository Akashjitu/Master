﻿// ***********************************************************************
// Assembly         : M2C.Configuration.Parsers
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="LegacyParser.cs" company="M2C.Configuration.Parsers">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using MexCfgRdr;
using System;

namespace M2C.Configuration.Parsers.LegacyParsers
{
    /// <summary>
    /// New MexCfgReader based parser
    /// </summary>
    /// <seealso cref="M2C.Configuration.Parsers.IConfigParser" />
    internal class LegacyParser : IConfigParser
    {
        /// <summary>
        /// The CFG reader
        /// </summary>
        private CPlcCfgReader _cfgReader = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="LegacyParser" /> class.
        /// </summary>
        public LegacyParser()
        {
            _cfgReader = new CPlcCfgReader();
        }

        /// <summary>
        /// Get Converted XML
        /// </summary>
        /// <returns>System.String.</returns>
        public string getXML()
        {
            return _cfgReader.Xml;
        }

        /// <summary>
        /// Read Configuration file
        /// </summary>
        /// <param name="filePath">Configuration File Path</param>
        /// <returns>System.Int32.</returns>
        /// <exception cref="Exception"></exception>
        /// <exception cref="System.Exception"></exception>
        public int ReadSourceFile(string filePath)
        {
            int statusCode = _cfgReader.ReadIOmap(filePath);
            if (statusCode != 0)
            {
                throw new Exception(filePath + " : Reading Failed with Error : " + _cfgReader.ErrorDescription[statusCode]);
            }

            return statusCode;
        }
    }
}