﻿namespace NuGetPackageExplorer.Types
{
    public interface IFileEditorService
    {
        void Save(string filePath);
    }
}