﻿using System;
using System.Reflection;
using System.Web.Http;
using Autofac;
using Autofac.Integration.WebApi;
using Fraca.Service.DataBaseAccessObject.Saver;
using Fraca.Service.Manager;
using Fraca.Data.Models;
using Fraca.Service.Service;
using Fraca.Service.ServiceConsumer;
using Microsoft.Owin.Hosting;
using Owin;
using Fraca.Service.DataBaseAccessObject.Loader;
using System.Web.Http.Cors;
using Fraca.Service.Reporting;
using Swashbuckle.Application;
using System.Configuration;
using Microsoft.Owin.Security.OAuth;
using Microsoft.Owin;
using System.Net;

namespace Fraca.Api.Service.Host
{
    internal class TopshelfService
    {
        private IDisposable _webapp;

        public TopshelfService()
        {
        }

        public bool Start()
        {
            var url = string.Format("http://{0}:{1}/", ConfigurationManager.AppSettings["SERVICE_NAME"].ToString(), ConfigurationManager.AppSettings["PORT_NUMBER"].ToString());


            _webapp = WebApp.Start<Startup>(url: url);// "http://localhost:8080/");
            
            Console.WriteLine("Service url:"+ url);
            System.Diagnostics.Trace.WriteLine(("Service url:" + url));
            return true;
        }

        public void Stop()
        {
            _webapp?.Dispose();
        }
    }

    public class Startup
    {
        public void Configuration(IAppBuilder appBuilder)
        {

            var config = new HttpConfiguration();
            config.MapHttpAttributeRoutes();
            
            config.Routes.MapHttpRoute(
                 name: "DefaultApi",
                routeTemplate: "api/{controller}/{Id}",
                defaults: new { id = RouteParameter.Optional }
                );

            config.EnableCors(new EnableCorsAttribute("*", "*", "*"));

            // GlobalConfiguration.Configuration
            config.EnableSwagger(c => c.SingleApiVersion("v1", "Fraca Service"))
                .EnableSwaggerUi();

   
            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());
           

            var assemblyType = typeof(FracaInfo).GetTypeInfo();

            builder.RegisterAssemblyTypes(assemblyType.Assembly)
            .Where(t => t.Name.EndsWith("Service"))
            .AsImplementedInterfaces()
            .InstancePerRequest();

            builder.RegisterWebApiFilterProvider(config); 
            builder.RegisterType<FracaService>().As<IFracaService>().InstancePerRequest();
            builder.RegisterType<FracaServiceManage>().As<IFracaServiceManage>().InstancePerRequest();
            builder.RegisterType<EmployeeServcie>().As<IEmployeeServcie>().InstancePerRequest();
            builder.RegisterType<SeviceDataSave>().As<ISeviceDataSave>().InstancePerRequest();
            builder.RegisterType<ServiceDataLoader>().As<IServiceDataLoader>().InstancePerRequest(); 
            builder.RegisterType<PdfReportMapper>().As<IPdfReportMapper>().InstancePerRequest();
            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
            appBuilder.UseAutofacMiddleware(container);


         //   HttpListener listener = (HttpListener)appBuilder.Properties["System.Net.HttpListener"];
           // listener.AuthenticationSchemes = AuthenticationSchemes.IntegratedWindowsAuthentication;

            //HttpListener listener =(HttpListener)app.Properties["System.Net.HttpListener"];
            //listener.AuthenticationSchemes = AuthenticationSchemes.IntegratedWindowsAuthentication;


            //appBuilder.UseOAuthAuthorizationServer(new OAuthAuthorizationServerOptions
            //{
            //    AllowInsecureHttp = true,
            //    TokenEndpointPath = new PathString("/token"),
            //    AccessTokenExpireTimeSpan = TimeSpan.FromDays(1),
            //   // Provider = new AppOAuthProvider(usermanager)
            //});

            var auth = new OAuthBearerAuthenticationOptions();
            auth.AuthenticationMode = Microsoft.Owin.Security.AuthenticationMode.Passive;
            appBuilder.UseOAuthBearerAuthentication(auth);
            appBuilder.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);


            appBuilder.UseWebApi(config);
        }
    }
}
