import { Injectable } from '@angular/core';
import { BehaviorSubject} from 'rxjs'; 
import { FracaInfo } from '../Models/fraca-info';

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {
  private messageSourse= new BehaviorSubject<FracaInfo>({
    FracaNo : '',
    PartNo : '',
    OpenDate : new Date(),
    CloseDate : new Date(),
    FailedDate :new Date(),
    Product : '',
    Program : '',
    Customer : '',
    TestEnv : '',
    Originator : '',
    RespEng : '',
    System : '',
    Electrical : '',
    Emi : '',
    ClosedBy : '',
    TestDoc : '',
    Paragraph : '',
    TestType : '',
    FailureCode : '',
    EndUnit : '',
    Level1 : '',
    Level2 : '',
    Nomenclature : '',
    SerialNumber : '',
    Designator : '',
    InflightShutdown : false,
    InflightPowerLoss : false,
    Chargeability : false,
    SafetyAffected : false,
    FailureToStart : false,
    ProblemDescription : ' ',
    Finding : '',
    Analysis : '',
    AccessType : 0,
    Status: 'InProgress'
  });

  currentMessage= this.messageSourse.asObservable()

  constructor() { }

changeMessage(message){
  this.messageSourse.next(message);
}

}





