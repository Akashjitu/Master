import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employeeService';
import { NgxSpinnerService } from 'ngx-spinner';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.css']
})
export class UserInfoComponent implements OnInit {

  UsersInfo: any;
  searchValue: any;
  seachBy: any;
  capction: string;
  constructor(private employeeService: EmployeeService, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.seachBy =0;
    this.capction = 'Employee ID';
  }


  // onExportChange(event) {
  //   this.isName = event;
  //   console.log(this.isName);
  //   console.log(event)
  // }



  onSeachBy(value) {
    this.seachBy = value
    this.capction = '';
    switch (value) {
      case 0:
        this.capction = 'Employee ID';
        break;
      case 2:
        this.capction = 'Mail';
        break;
      case 3:
        this.capction = 'Display Name';
        break;

      case 1:
        this.capction = 'First Name';
        break;
    }
  }

  onSearch() {
    this.spinner.show();
    this.employeeService.getEmployeeBySearch(this.searchValue, this.seachBy).subscribe(emp => {
      this.UsersInfo = emp;
      this.spinner.hide();
    });
  }

}
