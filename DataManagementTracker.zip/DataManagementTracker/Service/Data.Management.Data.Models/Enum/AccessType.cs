﻿namespace Data.Management.Data.Models.Enum
{
    public enum AccessDbType
    {
        NoAccess = 0,
        ViewOnly = 1,
        FullAccess = 2
    }


    public enum AccessUIType
    {
        ReadOnly = 0,
        Comment = 1,
        Edit = 2
    }
}