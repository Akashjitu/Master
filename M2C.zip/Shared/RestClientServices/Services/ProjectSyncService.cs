﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectSyncService.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using Newtonsoft.Json;
using RestClientServices.Contracts;
using RestClientServices.Helper;
using RestSharp;
using System;
using WinRegistryServices.Contracts;

namespace RestClientServices.Services
{
    /// <summary>
    /// Class ProjectSyncService.
    /// Implements the <see cref="RestClientServices.Contracts.IRestClientService" />
    /// </summary>
    /// <seealso cref="RestClientServices.Contracts.IRestClientService" />
    internal class ProjectSyncService : IProjectSyncService
    {
        /// <summary>
        /// The application configurations
        /// </summary>
        private readonly IAppConfigurations appConfigurations;

        /// <summary>
        /// The rest client
        /// </summary>
        private readonly IRestClient restClient;

        /// <summary>
        /// The registry store manger
        /// </summary>
        private readonly IRegistryStoreManger registryStoreManger;

        /// <summary>
        /// The rest service request
        /// </summary>
        private IRestServiceRequest restServiceRequest;

        /// <summary>
        /// Gets the service base path.
        /// </summary>
        /// <value>The service base path.</value>
        public string ServiceBasePath { get => appConfigurations.SyncServicePath; }

        /// <summary>
        /// The response
        /// </summary>
        private ServiceResponse response = new ServiceResponse();

        /// <summary>
        /// The rest sharp helper
        /// </summary>
        private readonly RestSharpHelper restSharpHelper;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectSyncService" /> class.
        /// </summary>
        /// <param name="appConfigurations">The application configurations.</param>
        /// <param name="restClient">The rest client.</param>
        /// <param name="registryStoreManger">The registry store manger.</param>
        public ProjectSyncService(IAppConfigurations appConfigurations, IRestClient restClient, IRegistryStoreManger registryStoreManger)
        {
            this.appConfigurations = appConfigurations;
            this.restClient = restClient;
            this.registryStoreManger = registryStoreManger;
            this.restSharpHelper = new RestSharpHelper(this.restClient);
        }

        /// <summary>
        /// Executes the specified request.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request">The request.</param>
        /// <returns>T.</returns>
        public T Execute<T>(IRestServiceRequest request)
        {
            try
            {
                response = restSharpHelper.ExecuteRequest(request);
                if (response != null && response.IsSuccess)
                {
                    return JsonConvert.DeserializeObject<T>(response.Content);
                }
                else
                {
                    return (T)Convert.ChangeType(null, typeof(T));
                }
            }
            catch (Exception ex)
            {
                return (T)Convert.ChangeType(null, typeof(T));
            }
        }

        /// <summary>
        /// Executes the specified request.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool Execute(IRestServiceRequest request)
        {
            try
            {
                response = restSharpHelper.ExecuteRequest(request);
                return response.IsSuccess;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the last synchronize date.
        /// </summary>
        /// <returns>System.String.</returns>
        public string GetLastSyncDate()
        {
            IRestServiceRequest restServiceRequest = new RestServiceRequest()
            {
                ResourcePath = "Project/LastSyncDate",
                RequestType = RequestTypes.GET
            };

            restServiceRequest.HeaderParams.Add("Authorization", $"Bearer {registryStoreManger.GetValue("Accesstoken")}");

            return this.Execute<string>(restServiceRequest);
        }

        /// <summary>
        /// Posts the project date.
        /// </summary>
        /// <param name="JsonData">The json data.</param>
        /// <param name="projectReferenceId">The project reference identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool PostProjectDate(string JsonData, string projectReferenceId)
        {
            IRestServiceRequest restServiceRequest = new RestServiceRequest()
            {
                ResourcePath = "Project",
                RequestType = RequestTypes.POST
            };

            restServiceRequest.HeaderParams.Add("Authorization", $"Bearer {registryStoreManger.GetValue("Accesstoken")}");
            restServiceRequest.HeaderParams.Add("projectRefrenceId", $"{projectReferenceId}");
            restServiceRequest.HeaderParams.Add("content-type", $"application/json");
            restServiceRequest.BodyParam = JsonData;

            return this.Execute(restServiceRequest);
        }

        /// <summary>
        /// Puts the project date.
        /// </summary>
        /// <param name="JsonData">The json data.</param>
        /// <param name="projectReferenceId">The project reference identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool PutProjectDate(string JsonData, string projectReferenceId)
        {
            IRestServiceRequest restServiceRequest = new RestServiceRequest()
            {
                ResourcePath = "Project",
                RequestType = RequestTypes.PUT
            };

            restServiceRequest.HeaderParams.Add("Authorization", $"Bearer {registryStoreManger.GetValue("Accesstoken")}");
            restServiceRequest.HeaderParams.Add("projectRefrenceId", $"{projectReferenceId}");
            restServiceRequest.HeaderParams.Add("content-type", $"application/json");
            restServiceRequest.BodyParam = JsonData;

            return this.Execute(restServiceRequest);
        }
    }
}