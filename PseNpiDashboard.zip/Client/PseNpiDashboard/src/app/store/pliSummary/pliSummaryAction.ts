
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { PliSummary } from 'src/app/model/pliSummary';

export const ADD_PLI_SUMMARY = 'ADD_PLI_SUMMARY';
export const LOAD_PLI_SUMMARY = 'LOAD_PLI_SUMMARY';
export const REMOVE_PLI_SUMMARY = 'REMOVE_PLI_SUMMARY';
export const UPDATE_PLI_SUMMARY: string = 'UPDATE_PLI_SUMMARY';



export class LoadPliSummary implements Action {
    readonly type = LOAD_PLI_SUMMARY;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddPliSummary implements Action {
    readonly type = ADD_PLI_SUMMARY;

    constructor(public payload: any) { }
}

export class UpdatePliSummary implements Action {
    readonly type = UPDATE_PLI_SUMMARY;

    constructor(public payload: PliSummary) { }
}

export class RemovePliSummary implements Action {
    readonly type = REMOVE_PLI_SUMMARY;

    constructor(public payload: number) { }
}


export type Actions = AddPliSummary | UpdatePliSummary | RemovePliSummary;
