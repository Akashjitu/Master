﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Employee.Service.Models
{
  public  class EmployeeInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int department_id { get; set; }
    }
}
