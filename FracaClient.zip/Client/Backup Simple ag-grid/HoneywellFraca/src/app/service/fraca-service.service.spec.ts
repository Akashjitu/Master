import { TestBed } from '@angular/core/testing';

import { FracaServiceService } from './fraca-service.service';

describe('FracaServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FracaServiceService = TestBed.get(FracaServiceService);
    expect(service).toBeTruthy();
  });
});
