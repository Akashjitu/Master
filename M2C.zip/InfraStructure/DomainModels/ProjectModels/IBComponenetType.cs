﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IBComponenetType.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class IBComponenetType.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class IBComponenetType
    {
        /// <summary>
        /// Gets or sets the component type identifier.
        /// </summary>
        /// <value>The component type identifier.</value>
        [Key]
        [Column(Order = 1)]
        public int ComponentTypeID { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        public ICollection<IBProjectComponent> IBProjectComponent { get; set; }
    }
}