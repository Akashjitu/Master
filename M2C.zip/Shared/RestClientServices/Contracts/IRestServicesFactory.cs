﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="IRestServicesFactory.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace RestClientServices.Contracts
{
    /// <summary>
    /// Interface IRestServicesFactory
    /// </summary>
    public interface IRestServicesFactory
    {
        /// <summary>
        /// Gets the rest client service.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="serviceType">Type of the service.</param>
        /// <returns>IRestClientService.</returns>
        T GetRestClientService<T>(RestServiceTypes serviceType) where T : IRestClientService;
    }
}