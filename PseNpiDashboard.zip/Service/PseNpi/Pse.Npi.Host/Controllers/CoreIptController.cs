﻿using Pse.Data.Models;
using Pse.Services.Service;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class CoreIptController : ApiController
    {
        private ICoreIptService _service;

        public CoreIptController(ICoreIptService service)
        {
            _service = service;
        }

        [HttpGet]
        public HttpResponseMessage GeCoreIpt()
        {
            var cp = _service.LoadAllCoreIpt();
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        public HttpResponseMessage AddCoreIpt(CoreIpt coreIpt)
        {
            var cp = _service.AddCoreIpt(coreIpt);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPut]
        public HttpResponseMessage UpdateCoreIpt(int id, CoreIpt coreIpt)
        {
            var cp = _service.UpdateCoreIpt(coreIpt);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}