﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ContactTypeSeed.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using Microsoft.EntityFrameworkCore;

namespace DataRepository.Seeds
{
    /// <summary>
    /// Class ContactTypeSeed.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    internal class ContactTypeSeed
    {
        /// <summary>
        /// Seeds the specified model builder.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public void Seed(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ContactType>().HasData(
                new ContactType
                {
                    ContactTypeID = 1,
                    Name = "Customer"
                },
                 new ContactType
                 {
                     ContactTypeID = 2,
                     Name = "Schneider"
                 }
            );
        }
    }
}