﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IntegerValidationRule.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Globalization;
using System.Windows.Controls;

namespace M2C.Desktop.Core.CommonValidations
{
    /// <summary>
    /// Class IntegerValidationRule.
    /// Implements the <see cref="System.Windows.Controls.ValidationRule" />
    /// </summary>
    /// <seealso cref="System.Windows.Controls.ValidationRule" />
    public class IntegerValidationRule : ValidationRule
    {
        /// <summary>
        /// Validates the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="cultureInfo">The culture information.</param>
        /// <returns>ValidationResult.</returns>
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            try
            {
                string stringData = value as string;
                int dummy;
                if (!string.IsNullOrEmpty(stringData) && !int.TryParse(stringData, out dummy))
                    return new ValidationResult(false, "Please Enter an Integer value");
                else if(string.IsNullOrEmpty(stringData))
                    return new ValidationResult(false, "Please Enter an Integer value");
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
            return ValidationResult.ValidResult;
        }
    }
}