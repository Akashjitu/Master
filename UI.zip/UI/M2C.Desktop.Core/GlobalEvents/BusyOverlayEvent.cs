﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="BusyOverlayEvent.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Events;

namespace M2C.Desktop.Core.GlobalEvents
{
    /// <summary>
    /// Class BusyOverlayEvent.
    /// Implements the <see cref="Prism.Events.PubSubEvent{M2C.Desktop.Core.GlobalEvents.OverlayMessage}" />
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{M2C.Desktop.Core.GlobalEvents.OverlayMessage}" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class BusyOverlayEvent : PubSubEvent<OverlayMessage>
    {
    }

    /// <summary>
    /// Class OverlayMessage.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OverlayMessage
    {
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>The status.</value>
        public OverlayStatus status { get; set; } = OverlayStatus.HIDDEN;

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }
    }

    /// <summary>
    /// Enum OverlayStatus
    /// </summary>
    public enum OverlayStatus
    {
        /// <summary>
        /// The visible
        /// </summary>
        VISIBLE = 0,
        /// <summary>
        /// The hidden
        /// </summary>
        HIDDEN
    }
}