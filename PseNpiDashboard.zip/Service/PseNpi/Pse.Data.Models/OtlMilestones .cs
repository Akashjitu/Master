//using Oracle.Data.Access;

//namespace Pse.Data.Models
//{
//    internal class OtlMilestones
//    {
//        [Columns("kc")]
//        public string kc { get; set; }

//        [Columns("Program_Name")]
//        public string Accolade_Program_Name { get; set; }

//        [Columns("MS_Name")]
//        public string MS_Name { get; set; }

//        [Columns("MS_Category")]
//        public string MS_Category { get; set; }

//        [Columns("Baseline_Date")]
//        public string Baseline_Date { get; set; }

//        [Columns("Forecast_Date")]
//        public string Forecast_Date { get; set; }

//        [Columns("Actual_Finish")]
//        public string Actual_Finish { get; set; }

//        [Columns("Status_CC_Cause_Code")]
//        public string Status_CC_Cause_Code { get; set; }

//        [Columns("Product_SBU")]
//        public string Accolade_Product_SBU { get; set; }

//        [Columns("GBE")]
//        public string Accolade_GBE { get; set; }

//        [Columns("PAC")]
//        public string PAC { get; set; }

//        [Columns("PM_Focal")]
//        public string Accolade_PM_Focal { get; set; }

//        [Columns("PP_c_Focal")]
//        public string Accolade_PP_c_Focal { get; set; }

//        [Columns("IPDS_Phase_EP3")]
//        public string Accolade_IPDS_Phase_EP3 { get; set; }

//        [Columns("Notes_")]
//        public string Notes_ { get; set; }

//        [Columns("Heatmap_KC")]
//        public string Heatmap_KC { get; set; }
//    }
//}