export interface Effectiveness {
    keyCode: string;
    programName: string;
    partIndex: string;
    partNumber: string;
    partDescription: string;
    makeBuy: string;
    productionSite: string;
    updatedPartNumber: string;
    otlGraduation: string;
    notes: string;
    createdDate: string;
    updatedDate: string;
    updatedBy: string;
    isActive: string;
    id: string;
    createBy:        String    

  
}