﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReferenceControl.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using M2C.Desktop.Core.CommonValidations;

namespace M2C.Desktop.Modules.CollectData.Views.InventoryControls
{
    /// <summary>
    /// Interaction logic for ReferenceControl.xaml
    /// </summary>
    public partial class ReferenceControl : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReferenceControl" /> class.
        /// </summary>
        public ReferenceControl()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Numbers the validation text box.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs" /> instance containing the event data.</param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            e.Handled = InputValidator.IsNumber(e.Text);
        }

        /// <summary>
        /// Handles the PreviewTextInput event of the comboReference control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs" /> instance containing the event data.</param>
        private void comboReference_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            comboReference.IsDropDownOpen = true;
        }

        /// <summary>
        /// Handles the LostFocus event of the comboReference control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void comboReference_LostFocus(object sender, RoutedEventArgs e)
        {
        
        }

        /// <summary>
        /// Handles the OnPreviewKeyDown event of the ComboReference control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="KeyEventArgs" /> instance containing the event data.</param>
        private void ComboReference_OnPreviewKeyDown(object sender, KeyEventArgs e)
        {

        }

        /// <summary>
        /// Handles the KeyDown event of the comboReference control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="KeyEventArgs" /> instance containing the event data.</param>
        private void comboReference_KeyDown(object sender, KeyEventArgs e)
        {

        }
    }
}
