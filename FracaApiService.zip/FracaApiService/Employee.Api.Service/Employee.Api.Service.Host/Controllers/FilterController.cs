﻿using Fraca.Data.Models;
using Fraca.Service.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace Fraca.Api.Service.Host.Controllers
{
    public class FilterController : ApiController
    {
        private IFracaService _FracaService;

        public FilterController(IFracaService FracaService)
        {
            _FracaService = FracaService;
        }


        [HttpPost]
        public HttpResponseMessage GetFracaByFilter(FracaCriteria criteria)
        {
            var fracaData = _FracaService.GetFracaByFilter(criteria);
            return Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);

        }
    }
}
