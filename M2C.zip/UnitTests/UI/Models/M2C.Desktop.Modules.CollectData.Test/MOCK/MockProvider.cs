﻿using M2C.Business.Models;
using System;
using System.Collections.Generic;
using Castle.Components.DictionaryAdapter;

namespace M2C.Desktop.Modules.CollectData.Test.MOCK
{
    public class MockProvider
    {

        public static List<Inventory> GetInventories()
        {
            return new List<Inventory>()
            {
                new Inventory
                {
                    Name = "FBM216b, Redundant Ready HART Inputs, 8 Channels", Reference = "RH927AJ", Brand = "Foxboro",
                    DeviceType = "HMI - Industrial PC", Quantity = 2, Range = "Flex"
                },
                new Inventory
                {
                    Name = "ME-6.5 MICRODRIVE ELITE CONF", Reference = "E006CB", Brand = "Foxboro",
                    DeviceType = "HMI - Industrial PC", Quantity = 2, Range = "Flex"
                },
                new Inventory
                {
                    Name = "ME:6.5 ME CONF FLT EARTH", Reference = "E006CITA", Brand = "Foxboro",
                    DeviceType = "HMI - Industrial PC", Quantity = 2, Range = "Flex"
                },
                new Inventory
                {
                    Name = "ALX 144 ULTRADRIVE IP54", Reference = "ALX-144-EA", Brand = "Foxboro",
                    DeviceType = "HMI - Industrial PC", Quantity = 2, Range = "Flex"
                }
            };
        }

        public static List<BrandModel> GetBrands()
        {
            return new List<BrandModel>
            {
                new BrandModel { Id = 1, Name = "Schneider",CreatedDate = DateTime.Today},
                new BrandModel { Id = 2, Name = "Schneider",CreatedDate = DateTime.Today},
                new BrandModel { Id = 3, Name = "Schneider",CreatedDate = DateTime.Today},
                new BrandModel { Id = 4, Name = "Schneider",CreatedDate = DateTime.Today},
                new BrandModel { Id = 5, Name = "Schneider",CreatedDate = DateTime.Today},
                new BrandModel { Id = 6, Name = "Schneider",CreatedDate = DateTime.Today},
                new BrandModel { Id = 9, Name = "Schneider",CreatedDate = DateTime.Today}
            };
        }

        public static List<DeviceTypeModel> GetDeviceTypes()
        {
            return new List<DeviceTypeModel>
            {
                new DeviceTypeModel { Id = 1, Type = "DeviceTypeLegacy1",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription1"},
                new DeviceTypeModel { Id = 2, Type = "DeviceTypeLegacy2",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription2"},
                new DeviceTypeModel { Id = 3, Type = "DeviceTypeLegacy3",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription3"},
                new DeviceTypeModel { Id = 4, Type = "DeviceTypeLegacy4",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription5"},
                new DeviceTypeModel { Id = 5, Type = "DeviceTypeLegacy5",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription4"},
                new DeviceTypeModel { Id = 6, Type = "DeviceTypeLegacy6",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription6"},
                new DeviceTypeModel { Id = 9, Type = "DeviceTypeLegacy7",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription7"}
            };
        }

        public static List<ProductModel> GetProducts()
        {
            return new List<ProductModel>
            {
                new ProductModel { Id = 1, Identifier="TSXRKY12EX",  CreatedDate = DateTime.Today, RangeId=1, Serviceable= "Serviceable1", BrandId=1, Configuration="Configuration1", DeviceTypeId =1  },
                new ProductModel { Id = 2, Identifier="TSXP57302M",  CreatedDate = DateTime.Today, RangeId=2, Serviceable= "Serviceable1", BrandId=2, Configuration="Configuration2", DeviceTypeId =2  },
                new ProductModel { Id = 3, Identifier="TSXPSY1610M",  CreatedDate = DateTime.Today, RangeId=1, Serviceable= "Serviceable1", BrandId=1, Configuration="Configuration3", DeviceTypeId =1  },
                new ProductModel { Id = 4, Identifier="TSXETY410",  CreatedDate = DateTime.Today, RangeId=3, Serviceable= "Serviceable1", BrandId=2, Configuration="Configuration4", DeviceTypeId =2  },
                new ProductModel { Id =5,  Identifier="TSXDSY32T2K",  CreatedDate = DateTime.Today, RangeId=4, Serviceable= "Serviceable1", BrandId=1, Configuration="Configuration5", DeviceTypeId =1  },
            };
        }

        public static List<RangeModel> GetRanges()
        {
            return new List<RangeModel>
            {
                new RangeModel { Id = 1, Name = "Range1", CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode1" },
                new RangeModel { Id = 2, Name = "Range2",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode2"},
                new RangeModel { Id = 3, Name = "Range3",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode3"},
                new RangeModel { Id = 4, Name = "Range4",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode4"},
                new RangeModel { Id = 5, Name = "Range5",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode5"},
                new RangeModel { Id = 6, Name = "Range6",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode6"},
                new RangeModel { Id = 9, Name = "Range10",CreatedDate =DateTime.Today,OpsDescription="SdhSubRangeCode7"}
            };
        }


    }
}