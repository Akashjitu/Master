export interface CoreIpt {

    id: number;            
    keyCode: string;                       
    ipdsCurrentPhase: string;             
    coupledDeCoupled: string;               
    hwDevelopmentScop: string;             
    swDevelopmentScop: string;            
    productManager: string;               
    programManager: string;              
    ppC: string;                        
    projectEngineer: string;               
    advanceManufacturingEngineer: string; 
    pseLaunchEngineer: string;             
    apqpEngineer: string;                  
    sourcingPm: string;                    
    contracts: string;                    
    supplierApqp: string;                  
    pmChief: string;                      
    cps: string;                          
    updatedDate: Date;                   
    updatedBy: string;                    
    active: string;                       
    createdDate: Date;                   
    createBy: string; 
}