﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="OpenProjectDialog.xaml.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for OpenProjectDialog
    /// </summary>
    public partial class OpenProjectDialog : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OpenProjectDialog" /> class.
        /// </summary>
        public OpenProjectDialog()
        {
            InitializeComponent();
        }
    }
}
