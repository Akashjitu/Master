
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';
import { OtlSummery } from 'src/app/model/otlSummey';

export const ADD_OTL_SUMMARY_GRID = 'ADD_OTL_SUMMARY_GRID:';
export const LOAD_OTL_SUMMARY_GRID = 'LOAD_OTL_SUMMARY_GRID:';
export const REMOVE_OTL_SUMMARY_GRID = 'REMOVE_OTL_SUMMARY_GRID:';
export const UPDATE_OTL_SUMMARY_GRID: string = 'UPDATE_OTL_SUMMARY_GRID:';



export class LoadGridOtlSummary implements Action {
    readonly type = LOAD_OTL_SUMMARY_GRID;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddGridOtlSummary implements Action {
    readonly type = ADD_OTL_SUMMARY_GRID;

    constructor(public payload: any) { }
}

export class UpdateGridOtlSummary implements Action {
    readonly type = UPDATE_OTL_SUMMARY_GRID;

    constructor(public payload: any) { }
}

export class RemoveGridOtlSummary implements Action {
    readonly type = REMOVE_OTL_SUMMARY_GRID;

    constructor(public payload: number) { }
}


export type Actions = AddGridOtlSummary | UpdateGridOtlSummary | RemoveGridOtlSummary;
