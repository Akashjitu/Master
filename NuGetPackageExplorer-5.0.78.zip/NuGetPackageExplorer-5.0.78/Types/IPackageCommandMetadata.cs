﻿namespace NuGetPackageExplorer.Types
{
    public interface IPackageCommandMetadata
    {
        string Text { get; }
    }
}