﻿using M2C.Business.Models.Chart;
using Prism.Mvvm;
using System.Collections.ObjectModel;

namespace M2C.Desktop.Modules.Charts.ReportData.Models
{
    public class ReportDataParameter : BindableBase
    {
        private ObservableCollection<ChartBarElement> _greenChartElements;
        private ObservableCollection<ChartBarElement> _yellowChartElements;
        private ObservableCollection<ChartBarElement> _redChartElements;
        private ObservableCollection<ChartBarElement> _chartBarElements;
        private bool _isObsolescence;
        private string _header;
        private string _yAxisLabel;
        private string _xAxisLabel;

        public string Header { get => _header; set => SetProperty(ref _header, value); }

        public string YAxisLabel { get => _yAxisLabel; set => SetProperty(ref _yAxisLabel, value); }

        public string XAxisLabel { get => _xAxisLabel; set => SetProperty(ref _xAxisLabel, value); }

        public bool IsObsolescence { get => _isObsolescence; set => SetProperty(ref _isObsolescence, value); }
        public ObservableCollection<ChartBarElement> RedChartElements { get => _redChartElements; set => SetProperty(ref _redChartElements, value); }
        public ObservableCollection<ChartBarElement> YellowChartElements { get => _yellowChartElements; set => SetProperty(ref _yellowChartElements, value); }
        public ObservableCollection<ChartBarElement> GreenChartElements { get => _greenChartElements; set => SetProperty(ref _greenChartElements, value); }

        public ObservableCollection<ChartBarElement> ChartBarElements { get => _chartBarElements; set => SetProperty(ref _chartBarElements, value); }
    }
}