﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ContextControl.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Core.Enums;
using M2C.Desktop.Modules.CollectData.ViewModels;
using System;
using System.Windows;
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for ContextControl
    /// </summary>
    public partial class ContextControl : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ContextControl" /> class.
        /// </summary>
        public ContextControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Gets the view model.
        /// </summary>
        /// <value>The view model.</value>
        private ContextControlViewModel _viewModel
        {
            get { return this.DataContext as ContextControlViewModel; }
        }

        /// <summary>
        /// Gets or sets the project create mode.
        /// </summary>
        /// <value>The project create mode.</value>
        public ProjectCreateModes ProjectCreateMode
        {
            get { return (ProjectCreateModes)GetValue(ProjectCreateModeProperty); }
            set { SetValue(ProjectCreateModeProperty, value); }
        }

        /// <summary>
        /// The project create mode property
        /// </summary>
        public static readonly DependencyProperty ProjectCreateModeProperty =
            DependencyProperty.Register("ProjectCreateMode", typeof(string), typeof(ContextControl), new PropertyMetadata(new PropertyChangedCallback(OnProjectCreateModeChanged)));

        /// <summary>
        /// Called when [project create mode changed].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnProjectCreateModeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((ContextControl)d).OnProjectCreateModeChanged(e);
        }

        /// <summary>
        /// Raises the <see cref="E:ProjectCreateModeChanged" /> event.
        /// </summary>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        protected virtual void OnProjectCreateModeChanged(DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue != null)
            {
                Enum.TryParse(e.NewValue as string, out ProjectCreateModes projectmode);
                this._viewModel.ProjectCreateMode = projectmode;
            }
            else
            {
                this._viewModel.ProjectCreateMode = ProjectCreateModes.NEW;
            }
        }
    }
}