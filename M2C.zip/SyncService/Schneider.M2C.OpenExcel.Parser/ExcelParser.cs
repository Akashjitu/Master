﻿// ***********************************************************************
// Assembly         : Schneider.M2C.OpenExcel.Parser
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="ExcelParser.cs" company="Schneider.M2C.OpenExcel.Parser">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace Schneider.M2C.OpenExcel.Parser
{
    /// <summary>
    /// Class ExcelParser.
    /// Implements the <see cref="Schneider.M2C.OpenExcel.Parser.IExcelParser" />
    /// </summary>
    /// <seealso cref="Schneider.M2C.OpenExcel.Parser.IExcelParser" />
    public class ExcelParser : IExcelParser
    {
        /// <summary>
        /// The progress call back
        /// </summary>
        private static Action<int> _progressCallBack = null;

        /// <summary>
        /// Get the models from excel.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <param name="callBack">The call back.</param>
        /// <returns>List&lt;T&gt;.</returns>
        public List<T> GeModelsFromExcel<T>(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2, Action<int> callBack = null)
        {
            _progressCallBack = callBack;
            return ConvertDataTable<T>(LoadTable(excelPath, sheetName, headerRowNumber, dataRowStart));
        }

        /// <summary>
        /// Gets the data table from excel.
        /// </summary>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>DataTable.</returns>
        /// <exception cref="FileNotFoundException">File Not Found</exception>
        /// <exception cref="FileNotFoundException">SheetName is Empty or null</exception>
        /// <exception cref="FileNotFoundException">File Not Found</exception>
        /// <exception cref="FileNotFoundException">SheetName is Empty or null</exception>
        public DataTable GetDataTableFromExcel(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2)
        {
            if (!File.Exists(excelPath))
                throw new FileNotFoundException("File Not Found");
            if (string.IsNullOrEmpty(sheetName))
                throw new FileNotFoundException("SheetName is Empty or null");

            return LoadTable(excelPath, sheetName, headerRowNumber, dataRowStart);
        }

        /// <summary>
        /// Gets the data table from excel.
        /// </summary>
        /// <param name="excelFileStream">The excel file stream.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>DataTable.</returns>
        public DataTable GetDataTableFromExcel(Stream excelFileStream, string sheetName, int headerRowNumber = 1, int dataRowStart = 2)
        {
            return ReadExcel(sheetName, headerRowNumber, dataRowStart, excelFileStream);
        }

        /// <summary>
        /// Ges the models from excel.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelFileStream">The excel file stream.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>List&lt;T&gt;.</returns>
        public List<T> GeModelsFromExcel<T>(Stream excelFileStream, string sheetName, int headerRowNumber = 1, int dataRowStart = 2)
        {
            return ConvertDataTable<T>(ReadExcel(sheetName, headerRowNumber, dataRowStart, excelFileStream));
        }

        /// <summary>
        /// Loads the table.
        /// </summary>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>DataTable.</returns>
        private static DataTable LoadTable(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2)
        {
            using (FileStream fs = new FileStream(excelPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                return ReadExcel(sheetName, headerRowNumber, dataRowStart, fs);
            }
        }

        /// <summary>
        /// Gets the columns.
        /// </summary>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="rows">The rows.</param>
        /// <param name="cellIndexValue">The cell index value.</param>
        /// <returns>DataColumn[].</returns>
        private static DataColumn[] GetColumns(int headerRowNumber, List<Row> rows, Dictionary<int, string> cellIndexValue)
        {
            return (headerRowNumber > 0) ? rows[headerRowNumber - 1].Elements<Cell>()
                                      .Select(i => new DataColumn
                                      {
                                          Caption = (i.DataType != null) ? cellIndexValue[int.Parse(i.InnerText)] : i.InnerText?.Trim(),
                                          ColumnName = Regex.Match(i.CellReference, "[A-Za-z]+").Value.Trim()
                                      }).ToArray() :

        rows[headerRowNumber].Elements<Cell>()
                                  .Select(i => new DataColumn
                                  {
                                      Caption = Regex.Match(i.CellReference, "[A-Za-z]+").Value.Trim(),
                                      ColumnName = Regex.Match(i.CellReference, "[A-Za-z]+").Value.Trim()
                                  }).ToArray();
        }

        /// <summary>
        /// Converts the data table.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataTable">The data table.</param>
        /// <returns>List&lt;T&gt;.</returns>
        private static List<T> ConvertDataTable<T>(DataTable dataTable)
        {
            if (dataTable == null || dataTable.Rows.Count == 0)
                return null;

            var columnNames = dataTable.Columns.OfType<DataColumn>().Select(i => i.ColumnName).ToArray();
            return dataTable.Rows.OfType<DataRow>().Select(row => GetItem<T>(row, columnNames)).ToList();
        }

        /// <summary>
        /// Gets the item.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr">The dr.</param>
        /// <param name="columnNames">The column names.</param>
        /// <returns>T.</returns>
        /// <exception cref="Exception">Please set 'ExcelParserColumn' Attribute on properties</exception>
        private static T GetItem<T>(DataRow dr, string[] columnNames)
        {
            var properties = typeof(T).GetProperties();
            var classInstance = Activator.CreateInstance<T>();

            var columnPro = properties.Where(i => i.GetCustomAttributes(false)
                            .OfType<ExcelParserColumn>().FirstOrDefault() != null)
                            .GroupBy(i => i.GetCustomAttributes(false)
                            .OfType<ExcelParserColumn>().FirstOrDefault()
                            ?.ExcelColumn)
                            .ToDictionary(i => i.Key, k => k.FirstOrDefault());

            if (columnPro == null || columnPro.Count == 0)
                throw new Exception("Please set 'ExcelParserColumn' Attribute on properties");

            columnPro.Keys.Where(i => columnNames.Contains(i) && !(dr[i] is DBNull)).ToList().ForEach(i =>
             columnPro[i].SetValue(classInstance, Convert.ChangeType(dr[i], columnPro[i].PropertyType), null));

            return classInstance;
        }

        /// <summary>
        /// Reads the excel.
        /// </summary>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <param name="excelStream">The excel stream.</param>
        /// <returns>DataTable.</returns>
        /// <exception cref="FileNotFoundException">Sheet not Found in Excel</exception>
        /// <exception cref="ApplicationException">Invalid file format</exception>
        /// <exception cref="Exception">Sheet not Found in Excel</exception>
        private static DataTable ReadExcel(string sheetName, int headerRowNumber, int dataRowStart, Stream excelStream)
        {
            var returnDataTable = new DataTable();
            try
            {
                using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(excelStream, false))
                {
                    var sheet = spreadsheetDocument.WorkbookPart.Workbook.Sheets.Cast<Sheet>().FirstOrDefault(i => i.Name == sheetName);

                    if (sheet == null)
                        throw new FileNotFoundException("Sheet not Found in Excel");

                    var worksheet = ((WorksheetPart)spreadsheetDocument.WorkbookPart.GetPartById(sheet.Id)).Worksheet;
                    var sharedStringTable = spreadsheetDocument.WorkbookPart.GetPartsOfType<SharedStringTablePart>().FirstOrDefault()?.SharedStringTable;
                    var cells = worksheet.Descendants<Cell>();
                    var rows = worksheet.Descendants<Row>().ToList();

                    if (sharedStringTable != null)
                    {
                        var cellIndexValue = sharedStringTable.ChildElements.Select((element, elementIndex) => new
                        {
                            Index = elementIndex,
                            Value = element.InnerText
                        }).ToDictionary(i => i.Index, k => k.Value);

                        var fromStartingCells = cells.Where(l =>
                            int.Parse(Regex.Match(l.CellReference, @"\d+").Value) >= dataRowStart &&
                            l.CellValue != null).ToList();

                        var cellInfo = fromStartingCells.
                            Select(i => new
                            {
                                rowNumber = int.Parse(Regex.Match(i.CellReference, @"\d+").Value),
                                columnNumber = Regex.Match(i.CellReference, "[A-Za-z]+").Value,
                                value = (i.DataType != null) ? cellIndexValue[int.Parse(i.InnerText)] : i.InnerText
                            }).ToList();

                        returnDataTable.Columns.AddRange(GetColumns(headerRowNumber, rows, cellIndexValue));

                        for (int i = headerRowNumber; i < rows.Count(); i++)
                        {
                            Debug.WriteLine($"Reading Row: {i}");
                            returnDataTable.Rows.Add(returnDataTable.NewRow());
                            // ProgressCallBack(i);
                        }

                        cellInfo.ForEach(item =>
                        {
                            returnDataTable.Rows[item.rowNumber - dataRowStart][item.columnNumber] = item.value;
                        });
                    }

                    returnDataTable.Columns.Cast<DataColumn>().ToList().ForEach(i => i.ColumnName = i.Caption.Trim());
                    return returnDataTable;
                }
            }
            catch (Exception)
            {
                throw new ApplicationException("Invalid file format");
            }
        }

        //public List<T> GeModelsFromExcel<T>(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2)
        //{
        //    throw new NotImplementedException();
        //}

        /// <summary>
        /// Ges the models from excel.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>List&lt;T&gt;.</returns>
        public List<T> GeModelsFromExcel<T>(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2)
        {
            return ConvertDataTable<T>(LoadTable(excelPath, sheetName, headerRowNumber, dataRowStart));
        }

        /// <summary>
        /// Gets the model from excel
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="columnNames">The column names.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>List&lt;T&gt;.</returns>
        public List<T> GetModelFromExcel<T>(string excelPath, string sheetName, List<string> columnNames, int headerRowNumber = 1, int dataRowStart = 2)
        {
            return ConvertDataTable<T>(LoadTableForImport(excelPath, sheetName, columnNames, headerRowNumber, dataRowStart));
        }

        /// <summary>
        /// DataTable load
        /// </summary>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="columnNames">The column names.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>DataTable.</returns>
        private static DataTable LoadTableForImport(string excelPath, string sheetName, List<string> columnNames, int headerRowNumber = 1, int dataRowStart = 2)
        {
            using (FileStream fs = new FileStream(excelPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                return ReadExcelForImport(sheetName, headerRowNumber, columnNames, dataRowStart, fs);
            }
        }

        /// <summary>
        /// Reading the excel data
        /// </summary>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="col">The col.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <param name="excelStream">The excel stream.</param>
        /// <returns>DataTable.</returns>
        /// <exception cref="FileNotFoundException">Sheet not Found in Excel</exception>
        /// <exception cref="Exception">Sheet not Found in Excel</exception>
        private static DataTable ReadExcelForImport(string sheetName, int headerRowNumber, List<string> col, int dataRowStart, Stream excelStream)
        {
            DataTable excelDataTable = new DataTable();

            var returnDataTable = new DataTable();
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(excelStream, false))
            {
                var sheet = spreadsheetDocument.WorkbookPart.Workbook.Sheets.Cast<Sheet>().FirstOrDefault(i => i.Name == sheetName);

                if (sheet == null)
                    throw new FileNotFoundException("Sheet not Found in Excel");

                var worksheets = ((WorksheetPart)spreadsheetDocument.WorkbookPart.GetPartById(sheet.Id)).Worksheet;
                var sharedStringTable = spreadsheetDocument.WorkbookPart.GetPartsOfType<SharedStringTablePart>().FirstOrDefault()?.SharedStringTable;
                var cells = worksheets.Descendants<Cell>();

                var rows = worksheets.Descendants<Row>().ToList();

                if (sharedStringTable != null)
                {
                    var cellIndexValue = sharedStringTable.ChildElements.Select((element, elementIndex) => new
                    {
                        Index = elementIndex,
                        Value = element.InnerText
                    }).ToDictionary(i => i.Index, k => k.Value);

                    var fromStartingCells = cells.Where(l =>
                        int.Parse(Regex.Match(l.CellReference, @"\d+").Value) >= dataRowStart &&
                        l.CellValue != null && (Regex.Match(l.CellReference, "[A-Za-z]+").Value.In(col))).ToList();

                    var cellInfo = fromStartingCells.
                        Select(i => new
                        {
                            rowNumber = int.Parse(Regex.Match(i.CellReference, @"\d+").Value),
                            columnNumber = Regex.Match(i.CellReference, "[A-Za-z]+").Value,
                            value = (i.DataType != null) ? cellIndexValue[int.Parse(i.InnerText)] : i.InnerText
                        }).ToList();

                    var columnData = new Dictionary<int, string>();
                    foreach (var item in cellIndexValue)
                    {
                        if (item.Key < col.Count)
                            columnData.Add(item.Key, item.Value);
                    }
                    returnDataTable.Columns.AddRange(GetColumns(headerRowNumber, rows, cellIndexValue));

                    foreach (DataColumn item in returnDataTable.Columns)
                    {
                        DataColumn newcol = new DataColumn();
                        if (item.ToString().In(col))
                        {
                            newcol.ColumnName = item.ColumnName;
                            newcol.Caption = item.Caption;
                            excelDataTable.Columns.Add(newcol);
                        }
                    }

                    if (cellInfo.Count > 0)
                    {
                        for (int i = headerRowNumber; i < rows.Count(); i++)
                        {
                            excelDataTable.Rows.Add(excelDataTable.NewRow());
                        }
                    }

                    cellInfo.ForEach(item =>
                    {
                        excelDataTable.Rows[item.rowNumber - dataRowStart][item.columnNumber] = item.value;
                    });

                    excelDataTable.Columns.Cast<DataColumn>().ToList().ForEach(i => i.ColumnName = i.Caption);
                }
                else
                {
                    if (rows != null && rows.Count > 0)
                    {
                        var cellHeaderValue = rows[0].ChildElements.Select((element, elementindex) => new
                        {
                            Index = elementindex,
                            Value = element.InnerText
                        }).ToDictionary(i => i.Index, k => k.Value);

                        foreach (var data in cellHeaderValue)
                        {
                            excelDataTable.Columns.Add(data.Value);
                        }

                        for (int j = 1; j < rows.Count; ++j)
                        {
                            var cellDataValues = rows[j].ChildElements.Select((element, elementindex) => new
                            {
                                Index = elementindex,
                                Value = element.InnerText
                            }).ToDictionary(i => i.Index, k => k.Value);

                            DataRow excelRow = excelDataTable.NewRow();

                            foreach (var data in cellDataValues)
                            {
                                excelRow[data.Key] = data.Value;
                            }
                            excelDataTable.Rows.Add(excelRow);
                        }
                    }
                }

                return excelDataTable;
            }
        }
    }

    /// <summary>
    /// Extension class
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    internal static class ExtensionClass
    {
        /// <summary>
        /// Ins the specified items.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="item">The item.</param>
        /// <param name="items">The items.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        /// <exception cref="ArgumentNullException">Data Error</exception>
        public static bool In<T>(this T item, List<T> items)
        {
            if (items == null)
                throw new ArgumentNullException("Data Error");

            return items.Contains(item);
        }
    }
}