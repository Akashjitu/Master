﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="OperationMode.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class OperationMode
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OperationMode
    {
        /// <summary>
        /// Gets or sets the operation mode identifier
        /// </summary>
        /// <value>The operation mode identifier.</value>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OperationModeID { get; set; }

        /// <summary>
        /// Gets or sets the operating mode parameter
        /// </summary>
        /// <value>The operating mode.</value>
        public string OperatingMode { get; set; }

        /// <summary>
        /// Gets or Sets the hourly production
        /// </summary>
        /// <value>The hourly production.</value>
        public string HourlyProduction { get; set; }

        /// <summary>
        /// Gets or sets the Start up date
        /// </summary>
        /// <value>The startup date.</value>
        public string StartupDate { get; set; }

        /// <summary>
        /// Gets or sets the Age
        /// </summary>
        /// <value>The age.</value>
        public string Age { get; set; }

        /// <summary>
        /// gets or sets the end of Life
        /// </summary>
        /// <value>The end of life.</value>
        public string EndOfLife { get; set; }

        /// <summary>
        /// Gets or Sets the Comments
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        [ForeignKey("IBProjectComponentId")]
        public int NodeID { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        public virtual IBProjectComponent IBProjectComponent { get; set; }

        /// <summary>
        /// Gets or sets the  project Id.
        /// </summary>
        /// <value>The project.</value>
        [ForeignKey("ProjectID")]
        public Project Project { get; set; }
    }
}