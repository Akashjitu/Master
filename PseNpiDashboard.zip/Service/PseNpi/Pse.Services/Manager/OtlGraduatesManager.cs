﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pse.Data.Models;
using Pse.Services.DataBaseAccessObject.Loader;

namespace Pse.Services.Manager
{
    public class OtlGraduatesManager : IOtlGraduatesManager
    {

       private readonly IOtlGraduatesDataAccess _dataAcces;
        public OtlGraduatesManager(IOtlGraduatesDataAccess dataAcces)
        {
            _dataAcces = dataAcces;
        }

        public OtlGraduate AddOtlGraduate(OtlGraduate otlGraduate)
        {
            return _dataAcces.AddOtlGraduate(otlGraduate);
        }

        public List<OtlGraduate> LoadAllOtlGraduates()
        {
            return _dataAcces.LoadAllOtlGraduates();
        }

        public List<OtlGraduate> LoadGraduatesByCreationDate(DateTime creationDate)
        {
            return _dataAcces.LoadGraduatesByCreationDate(creationDate);
        }



        public List<OtlGraduate> LoadOtlGraduatesById(int Id)
        {
            return _dataAcces.LoadOtlGraduatesById(Id);
        }

        public List<OtlGraduate> LoadOtlGraduatesByKeyCode(string keycode)
        {
            return _dataAcces.LoadOtlGraduatesByKeyCode(keycode);
        }

        public OtlGraduate UpdateOtlGraduate(OtlGraduate otlGraduate)
        {
            return _dataAcces.UpdateOtlGraduate( otlGraduate);
        }

        public List<OtlGraduate> LoadLatestOtlGraduates()
        {
            return _dataAcces.LoadLatestOtlGraduates();
        }
    }
}
