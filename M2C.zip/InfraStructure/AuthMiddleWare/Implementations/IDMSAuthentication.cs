﻿// ***********************************************************************
// Assembly         : AuthMiddleWare
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-20-2020
// ***********************************************************************
// <copyright file="IDMSAuthentication.cs" company="Schneider Electric">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AuthMiddleWare.Contracts;
using Newtonsoft.Json.Linq;
using RestClientServices.Contracts;
using RestClientServices.Services;
using System.Collections.Generic;

namespace AuthMiddleWare.Implementations
{
    /// <summary>
    /// IDMS based Authentication
    /// </summary>
    /// <seealso cref="AuthMiddleWare.Contracts.IAuthentication" />
    public class IDMSAuthentication : IAuthentication
    {
        /// <summary>
        /// The rest services factory
        /// </summary>
        private readonly IRestServicesFactory restServicesFactory;
        /// <summary>
        /// The rest client service
        /// </summary>
        private IRestClientService restClientService;

        /// <summary>
        /// Initializes a new instance of the <see cref="IDMSAuthentication" /> class.
        /// </summary>
        /// <param name="restServicesFactory">The rest services factory.</param>
        public IDMSAuthentication(IRestServicesFactory restServicesFactory)
        {
            this.restServicesFactory = restServicesFactory;

            this.restClientService = this.restServicesFactory.GetRestClientService<IAuthService>(RestServiceTypes.AUTH_SERVICE);
        }

        /// <summary>
        /// Gets the access token.
        /// </summary>
        /// <param name="AuthCode">The authentication code.</param>
        /// <returns>System.String.</returns>
        public string getAccessToken(string AuthCode)
        {
            //Construct Request for getting token
            IRestServiceRequest request = new RestServiceRequest() { ResourcePath = "Token" };
            request.HeaderParams.Add("authCode", AuthCode);

            string response = this.restClientService.Execute<string>(request);

            if (!string.IsNullOrEmpty(response))
            {
                return response;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Gets the login URL.
        /// </summary>
        /// <returns>System.String.</returns>
        public string GetLoginPath()
        {
            IRestServiceRequest request = new RestServiceRequest() { ResourcePath = "LoginUrl" };

            return this.restClientService.Execute<string>(request);
        }

        /// <summary>
        /// Alls the tokens.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns>IEnumerable&lt;JToken&gt;.</returns>
        private IEnumerable<JToken> AllTokens(JObject obj)
        {
            var toSearch = new Stack<JToken>(obj.Children());
            while (toSearch.Count > 0)
            {
                var inspected = toSearch.Pop();
                yield return inspected;
                foreach (var child in inspected)
                {
                    toSearch.Push(child);
                }
            }
        }
    }
}