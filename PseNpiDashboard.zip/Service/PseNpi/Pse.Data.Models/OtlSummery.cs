﻿using Oracle.Data.Access;
using Pse.Data.Models.Attributes;
using System;

namespace Pse.Data.Models
{
    public class OtlSummery
    {
        [Columns("P_KEY_CODE")]
        public string KeyCode { get; set; }

        [Columns("P_PROGRAM_NAME")]
        public string ProgramName { get; set; }

        [Columns("P_PRODUCT_SBU")]
        public string ProductSbu { get; set; }

        [Columns("P_HMR_BASELINE_DATE")]
        public DateTime HmrBaseline { get; set; }

        [Columns("P_RTY")]
        public string Rty { get; set; }

        [Columns("P_UPC")]
        public string Upc { get; set; }

        [Columns("P_ESCAPES")]
        public string Escapes { get; set; }

        [Columns("P_PPAP")]
        public string Ppap { get; set; }

        [Columns("P_PRR")]
        public string Prr { get; set; }

        [Columns("P_MRA")]
        public string Mra { get; set; }

        [Columns("P_OTL_HEALTH")]
        public string OtlHealth { get; set; }

        [ExportColumn(true)]
        [Columns("P_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("P_CREATE_BY")]
        public string CreatedBy { get; set; }

        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("P_ACTIVE")]
        public string Active { get; set; }

        [ExportColumn(true)]
        [Columns("P_UPDATED_DATE")]
        public DateTime UpdatedDate { get; set; }

        [ExportColumn(true)]
        [Columns("P_UPDATED_BY_DASHBOARD")]
        public bool UpdatedByDashBoard { get; set; }

        [ExportColumn(true)]
        [Columns("P_ID")]
        public int Id { get; set; }
    }
}