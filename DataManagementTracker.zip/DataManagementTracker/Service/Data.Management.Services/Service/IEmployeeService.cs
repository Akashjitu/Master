﻿using Data.Management.Data.Models;
using System.Collections.Generic;

namespace Data.Management.Services.Service
{
    public interface IEmployeeService
    {
        EmployeeInfo GetEmployeeInfo(string id);
        List<EmployeeInfo> GetEmployeeInfo(string value, EmployeeSearchType type);

        EmployeeInfo UpdateEmployeeAccess(EmployeeInfo employeeInfo);

        EmployeeInfo AddEmployeeAccess(EmployeeInfo employeeInfo);

        List<EmployeeInfo> GetAllEmployeeAccess(string eid);
    }
}