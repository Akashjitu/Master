﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ChartParameterEvent.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using M2C.Business.Models.CommonChartParameters;
using Prism.Events;

namespace M2C.Desktop.Modules.Charts.Events
{
    /// <summary>
    /// event for Chart Parameter
    /// </summary>
    public class ChartParameterEvent : PubSubEvent<ChartParameter>
    {
    }
}