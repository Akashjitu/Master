﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="LoadingWindowViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Desktop.App.ViewModels
{
    /// <summary>
    /// Class LoadingWindowViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class LoadingWindowViewModel : BindableBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LoadingWindowViewModel" /> class.
        /// </summary>
        public LoadingWindowViewModel()
        {

        }


    }
}
