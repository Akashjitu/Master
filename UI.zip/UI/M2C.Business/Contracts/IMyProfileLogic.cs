﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IMyProfileLogic.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;

namespace M2C.Business.Contracts
{
    /// <summary>
    /// Interface IMyProfileLogic
    /// </summary>
    public interface IMyProfileLogic
    {
        /// <summary>
        /// Gets the profile.
        /// </summary>
        /// <returns>ProfileModel.</returns>
        ProfileModel GetProfile();
        /// <summary>
        /// Saves the profile.
        /// </summary>
        /// <param name="profile">The profile.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool SaveProfile(ProfileModel profile);
        /// <summary>
        /// Deletes the profile.
        /// </summary>
        /// <param name="profileId">The profile identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool DeleteProfile(int profileId);
    }
}