﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="CompetitorControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Mvvm;
using System.Collections.Generic;
using M2C.Business.GlobalFields;

namespace M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls
{
    /// <summary>
    /// ViewModel for CompetitorControl.
    /// Provide Binding Data and Event
    /// </summary>
    public class CompetitorControlViewModel : BindableBase, ICommonInventory
    {
        #region Class fields

        /// <summary>
        /// The common inventory common reference
        /// </summary>
        private readonly ICommonInventoryReference _commonInventoryCommonReference;
        /// <summary>
        /// The brands
        /// </summary>
        private List<BrandModel> _brands;
        /// <summary>
        /// The device type model
        /// </summary>
        private DeviceTypeModel _deviceTypeModel;
        /// <summary>
        /// The device types
        /// </summary>
        private List<DeviceTypeModel> _deviceTypes;
        /// <summary>
        /// The products
        /// </summary>
        private List<ProductModel> _products;
        /// <summary>
        /// The ranges
        /// </summary>
        private List<RangeModel> _ranges;
        /// <summary>
        /// The selected brand
        /// </summary>
        private BrandModel _selectedBrand;
        /// <summary>
        /// The selected product
        /// </summary>
        private ProductModel _selectedProduct;
        /// <summary>
        /// The selected range models
        /// </summary>
        private RangeModel _selectedRangeModels;

        #endregion Class fields

        /// <summary>
        /// Initialize Class fields
        /// </summary>
        /// <param name="commonInventoryCommonReference">The common inventory common reference.</param>
        public CompetitorControlViewModel(ICommonInventoryReference commonInventoryCommonReference)
        {
            _commonInventoryCommonReference = commonInventoryCommonReference;
            OnKeyUpPChangeCommand = new DelegateCommand<string>(OnKeyUpPChange);
            OnSelectionChangeCommand = new DelegateCommand<string>(OnSelectionChange);
            Brands = _commonInventoryCommonReference.GetBrandModels("S",false);
        }

        #region Event and Commands

        /// <summary>
        /// Event for All Combo box Selection Change
        /// </summary>
        /// <value>The on selection change command.</value>
        public DelegateCommand<string> OnSelectionChangeCommand { get; set; }

        /// <summary>
        /// event When user Start typing
        /// </summary>
        /// <value>The on key up p change command.</value>
        public DelegateCommand<string> OnKeyUpPChangeCommand { get; set; }

        #endregion Event and Commands

        #region Properties

        /// <summary>
        /// All Brands. bind with Brand Combo box.
        /// </summary>
        /// <value>The brands.</value>
        public List<BrandModel> Brands
        {
            get => _brands;
            set => SetProperty(ref _brands, value);
        }

        /// <summary>
        /// Product Based on the Selection. bind with Reference combo box.
        /// </summary>
        /// <value>The products.</value>
        public List<ProductModel> Products
        {
            get => _products;
            set => SetProperty(ref _products, value);
        }

        /// <summary>
        /// Get Device Type Based on Brand  and  range Selection.
        /// </summary>
        /// <value>The device types.</value>
        public List<DeviceTypeModel> DeviceTypes
        {
            get => _deviceTypes;
            set => SetProperty(ref _deviceTypes, value);
        }

        /// <summary>
        /// Ger range based on Brand selection
        /// </summary>
        /// <value>The ranges.</value>
        public List<RangeModel> Ranges
        {
            get => _ranges;
            set => SetProperty(ref _ranges, value);
        }

        /// <summary>
        /// Get Selected range from range combo box Selection.
        /// </summary>
        /// <value>The selected range models.</value>
        public RangeModel SelectedRangeModels
        {
            get => _selectedRangeModels;
            set => SetProperty(ref _selectedRangeModels, value);
        }

        /// <summary>
        /// Get Selected Device type based on Device type combo box Selection
        /// </summary>
        /// <value>The type of the selected device.</value>
        public DeviceTypeModel SelectedDeviceType
        {
            get => _deviceTypeModel;
            set => SetProperty(ref _deviceTypeModel, value);
        }

        /// <summary>
        /// Get Selected Brand based on Brand combo box Selection
        /// </summary>
        /// <value>The selected brand.</value>
        public BrandModel SelectedBrand
        {
            get => _selectedBrand;
            set => SetProperty(ref _selectedBrand, value);
        }

        /// <summary>
        /// Get Selected  Product based on Reference Combo box Selection
        /// </summary>
        /// <value>The selected product.</value>
        public ProductModel SelectedProduct
        {
            get => _selectedProduct;
            set => SetProperty(ref _selectedProduct, value);
        }

        /// <summary>
        /// Get Collection of Selected  Product based if multiple selected
        /// </summary>
        /// <value>The selected products.</value>
        public List<ProductModel> SelectedProducts => SelectedProduct != null
            ? new List<ProductModel> { SelectedProduct }
            : new List<ProductModel>();

        #endregion Properties

        /// <summary>
        /// Event Handler when user start typing
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        private void OnKeyUpPChange(string identifier)
        {
        }

        /// <summary>
        /// event Handler based on thr user combo box selection change
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        private void OnSelectionChange(string identifier)
        {
            if (string.IsNullOrEmpty(identifier))
                return;
            switch (identifier.ToUpper())
            {
                case CollectionConstant.Range:
                    if (SelectedDeviceType == null || SelectedBrand == null || SelectedRangeModels == null)
                        return;
                    SelectedProduct = null;
                    Products = _commonInventoryCommonReference.GetProducts(SelectedBrand.Id, SelectedDeviceType.Id,
                        SelectedRangeModels.Id);
                    break;

                case CollectionConstant.DeviceType:
                    if (SelectedDeviceType == null || SelectedBrand == null)
                        return;
                    Products?.Clear();
                    Ranges?.Clear();
                    SelectedProduct = null;
                    SelectedRangeModels = null;
                    Ranges = _commonInventoryCommonReference.GetRangeByBrandAndDeviceTypeIds(SelectedBrand.Id,
                        SelectedDeviceType.Id);
                    break;

                case CollectionConstant.Brand:
                    if (SelectedBrand == null)
                        return;
                    Products?.Clear();
                    Ranges?.Clear();
                    SelectedProduct = null;
                    SelectedRangeModels = null;
                    SelectedDeviceType = null;
                    DeviceTypes =
                        _commonInventoryCommonReference.GetDeviceTypesByBrandIdAndNodeType(SelectedBrand.Id,
                            GlobalFiled.SelectedNodeType);
                    break;
            }
        }
    }
}