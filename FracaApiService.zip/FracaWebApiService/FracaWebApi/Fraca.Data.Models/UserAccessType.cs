﻿namespace Fraca.Data.Models
{
   public enum UserAccessType
    {
        ReadOnly=0,
        Edit=1,
        Complete = 2,
        New =3
    }
}
