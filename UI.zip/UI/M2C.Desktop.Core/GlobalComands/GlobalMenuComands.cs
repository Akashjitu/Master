﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="GlobalMenuComands.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Commands;

namespace M2C.Desktop.Core.GlobalComands
{
    /// <summary>
    /// Global commands across all modules
    /// These commands follow facade pattern
    /// </summary>
    public interface IGlobalMenuComands
    {
        /// <summary>
        /// Gets the save command.
        /// </summary>
        /// <value>The save command.</value>
        CompositeCommand SaveCommand { get; }
        /// <summary>
        /// Creates new projectcommand.
        /// </summary>
        /// <value>The new project command.</value>
        CompositeCommand NewProjectCommand { get; }
        /// <summary>
        /// Gets the export project command.
        /// </summary>
        /// <value>The export project command.</value>
        CompositeCommand ExportProjectCommand { get; }

        /// <summary>
        /// Gets the open project command.
        /// </summary>
        /// <value>The open project command.</value>
        CompositeCommand OpenProjectCommand { get; }

        /// <summary>
        /// Gets the project synchronize command.
        /// </summary>
        /// <value>The project synchronize command.</value>
        CompositeCommand ProjectSyncCommand { get; }
    }

    /// <summary>
    /// Implementation for IGlobalMenuComands
    /// </summary>
    /// <seealso cref="M2C.Desktop.Core.GlobalComands.IGlobalMenuComands" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class GlobalMenuComands : IGlobalMenuComands
    {
        /// <summary>
        /// Gets the save command.
        /// </summary>
        /// <value>The save command.</value>
        public CompositeCommand SaveCommand { get; } = new CompositeCommand();

        /// <summary>
        /// Creates new projectcommand.
        /// </summary>
        /// <value>The new project command.</value>
        public CompositeCommand NewProjectCommand { get; } = new CompositeCommand();

        /// <summary>
        /// Gets the export project command.
        /// </summary>
        /// <value>The export project command.</value>
        public CompositeCommand ExportProjectCommand { get; } = new CompositeCommand();

        /// <summary>
        /// Gets the open project command.
        /// </summary>
        /// <value>The open project command.</value>
        public CompositeCommand OpenProjectCommand { get; } = new CompositeCommand();

        /// <summary>
        /// Gets the project synchronize command.
        /// </summary>
        /// <value>The project synchronize command.</value>
        public CompositeCommand ProjectSyncCommand { get; } = new CompositeCommand();
    }
}