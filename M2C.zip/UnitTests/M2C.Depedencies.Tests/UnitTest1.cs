using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace M2C.Depedencies.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
