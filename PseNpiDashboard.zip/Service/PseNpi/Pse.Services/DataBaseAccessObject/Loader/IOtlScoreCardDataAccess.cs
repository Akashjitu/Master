﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pse.Services.DataBaseAccessObject.Loader
{
 public interface IOtlScoreCardDataAccess
    {
        List<OtlScoreCard> LoadAllOtlScoreCards();

        List<OtlScoreCard> LoadScoreCardByCreationDate(DateTime creationDate);


        List<OtlScoreCard> LoadOtlScoreCardByBaseLineDate(DateTime baselineDate);


        List<OtlScoreCard> LoadOtlScoreCardByKeyCode(string keycode);

        List<OtlScoreCard> LoadLatestOtlScoreCard(string keycode);


        List<OtlScoreCard> LoadOtlScoreCardById(int Id);

        OtlScoreCard AddOtlScoreCard(OtlScoreCard otlScoreCard);

        OtlScoreCard UpdateOtlScoreCard(OtlScoreCard otlScoreCard);
    }
}
