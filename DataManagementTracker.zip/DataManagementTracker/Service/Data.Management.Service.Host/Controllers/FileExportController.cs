﻿using Data.Management.Service.Host.ExceptionFilters;
using Data.Management.Services;
using Data.Management.Services.Exports;
using DataManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Http;

namespace Data.Management.Service.Host.Controllers
{
    [LogExceptionFilterAttribute]
    public class FileExportController : ApiController
    {
        private  readonly IDataManagementServices _dataManagementServices;
        private readonly ISimpleExport _export;

        public FileExportController(IDataManagementServices dataManagementServices, ISimpleExport export)
        {
            _dataManagementServices = dataManagementServices;
            _export = export;


        }

        [HttpGet]
        public HttpResponseMessage ExportDataManagementReport()
        {

            var dataManagementTracks = _dataManagementServices.LoadAllDataManagements();
           var exort= _export.Export<DataManagementTrack>(dataManagementTracks, "Customer Approval Tracker", 0);

            var dataStream = new MemoryStream(exort);
            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");
            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "CustomerApprovalTracker_" + DateTime.Today + ".xlsx";
            return response;
        }

        [HttpPost]
        
        public HttpResponseMessage ExportFilterDataManagementReport(DataManagementTrack dataManagementTrack)
        {
            var data = _dataManagementServices.LoadAllDataManagements();

            if (dataManagementTrack.CustomerId > 0)
                data = data.Where(i => i.CustomerId == dataManagementTrack.CustomerId).ToList();

            if (!string.IsNullOrEmpty(dataManagementTrack.Cm))
                data = data.Where(i => i.Cm == dataManagementTrack.Cm).ToList();

            if (!string.IsNullOrEmpty(dataManagementTrack.Requestor))
                data = data.Where(i => i.Requestor == dataManagementTrack.Requestor).ToList();

            var exort = _export.Export<DataManagementTrack>(data, "Customer Approval Tracker", 0);


            var dataStream = new MemoryStream(exort);
            HttpResponseMessage response;
            response = Request.CreateResponse(HttpStatusCode.OK);
            MediaTypeHeaderValue mediaType = new MediaTypeHeaderValue("application/octet-stream");
            response.Content = new StreamContent(dataStream);
            response.Content.Headers.ContentType = mediaType;
            response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            response.Content.Headers.ContentDisposition.FileName = "CustomerApprovalTracker_" + DateTime.Today + ".xlsx";
            return response;
        }
    }
}
