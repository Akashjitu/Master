﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-08-2020
// ***********************************************************************
// <copyright file="CustomerDocumentsViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.UIModels;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// This use for Add or Update Customer Documents based on Node Selection
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class CustomerDocumentsViewModel : BindableBase
    {
        /// <summary>
        /// use for hide and show the Open button based on Selection
        /// </summary>
        /// <value><c>true</c> if this instance is BTN delete visible; otherwise, <c>false</c>.</value>
        public bool IsBtnOpenVisible
        {
            get => _isBtnOpenVisible;
            set => SetProperty(ref _isBtnOpenVisible, value);
        }

        /// <summary>
        /// use for hide and show the Delete button based on Selection
        /// </summary>
        /// <value><c>true</c> if this instance is BTN delete visible; otherwise, <c>false</c>.</value>
        public bool IsBtnDeleteVisible
        {
            get => _isBtnDeleteVisible;
            set => SetProperty(ref _isBtnDeleteVisible, value);
        }

        /// <summary>
        /// use for hide and show the Add button based on Selection
        /// </summary>
        /// <value><c>true</c> if this instance is BTN add visible; otherwise, <c>false</c>.</value>
        public bool IsBtnAddVisible
        {
            get => _isBtnAddVisible;
            set => SetProperty(ref _isBtnAddVisible, value);
        }

        /// <summary>
        /// Provide action to  buttons.
        /// Like Add. Open, delete
        /// </summary>
        /// <value>The action command.</value>
        public DelegateCommand<string> ActionCommand { get; set; }

        /// <summary>
        /// Provide action to Container buttons.
        /// Like Edit. view Info, delete
        /// </summary>
        /// <value>The action command.</value>
        public DelegateCommand<object> MouseActionCommand { get; set; }

        /// <summary>
        /// Current Selected node.
        /// </summary>
        private INode _selectedNode;

        /// <summary>
        /// The Collection of Customer Documents
        /// </summary>
        private ObservableCollection<CustomerDocument> _customerDocuments;

        /// <summary>
        /// The dialog service
        /// </summary>
        private IDialogService _dialogService;
        /// <summary>
        /// The is BTN delete visible
        /// </summary>
        private bool _isBtnDeleteVisible;
        /// <summary>
        /// The is BTN add visible
        /// </summary>
        private bool _isBtnAddVisible;
        /// <summary>
        /// The is BTN open visible
        /// </summary>
        private bool _isBtnOpenVisible;
        /// <summary>
        /// The grid column descriptions
        /// </summary>
        private ObservableCollection<GridColumnDescription> _gridColumnDescriptions;

        /// <summary>
        /// The Collection of Customer Documents
        /// </summary>
        /// <value>The customer documents.</value>
        public ObservableCollection<CustomerDocument> CustomerDocuments
        {
            get => _customerDocuments;
            set => SetProperty(ref _customerDocuments, value);
        }

        /// <summary>
        /// Gets or sets the grid column descriptions.
        /// </summary>
        /// <value>The grid column descriptions.</value>
        public ObservableCollection<GridColumnDescription> GridColumnDescriptions
        {
            get => _gridColumnDescriptions;
            set => SetProperty(ref _gridColumnDescriptions, value);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerDocumentsViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="dialogService">The dialog service.</param>
        public CustomerDocumentsViewModel(IEventAggregator eventAggregator, IDialogService dialogService)
        {
            GridColumnDescriptions = new ObservableCollection<GridColumnDescription>();
            ActionCommand = new DelegateCommand<string>(OnButtonAction);
            MouseActionCommand = new DelegateCommand<object>(OnMouseAction);
            CustomerDocuments = new ObservableCollection<CustomerDocument>();
            _dialogService = dialogService;
            eventAggregator.GetEvent<IBTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            eventAggregator.GetEvent<TRTreeViewChangeEvent>().Subscribe(OnTrNodeSelectionChanged);
            _isBtnAddVisible = true;
            var columns = CustomerDocumentColumnsProvide.GetCustomerDocumentColumns(out var contextItems);
            GridColumnDescriptions.AddRange(columns);
        }

        /// <summary>
        /// Called when [tr node selection changed].
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnTrNodeSelectionChanged(INode node)
        {
            _selectedNode = node;
            BindSelectedNode();
        }

        /// <summary>
        /// On Node Selection Change
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnNodeSelectionChanged(INode node)
        {
            _selectedNode = node;
            BindSelectedNode();
            RefreshCustomerDocuments();
        }

        /// <summary>
        /// Binds the selected node.
        /// </summary>
        private void BindSelectedNode()
        {
            if (_selectedNode == null)
                return;
            if (CustomerDocuments == null)
                return;
            CustomerDocuments.ToList().ForEach(i => i.PropertyChanged -= OnCustomerDocumentPropertyChanged);
            CustomerDocuments.Clear();
            CustomerDocuments.AddRange(_selectedNode.CustomerDocuments);
            CustomerDocuments.ToList().ForEach(i => i.PropertyChanged += OnCustomerDocumentPropertyChanged);
        }

        /// <summary>
        /// Handles the <see cref="E:CustomerDocumentPropertyChanged" /> event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.ComponentModel.PropertyChangedEventArgs" /> instance containing the event data.</param>
        private void OnCustomerDocumentPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            IsBtnDeleteVisible = _selectedNode.CustomerDocuments.Any(i => i.IsSelected);
            IsBtnOpenVisible = _selectedNode.CustomerDocuments.Count(i => i.IsSelected) == 1;
            IsBtnAddVisible = !(IsBtnOpenVisible || IsBtnDeleteVisible);
        }

        /// <summary>
        /// Remove Selected Inventories
        /// </summary>
        /// <param name="customerDocuments">The customer documents.</param>
        private void RemoveDocument(List<CustomerDocument> customerDocuments)
        {
            if (customerDocuments == null || !customerDocuments.Any())
                return;
            foreach (var document in customerDocuments)
            {
                _selectedNode.CustomerDocuments.Remove(document);
                CustomerDocuments.Remove(document);
            }
        }

        /// <summary>
        /// Add Selected Document
        /// </summary>
        private void AddDocument()
        {
            _dialogService.ShowDialog(CollectionConstant.CustomerDocumentFileDialog, null, dialogResult =>
            {
                if (dialogResult.Result != ButtonResult.OK)
                    return;

                if (!dialogResult.Parameters.TryGetValue(CollectionConstant.Add,
                    out CustomerDocument customerDocument)) return;

                customerDocument.PropertyChanged += OnCustomerDocumentPropertyChanged;
                _selectedNode.CustomerDocuments.Add(customerDocument);
                CustomerDocuments.Add(customerDocument);
            });
        }

        /// <summary>
        /// Event Handler for container action on mouse button .
        /// </summary>
        /// <param name="action">The action.</param>
        private void OnMouseAction(object action)
        {
            var customerDocuments = new List<CustomerDocument>();
            if (!(action is RoutedEventArgs mouseEvent)) return;
            if (!(mouseEvent.Source is System.Windows.Controls.MenuItem menuItem)) return;
            if (!(menuItem.Tag is FocusAction focusAction)) return;
            if (focusAction.CustomerDocument == null) return;
            customerDocuments.Add(focusAction.CustomerDocument);//Added focus Customer Document

            if (!string.IsNullOrEmpty(focusAction.Action) &&
                focusAction.Action.ToUpper() == CollectionConstant.Delete)
            {
                var selectedItems = _selectedNode.CustomerDocuments.ToList().Where(i => i.IsSelected).ToList();// Get selected Customer Documents
                if (selectedItems.Count > 0)
                {
                    customerDocuments.Clear();
                    customerDocuments.AddRange(selectedItems);
                }
            }
            OnAction(focusAction.Action, customerDocuments);
        }

        /// <summary>
        /// Event Handler for container action button .
        /// </summary>
        /// <param name="actionType">Type of the action.</param>
        private void OnButtonAction(string actionType)
        {
            if (_selectedNode == null)
                return;
            var selectedItems = _selectedNode.CustomerDocuments.ToList().Where(i => i.IsSelected).ToList();
            OnAction(actionType, selectedItems);
        }

        /// <summary>
        /// Use for On grid  Action button
        /// </summary>
        /// <param name="actionType">Type of the action.</param>
        /// <param name="customerDocuments">The customer documents.</param>
        private void OnAction(string actionType, List<CustomerDocument> customerDocuments)
        {
            if (string.IsNullOrEmpty(actionType))
                return;
            switch (actionType)
            {
                case "Delete":
                    if (ShowMessages(customerDocuments.Select(i => i.Name).ToList()))
                        RemoveDocument(customerDocuments);
                    break;

                case CollectionConstant.Add:
                    AddDocument();
                    break;

                case CollectionConstant.Open:
                    if (customerDocuments == null || customerDocuments.Count == 0)
                        return;
                    if (customerDocuments.Count == 1)
                        if (File.Exists(customerDocuments[0].FilePath))
                            System.Diagnostics.Process.Start(customerDocuments[0].FilePath);
                        else
                            MessageBox.Show(CollectionConstant.MessageFileNotExist);
                    else
                        MessageBox.Show(CollectionConstant.MessageSelectDocument);
                    break;
            }
            RefreshCustomerDocuments();
        }

        /// <summary>
        /// Show Message Box Dialog
        /// </summary>
        /// <param name="messages">The messages.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ShowMessages(IReadOnlyCollection<string> messages)
        {
            var returnValue = false;
            if (messages == null || !messages.Any())
                return false;

            var parameters = new DialogParameters
            {
                {CollectionConstant.MessageLabel,string.Format(CollectionConstant.MessageDeleteDocument, messages.Count())},
                {CollectionConstant.MessageCollection, messages},
                {CollectionConstant.Title, CollectionConstant.DeleteDocuments},
                {CollectionConstant.IsCancelVisible, true}// set if require Cancel button
            };

            _dialogService.ShowDialog("CustomMessageCollectionDialog", parameters,
                result => returnValue = result.Result == ButtonResult.OK);
            return returnValue;
        }

        /// <summary>
        /// Refreshes the Customer Documents.
        /// </summary>
        private void RefreshCustomerDocuments()
        {
            CollectionViewSource.GetDefaultView(CustomerDocuments).Refresh();
            OnCustomerDocumentPropertyChanged(null, null);
        }
    }
}