﻿// ***********************************************************************
// Assembly         : Schneider.M2C.OpenExcel.Parser
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IExcelParser.cs" company="Schneider.M2C.OpenExcel.Parser">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace Schneider.M2C.OpenExcel.Parser
{
    /// <summary>
    /// Interface IExcelParser
    /// </summary>
    public interface IExcelParser
    {
        /// <summary>
        /// Ges the models from excel.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <param name="callBack">The call back.</param>
        /// <returns>List&lt;T&gt;.</returns>
        List<T> GeModelsFromExcel<T>(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2, Action<int> callBack = null);

        /// <summary>
        /// Gets the data table from excel.
        /// </summary>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>DataTable.</returns>
        DataTable GetDataTableFromExcel(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2);

        /// <summary>
        /// Gets the data table from excel.
        /// </summary>
        /// <param name="excelFileStream">The excel file stream.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>DataTable.</returns>
        DataTable GetDataTableFromExcel(Stream excelFileStream, string sheetName, int headerRowNumber = 1, int dataRowStart = 2);

        /// <summary>
        /// Ges the models from excel.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelFileStream">The excel file stream.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>List&lt;T&gt;.</returns>
        List<T> GeModelsFromExcel<T>(Stream excelFileStream, string sheetName, int headerRowNumber = 1, int dataRowStart = 2);

        /// <summary>
        /// Ges the models from excel.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>List&lt;T&gt;.</returns>
        List<T> GeModelsFromExcel<T>(string excelPath, string sheetName, int headerRowNumber = 1, int dataRowStart = 2);

        /// <summary>
        /// Gets the model from Excel
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelPath">The excel path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="columnNames">The column names.</param>
        /// <param name="headerRowNumber">The header row number.</param>
        /// <param name="dataRowStart">The data row start.</param>
        /// <returns>List&lt;T&gt;.</returns>
        List<T> GetModelFromExcel<T>(string excelPath, string sheetName, List<string> columnNames, int headerRowNumber = 1, int dataRowStart = 2);
    }
}