﻿using M2C.Business.Contracts;
using M2C.Desktop.Modules.CollectData.Test.MOCK;
using M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace M2C.Desktop.Modules.CollectData.Test.ViewModels.InventoryControls
{
    [TestClass]
    public class CompetitorControlViewModelTest
    {
        private CompetitorControlViewModel _competitorControlViewModel;
        private ICommonInventoryReference _commonInventoryReference;

        [TestInitialize]
        public void Setup()
        {
            _commonInventoryReference = Substitute.For<ICommonInventoryReference>();
            _commonInventoryReference.GetBrandModels(Arg.Any<string>()).Returns(MockProvider.GetBrands());
            _commonInventoryReference.GetProducts(Arg.Any<int>(), Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetProducts()); ;
            _commonInventoryReference.GetRangeByBrandAndDeviceTypeIds(Arg.Any<int>(), Arg.Any<int>()).Returns(MockProvider.GetRanges()); ;
            _commonInventoryReference.GetDeviceTypesByBrand(Arg.Any<int>()).Returns(MockProvider.GetDeviceTypes()); ;
          
            _competitorControlViewModel = new CompetitorControlViewModel(_commonInventoryReference);
          
        }

        [TestMethod]
        public void ShouldReturnProductBasedOnSelection()
        {
            _competitorControlViewModel.OnKeyUpPChangeCommand.Execute("Sc");
            _competitorControlViewModel.SelectedBrand = MockProvider.GetBrands()[0];

            _competitorControlViewModel.OnSelectionChangeCommand.Execute("BRAND");
            _competitorControlViewModel.SelectedDeviceType = MockProvider.GetDeviceTypes()[0];

            _competitorControlViewModel.OnSelectionChangeCommand.Execute("DEVICE-TYPE");
            _competitorControlViewModel.SelectedRangeModels = MockProvider.GetRanges()[0];

            _competitorControlViewModel.OnSelectionChangeCommand.Execute("RANGE");
            _competitorControlViewModel.SelectedProduct = MockProvider.GetProducts()[0];


            Assert.IsNotNull(_competitorControlViewModel.OnKeyUpPChangeCommand);
            Assert.IsNotNull(_competitorControlViewModel.OnSelectionChangeCommand);
            Assert.IsNotNull(_competitorControlViewModel.SelectedBrand);
            Assert.IsNotNull(_competitorControlViewModel.SelectedDeviceType);
            Assert.IsNotNull(_competitorControlViewModel.SelectedRangeModels);
            Assert.IsNotNull(_competitorControlViewModel.SelectedProduct);
            Assert.IsTrue(_competitorControlViewModel.Products!=null && _competitorControlViewModel.Products.Count>0);
            Assert.IsTrue(_competitorControlViewModel.DeviceTypes != null && _competitorControlViewModel.DeviceTypes.Count > 0);
            Assert.IsTrue(_competitorControlViewModel.Brands != null && _competitorControlViewModel.Brands.Count > 0);
            Assert.IsTrue(_competitorControlViewModel.Ranges != null && _competitorControlViewModel.Ranges.Count > 0);
        }

    }
}