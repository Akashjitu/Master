﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 01-21-2020
// ***********************************************************************
// <copyright file="TRBaseNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Newtonsoft.Json;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;

namespace M2C.Business.Models.Project.TRComponents
{
    /// <summary>
    /// Technical Resource Node Base class
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class TRBaseNode : BindableBase
    {
        /// <summary>
        /// The identifier
        /// </summary>
        private int id;
        /// <summary>
        /// The name
        /// </summary>
        private string name;
        /// <summary>
        /// The node type
        /// </summary>
        private TRNodeType nodeType = TRNodeType.NONE;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public int Id { get => id; set => SetProperty(ref id, value); }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get => name; set => SetProperty(ref name, value); }
        /// <summary>
        /// Gets or sets the type of the node.
        /// </summary>
        /// <value>The type of the node.</value>
        public TRNodeType NodeType { get => nodeType; set => SetProperty(ref nodeType, value); }

        /// <summary>
        /// Gets or sets the parent node.
        /// </summary>
        /// <value>The parent node.</value>
        [JsonIgnore]
        public TRBaseNode ParentNode { get; set; }
    }
}
