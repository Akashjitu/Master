﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SubRangeModelMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using M2C.Business.Models;
using Schneider.M2C.OpenExcel.Parser.Model;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Class SubRangeModelMapper.
    /// Implements the <see cref="M2C.Business.Mappers.ISubRangeModelMapper" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.ISubRangeModelMapper" />
    public class SubRangeModelMapper : ISubRangeModelMapper
    {
        /// <summary>
        /// Maps the specified sub ranges.
        /// </summary>
        /// <param name="subRanges">The sub ranges.</param>
        /// <returns>List&lt;SubRangeModel&gt;.</returns>
        public List<SubRangeModel> Map(List<SubRange> subRanges)
        {
            return subRanges.Select(k => new SubRangeModel
            {
                Id = k.Id,
                Name = k.Name,
                SdhCode = k.SdhCode,
                SdhDescription = k.SdhDescription,
                CreatedDate = k.CreatedDate,
                UpdatedDate = k.UpdatedDate,
                RangeId = k.RangeId,
            }).ToList();
        }

        /// <summary>
        /// Maps the specified one ib catalogs.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <param name="ranges">The ranges.</param>
        /// <returns>List&lt;SubRange&gt;.</returns>
        public List<SubRange> Map(List<OneIbCatalog> oneIbCatalogs, List<Range> ranges)
        {
            var range = ranges == null ? new Dictionary<string, int>() :
                ranges.GroupBy(i => i.Name).ToDictionary(k => k.Key, l => l.FirstOrDefault(k => k != null).Id);

            var dic = oneIbCatalogs.Where(i => 
                    !string.IsNullOrEmpty(i.SdhSubRangeDescription) &&
                    !string.IsNullOrEmpty(i.SdhSubRangeCode) &&
                    !string.IsNullOrEmpty(i.RangeLegacy))
                .GroupBy(i => i.SdhSubRangeDescription).
                ToDictionary(i => i.Key, k =>
                new
                {
                    SdhCode = k.FirstOrDefault(i => !string.IsNullOrEmpty(i.SdhSubRangeCode))?.SdhSubRangeCode,
                    RangeName = k.FirstOrDefault(i => !string.IsNullOrEmpty(i.RangeLegacy))?.RangeLegacy
                });
            return dic.Select(i => new SubRange
            {
                SdhDescription = i.Key,
                SdhCode = i.Value?.SdhCode,
                RangeId = range.ContainsKey(i.Value?.RangeName ?? "") ? range[i.Value.RangeName] : 0,
            }).ToList();
        }
    }
}