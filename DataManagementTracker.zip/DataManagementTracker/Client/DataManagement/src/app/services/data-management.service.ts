import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/dataManagement/dataManagementReducer';
import { saveAs } from 'file-saver';
import * as DataManagementAction from '../store/dataManagement/dataManagementAction';
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from '../../environments/environment'
import { throwError } from 'rxjs';
import { NotifierService } from 'angular-notifier';
import { filter, map, catchError } from 'rxjs/operators'
import { ReferenceService } from './referenceService';
@Injectable({
  providedIn: 'root'
})
export class DataManagementService {



  headers: any;
  url = environment.apiBaseUrl;
  fileBaseUrl = environment.fileBaseUrl;

  constructor(private http: HttpClient, 
    private store: Store<IAppState>,
    public referenceService: ReferenceService,
     private spinner: NgxSpinnerService,
      private notifier: NotifierService) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
      withCredentials: 'true',
    });
  }

  private handleError(error: HttpErrorResponse) {

    console.log("Service Error :-" + JSON.stringify( error.error));
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
      this.showNotification('error', error.error.message)
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);

        this.showNotification('error', JSON.stringify(error.error));
    }
    return throwError(
      'Something bad happened; please try again later.');
  }

  public showNotification(type: string, message: string): void {
    this.notifier.notify(type, message);
  }

  reportDownload(date) {
    console.log(date);

    this.http.get(this.fileBaseUrl + 'plisummary?date=' + date, { responseType: 'blob', headers: this.headers }).pipe(
      catchError( err => this.handleError(err))
    ).subscribe(response => {
        saveAs(response, 'PliSummary' + date + '.xlsx',
          { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
      },
        err => {
          console.log(`ERROR: ${err}`);
          this.showNotification('error', 'Whoops, Not able to connect with service. Please check Service');
        });
  }

  getAlDataManagement() {
    this.spinner.show();
    this.http.get<any>(this.url + 'DataManagement').pipe(
      catchError( err => this.handleError(err))
    ).subscribe(res => {
        this.spinner.hide()
        this.store.dispatch(new DataManagementAction.LoadDataManagement(res)
        )
      }, err => {
        console.log(`ERROR: ${err}`);
        this.spinner.hide();
        this.showNotification('error', 'Whoops, Not able to connect with service. Please check Service');
      });
  }


  addDataManagement(criteria) {
    this.spinner.show();
    console.log('Load By  criteria ' + criteria)
    return this.http.post(this.url + 'DataManagement', criteria, { headers: this.headers }).pipe(
      catchError( err => this.handleError(err))
    ).subscribe(res => {
        this.spinner.hide()
        this.store.dispatch(new DataManagementAction.AddDataManagement(res))
        this.showNotification('success', 'Successfully Added New Request.')
        this.RefreshReference(criteria.customerId)
      }
        , err => {
          console.log(`ERROR: ${err}`);
          this.spinner.hide();
          this.showNotification('error', 'Whoops, something went wrong. Please Check all input boxes');
        });
  }

  RefreshReference(customerId)
  {
    if(customerId==5)
    {
      this.referenceService.getAllReference();
    }
  }


  loadDataManagementFilter(criteria) {
    this.spinner.show();
    console.log('Load By  criteria ' + criteria)
    return this.http.post(this.url + 'DataManagement/loadbycriteria', criteria, { headers: this.headers }).pipe(
      catchError( err => this.handleError(err))
    ).subscribe(res => {
        this.spinner.hide()
        this.store.dispatch(new DataManagementAction.LoadDataManagement(res)
        )
      }, err => {
        console.log(`ERROR: ${err}`);
        this.showNotification('error', 'Whoops, Not able to connect with service. Please check Service');
        this.spinner.hide();
      });
  }


  reportDownloadByFilter(data) {
    console.log('fileBaseUrl :- ' + this.fileBaseUrl + 'FileExport')
    this.spinner.show();
    this.http.post(this.url + 'FileExport', data, { responseType: 'blob', headers: this.headers }).pipe(
      catchError( err => this.handleError(err))
    ).subscribe(response => {
        saveAs(response, 'CustomerApprovalTracker.xlsx',
          { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          this.spinner.hide()
      },
        err => {
          this.spinner.hide()
          console.log(`ERROR: ${err}`),
          console.log('error', 'Whoops, Not able to connect with service. Please check Service');
        });
  }

  reportDownloadAll() {
    this.spinner.show();
    console.log('fileBaseUrl :- ' + this.fileBaseUrl + 'FileExport')
    this.http.get(this.url + 'FileExport', { responseType: 'blob', headers: this.headers }).pipe(
      catchError( err => this.handleError(err))
    ).subscribe(response => {
        saveAs(response, 'CustomerApprovalTracker.xlsx',
          { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }); this.spinner.hide()
      },
        err => {
          this.spinner.hide()
          console.log(`ERROR: ${err}`),
          console.log('error', 'Whoops, Not able to connect with service. Please check Service');
        });
  }

  UpdateDataManagement(selectedRow) {
    this.spinner.show();
    return this.http.put(this.url + 'DataManagement/' + selectedRow.id, selectedRow, { headers: this.headers })
      .pipe(
        catchError( err => this.handleError(err))
      ).subscribe(infoData => {
        this.store.dispatch(new DataManagementAction.UpdateDataManagement(infoData));
        this.spinner.hide();
        this.showNotification('success', 'Successfully Report Updated');
      },
        err => {
          console.log(`ERROR: ${err}`),
          this.showNotification('error', 'Whoops, something went wrong. Please Check Comment text length.'); 
          this.spinner.hide();
        },
      );
  }


}
