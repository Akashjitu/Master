﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface ITtiDataAccess
    {
        List<TtiPartAlignment> LoadTti();

        List<TtiPartAlignment> LoadTtiByParameter(TtiPartAlignment ttiPartAlignment);

        List<TtiPartAlignment> LoadTtiByDate(TtiPartAlignment ttiPartAlignment);

        List<TtiPartAlignment> LoadTtiById(TtiPartAlignment ttiPartAlignment);

        int AddTTiInfo(TtiPartAlignment ttiPartAlignment);

        int UpdateTTiInfo(TtiPartAlignment ttiPartAlignment);
    }
}