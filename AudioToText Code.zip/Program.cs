﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualBasic;
using NAudio.Wave;
using System.Text;
using Whisper.net;
using Whisper.net.Ggml;
using Whisper.net.Logger;
using Xabe.FFmpeg;
using System.Text.Json;

using System.Configuration;



class Program
{
    static async Task Main(string[] args)
    {
        try
        {
            var services = new ServiceCollection();

            // Register services
            services.AddSingleton<IFileService, FFmpegFileService>();
            services.AddSingleton<ITranscriptionService, WhisperTranscriptionService>();

            var provider = services.BuildServiceProvider();

            Console.WriteLine("Choose input:\n1. Microphone\n2. Audio/Video File");
            var choice = Console.ReadLine();

            IAudioInputService audioInputService;
            var filePath = "";
            if (choice == "1")
            {
                audioInputService = new MicrophoneInputService();
            }
            else
            {
                Console.Write("Enter full file path (audio/video): ");
                filePath = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
                {
                    Console.WriteLine("Invalid file path. Exiting.");
                    return;
                }

                var fileService = provider.GetRequiredService<IFileService>();
                audioInputService = new FileInputService(fileService, filePath);
            }

            var audioData = await audioInputService.GetAudioAsync();

            var transcriptionService = provider.GetRequiredService<ITranscriptionService>();
            var transcription = await transcriptionService.TranscribeAsync(audioData);

            var FOLDER = Path.GetDirectoryName(filePath);
            var fileNamme = Path.GetFileNameWithoutExtension(filePath);
            var textFilePath = Path.Combine(FOLDER, $"{fileNamme}.txt");
            File.WriteAllText(textFilePath, transcription);

            Console.WriteLine("\n📝 Transcription Result:\n");
            Console.WriteLine(transcription);
        }
        catch (Exception ex)
        {
            Console.WriteLine("========================================");
            Console.WriteLine($"Exception: {ex.Message}");
            Console.WriteLine("========================================");
            if (ex.InnerException != null) {
                Console.WriteLine($"Inner Exception: {ex.InnerException.Message}");
            }
            Console.WriteLine("========================================");
            Console.WriteLine($"Source: {ex.Source}"); 
            Console.WriteLine("========================================");
            Console.WriteLine($"Stack Trace: {ex.StackTrace}");
        }
    }
}






public class WhisperTranscriptionService : ITranscriptionService
{
    private readonly string _modelPath = "ggml-base.bin";
    private readonly WhisperFactory _whisperFactory;

    public WhisperTranscriptionService()
    {
        // Force CPU mode by disabling Vulkan
        Environment.SetEnvironmentVariable("WHISPER_NO_VULKAN", "1");

        if (!File.Exists(_modelPath))
        {
            Console.WriteLine($"Downloading Model {_modelPath}");
            using var modelStream = WhisperGgmlDownloader.Default.GetGgmlModelAsync(GgmlType.Base).Result;
            using var fileWriter = File.OpenWrite(_modelPath);
            modelStream.CopyTo(fileWriter);
        }

        _whisperFactory = WhisperFactory.FromPath(_modelPath);
    }

    public async Task<string> TranscribeAsync(byte[] audioData)
    {
        using var processor = _whisperFactory.CreateBuilder()
            .WithLanguage("auto")
            .Build();

        using var stream = new MemoryStream(audioData);
        var resultText = new StringBuilder();

        await foreach (var result in processor.ProcessAsync(stream))
        {
            resultText.AppendLine($"{result.Start}->{result.End}: {result.Text}");
        }

        return resultText.ToString();
    }
}



public class FFmpegFileService : IFileService
{
    public async Task<byte[]> ExtractAudioAsync(string filePath)
    {
        // FFmpeg.SetExecutablesPath(@"C:\ffmpeg\bin");
        var ffmpegPath = ConfigurationManager.AppSettings["FFmpegPath"];
        FFmpeg.SetExecutablesPath(ffmpegPath);
        if (string.IsNullOrWhiteSpace(ffmpegPath))
        {
            throw new InvalidOperationException("FFmpegPath is not configured in App.config.");
        }

        var outputPath = Path.ChangeExtension(Path.GetTempFileName(), ".wav");

        var conversion = FFmpeg.Conversions.New()
            .AddParameter($"-i \"{filePath}\" -ar 16000 -ac 1 \"{outputPath}\"", ParameterPosition.PreInput);

        await conversion.Start(); // ✅ Await the Start method, not the conversion itself

        return await File.ReadAllBytesAsync(outputPath);
    }
}



public class FileInputService : IAudioInputService
{
    private readonly IFileService _fileService;
    private readonly string _filePath;

    public FileInputService(IFileService fileService, string filePath)
    {
        _fileService = fileService;
        _filePath = filePath;
    }

    public async Task<byte[]> GetAudioAsync()
    {
        return await _fileService.ExtractAudioAsync(_filePath);
    }
}


public class MicrophoneInputService : IAudioInputService
{
    public async Task<byte[]> GetAudioAsync()
    {
        using var memoryStream = new MemoryStream();
        using var waveIn = new WaveInEvent
        {
            WaveFormat = new WaveFormat(16000, 1)
        };

        waveIn.DataAvailable += (s, e) => memoryStream.Write(e.Buffer, 0, e.BytesRecorded);
        waveIn.StartRecording();

        Console.WriteLine("Recording... Press any key to stop.");
        Console.ReadKey();

        waveIn.StopRecording();
        return memoryStream.ToArray();
    }
}
public interface IFileService
{
    Task<byte[]> ExtractAudioAsync(string filePath);
}
public interface ITranscriptionService
{
    Task<string> TranscribeAsync(byte[] audioData);
}

public interface IAudioInputService
{
    Task<byte[]> GetAudioAsync();
}
