﻿using Autofac;
using Autofac.Integration.WebApi;
using Data.Management.Service.Host.ExceptionFilters;
using Data.Management.Service.Host.Mail;
using Data.Management.Services;
using Data.Management.Services.DataBaseAccessObject;
using Data.Management.Services.Exports;
using Data.Management.Services.Filter;
using Data.Management.Services.Manager;
using Data.Management.Services.Service;
using DataManagement.Data.Models;
using Honeywell.ActiveDirectory;
using System.Linq;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace Data.Management.Service.Host
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var config = GlobalConfiguration.Configuration;
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

         //   config.Filters.Add(new LogExceptionFilterAttribute());


            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            var assemblyType = typeof(DataManagementTrack).GetTypeInfo();
            builder.RegisterAssemblyTypes(assemblyType.Assembly)
            .Where(t => t.Name.EndsWith("Service"))
            .AsImplementedInterfaces()
            .InstancePerRequest();
            config.EnableCors(new EnableCorsAttribute("*", "*", "*"));
            config.EnableCors();
            builder.RegisterWebApiFilterProvider(config);
            builder.RegisterType<DataManagementServices>().As<IDataManagementServices>().InstancePerRequest();
            builder.RegisterType<DataManagementManage>().As<IDataManagementManage>().InstancePerRequest();
            builder.RegisterType<DataManagementDbAccess>().As<IDataManagementDbAccess>().InstancePerRequest();
            builder.RegisterType<ReferenceService>().As<IReferenceService>().InstancePerRequest();
            builder.RegisterType<ReferenceManager>().As<IReferenceManager>().InstancePerRequest();
            builder.RegisterType<MailProvider>().As<IMailProvider>().InstancePerRequest();
            builder.RegisterType<SimpleExport>().As<ISimpleExport>().InstancePerRequest();
            builder.RegisterType<EmployeeService>().As<IEmployeeService>().InstancePerRequest();
            builder.RegisterType<DataManagementFilter>().As<IDataManagementFilter>().InstancePerRequest();
            builder.RegisterType<ActiveDirectoryHelper>().As<IActiveDirectoryHelper>().InstancePerRequest();

            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }
    }
}