﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IEffectivenessAnalysisDataAccess
    {
        List<EffectivenessAnalysis> LoadEffectivenessAnalysisByPart(EffectivenessAnalysis effectivenessAnalysis);

        List<EffectivenessAnalysis> LoadEffectivenessAnalysisById(EffectivenessAnalysis effectivenessAnalysis);

        List<EffectivenessAnalysis> LoadEffectivenessAnalysisByCreationDate(EffectivenessAnalysis effectivenessAnalysis);

        List<EffectivenessAnalysis> LoadEffectivenesAnalysis();
    }
}