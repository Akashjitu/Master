﻿
using System.DirectoryServices.AccountManagement;

namespace Honeywell.ActiveDirectory
{
    public class ADManager
    {
        private PrincipalContext context;

        public ADManager()
        {
            this.context = new PrincipalContext(ContextType.Machine, "xxx", "xxx", "xxx");
        }

        public ADManager(string domain, string container)
        {
            this.context = new PrincipalContext(ContextType.Domain, domain, container);
        }

        public ADManager(string domain, string username, string password)
        {
            this.context = new PrincipalContext(ContextType.Domain, username, password);
        }

        public bool AddUserToGroup(string userName, string groupName)
        {
            bool flag = false;
            GroupPrincipal group = GroupPrincipal.FindByIdentity(this.context, groupName) ?? new GroupPrincipal(this.context, groupName);
            UserPrincipal byIdentity = UserPrincipal.FindByIdentity(this.context, userName);
            if (byIdentity != null & group != null)
            {
                group.Members.Add(byIdentity);
                group.Save();
                flag = byIdentity.IsMemberOf(group);
            }
            return flag;
        }

        public bool RemoveUserFromGroup(string userName, string groupName)
        {
            bool flag = false;
            UserPrincipal byIdentity1 = UserPrincipal.FindByIdentity(this.context, userName);
            GroupPrincipal byIdentity2 = GroupPrincipal.FindByIdentity(this.context, groupName);
            if (byIdentity1 != null & byIdentity2 != null)
            {
                byIdentity2.Members.Remove(byIdentity1);
                byIdentity2.Save();
                flag = !byIdentity1.IsMemberOf(byIdentity2);
            }
            return flag;
        }
    }
}
