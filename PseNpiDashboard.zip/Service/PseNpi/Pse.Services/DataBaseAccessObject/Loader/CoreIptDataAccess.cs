﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class CoreIptDataAccess : ICoreIptDataAccess
    {
        public CoreIpt AddCoreIpt(CoreIpt coreIpt)
        {
            using (var dao = new DataAccessObject<CoreIpt>())
            {
                var count = dao.Put(coreIpt, "PK_CORE_IPT.SP_ADD_SP_ADD_CORE_IPT");
                var data = dao.Load("PK_CORE_IPT.SP_LOAD_LATEST_CORE_IPT");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public List<CoreIpt> LoadAllCoreIpt()
        {
            using (var dao = new DataAccessObject<CoreIpt>())
            {
                var data = dao.Load("PK_CORE_IPT.SP_LOAD_CORE_IPT");
                var returndata = new List<CoreIpt>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<CoreIpt> LoadCoreIptByCreationDate(DateTime creationDate)
        {
            using (var dao = new DataAccessObject<CoreIpt>())
            {
                var data = dao.LoadByInput(new CoreIpt { CreatedDate = creationDate }, "PK_CORE_IPT.SP_LOAD_BY_MO_YY");
                var returndata = new List<CoreIpt>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<CoreIpt> LoadLatestCoreIpt()
        {
            using (var dao = new DataAccessObject<CoreIpt>())
            {
                var data = dao.Load("PK_CORE_IPT.SP_LOAD_LATEST_CORE_IPT");
                var returndata = new List<CoreIpt>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<CoreIpt> LoadCoreIptById(int Id)
        {
            using (var dao = new DataAccessObject<CoreIpt>())
            {
                var data = dao.LoadByInput(new CoreIpt { Id = Id }, "PK_CORE_IPT.SP_LOAD_BY_ID");
                var returndata = new List<CoreIpt>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<CoreIpt> LoadCoreIptByKeyCode(string keycode)
        {
            using (var dao = new DataAccessObject<CoreIpt>())
            {
                var data = dao.LoadByInput(new CoreIpt { KeyCode = keycode }, "PK_CORE_IPT.SP_LOAD_BY_KEY_CODE");
                var returndata = new List<CoreIpt>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public CoreIpt UpdateCoreIpt(CoreIpt coreIpt)
        {
            {
                using (var dao = new DataAccessObject<CoreIpt>())
                {
                    var count = dao.Put(coreIpt, "PK_CORE_IPT.SP_UPDATE_CORE_IPT");
                    var data = dao.LoadByInput(coreIpt, "PK_CORE_IPT.SP_LOAD_BY_ID");
                    if (data == null || data.Count == 0)
                        return null;
                    return data[0];
                }
            }
        }
    }
}