﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class EffectivenessDataAccess : IEffectivenessDataAccess
    {
        public List<Effectiveness> LoadPppPartInfo(Effectiveness ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_PPP_PART.SP_LOAD_PPP_PART_INFO");
                var returndata = new List<Data.Models.Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Effectiveness> LoadEffectivenesByDate(Effectiveness effectiveness)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.LoadByInput(effectiveness, "PK_PSE_EFFECTIVENESS.SP_LOAD_EFFECTIV_BY_MO_YY");
                var returndata = new List<Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Effectiveness> LoadEffectivenesById(Effectiveness effectiveness)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.LoadByInput(effectiveness, "PK_PSE_EFFECTIVENESS.SP_LOAD_EFFECTIV_BY_ID");
                var returndata = new List<Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Effectiveness> LoadEffectivenesByPart(Effectiveness effectiveness)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.LoadByInput(effectiveness, "PK_PSE_EFFECTIVENESS.SP_LOAD_EFFECTIV_BY_PART");
                var returndata = new List<Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public int AddEffectiveness(Effectiveness eft)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.Post(eft, "PK_PSE_EFFECTIVENESS.SP_INSERT_EFFECTIV_INFO");
                return data;
            }
        }

        public int UpdateEffectiveness(Effectiveness eft)
        {
            using (var dao = new DataAccessObject<Effectiveness>())
            {
                var data = dao.Put(eft, "PK_PSE_EFFECTIVENESS.SP_UPDATE_EFFECTIV_INFO");
                return data;
            }
        }
    }
}