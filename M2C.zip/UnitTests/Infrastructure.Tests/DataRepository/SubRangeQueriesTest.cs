﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class SubRangeQueriesTest : TestBase
    {
        private IQueryable<SubRange> subRangeList;
        private Mock<DbSet<SubRange>> subRangeMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            SubRange subRangeObj = new SubRange() { Id = 1, Name = "SubRange1", RangeId = 1, SdhDescription = "Description" };
            List<SubRange> subRange = new List<SubRange>() { subRangeObj };
            subRangeList = subRange.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();
            subRangeMock = MockRepo.Create<DbSet<SubRange>>();
            subRangeMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(subRangeList.Provider);
            subRangeMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(subRangeList.Expression);
            subRangeMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(subRangeList.ElementType);
            subRangeMock.As<IQueryable<SubRange>>().Setup(m => m.GetEnumerator()).Returns(subRangeList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.SubRanges).Returns(subRangeMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void SubRangeQueriesConstructorTest()
        {
            ISubRangeQueries subRange = new ProductQueries(IDbContextFactoryMock.Object);
            subRange.Should().NotBeNull();
            ((IDisposable)subRange).Dispose();
        }

        [TestMethod]
        public void SubRangeQueriesSaveSubRangesTest()
        {
            ISubRangeQueries subRange = new ProductQueries(IDbContextFactoryMock.Object);
            SubRange subRangeObj = new SubRange() { Id = 1, Name = "SubRange1", RangeId = 1, SdhDescription = "Description" };
            List<SubRange> subRanges = new List<SubRange>() { subRangeObj };
            Action action = () => subRange.SaveSubRanges(null);
            action.Should().NotThrow();
            action = () => subRange.SaveSubRanges(subRanges);
            action.Should().NotThrow();

            subRangeObj.Id = 0;
            subRangeObj.Name = "SubRangeNew";
            subRangeObj.SdhDescription = "DescriptionNew";
            action = () => subRange.SaveSubRanges(subRanges);
            action.Should().NotThrow();
            ((IDisposable)subRange).Dispose();
        }

        [TestMethod]
        public void SubRangeQueriesLoadSubRanges()
        {
            ISubRangeQueries subRange = new ProductQueries(IDbContextFactoryMock.Object);
            List<SubRange> subrangeRes = subRange.LoadSubRanges();
            subrangeRes.Should().HaveCount(1);
            ((IDisposable)subRange).Dispose();
        }

        [TestMethod]
        public void SubRangeQueriesLoadSubRangesbySubRange()
        {
            SubRange subRanges = new SubRange() { Id = 1, Name = "SubRange1" };
            ISubRangeQueries subRange = new ProductQueries(IDbContextFactoryMock.Object);
            List<SubRange> subrangeRes = subRange.LoadSubRanges(null);
            subrangeRes.Should().BeNull();
            subrangeRes = subRange.LoadSubRanges(subRanges);
            subrangeRes.Should().HaveCount(1);
            ((IDisposable)subRange).Dispose();
        }
    }
}