

import { Action } from '@ngrx/store';
import * as EffectivenessAction from './effectivenessAction';
import { Compliance } from 'src/app/model/compliance';
import { Effectiveness } from 'src/app/model/effectiveness';


export interface IAppState {
    readonly compliance: Effectiveness[];
}


export function effectivenessReducer(state: Effectiveness[] = [], action: EffectivenessAction.Actions) {

    switch (action.type) {

        case EffectivenessAction.ADD_EFFECTIVENESS: {
            return [...state, action.payload]

        }

        case EffectivenessAction.LOAD_EFFECTIVENESS: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case EffectivenessAction.UPDATE_EFFECTIVENESS: {
            const tti = (action.payload as Effectiveness);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            //return Object.assign([], state);
            return state.slice();
        }



        default:
            return state;
    }
}