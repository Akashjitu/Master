﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectBusinessModelBuilder.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DomainModels.ProjectModels;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using Newtonsoft.Json;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace M2C.Business.Mappers.ProjectMap
{
    /// <summary>
    /// Project DB Model to Project Business Model builder
    /// </summary>
    public class ProjectBusinessModelBuilder : IProjectBusinessModelBuilder
    {
        /// <summary>
        /// The d b model
        /// </summary>
        private Project _dBModel;

        /// <summary>
        /// The context model
        /// </summary>
        private ProjectContextModel _contextModel;

        /// <summary>
        /// The inventory mapper
        /// </summary>
        private readonly IInventoryMapper _inventoryMapper;

        /// <summary>
        /// The dialog service
        /// </summary>
        private readonly IDialogService _dialogService;

        /// <summary>
        /// The product queries
        /// </summary>
        private readonly IProductQueries _productQueries;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectBusinessModelBuilder" /> class.
        /// </summary>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        /// <param name="dialogService">The dialog service.</param>
        public ProjectBusinessModelBuilder(IInventoryMapper inventoryMapper, IDialogService dialogService, IProductQueries productQueries)
        {
            _inventoryMapper = inventoryMapper;
            _contextModel = new ProjectContextModel();
            _dialogService = dialogService;
            this._productQueries = productQueries;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectBusinessModelBuilder" /> class.
        /// </summary>
        /// <param name="dbModel">The database model.</param>
        /// <param name="projectContextModel">The project context model.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        /// <param name="dialogService">The dialog service.</param>
        public ProjectBusinessModelBuilder(ref Project dbModel, ref ProjectContextModel projectContextModel,
            IInventoryMapper inventoryMapper, IDialogService dialogService, IProductQueries productQueries)
        {
            _inventoryMapper = inventoryMapper;
            _dBModel = dbModel;
            _contextModel = projectContextModel ?? new ProjectContextModel();
            _dialogService = dialogService;
            this._productQueries = productQueries;
        }

        /// <summary>
        /// Builds the project.
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildProject()
        {
            if (_dBModel == null) return this;

            _contextModel.ProjectId = _dBModel.ProjectID;
            _contextModel.Version = _dBModel.Version;
            _contextModel.CreatedDate = _dBModel.CreatedOn;
            _contextModel.ModifieddDate = _dBModel.ModifiedOn;
            _contextModel.LastSyncDate = _dBModel.LastSyncDate;
            _contextModel.ProjectReferenceId = _dBModel.ProjectReferenceId;
            return this;
        }

        /// <summary>
        /// Builds the customer.
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildCustomer()
        {
            if (_dBModel?.Customer == null) return this;

            _contextModel.Customer.BfoId = _dBModel.Customer.BfoId.ToString();
            _contextModel.Customer.CustomerID = _dBModel.Customer.CustomerID;
            _contextModel.Customer.City = _dBModel.Customer.City;
            _contextModel.Customer.Comment = _dBModel.Customer.Comment;
            _contextModel.Customer.CompanyName = _dBModel.Customer.CompanyName;
            if (_dBModel.Customer?.Country != null)
            {
                _contextModel.Customer.Country = new CountryModel()
                {
                    Id = _dBModel.Customer.Country.Id,
                };
            }
            _contextModel.Customer.PostalCode = _dBModel.Customer.PostalCode;
            _contextModel.Customer.ProjectName = _dBModel.Customer.ProjectName;
            _contextModel.Customer.Region = _dBModel.Customer.Region;
            _contextModel.Customer.Street = _dBModel.Customer.Street;

            return this;
        }

        /// <summary>
        /// Builds the contact.
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildContact()
        {
            if (_dBModel?.Contacts == null) { return this; }

            _contextModel.Contacts.Clear();
            foreach (var contact in _dBModel?.Contacts)
            {
                ContactModel c = new ContactModel();

                c.Id = contact.ContactID;
                if (!string.IsNullOrEmpty(contact.ContactType?.Name))
                {
                    c.ContactType = (Models.Project.ContactType)Enum.Parse(typeof(Models.Project.ContactType), contact.ContactType.Name.ToUpper());
                }
                c.IsLinked = contact.IsLinked;
                c.Email = contact.Email;
                c.FirstName = contact.FirstName;
                c.LastName = contact.LastName;
                c.MobileNumber = contact.Mobile;
                c.PostalCode = contact.PostalCode;
                c.Street = contact.Street;
                c.PostalCode = contact.PostalCode;
                c.Telephone = contact.Telephone;
                c.Fax = contact.Fax;
                c.Town = contact.City;
                c.Region = contact.Region;

                c.Country = new CountryModel()
                {
                    Id = contact.CountryId
                };

                c.Created = contact.CreatedOn;
                c.Position = new PositionModel()
                {
                    Id = contact.PositionId
                };

                _contextModel.Contacts.Add(c);
            }

            return this;
        }

        /// <summary>
        /// Builds the Ib.
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildIb()
        {
            _contextModel.InstalledBase = new InstalledBase();
            var listNodes = _contextModel.InstalledBase.GetAllNodes();

            if (_dBModel?.IBProjectComponents == null || listNodes.Count > 1)
            { return this; }

            var ib = _dBModel?.IBProjectComponents.FirstOrDefault(x => x.IBComponenetType?.ComponentTypeID == 1);
            if (ib == null) return this;
            _contextModel.InstalledBase = new InstalledBase()
            {
                Id = ib.NodeID,
                ParentNode = null,
                Name = ib.ComponentName,
            };

            _contextModel.InstalledBase.AddChild(_dBModel?.IBProjectComponents.ToList());
            return this;
        }

        /// <summary>
        /// Builds the Tr.
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildTr()
        {
            _contextModel.TechnicalResources = new TRNode();
            var listNodes = _contextModel.TechnicalResources.GetAllNodes();

            if (_dBModel?.IBProjectComponents == null || listNodes.Count > 1) return this;
            var ib = _dBModel?.IBProjectComponents.FirstOrDefault(x => x.IBComponenetType?.ComponentTypeID == 10);
            if (ib == null) return this;
            _contextModel.TechnicalResources = new TRNode()
            {
                Id = ib.NodeID,
                ParentNode = null,
                Name = ib.ComponentName,
            };

            _contextModel.TechnicalResources.AddChild(_dBModel?.IBProjectComponents.ToList());
            return this;
        }

        /// <summary>
        /// Gets the project.
        /// </summary>
        /// <returns>ProjectContextModel.</returns>
        public ProjectContextModel GetProject()
        {
            return _contextModel;
        }

        /// <summary>
        /// builds the Operation mode
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildOperationMode()
        {
            if (_dBModel?.OperationModes != null)
            {
                var nodes = _contextModel.InstalledBase.GetAllNodes();

                foreach (var item in _dBModel?.OperationModes)
                {
                    var machineNode = nodes.Where(x => x.Id == item.IBProjectComponent.NodeID);
                    foreach (var node in machineNode)
                    {
                        if (node != null && node is IOperationMode)
                        {
                            (node as IOperationMode).OperationParams = new OperationModeModel()
                            {
                                HourlyProduction = item.HourlyProduction,
                                OperatingMode = item.OperatingMode,
                                StartDate = string.IsNullOrEmpty(item.StartupDate) ? DateTime.Now : Convert.ToDateTime(item.StartupDate),
                                EndDate = string.IsNullOrEmpty(item.EndOfLife) ? DateTime.Now : Convert.ToDateTime(item.EndOfLife),
                                Age = item.Age,
                                Comments = item.Comments
                            };
                        }
                    }
                }
            }

            return this;
        }

        /// <summary>
        /// builds the ProjectInventories
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildProjectInventories()
        {
            if (_dBModel?.ProjectInventories == null) return this;

            var installBasedNode = _contextModel.InstalledBase;
            var technicalResourcesNode = _contextModel.TechnicalResources;
            var dbprojectInventories = _dBModel?.ProjectInventories;

            if (dbprojectInventories == null || !dbprojectInventories.Any()) return this;

            var inventories = UpdateInventoriesWithDatabase(dbprojectInventories);
            if (inventories == null)
                return this;

            var technicalResourcesInventories = inventories.Where(i => !string.IsNullOrEmpty(i.MaintenanceZone)).ToList();
            var installBasedInventories = inventories.Where(i => string.IsNullOrEmpty(i.MaintenanceZone)).ToList();

            //var installBasedInventories = _inventoryMapper.Map(installBasedProjectInventories);
            //var technicalResourcesInventories = _inventoryMapper.Map(technicalResourcesProjectInventories);

            var nodes = installBasedNode.GetAllNodes();
            nodes.ForEach(i => i.MasterInventories = installBasedNode.MasterInventories);
            installBasedNode.MasterInventories.AddRange(installBasedInventories);

            var trNodes = technicalResourcesNode.GetAllNodes();
            trNodes.ForEach(i => i.MasterInventories = technicalResourcesNode.MasterInventories);
            technicalResourcesNode.MasterInventories.AddRange(technicalResourcesInventories);

            return this;
        }

        /// <summary>
        /// Update Inventories with Data base
        /// </summary>
        /// <param name="projectInventories">The project inventories.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        public ObservableCollection<Inventory> UpdateInventoriesWithDatabase(ICollection<ProjectInventory> projectInventories)
        {
            if (UpdateInventoryBuilderCallback != null)
            {
                List<ProjectInventory> outDatedInv = new List<ProjectInventory>();
                foreach (var item in projectInventories)
                {
                    DomainModels.IbCatalogModels.Product currentProduct = _productQueries.GetProductsByIdentifier(item.Reference);
                    if (currentProduct?.Version != item.Version)
                    {
                        outDatedInv.Add(item);
                    }
                }

                if (UpdateInventoryBuilderCallback(outDatedInv.Select(i => i.Reference).ToList()))
                {
                    return _inventoryMapper.MapWithUpdateDatabase(projectInventories);
                }
            }
            return _inventoryMapper.Map(projectInventories);
        }

        /// <summary>
        /// builds the Inventory Comments
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildInventoryComments()
        {
            var installBasedNode = _contextModel.InstalledBase;
            var technicalResourcesNode = _contextModel.TechnicalResources;

            if (_dBModel?.InventoryComments == null) return this;
            var installBasedNodes = installBasedNode.GetAllNodes();
            var technicalResourcesNodes = technicalResourcesNode.GetAllNodes();

            foreach (var inventoryComment in _dBModel?.InventoryComments)
            {
                var node = installBasedNodes.FirstOrDefault(x => x.Id == inventoryComment.NodeId && x.NodeType == (NodeType)inventoryComment.NodeType);
                if (node == null) continue;
                if (!string.IsNullOrEmpty(inventoryComment.CustomerDocuments))
                    node.CustomerDocuments = JsonConvert.DeserializeObject<ObservableCollection<CustomerDocument>>(inventoryComment.CustomerDocuments);
                node.Comment = inventoryComment.Comments;
            }
            foreach (var inventoryComment in _dBModel?.InventoryComments)
            {
                var node = technicalResourcesNodes.FirstOrDefault(x => x.Id == inventoryComment.NodeId && x.NodeType == (NodeType)inventoryComment.NodeType);
                if (node == null) continue;
                if (!string.IsNullOrEmpty(inventoryComment.CustomerDocuments))
                    node.CustomerDocuments = JsonConvert.DeserializeObject<ObservableCollection<CustomerDocument>>(inventoryComment.CustomerDocuments);
                node.Comment = inventoryComment.Comments;
            }
            return this;
        }

        /// <summary>
        /// Builds Criticality
        /// </summary>
        /// <returns>ProjectBusinessModelBuilder.</returns>
        public ProjectBusinessModelBuilder BuildCriticality()
        {
            if (_dBModel?.Criticalities == null) return this;
            var nodes = _contextModel.InstalledBase.GetAllNodes();

            foreach (var item in _dBModel?.Criticalities)
            {
                var machineNode = nodes.Where(x => x.Id == item.IBProjectComponent.NodeID);
                foreach (var node in machineNode)
                {
                    if (node is MachineNode)
                    {
                        (node as MachineNode).CriticalityParameters = new CriticalityModel()
                        {
                            SafetyIssue = item.SafetyIssue,
                            QualityIssue = item.QualityIssue,
                            LeadTimeIssue = item.LeadTimeIssue,
                            CostsIssue = item.CostsIssue,
                            SelectedValue = item.CriticalityValue,
                            Comments = item.Comments
                        };
                    }
                }
            }

            return this;
        }

        /// <summary>
        /// Get the fills project ProjectContextModel
        /// </summary>
        /// <param name="project">The project.</param>
        /// <returns>ProjectContextModel.</returns>
        public ProjectContextModel GetProjectContextModel(Project project)
        {
            _dBModel = project;
            _contextModel = new ProjectContextModel();
            BuildProject();
            BuildCustomer();
            BuildContact();
            BuildIb();
            BuildTr();
            BuildOperationMode();
            BuildProjectInventories();
            BuildInventoryComments();
            BuildCriticality();
            return _contextModel;
        }

        /// <summary>
        /// Loads the projects with customers.
        /// </summary>
        /// <param name="project">The project.</param>
        /// <returns>ProjectContextModel.</returns>
        public ProjectContextModel LoadProjectsWithCustomers(Project project)
        {
            _dBModel = project;
            _contextModel = new ProjectContextModel();
            BuildProject();
            BuildCustomer();
            return _contextModel;
        }

        /// <summary>
        /// Gets or sets the update inventory callback.
        /// </summary>
        /// <value>
        /// The update inventory callback.
        /// </value>
        public Predicate<IReadOnlyCollection<string>> UpdateInventoryBuilderCallback { get; set; }
    }
}