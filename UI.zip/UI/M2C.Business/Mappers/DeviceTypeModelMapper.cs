﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="DeviceTypeModelMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using M2C.Business.Models;
using Schneider.M2C.OpenExcel.Parser.Model;
using System.Collections.Generic;
using System.Linq;
using M2C.Business.Models.Project.IBComponents;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Class DeviceTypeModelMapper.
    /// Implements the <see cref="M2C.Business.Mappers.IDeviceTypeModelMapper" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IDeviceTypeModelMapper" />
    public class DeviceTypeModelMapper : IDeviceTypeModelMapper
    {
        /// <summary>
        /// Maps the specified device types.
        /// </summary>
        /// <param name="deviceTypes">The device types.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceTypeModel> Map(List<DeviceType> deviceTypes)
        {
            if (deviceTypes == null)
                return new List<DeviceTypeModel>();
            return deviceTypes.Select(i => new DeviceTypeModel
            {
                Id = i.Id,
                Type = i.Type,
                OpsTypeDescription = i.OpsTypeDescription,
                CreatedDate = i.CreatedDate,
                UpdatedDate = i.UpdatedDate,
            }).ToList();
        }

        /// <summary>
        /// Maps the specified one ib catalogs.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        public List<DeviceType> Map(params OneIbCatalog[] oneIbCatalogs)
        {
            var dic = oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.DeviceTypeLegacy)).GroupBy(i => i.DeviceTypeLegacy).ToDictionary(i => i.Key, k => k.ToList());
            return dic.Select(x => new DeviceType
            {
                Type = x.Key,
                ConfigType = GetConfigurationType(x.Key),
                OpsTypeDescription = x.Value.FirstOrDefault(i => !string.IsNullOrEmpty(i.OpsDeviceTypeDescription))?.OpsDeviceTypeDescription
            }).ToList();
        }

        /// <summary>
        /// Gets the type of the configuration.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>System.String.</returns>
        private static string GetConfigurationType(string type)
        {
            if(string.IsNullOrEmpty(type))
                return nameof(NodeType.NONE);
            if (type.ToUpper().StartsWith("PLC ") || type.ToUpper().StartsWith("SOLUTION") ||
                type.ToUpper().StartsWith("SOLUTION ") || type.ToUpper().StartsWith("AUTOMATION ") || type.ToUpper().StartsWith("NETWORKING "))
                return nameof(NodeType.PLC_CONFIG);

            if (type.ToUpper().StartsWith("MOTION ") || type.ToUpper().StartsWith("VARIABLE ") || type.ToUpper().StartsWith("SOFT "))
                return nameof(NodeType.MD_CONFIG);

            if (type.ToUpper().StartsWith("HMI "))
                return nameof(NodeType.SHMI_CONFIG);

            if (type.ToUpper().StartsWith("SOFTWARE "))
                return nameof(NodeType.OPEN_CONFIG);

            return nameof(NodeType.OPEN_CONFIG);
        }
    }
}