﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.Common;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class ProfileQueriesTest : TestBase
    {
        private IQueryable<Profile> profileList;
        private Mock<DbSet<Profile>> profileMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            Profile profileObj = new Profile() { Id = 1, Country = new Country() { Id = 1, Name = "India", Code = "IN", Region = "Asia" }, 
                Position = new Position() { Id = 1, Name = "Name1" }, CountryId = 1, FirstName = "User1" };
            List<Profile> profile = new List<Profile>() { profileObj };
            profileList = profile.AsQueryable();

            profileMock = MockRepo.Create<DbSet<Profile>>();
            profileMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(profileList.Provider);
            profileMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(profileList.Expression);
            profileMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(profileList.ElementType);
            profileMock.As<IQueryable<Profile>>().Setup(m => m.GetEnumerator()).Returns(profileList.GetEnumerator());

            IProjectDbContextMock.Setup(x => x.Profiles).Returns(profileMock.Object);
            IProjectDbContextMock.Setup(m => m.SaveChanges()).Returns(1);
            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);
        }

        [TestMethod]
        public void ProfileQueriesConstructorTest()
        {
            IProfileQueries profile = new ProjectQueries(IDbContextFactoryMock.Object);
            profile.Should().NotBeNull();
            ((IDisposable)profile).Dispose();
        }

        [TestMethod]
        public void ProfileQueriesSaveProfileTest()
        {
            Profile profileObj = new Profile() { Id = 1, Country = new Country() { Id = 1, Name = "India", Code = "IN", Region = "Asia" }, 
                Position = new Position() { Id = 1, Name = "Name1" }, CountryId = 1, FirstName = "User1" };

            IProfileQueries profile = new ProjectQueries(IDbContextFactoryMock.Object);
            Action action = () => profile.SaveProfile(null);
            action.Should().NotThrow();
            action = () => profile.SaveProfile(profileObj);
            action.Should().NotThrow();
            profileObj.Id = 2;
            action = () => profile.SaveProfile(profileObj);
            action.Should().NotThrow();
            ((IDisposable)profile).Dispose();
        }

        [TestMethod]
        public void ProfileQueriesRemoveProfileTest()
        {
            int profileId = 1;
            IProfileQueries profile = new ProjectQueries(IDbContextFactoryMock.Object);
            bool profileRes = profile.RemoveProfile(profileId);
            profileRes.Should().BeTrue();
            ((IDisposable)profile).Dispose();
        }

        [TestMethod]
        public void ProfileQueriesGetProfileTest()
        {
            IProfileQueries profile = new ProjectQueries(IDbContextFactoryMock.Object);
            Profile profileRes = profile.GetProfile();
            profileRes.Should().NotBeNull();
            ((IDisposable)profile).Dispose();
        }
    }
}