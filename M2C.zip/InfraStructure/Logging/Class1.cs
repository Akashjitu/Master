﻿// ***********************************************************************
// Assembly         : Logging
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Class1.cs" company="Logging">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace Logging
{
    /// <summary>
    /// Class Class1.
    /// </summary>
    public class Class1
    {
    }
}
