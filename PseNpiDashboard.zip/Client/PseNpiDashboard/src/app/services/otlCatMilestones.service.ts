import { Injectable } from '@angular/core';

import { Store } from '@ngrx/store';
import { IAppState } from '../store/accoladeReducer';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import * as EffectivenessAction from '../store/effectiveness/effectivenessAction';
import { saveAs } from 'file-saver';
@Injectable({
  providedIn: 'root'
})
export class otlCatMilestonesService {
 




  headers: any;

  constructor(private http: HttpClient, private store: Store<IAppState>, ) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
      withCredentials: 'true',
    });
  }


  reportDownload(date) {
    console.log(date);
    this.http.get('http://localhost:49855/effectivene?date=' + date, { responseType: 'blob', headers: this.headers })
      .subscribe(response => {
        saveAs(response, 'EffectivenessAnalysis-' + date + '.xlsx',
          { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
      },
        err => {
          console.log(`ERROR: ${err}`),
          console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service');
        });
  }

  getAllEffectivenessParts() {
   // throw new Error("Method not implemented.");
  }

  reportDownloadByFilter(pliModel: { sbu: string; ipdsPhase: string; pliRating: string; gbe: string; }) {
  //  throw new Error("Method not implemented.");
  }
  reportDownloadAll() {
   // throw new Error("Method not implemented.");
  }


  loadByFilter(pliModel) {
   
  }


  getEffectivenes(date) {
    console.log('http://localhost:49855/api/Effectiveness?date=');
    this.http.get<any>('http://localhost:49855/api/Effectiveness?date=' + date)
      .subscribe(values => this.store.dispatch(new EffectivenessAction.LoadEffectiveness(values),
      ),
        err => { console.log(`ERROR: ${err}`); });
  }


  saveEffectivenes(modifieditems) {
    console.log('saveCompliance' + modifieditems );
    return this.http.post('http://localhost:49855/api/Effectiveness', modifieditems,  { headers: this.headers})
      .subscribe(infoData => console.log(infoData)      );
  }
}
