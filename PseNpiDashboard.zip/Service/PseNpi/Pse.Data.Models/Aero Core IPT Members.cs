//using Oracle.Data.Access;

//namespace Pse.Data.Models
//{
//    public class Aero_Core_IPT
//    {
//        [Columns("Keycode")]
//        public string Keycode { get; set; }

//        [Columns("IPDS_Current_Phase")]
//        public string IPDS_Current_Phase { get; set; }

//        [Columns("Coupled_De_coupled")]
//        public string Coupled_De_coupled { get; set; }

//        [Columns("H_W_Development_Scope")]
//        public string H_W_Development_Scope { get; set; }

//        [Columns("S_W_Development_Scope")]
//        public string S_W_Development_Scope { get; set; }

//        [Columns("Product_Manager")]
//        public string Product_Manager { get; set; }

//        [Columns("Program_Manager")]
//        public string Program_Manager { get; set; }

//        [Columns("PP_C")]
//        public string PP_C { get; set; }

//        [Columns("Project_Engineer")]
//        public string Project_Engineer { get; set; }

//        [Columns("mfg_Engineer_AME")]
//        public string Advance_Manufacturing_Engineer_AME { get; set; }

//        [Columns("PSE_Launch_Engineer")]
//        public string PSE_Launch_Engineer { get; set; }

//        [Columns("APQP_Engineer")]
//        public string APQP_Engineer { get; set; }

//        [Columns("Sourcing_PM")]
//        public string Sourcing_PM { get; set; }

//        [Columns("Contracts")]
//        public string Contracts { get; set; }

//        [Columns("Supplier_APQP")]
//        public string Supplier_APQP { get; set; }

//        [Columns("PM_Chief")]
//        public string PM_Chief { get; set; }

//        [Columns("CPS")]
//        public string CPS { get; set; }

//        [Columns("Contracts_Representative")]
//        public string Contracts_Representative { get; set; }
//    }
//}