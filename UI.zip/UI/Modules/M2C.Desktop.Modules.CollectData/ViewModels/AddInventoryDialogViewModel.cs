﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="AddInventoryDialogViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Mappers;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core;
using M2C.Desktop.Modules.CollectData.Constants;
using M2C.Desktop.Modules.CollectData.Views.InventoryControls;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using M2C.Business.GlobalFields;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// This class work as a dialog box and Inventory Container.
    /// it provide Data and Columns to grid.
    /// </summary>
    public class AddInventoryDialogViewModel : BindableBase, IDialogAware
    {
        #region Class fields

        /// <summary>
        /// The region manager
        /// </summary>
        private readonly IRegionManager _regionManager;

        /// <summary>
        /// The is read configuration visible
        /// </summary>
        private bool _isReadConfigurationVisible;

        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// The inventory mapper
        /// </summary>
        private readonly IInventoryMapper _inventoryMapper;

        /// <summary>
        /// The years
        /// </summary>
        private Years _years;

        /// <summary>
        /// Get selected node from tree
        /// </summary>
        private INode _selectNode;

        /// <summary>
        /// The selected inventory control
        /// </summary>
        private ICommonInventory _selectedInventoryControl;

        #endregion Class fields

        #region Event and Command

        /// <summary>
        /// Gets or sets the close dialog command.
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }

        /// <summary>
        /// Gets or sets the navigate command.
        /// </summary>
        /// <value>The navigate command.</value>
        public DelegateCommand<string> NavigateCommand { get; set; }

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        #endregion Event and Command

        #region Properties

        /// <summary>
        /// Ui Property use for set Visibility to Read Config Radio button
        /// </summary>
        /// <value><c>true</c> if this instance is read configuration visible; otherwise, <c>false</c>.</value>
        public bool IsReadConfigurationVisible
        {
            get => _isReadConfigurationVisible;
            set => SetProperty(ref _isReadConfigurationVisible, value);
        }

        #endregion Properties

        /// <summary>
        /// Initialize class fields
        /// </summary>
        /// <param name="regionManager">The region manager.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        public AddInventoryDialogViewModel(IRegionManager regionManager, IEventAggregator eventAggregator, IInventoryMapper inventoryMapper)
        {
            _eventAggregator = eventAggregator;
            _inventoryMapper = inventoryMapper;
            _regionManager = regionManager;
            _regionManager.RegisterViewWithRegion(RegionNames.InventoryRegion, typeof(ReferenceControl));

            CloseDialogCommand = new DelegateCommand<string>(OnCloseAction);
            NavigateCommand = new DelegateCommand<string>(ExecuteNavigation);
        }

        /// <summary>
        /// Event handler when radio button change
        /// </summary>
        /// <param name="path">The path.</param>
        private void ExecuteNavigation(string path)
        {
            _regionManager.RequestNavigate(RegionNames.InventoryRegion, path);

            //Get selected control
            _selectedInventoryControl = GetActiveInventory();
        }

        /// <summary>
        /// While closing the  Dialog box.
        /// Handle when user click ok or cancel
        /// </summary>
        /// <param name="commandParam">The command parameter.</param>
        private void OnCloseAction(string commandParam)
        {
            var parameters = new DialogParameters();
            if (string.Compare(commandParam, CollectionConstant.Ok, StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                //work for current selected inventory
                if (_selectedInventoryControl.SelectedProduct != null && !string.IsNullOrEmpty(_selectedInventoryControl.SelectedProduct.Identifier))

                    parameters.Add(CollectionConstant.Add, _inventoryMapper.Map(_selectedInventoryControl.SelectedProduct, _selectNode, _years));
                // event for send data to handler
                //  _eventAggregator.GetEvent<InventoryModelEvent>().Publish(new List<Inventory> { _inventoryMapper.Map(_selectedInventoryControl.SelectedProduct, _parentNodeTypeAndName) });

                //Work for read Config
                else if (_selectedInventoryControl.SelectedProduct == null && _selectedInventoryControl.SelectedProducts != null && _selectedInventoryControl.SelectedProducts.Count > 0)
                {
                    var inventories = _inventoryMapper.Map(_selectedInventoryControl.SelectedProducts, _selectNode, _years);
                    parameters.Add(CollectionConstant.AddConfig, inventories);
                    //  _eventAggregator.GetEvent<InventoryModelEvent>().Publish(inventories);
                }
                else
                {
                    MessageBox.Show(CollectionConstant.MessageInventorySelection, CollectionConstant.AddInventory,
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                RequestClose?.Invoke(new DialogResult(ButtonResult.OK, parameters));
            }
            else
                RaiseRequestClose(new DialogResult(ButtonResult.Cancel));
        }

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        private void RaiseRequestClose(DialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }

        #region IDialogAware functions

        /// <summary>
        /// Title of dialog
        /// </summary>
        /// <value>The title.</value>
        public string Title => CollectionConstant.AddInventory;

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
            _regionManager.Regions.Remove(RegionNames.InventoryRegion);
        }

        /// <summary>
        /// While opening the Dialog for Inventory.
        /// initializing some class variable
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            if (parameters.TryGetValue(CollectionConstant.InstalledBased, out Node installedBasedNode))
            {
                if (parameters.TryGetValue(CollectionConstant.Years, out Years years))
                    _years = years;

                IsReadConfigurationVisible = true;
                _selectNode = installedBasedNode;
            }
            if (parameters.TryGetValue(CollectionConstant.TechnicalResource, out Node technicalResourceNode))
            {
                if (parameters.TryGetValue(CollectionConstant.Years, out Years years))
                    _years = years;

                IsReadConfigurationVisible = false;
                _selectNode = technicalResourceNode;
            }
            GlobalFiled.SelectedNodeType = _selectNode.NodeType.ToString();
            GlobalFiled.CurrentSelectedNode = _selectNode;
            _selectedInventoryControl = GetActiveInventory();
        }

        #endregion IDialogAware functions

        #region Private Function

        /// <summary>
        /// Get Active Inventory or selected  Inventory as ICommonInventory
        /// </summary>
        /// <returns>ICommonInventory.</returns>
        private ICommonInventory GetActiveInventory()
        {
            if (!_regionManager.Regions.ContainsRegionWithName(RegionNames.InventoryRegion))
                return null;
            var region = _regionManager.Regions[RegionNames.InventoryRegion];

            if (!region.ActiveViews.Any()) return null;

            var dataContext = region.ActiveViews.Cast<UserControl>().FirstOrDefault()?.DataContext;
            return dataContext as ICommonInventory;
        }

        #endregion Private Function
    }
}