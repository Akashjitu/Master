﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="RestServiceRequest.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using RestClientServices.Contracts;
using System.Collections.Generic;

namespace RestClientServices.Services
{
    /// <summary>
    /// Class RestServiceRequest.
    /// Implements the <see cref="RestClientServices.Contracts.IRestServiceRequest" />
    /// </summary>
    /// <seealso cref="RestClientServices.Contracts.IRestServiceRequest" />
    public class RestServiceRequest : IRestServiceRequest
    {
        /// <summary>
        /// The URL parameters
        /// </summary>
        private Dictionary<string, object> urlParams = new Dictionary<string, object>();
        /// <summary>
        /// The queryparams
        /// </summary>
        private Dictionary<string, object> queryparams = new Dictionary<string, object>();
        /// <summary>
        /// The header parameters
        /// </summary>
        private Dictionary<string, object> headerParams = new Dictionary<string, object>();

        /// <summary>
        /// Gets or sets the resource path.
        /// </summary>
        /// <value>The resource path.</value>
        public string ResourcePath { get; set; }

        /// <summary>
        /// Gets or sets the type of the request.
        /// </summary>
        /// <value>The type of the request.</value>
        public RequestTypes RequestType { get; set; }
        /// <summary>
        /// Gets or sets the path parameters.
        /// </summary>
        /// <value>The path parameters.</value>
        public Dictionary<string, object> PathParams { get => urlParams; set => urlParams = value; }
        /// <summary>
        /// Gets or sets the queryparams.
        /// </summary>
        /// <value>The queryparams.</value>
        public Dictionary<string, object> Queryparams { get => queryparams; set => queryparams = value; }
        /// <summary>
        /// Gets or sets the header parameters.
        /// </summary>
        /// <value>The header parameters.</value>
        public Dictionary<string, object> HeaderParams { get => headerParams; set => headerParams = value; }

        /// <summary>
        /// Gets or sets the body parameter.
        /// </summary>
        /// <value>The body parameter.</value>
        public object BodyParam { get; set; }
    }
}