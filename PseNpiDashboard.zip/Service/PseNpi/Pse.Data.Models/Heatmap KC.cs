[Columns("Trim_KC")]
public string Trim_KC {get;set}
[Columns("Key_Code")]
public string Key_Code {get;set}
