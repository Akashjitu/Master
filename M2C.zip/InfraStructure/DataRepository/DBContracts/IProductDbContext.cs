﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProductDbContext.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogFilter;
using DomainModels.IbCatalogModels;
using Microsoft.EntityFrameworkCore;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IProductDbContext
    /// Implements the <see cref="DataRepository.DBContracts.IDbContext" />
    /// </summary>
    /// <seealso cref="DataRepository.DBContracts.IDbContext" />
    public interface IProductDbContext : IDbContext
    {
        /// <summary>
        /// Gets or sets the filter ib catalog bus.
        /// </summary>
        /// <value>The filter ib catalog bus.</value>
        DbSet<FilterIbCatalogBu> FilterIbCatalogBus { get; set; }

        /// <summary>
        /// Gets or sets the filter ib catalog product categories.
        /// </summary>
        /// <value>The filter ib catalog product categories.</value>
        DbSet<FilterIbCatalogProductCategory> FilterIbCatalogProductCategories { get; set; }

        /// <summary>
        /// Gets or sets the filter ib catalog status ip creations.
        /// </summary>
        /// <value>The filter ib catalog status ip creations.</value>
        DbSet<FilterIbCatalogStatusIpCreation> FilterIbCatalogStatusIpCreations { get; set; }

        /// <summary>
        /// Gets or sets the brands.
        /// </summary>
        /// <value>The brands.</value>
        DbSet<Brand> Brands { get; set; }

        /// <summary>
        /// Gets or sets the device types.
        /// </summary>
        /// <value>The device types.</value>
        DbSet<DeviceType> DeviceTypes { get; set; }

        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>The products.</value>
        DbSet<Product> Products { get; set; }

        /// <summary>
        /// Gets or sets the product entries.
        /// </summary>
        /// <value>The product entries.</value>
        DbSet<ProductEntry> ProductEntries { get; set; }

        /// <summary>
        /// Gets or sets the ranges.
        /// </summary>
        /// <value>The ranges.</value>
        DbSet<Range> Ranges { get; set; }

        /// <summary>
        /// Gets or sets the sub ranges.
        /// </summary>
        /// <value>The sub ranges.</value>
        DbSet<SubRange> SubRanges { get; set; }

        /// <summary>
        /// Gets or sets the sync history
        /// </summary>
        /// <value>The synchronize histories.</value>
        DbSet<SyncHistory> SyncHistories { get; set; }
    }
}