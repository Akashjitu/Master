﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.ProjectPlan
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="OptionsContainer.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Core.CommonValidations;
using System.Windows.Controls;
using System.Windows.Input;

namespace M2C.Desktop.Modules.ProjectPlan.Views
{
    /// <summary>
    /// Interaction logic for OptionsContainer
    /// </summary>
    public partial class OptionsContainer : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionsContainer" /> class.
        /// </summary>
        public OptionsContainer()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the <see cref="E:PreviewTextInput" /> event.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs" /> instance containing the event data.</param>
        public void OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !InputValidator.AreAllValidNumericChars(e.Text);
            if (!e.Handled)
            {
                e.Handled = !InputValidator.MaxLengthReached(e);
            }
            base.OnPreviewTextInput(e);
        }

        /// <summary>
        /// Numbers the validation text box.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs" /> instance containing the event data.</param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            e.Handled = InputValidator.IsNumber(e.Text);
        }
    }
}
