﻿using M2C.Business.Contracts;
using M2C.Desktop.Modules.CollectData.Test.MOCK;
using M2C.Desktop.Modules.CollectData.ViewModels.InventoryControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using Prism.Events;
using  System.Windows;
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Test.ViewModels.InventoryControls
{
    [TestClass]
    public class ReferenceControlViewModelTest
    {
        private ReferenceControlViewModel _referenceControlViewModel;
        private ICommonInventoryReference _commonInventoryReference;
        private IEventAggregator eventAggregator;

        [TestInitialize]
        public void Setup()
        {
            eventAggregator = new EventAggregator();
            _commonInventoryReference = Substitute.For<ICommonInventoryReference>();
            _referenceControlViewModel = new ReferenceControlViewModel(_commonInventoryReference, eventAggregator);
            _commonInventoryReference.GetProductsStartWithIdentifier(Arg.Any<string>()).Returns(MockProvider.GetProducts());
        }

        [TestMethod]
        public void ShouldReturnProductBasedOnSelection()
        {
            var c = new RoutedEventArgs(null, new TextBox() {Text = "s"});
            _referenceControlViewModel.OnKeyUpPChangeCommand.Execute(c);
            _referenceControlViewModel.OnReferenceChangeCommand.Execute(string.Empty);
            _referenceControlViewModel.SelectedProduct = MockProvider.GetProducts()[0];
            Assert.IsNotNull(_referenceControlViewModel.OnKeyUpPChangeCommand);
            Assert.IsNotNull(_referenceControlViewModel.OnReferenceChangeCommand);
            Assert.IsNotNull(_referenceControlViewModel.SelectedProduct);
            Assert.IsTrue(_referenceControlViewModel.Products != null && _referenceControlViewModel.Products.Count > 0);
        }
    }
}