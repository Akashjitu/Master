﻿using Pse.Data.Models;
using Pse.Services.Service;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class OtlSummeryController : ApiController
    {
        private IOtlSummeryService _service;

        public OtlSummeryController(IOtlSummeryService service)
        {
            _service = service;
        }

        [HttpGet]
        public HttpResponseMessage GeOtlSummery()
        {
            var cp = _service.LoadAllOtlSummery();
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        public HttpResponseMessage AddOtlSummery(OtlSummery otlSummery)
        {
            var cp = _service.AddOtlSummery(otlSummery);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPut]
        public HttpResponseMessage UpdateOtlSummery(int id,  OtlSummery otlSummery)
        {
            var cp = _service.UpdateOtlSummery(otlSummery);
            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}