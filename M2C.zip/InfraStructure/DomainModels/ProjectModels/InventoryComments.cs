﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="InventoryComments.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Inventory Comments
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class InventoryComments
    {
        /// <summary>
        /// Gets or sets the ProjectInventory
        /// </summary>
        /// <value>The identifier.</value>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Get set Product id
        /// </summary>
        /// <value>The project identifier.</value>
        public int ProjectId { get; set; }

        /// <summary>
        /// Get set Node Id
        /// </summary>
        /// <value>The node identifier.</value>
        public int NodeId { get; set; }

        /// <summary>
        /// Comment of Node
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets the type of the node.
        /// </summary>
        /// <value>The type of the node.</value>
        public int NodeType { get; set; }

        /// <summary>
        /// Collection node CustomerDocuments in Json
        /// </summary>
        /// <value>The customer documents.</value>
        public string CustomerDocuments { get; set; }

        /// <summary>
        /// Gets or sets the  project Id.
        /// </summary>
        /// <value>The project.</value>
        [ForeignKey("ProjectId")]
        public Project Project { get; set; }
    }
}
