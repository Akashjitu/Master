﻿// ***********************************************************************
// Assembly         : Schneider.M2C.OpenExcel.Parser
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IBImportModel.cs" company="Schneider.M2C.OpenExcel.Parser">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace Schneider.M2C.OpenExcel.Parser.Model
{
    /// <summary>
    /// Excel headers
    /// </summary>
    public class IBImportModel
    {
        /// <summary>
        /// Gets or sets the factory.
        /// </summary>
        /// <value>The factory.</value>
        [ExcelParserColumn(ExcelParserConstants.FACTORY)]
        public string Factory { get; set; }

        /// <summary>
        /// Gets or sets the workshop.
        /// </summary>
        /// <value>The workshop.</value>
        [ExcelParserColumn(ExcelParserConstants.WORKSHOP)]
        public string Workshop { get; set; }

        /// <summary>
        /// Gets or sets the line.
        /// </summary>
        /// <value>The line.</value>
        [ExcelParserColumn(ExcelParserConstants.LINE)]
        public string Line { get; set; }

        /// <summary>
        /// Gets or sets the machine.
        /// </summary>
        /// <value>The machine.</value>
        [ExcelParserColumn(ExcelParserConstants.MACHINE)]
        public string Machine { get; set; }

        /// <summary>
        /// Gets or sets the machine criticity.
        /// </summary>
        /// <value>The machine criticity.</value>
        [ExcelParserColumn(ExcelParserConstants.MACHINE_CRITICITY)]
        public string MachineCriticity { get; set; }

        /// <summary>
        /// Gets or sets the name of the configuration.
        /// </summary>
        /// <value>The name of the configuration.</value>
        [ExcelParserColumn(ExcelParserConstants.CONFIGURATION_NAME)]
        public string ConfigurationName { get; set; }

        /// <summary>
        /// Gets or sets the type of the configuration.
        /// </summary>
        /// <value>The type of the configuration.</value>
        [ExcelParserColumn(ExcelParserConstants.CONFIGURATION_TYPE)]
        public string ConfigurationType { get; set; }

        /// <summary>
        /// Gets or sets the reference.
        /// </summary>
        /// <value>The reference.</value>
        [ExcelParserColumn(ExcelParserConstants.REFERENCE)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        [ExcelParserColumn(ExcelParserConstants.DESCRIPTION)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the pv.
        /// </summary>
        /// <value>The pv.</value>
        [ExcelParserColumn(ExcelParserConstants.PV)]
        public string PV { get; set; }

        /// <summary>
        /// Gets or sets the sv.
        /// </summary>
        /// <value>The sv.</value>
        [ExcelParserColumn(ExcelParserConstants.SV)]
        public string SV { get; set; }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        [ExcelParserColumn(ExcelParserConstants.QUANTTY)]
        public string Quantity { get; set; }

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        [ExcelParserColumn(ExcelParserConstants.BRAND)]
        public string Brand { get; set; }

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        [ExcelParserColumn(ExcelParserConstants.COMMENT)]
        public string Comment { get; set; }
    }
}