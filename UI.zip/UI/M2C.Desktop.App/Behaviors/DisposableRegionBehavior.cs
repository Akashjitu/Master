﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 01-29-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="DisposableRegionBehavior.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Regions;
using System;
using System.Collections;
using System.Collections.Specialized;
using System.Windows;

namespace M2C.Desktop.App.Behaviors
{
    /// <summary>
    /// behavior which will call VM dispose methods
    /// </summary>
    /// <seealso cref="Prism.Regions.RegionBehavior" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DisposableRegionBehavior : RegionBehavior
    {
        /// <summary>
        /// The behavior key
        /// </summary>
        public const string BehaviorKey = "DisposableRegion";

        /// <summary>
        /// Override this method to perform the logic after the behavior has been attached.
        /// </summary>
        protected override void OnAttach()
        {
            Region.Views.CollectionChanged += OnActiveViewsChanged;
        }

        /// <summary>
        /// Called when [active views changed].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void OnActiveViewsChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Remove)
            {
                DisposeViewsOrViewModels(e.OldItems);
            }
        }

        /// <summary>
        /// Disposes the views or view models.
        /// </summary>
        /// <param name="views">The views.</param>
        private static void DisposeViewsOrViewModels(IList views)
        {
            foreach (var view in views)
            {
                var frameworkElement = view as FrameworkElement;
                if (frameworkElement != null)
                {
                    var disposableDataContext = frameworkElement.DataContext as IDisposable;
                    if (disposableDataContext != null)
                        disposableDataContext.Dispose();

                    if (view is IDisposable)
                    {
                        var disposableView = view as IDisposable;
                        disposableView.Dispose();
                    }
                }
            }
        }
    }
}