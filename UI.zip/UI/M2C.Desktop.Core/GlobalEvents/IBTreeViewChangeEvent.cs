﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IBTreeViewChangeEvent.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using Prism.Events;

namespace M2C.Desktop.Core.GlobalEvents
{
    /// <summary>
    /// Installed base navigation change events
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{M2C.Business.Models.Project.IBComponents.Node}" />
    public class IBTreeViewChangeEvent : PubSubEvent<INode>
    {
    }
}