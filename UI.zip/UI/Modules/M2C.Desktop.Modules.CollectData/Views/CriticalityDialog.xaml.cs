﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CriticalityDialog.xaml.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for CriticalityDialog.xaml
    /// </summary>
    public partial class CriticalityDialog : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CriticalityDialog" /> class.
        /// </summary>
        public CriticalityDialog()
        {
            InitializeComponent();
        }
    }
}