
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';

import { TtiPartAlignment } from '../model/ttiPartAlignment';

export const ADD_ACCOLADE = 'ADD_ACCOLADE';
export const LOAD_ACCOLADE = 'LOAD_ACCOLADE';
export const REMOVE_ACCOLADE = 'ADD_ACCOLADE';
export const UPDATE_ACCOLADE: string = 'UPDATE_ACCOLADE';

export class LoadAccolade implements Action {
    readonly type = LOAD_ACCOLADE;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload  :'+ JSON.stringify(payload));
    }
}

export class AddAccolade implements Action {
    readonly type = ADD_ACCOLADE;

    constructor(public payload: TtiPartAlignment) {}
}

export class UpdateAccolade implements Action {
    readonly type = UPDATE_ACCOLADE;

    constructor(public payload: TtiPartAlignment) { }
}

export class RemoveAccolade implements Action {
    readonly type = REMOVE_ACCOLADE;

    constructor(public payload: number) { }
}


export type Actions = AddAccolade | RemoveAccolade | LoadAccolade;
