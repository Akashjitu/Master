﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Range = DomainModels.IbCatalogModels.Range;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class DevicetypeQueriesTest : TestBase
    {
        private IQueryable<DeviceType> deviceTypeList;
        private Mock<DbSet<DeviceType>> devicetypeMock;
        private IQueryable<Product> productList;
        private Mock<DbSet<Product>> productMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            Product productObj = new Product() { Id = 1, Brand = new Brand() { Id = 1 }, Range = new Range() { Id = 1 }, RangeId = 1, BrandId = 1, DeviceTypeId = 1, DeviceType = new DeviceType() { Id = 1 } };
            List<Product> product = new List<Product>() { productObj };
            productList = product.AsQueryable();

            DeviceType deviceTypeObj = new DeviceType() { Id = 1, Products = product, Type = "TYPE1", ConfigType = "1" };
            List<DeviceType> device = new List<DeviceType>() { deviceTypeObj };
            deviceTypeList = device.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();
            devicetypeMock = MockRepo.Create<DbSet<DeviceType>>();
            devicetypeMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(deviceTypeList.Provider);
            devicetypeMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(deviceTypeList.Expression);
            devicetypeMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(deviceTypeList.ElementType);
            devicetypeMock.As<IQueryable<DeviceType>>().Setup(m => m.GetEnumerator()).Returns(deviceTypeList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.DeviceTypes).Returns(devicetypeMock.Object);

            productMock = MockRepo.Create<DbSet<Product>>();
            productMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(productList.Provider);
            productMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(productList.Expression);
            productMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(productList.ElementType);
            productMock.As<IQueryable<Product>>().Setup(m => m.GetEnumerator()).Returns(productList.GetEnumerator());//added
            IProductDbContextMock.Setup(x => x.Products).Returns(productMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void DevicetypeQueriesTestConstructorTest()
        {
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            deviceType.Should().NotBeNull();
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void DevicetypeQueriesSaveDeviceTypesTest()
        {
            DeviceType deviceTypeObject = new DeviceType() { Id = 1, Type = "type1", ConfigType = "1" };
            List<DeviceType> devicetypes = new List<DeviceType>() { deviceTypeObject };
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            Action action = () => deviceType.SaveDeviceTypes(null);
            action.Should().NotThrow();
            action = () => deviceType.SaveDeviceTypes(devicetypes);
            action.Should().NotThrow();

            deviceTypeObject.Id = 0;
            deviceTypeObject.Type = "type2";

            action = () => deviceType.SaveDeviceTypes(devicetypes);
            action.Should().NotThrow();
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void DevicetypeQueriesLoadDeviceTypesTest()
        {
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            List<DeviceType> devicetypRes = deviceType.LoadDeviceTypes();
            devicetypRes.Should().HaveCount(1);
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void DevicetypeQueriesLoadDeviceTypesbyDevicetypeTest()
        {
            DeviceType deviceTypeObj = null;
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);

            List<DeviceType> devicetypRes = deviceType.LoadDeviceTypes(deviceTypeObj);
            devicetypRes.Should().BeNull();
            deviceTypeObj = new DeviceType() { Id = 1, Type = "type1" };
            devicetypRes = deviceType.LoadDeviceTypes(deviceTypeObj);
            devicetypRes.Should().HaveCount(1);
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void DevicetypeQueriesLoadDeviceTypesbytypeTest()
        {
            string type = null;
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            type = "type1";
            List<DeviceType> devicetypRes = deviceType.LoadDeviceTypes(type);
            devicetypRes.Should().HaveCount(1);
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void DevicetypeQueriesGetDeviceTypesByBrandAndRangeIdTest()
        {
            int brandID = 1;
            int rangeID = 1;
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            List<DeviceType> devicetypRes = deviceType.GetDeviceTypesByBrandAndRangeId(brandID, rangeID);
            devicetypRes.Should().HaveCount(1);
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void DevicetypeQueriesGetDeviceTypesByBrandIdTest()
        {
            int brandID = 1;

            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            List<DeviceType> devicetypRes = deviceType.GetDeviceTypesByBrandId(brandID);
            devicetypRes.Should().HaveCount(1);
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void GetDeviceTypesByNodeTypeTest()
        {
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            List<DeviceType> devicetypRes = deviceType.GetDeviceTypesByNodeType("1");
            devicetypRes.Should().NotBeNull();

            devicetypRes = deviceType.GetDeviceTypesByNodeType("2");
            devicetypRes.Should().NotBeNull();
            ((IDisposable)deviceType).Dispose();
        }

        [TestMethod]
        public void GetDeviceTypesByBrandIdAndNodeTypeTest()
        {
            IDeviceTypeQueries deviceType = new ProductQueries(IDbContextFactoryMock.Object);
            List<DeviceType> devicetypRes = deviceType.GetDeviceTypesByBrandIdAndNodeType(1, "1");
            devicetypRes.Should().NotBeNull();
            devicetypRes = deviceType.GetDeviceTypesByBrandIdAndNodeType(1, "2");
            devicetypRes.Should().NotBeNull();
            ((IDisposable)deviceType).Dispose();
        }

    }
}