﻿using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.Charts.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Prism.Events;

namespace M2C.Desktop.Modules.Charts.ViewModels
{
    /// <summary>
    /// Interaction logic for ChartToolBar
    /// </summary>
    [TestClass]
    public class ChartToolBarViewModelTest
    {
        private ChartToolBarViewModel _chartToolBarViewModel;
        private IEventAggregator _eventAggregator;
        private ISharedContextService sharedContextService;

        [TestInitialize]
        public void Setup()
        {
            _eventAggregator = new EventAggregator();
            _chartToolBarViewModel = new ChartToolBarViewModel(_eventAggregator, sharedContextService);
            _eventAggregator.GetEvent<IBTreeViewChangeEvent>().Publish(ChartMockProvide.GetInstalledBasedNodeTree());
            _eventAggregator.GetEvent<TRTreeViewChangeEvent>().Publish(ChartMockProvide.GetTechnicalResourceNodeTree());
        }

        [TestMethod]
        public void ShouldProvideDefaultValue()
        {
            Assert.IsTrue(_chartToolBarViewModel.Years.Count > 0);
            Assert.IsTrue(_chartToolBarViewModel.DefineIndicator.Count > 0);
            Assert.IsTrue(_chartToolBarViewModel.ChartMappings.Count > 0);
        }

        [TestMethod]
        public void ShouldCallInventoryChangeEvent()
        {
            _chartToolBarViewModel.SelectInventoryType = "Installed Base";

            Assert.IsTrue(_chartToolBarViewModel.Years.Count > 0);
            Assert.IsTrue(_chartToolBarViewModel.DefineIndicator.Count > 0);
            Assert.IsTrue(_chartToolBarViewModel.ChartMappings.Count > 0);

            Assert.IsNotNull(_chartToolBarViewModel.ChartParameterNodes);
            Assert.IsNotNull(_chartToolBarViewModel.ChartParameter);
            Assert.IsTrue(_chartToolBarViewModel.SelectChartMapping == "Mapping");
            Assert.IsTrue(_chartToolBarViewModel.ChartParameter.SelectInventoryType == _chartToolBarViewModel.SelectInventoryType);
            Assert.IsTrue(_chartToolBarViewModel.ChartParameterNodes.Count > 0);
            Assert.IsTrue(_chartToolBarViewModel.ChartParameter.AllParameterNodes.Count > 0);
        }

        [TestMethod]
        public void ShouldCallMappingChangeEvent()
        {
            _chartToolBarViewModel.SelectChartMapping = "Obsolescence";
            Assert.IsTrue(_chartToolBarViewModel.IsYearEnable);
            Assert.IsFalse(_chartToolBarViewModel.IsTreeEnable);
            Assert.IsTrue(_chartToolBarViewModel.ChartParameter.SelectedParameterNode == null);
            Assert.IsTrue(_chartToolBarViewModel.XAxisCount.Count == 0);
        }
    }
}