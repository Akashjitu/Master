﻿using System;
using DataManagement.Data.Models;
using System.Collections.Generic;

namespace Data.Management.Services.Manager
{
    public interface IDataManagementManage
    {
        List<DataManagementTrack> LoadAllDataManagements();
        List<DataManagementTrack> LoadById(int id);
        List<DataManagementTrack> LoadByDate(DateTime created);

       DataManagementTrack AddNew(DataManagementTrack dataManagement);
        DataManagementTrack UpdateData(DataManagementTrack dataManagement);
    }
}