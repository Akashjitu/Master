﻿using Fraca.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fraca.Service.DataBaseAccessObject.Loader
{
    public interface IServiceDataLoader
    {
        FracaData GetAllFracaData();

        FracaData GetFracaById(string Fracaid);
        FracaData GetFracaByDate(FracaCriteria criteria);
        FracaData GetFracaByFilter(FracaCriteria criteria);
         FracaData GetFracaByPartNo(string partNo);

    }
}
