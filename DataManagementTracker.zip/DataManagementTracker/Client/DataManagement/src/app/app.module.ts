import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TranslateModule } from '@ngx-translate/core';
import { StoreModule } from '@ngrx/store';
import { DpDatePickerModule } from 'ng2-date-picker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { GridsterModule } from 'angular-gridster2';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AgGridModule } from 'ag-grid-angular';
import { dataManagementReducer } from './store/dataManagement/dataManagementReducer';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { AccordionModule } from 'primeng/accordion';

import { UserInfoComponent } from './admin/user-info/user-info.component';
import { UserControlComponent } from './admin/user-control/user-control.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { DataManagmentGridComponent } from './dataManagmentView/dataManagmentGrid.component';
import { UiSwitchModule } from 'ngx-ui-switch';
import { NotifierModule, NotifierOptions, NotifierService } from 'angular-notifier';
import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule,
} from '@angular/material';
import { RequestorEntryComponent } from './requestor-entry/requestor-entry.component';
import { DataManagementEntryComponent } from './data-management-entry/data-management-entry.component';
import { referenceReducer } from './store/reference/referenceReducer';
import { ReferenceService } from './services/referenceService';
import { ShareDataService } from './services/share-data.service';
import { EmployeeService } from './services/employeeService';
import {DatePipe} from '@angular/common';
import { FeedbackComponent } from './feedback/feedback.component';
import { userAccessReducer } from './store/userAccessRight/userAccessttReducer';
import { UserFinderComponent } from './admin/user-finder/user-finder.component';
const customNotifierOptions: NotifierOptions = {
  position: {
		horizontal: {
			position: 'right',
			distance: 12
		},
		vertical: {
			position: 'top',
			distance: 12,
			gap: 10
		}
	},
  theme: 'material',
  behaviour: {
    autoHide: 5000,
    onClick: 'hide',
    onMouseover: 'pauseAutoHide',
    showDismissButton: true,
    stacking: 4
  },
  animations: {
    enabled: true,
    show: {
      preset: 'slide',
      speed: 300,
      easing: 'ease'
    },
    hide: {
      preset: 'fade',
      speed: 300,
      easing: 'ease',
      offset: 50
    },
    shift: {
      speed: 300,
      easing: 'ease'
    },
    overlap: 150
  }
};

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    //AngularFontAwesomeModule,
    DataManagmentGridComponent,
    UserControlComponent,
    UserInfoComponent,
    RequestorEntryComponent,
    DataManagementEntryComponent,
    FeedbackComponent,
    UserFinderComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    DpDatePickerModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    AccordionModule,
    GridsterModule,
    NgxSpinnerModule,
    AngularEditorModule,
    TranslateModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot(),
    AgGridModule.withComponents([]),
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    ModalModule.forRoot(),
    StoreModule.forRoot({
      dataManagementReducer: dataManagementReducer,
      referenceReducer: referenceReducer,
      userAccessReducer : userAccessReducer
    }),
    NotifierModule.withConfig(customNotifierOptions),
    UiSwitchModule
  ],
  providers: [ShareDataService, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
