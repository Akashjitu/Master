
import { Action } from '@ngrx/store';

export const LOAD_REFERENCE = 'LOAD_REFERENCE';

export class LoadReference implements Action {
    readonly type = LOAD_REFERENCE;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}
