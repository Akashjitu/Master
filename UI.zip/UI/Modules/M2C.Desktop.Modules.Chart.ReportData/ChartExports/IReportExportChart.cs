﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IReportExportChart.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.Drawing;
using M2C.Business.Models.Project;

namespace M2C.Desktop.Modules.Charts.ReportData.ChartExports
{
    /// <summary>
    /// Interface IReportExportChart
    /// </summary>
    public interface IReportExportChart
    {
        /// <summary>
        /// Gets or sets the installed base node.
        /// </summary>
        /// <value>The installed base node.</value>
        INode InstalledBaseNode { get; set; }
        /// <summary>
        /// Gets or sets the tr node.
        /// </summary>
        /// <value>The tr node.</value>
        INode TrNode { get; set; }
        /// <summary>
        /// Exports the specified chart images.
        /// </summary>
        /// <param name="chartImages">The chart images.</param>
        /// <param name="headingValue">The heading value.</param>
        /// <param name="exportType">Type of the export.</param>
        /// <param name="saveFileLocation">The save file location.</param>
        void Export(List<Image> chartImages, string headingValue, ExportType exportType, string saveFileLocation);
    }
}