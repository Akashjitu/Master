﻿using Oracle.Data.Access;
using System;

namespace Pse.Data.Models
{
    public class EffectivenessAnalysis
    {
        [Columns("p_ID")]
        public int Id { get; set; }

        [Columns("p_ACCOLADE_KC")]
        public string KC { get; set; }

        [Columns("p_Site")]
        public string Site { get; set; }

        [Columns("p_SBU")]
        public string SBU { get; set; }

        [Columns("p_Part")]
        public string Part { get; set; }

        [Columns("p_QN")]
        public string QN { get; set; }

        [Columns("p_Serial_No")]
        public string SerialNo { get; set; }

        [Columns("p_Notification")]
        public DateTime Notification { get; set; }

        [Columns("p_Material_Description")]
        public string MaterialDescription { get; set; }

        [Columns("p_Cause_Code")]
        public string CauseCode { get; set; }

        [Columns("p_Cause_Code_Description")]
        public string CauseCodeDescription { get; set; }

        [Columns("p_Car_Issue")]
        public DateTime CarIssue { get; set; }

        [Columns("p_Title")]
        public string Title { get; set; }

        [Columns("p_Make")]
        public string Make { get; set; }

        [Columns("p_Cause_Text")]
        public string CauseText { get; set; }

        [Columns("p_Rcca_Cause")]
        public string RccaCause { get; set; }

        [Columns("p_RCCA_Cause_Group")]
        public string RccaCauseGroup { get; set; }

        [Columns("p_Ido_Caused")]
        public string IdoCaused { get; set; }

        [Columns("p_Status")]
        public string Status { get; set; }

        [Columns("p_Req_Text")]
        public string ReqText { get; set; }

        [Columns("p_Finding_Code")]
        public string FindingCode { get; set; }

        [Columns("p_Finding_Type")]
        public string FindingType { get; set; }

        [Columns("p_Direct_Cause")]
        public string DirectCause { get; set; }

        [Columns("p_Contributing_Cause")]
        public string ContributingCause { get; set; }

        [Columns("p_Root_Cause")]
        public string RootCause { get; set; }

        [Columns("p_Specific_Action")]
        public string SpecificAction { get; set; }

        [Columns("P_Preventive_Action")]
        public string PreventiveAction { get; set; }

        [Columns("P_Systemic_Action")]
        public string SystemicAction { get; set; }

        [Columns("p_Qn_Age")]
        public string QnAge { get; set; }

        [Columns("P_CAR_TITLE")]
        public string CarTitle { get; set; }

        [Columns("p_Level_Description")]
        public string LevelDescription { get; set; }

        [Columns("p_Requester")]
        public string Requester { get; set; }

        [Columns("P_EXPORT_CONTROL")]
        public string ExportControl { get; set; }

        [Columns("P_MONTH")]
        public string Month { get; set; }

        [Columns("P_YEAR")]
        public string Year { get; set; }

        [Columns("p_ORIGINAL_SHIP")]
        public DateTime OriginalShip { get; set; }

        [Columns("p_OTL_Gradution")]
        public DateTime OtlGradution{ get; set; }

        [Columns("P_POST_OTL_IN_MONTHS")]
        public string PostOTLInMonths { get; set; }


        [Columns("P_PROGRAM")]
        public string Program { get; set; }

        [Columns("P_CREATED")]
        public DateTime CREATED      { get; set; }

        [Columns("P_UPDATED")]
        public DateTime UPDATED      { get; set; }

        [Columns("P_ACTIVATED")]
        public string ACTIVATED    { get; set; }


        [Columns("P_CREATED_BY")]
        public string CREATED_BY { get; set; }

    }
}