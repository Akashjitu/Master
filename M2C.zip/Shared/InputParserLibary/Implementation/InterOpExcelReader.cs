﻿// ***********************************************************************
// Assembly         : InputParserLibary
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="InterOpExcelReader.cs" company="InputParserLibary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using InputParserLibary.Contracts;
using Microsoft.Office.Interop.Excel;
using System;
using System.IO;
using System.Reflection;

namespace InputParserLibary.Implementation
{
    /// <summary>
    /// Class InterOpExcelReader.
    /// Implements the <see cref="InputParserLibary.Contracts.IExcelReader" />
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="InputParserLibary.Contracts.IExcelReader" />
    /// <seealso cref="System.IDisposable" />
    public class InterOpExcelReader: IExcelReader,IDisposable
    {
        /// <summary>
        /// The application factory
        /// </summary>
        private ICOMAppFactory appFactory;
        /// <summary>
        /// The excel application
        /// </summary>
        private Application excelApp;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="AppFactory">The application factory.</param>
        public InterOpExcelReader(ICOMAppFactory AppFactory)
        {
            this.appFactory = AppFactory;
        }

        /// <summary>
        /// Open the template file
        /// </summary>
        /// <param name="sourcePath">The source path.</param>
        public void openAsNewFile(string sourcePath)
        {
            excelApp = appFactory.getExcelApp();
            FileInfo file = new FileInfo(sourcePath);
            excelApp.Visible = true;
            var xlsFile = file.FullName;
            var wb = excelApp.Workbooks.Open(xlsFile, Missing.Value, Missing.Value, Missing.Value, Missing.Value,
                Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            wb.Saved = false;
        }
        /// <summary>
        /// dispose method
        /// </summary>
        public void Dispose()
        {
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(excelApp);
        }
    }
}
