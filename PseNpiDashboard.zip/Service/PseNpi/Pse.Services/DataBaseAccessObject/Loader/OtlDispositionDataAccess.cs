﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class OtlDispositionDataAccess : IOtlDispositionDataAccess
    {
        public List<OtlDispositionDetails> LoadOtlDispositionByDate(OtlDispositionDetails otlDisposition)
        {
            using (var dao = new DataAccessObject<OtlDispositionDetails>())
            {
                var data = dao.LoadByInput(otlDisposition, "PK_PSE_OTL_DISPOSITION.SP_LOAD_BY_MO_YY");
                var returndata = new List<OtlDispositionDetails>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlDispositionDetails> LoadOtlDispositionById(OtlDispositionDetails otlDisposition)
        {
            using (var dao = new DataAccessObject<OtlDispositionDetails>())
            {
                var data = dao.LoadByInput(otlDisposition, "PK_PSE_OTL_DISPOSITION.SP_LOAD_BY_ID");
                var returndata = new List<OtlDispositionDetails>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlDispositionDetails> LoadOtlDispositionByKeyCode(OtlDispositionDetails otlDisposition)
        {
            using (var dao = new DataAccessObject<OtlDispositionDetails>())
            {
                var data = dao.LoadByInput(otlDisposition, "PK_PSE_OTL_DISPOSITION.SP_LOAD_BY_KEY_CODE");
                var returndata = new List<OtlDispositionDetails>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public int UpdateOtlDispositionByID(OtlDispositionDetails otlDisposition)
        {
            using (var dao = new DataAccessObject<OtlDispositionDetails>())
            {
                return dao.Put(otlDisposition, "PK_PSE_OTL_DISPOSITION.SP_UPDATE_BY_ID");
            }
        }
    }
}