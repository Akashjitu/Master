﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pse.Data.Models;
using Oracle.Data.Access;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class OtlScoreCardDataAccess : IOtlScoreCardDataAccess
    {
        public OtlScoreCard AddOtlScoreCard(OtlScoreCard otlScoreCard)
        {

            using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var count = dao.Put(otlScoreCard, "PK_OTL_SCORE_CARD.SP_ADD_SP_ADD_SCORE_CARD");
                var data = dao.Load("PK_OTL_SCORE_CARD.SP_LOAD_LATEST_SCORE_CARD");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }

        public List<OtlScoreCard> LoadAllOtlScoreCards()
        {
            using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var data = dao.Load("PK_OTL_SCORE_CARD.SP_LOAD_OTL_SCORE_CARD");
                var returndata = new List<OtlScoreCard>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlScoreCard> LoadLatestOtlScoreCard(string keycode)
        {

              using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var data = dao.Load("PK_OTL_SCORE_CARD.SP_LOAD_LATEST_SCORE_CARD");
                var returndata = new List<OtlScoreCard>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlScoreCard> LoadOtlScoreCardByBaseLineDate(DateTime baselineDate)
        {
            using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var data = dao.LoadByInput(new OtlScoreCard { OTLBaselineDate = baselineDate }, "PK_OTL_SCORE_CARD.SP_LOAD_BASE_LINE");
                var returndata = new List<OtlScoreCard>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlScoreCard> LoadOtlScoreCardById(int Id)
        {
            using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var data = dao.LoadByInput(new OtlScoreCard { Id = Id }, "PK_OTL_SCORE_CARD.SP_LOAD_BY_ID");
                var returndata = new List<OtlScoreCard>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlScoreCard> LoadOtlScoreCardByKeyCode(string keycode)
        {
            using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var data = dao.LoadByInput(new OtlScoreCard { KeyCode = keycode }, "PK_OTL_SCORE_CARD.SP_LOAD_BY_KEY_CODE");
                var returndata = new List<OtlScoreCard>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlScoreCard> LoadScoreCardByCreationDate(DateTime creationDate)
        {
            using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var data = dao.LoadByInput(new OtlScoreCard { CreatedDate = creationDate }, "PK_OTL_SCORE_CARD.SP_LOAD_BY_MO_YY");
                var returndata = new List<OtlScoreCard>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public OtlScoreCard UpdateOtlScoreCard(OtlScoreCard otlScoreCard)
        {
            using (var dao = new DataAccessObject<OtlScoreCard>())
            {
                var count = dao.Put(otlScoreCard, "PK_OTL_SCORE_CARD.SP_UPDATE_SCORE_CARD");
                var data = dao.LoadByInput(otlScoreCard, "PK_OTL_SCORE_CARD.SP_LOAD_BY_ID");
                if (data == null || data.Count == 0)
                    return null;
                return data[0];
            }
        }
    }
}
