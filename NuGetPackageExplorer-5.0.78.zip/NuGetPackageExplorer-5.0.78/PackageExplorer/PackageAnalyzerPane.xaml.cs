﻿using System.Windows.Controls;

namespace PackageExplorer
{
    /// <summary>
    /// Interaction logic for PackageAnalyzerPane.xaml
    /// </summary>
    public partial class PackageAnalyzerPane : UserControl
    {
        public PackageAnalyzerPane()
        {
            InitializeComponent();
        }
    }
}