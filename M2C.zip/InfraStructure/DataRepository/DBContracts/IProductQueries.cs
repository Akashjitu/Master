﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="IProductQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IProductQueries
    /// </summary>
    public interface IProductQueries
    {
        /// <summary>
        /// Saves the products.
        /// </summary>
        /// <param name="products">The products.</param>
        void SaveProducts(List<Product> products);

        /// <summary>
        /// Loads the products.
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> GetProductsStartWithIdentifier(string identifier);

        /// <summary>
        /// Gets the product by ids.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="rangeId">The range identifier.</param>
        /// <param name="deviceId">The device identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> GetProductByIds(int brandId, int rangeId, int deviceId);

        /// <summary>
        /// Gets the products by device identifier and range identifier.
        /// </summary>
        /// <param name="rangeId">The range identifier.</param>
        /// <param name="deviceId">The device identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> GetProductsByDeviceIdAndRangeId(int rangeId, int deviceId);

        /// <summary>
        /// Gets the products Start With Identifier
        /// </summary>
        /// <param name="product">The product.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> GetProductsByIdOrIdentifier(Product product);

        /// <summary>
        /// Gets the products Start With Identifier and Config Node
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <param name="configNodeType"></param>
        /// <param name="isSe"></param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        List<Product> GetProductsStartWithIdentifier(string identifier, string configNodeType, bool isSe=true);

        /// <summary>
        /// Loads the products.
        /// </summary>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> LoadProducts();

        /// <summary>
        /// Get the Products Only
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        List<Product> GetProducts(string identifier);

        /// <summary>
        /// Get the First Product only by Count
        /// </summary>
        /// <param name="count">How many product, you want to Get</param>
        /// <returns>Collection Of Product</returns>
        List<Product> GetProductsByCount(int count = 2);

        /// <summary>
        /// Gets the products by identifier.
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>Product.</returns>
        Product GetProductsByIdentifier(string identifier);

       
    }
}