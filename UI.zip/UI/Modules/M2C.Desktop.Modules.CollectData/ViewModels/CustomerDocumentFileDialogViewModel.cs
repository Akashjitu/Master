﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CustomerDocumentFileDialogViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Windows;
using M2C.Business.Models.Project;
using Microsoft.Win32;
using System.IO;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class CustomerDocumentFileDialogViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    public class CustomerDocumentFileDialogViewModel : BindableBase, IDialogAware
    {
        #region Class field

        /// <summary>
        /// The file paths
        /// </summary>
        private string _filePaths;
        /// <summary>
        /// The name
        /// </summary>
        private string _name;
        /// <summary>
        /// The customer document
        /// </summary>
        private CustomerDocument _customerDocument;
        #endregion

        #region Binding Properties

        /// <summary>
        /// Get Set User Based Name
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get => _name;
            set => SetProperty(ref _name, value);
        }

        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>The file path.</value>
        public string FilePath
        {
            get => _filePaths;
            set => SetProperty(ref _filePaths, value);
        }

        #endregion
        #region Commands

        /// <summary>
        /// Provide action to  buttons.
        /// Like Add.
        /// </summary>
        /// <value>The action command.</value>
        public DelegateCommand<string> ActionCommand { get; set; }

        #endregion Commands

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerDocumentFileDialogViewModel" /> class.
        /// </summary>
        public CustomerDocumentFileDialogViewModel()
        {
            ActionCommand = new DelegateCommand<string>(OnActionCommand);
        }


        #region Command Function
        /// <summary>
        /// Called when [action command].
        /// </summary>
        /// <param name="value">The value.</param>
        private void OnActionCommand(string value)
        {
            if (string.IsNullOrEmpty(value))
                return;
            
            if (string.Compare(value, CollectionConstant.Add, StringComparison.OrdinalIgnoreCase) == 0)
            {
                SelectFileDialog();
                return;
            }
            if (string.Compare(value, CollectionConstant.Ok, StringComparison.OrdinalIgnoreCase) == 0)
            {
                if (string.IsNullOrEmpty(FilePath) || string.IsNullOrEmpty(Name))
                {
                    MessageBox.Show(CollectionConstant.MessageFileNamePath, CollectionConstant.Information,
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                   
                _customerDocument = new CustomerDocument()
                {
                    Name = Name,
                    FilePath = FilePath
                };
                var parameters = new DialogParameters { { CollectionConstant.Add, _customerDocument } };
                RequestClose?.Invoke(new DialogResult(ButtonResult.OK, parameters));
                return;
            }
            if (string.Compare(value, CollectionConstant.Cancel, StringComparison.OrdinalIgnoreCase) == 0)
            {
                RequestClose?.Invoke(new DialogResult(ButtonResult.Cancel));
            }
        }

        /// <summary>
        /// Selects the file dialog.
        /// </summary>
        private void SelectFileDialog()
        {
            var openFileDialog = new OpenFileDialog {Multiselect = false};
            FilePath = openFileDialog.ShowDialog() == true ? openFileDialog.FileName : string.Empty;
            if (!string.IsNullOrEmpty(FilePath))
                Name = string.IsNullOrEmpty(Name) ? Path.GetFileNameWithoutExtension(FilePath) : Name;
        }

        #endregion


        #region IDialogAware Implements

        /// <summary>
        /// Title of Dialog Box
        /// </summary>
        /// <value>The title.</value>
        public string Title => CollectionConstant.AddCustomerDocuments;

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// TO Enable close button
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Handler when Dialog Close
        /// </summary>
        public void OnDialogClosed()
        {
        }

        /// <summary>
        /// Handler when Dialog Open
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
        }

        #endregion IDialogAware Implements
    }
}