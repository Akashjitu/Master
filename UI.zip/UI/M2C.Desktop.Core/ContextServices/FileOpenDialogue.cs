﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="FileOpenDialogue.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Microsoft.Win32;

namespace M2C.Desktop.Core.ContextServices
{
    /// <summary>
    /// Class FileOpenDialogue.
    /// Implements the <see cref="M2C.Desktop.Core.ContextServices.IFileOpenDialogue" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Core.ContextServices.IFileOpenDialogue" />
    public class FileOpenDialogue : IFileOpenDialogue
    {
        /// <summary>
        /// Gets or sets the filter.
        /// </summary>
        /// <value>The filter.</value>
        public string Filter { get; set; }
        /// <summary>
        /// Gets or sets the name of the file.
        /// </summary>
        /// <value>The name of the file.</value>
        public string FileName { get; set; }

        /// <summary>
        /// Shows the dialog.
        /// </summary>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool ShowDialog()
        {
            OpenFileDialog _openFileDialog = new OpenFileDialog();
            _openFileDialog.Filter = Filter;
            if (_openFileDialog.ShowDialog() == true)
            {
                FileName = _openFileDialog.FileName;
                return true;
            }
            else
            {
                FileName = null;
                return false;
            }
        }
    }
}