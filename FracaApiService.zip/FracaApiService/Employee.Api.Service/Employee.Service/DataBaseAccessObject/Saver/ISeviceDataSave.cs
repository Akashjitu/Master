﻿using Fraca.Data.Models;

namespace Fraca.Service.DataBaseAccessObject.Saver
{
   public interface ISeviceDataSave
    {
        FracaInfo SaveFraca(FracaInfo fracaInfo);
        FracaInfo UpdateFraca(string fracaid, FracaInfo fracaInfo);
        void DeleteFraca(string fracaid);
    }
}
