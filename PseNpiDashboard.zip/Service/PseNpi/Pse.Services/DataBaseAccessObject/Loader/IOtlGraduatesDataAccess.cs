﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pse.Services.DataBaseAccessObject.Loader
{
 public interface IOtlGraduatesDataAccess
    {
        List<OtlGraduate> LoadAllOtlGraduates();

        List<OtlGraduate> LoadGraduatesByCreationDate(DateTime creationDate);

        List<OtlGraduate> LoadOtlGraduatesByKeyCode(string keycode);

        List<OtlGraduate> LoadLatestOtlGraduates();

        List<OtlGraduate> LoadOtlGraduatesById(int Id);

        OtlGraduate AddOtlGraduate(OtlGraduate otlGraduate);

        OtlGraduate UpdateOtlGraduate(OtlGraduate otlGraduate);
    }
}
