using System.Windows.Controls;

namespace xamlSpinnersWPF
{
    /// <summary>
    /// Interaction logic for ucSpinnerDotCircle.xaml
    /// </summary>
    public partial class ucSpinnerDotCircle : UserControl
    {
        public ucSpinnerDotCircle()
        {
            this.InitializeComponent();
        }
    }
}