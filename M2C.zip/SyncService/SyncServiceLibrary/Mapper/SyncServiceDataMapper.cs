﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-09-2020
// ***********************************************************************
// <copyright file="SyncServiceDataMapper.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using Schneider.M2C.OpenExcel.Parser.Model;
using SyncServiceLibrary.Model;
using System.Collections.Generic;
using System.Linq;

namespace SyncServiceLibrary.Mapper
{
    /// <summary>
    /// Class SyncServiceDataMapper.
    /// Implements the <see cref="SyncServiceLibrary.Mapper.ISyncServiceDataMapper" />
    /// </summary>
    /// <seealso cref="SyncServiceLibrary.Mapper.ISyncServiceDataMapper" />
    public class SyncServiceDataMapper : ISyncServiceDataMapper
    {
        /// <summary>
        /// Brands the map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;Brand&gt;.</returns>
        public List<Brand> BrandMap(params OneIbCatalog[] oneIbCatalogs)
        {
            return oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.BrandLegacy)).GroupBy(i => i.BrandLegacy).Select(i => new Brand
            {
                Name = i.Key,
            }).ToList();
        }

        /// <summary>
        /// Devices the type map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        public List<DeviceType> DeviceTypeMap(params OneIbCatalog[] oneIbCatalogs)
        {
            var dic = oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.DeviceTypeLegacy)).GroupBy(i => i.DeviceTypeLegacy).ToDictionary(i => i.Key, k => k.ToList());
            return dic.Select(x => new DeviceType
            {
                Type = x.Key,
                ConfigType = GetConfigurationType(x.Key),
                OpsTypeDescription = x.Value.FirstOrDefault(i => !string.IsNullOrEmpty(i.OpsDeviceTypeDescription)).OpsDeviceTypeDescription
            }).ToList();
        }

        /// <summary>
        /// Gets the type of the configuration.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>System.String.</returns>
        private static string GetConfigurationType(string type)
        {
            if (string.IsNullOrEmpty(type))
                return SyncService_Constants.NONE;
            if (type.ToUpper().StartsWith("PLC ") || type.ToUpper().StartsWith("SOLUTION") ||
                type.ToUpper().StartsWith("SOLUTION ") || type.ToUpper().StartsWith("AUTOMATION ") || type.ToUpper().StartsWith("NETWORKING "))
                return SyncService_Constants.PLC_CONFIG;

            if (type.ToUpper().StartsWith("MOTION ") || type.ToUpper().StartsWith("VARIABLE ") || type.ToUpper().StartsWith("SOFT "))
                return SyncService_Constants.MD_CONFIG;

            if (type.ToUpper().StartsWith("HMI "))
                return SyncService_Constants.SHMI_CONFIG;

            if (type.ToUpper().StartsWith("SOFTWARE "))
                return SyncService_Constants.OPEN_CONFIG;

            return SyncService_Constants.NONE;
        }

        /// <summary>
        /// Ranges the map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        public List<Range> RangeMap(params OneIbCatalog[] oneIbCatalogs)
        {
            var dic = oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.RangeLegacy)).GroupBy(i => i.RangeLegacy).ToDictionary(i => i.Key, k => k.ToList());
            return dic.Select(i => new Range
            {
                Name = i.Key,
                OpsDescription = i.Value.FirstOrDefault(x => !string.IsNullOrEmpty(x.OpsRangeDescription)).OpsRangeDescription,
            }).ToList();
        }

        /// <summary>
        /// Subs the range map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <param name="ranges">The ranges.</param>
        /// <returns>List&lt;SubRange&gt;.</returns>
        public List<SubRange> SubRangeMap(List<OneIbCatalog> oneIbCatalogs, List<Range> ranges)
        {
            var renge = ranges == null ? new Dictionary<string, int>() : ranges.GroupBy(i => i.Name).ToDictionary(k => k.Key, l => l.FirstOrDefault().Id);

            var dic = oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.SdhSubRangeDescription)).GroupBy(i => i.SdhSubRangeDescription).
                ToDictionary(i => i.Key, k =>
                new
                {
                    SdhCode = k.FirstOrDefault(i => !string.IsNullOrEmpty(i.SdhSubRangeCode)).SdhSubRangeCode,
                    RangeName = k.FirstOrDefault(i => !string.IsNullOrEmpty(i.RangeLegacy)).RangeLegacy
                });
            return dic.Select(i => new SubRange
            {
                SdhDescription = i.Key,
                SdhCode = i.Value.SdhCode,
                RangeId = renge.ContainsKey(i.Value.RangeName) ? renge[i.Value.RangeName] : 0,
            }).ToList();
        }

        /// <summary>
        /// Products the map.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <param name="brands">The brands.</param>
        /// <param name="deviceTypes">The device types.</param>
        /// <param name="ranges">The ranges.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> ProductMap(List<OneIbCatalog> oneIbCatalogs, List<Brand> brands, List<DeviceType> deviceTypes, List<Range> ranges)
        {
            if (oneIbCatalogs == null)
                return null;
            var brand = brands == null ? new Dictionary<string, int>() : brands.GroupBy(i => i.Name).ToDictionary(k => k.Key, l => l.FirstOrDefault().Id);
            var renge = ranges == null ? new Dictionary<string, int>() : ranges.GroupBy(i => i.Name).ToDictionary(k => k.Key, l => l.FirstOrDefault().Id);
            var deviceType = deviceTypes == null ? new Dictionary<string, int>() : deviceTypes.GroupBy(i => i.Type).ToDictionary(k => k.Key, l => l.FirstOrDefault().Id);

            return oneIbCatalogs.Select(i => new Product
            {
                Identifier = i.ProductIdentifier,
                IdentifierCategory = i.ProductIdentifierCategory,
                Description = i.ProductDescription,
                Serviceable = i.Serviceable,
                Traceable = i.Traceable,
                ServiceBusinessValue = i.ServiceBusinessValue,
                ObsolescenceYear = i.ObsolescenceYear,
                EndProductionOrPhaseOut = i.EndOfProductionOrPhaseOut,
                EndCommercialization = i.EndOfCommercialisation,
                EndServicesWithdrawalSupport = i.EndOfServicesYearOrWithdrawalYearOrEndOfSupport,
                BrandId = brand.ContainsKey(i.BrandLegacy) ? brand[i.BrandLegacy] : 0,
                RangeId = renge.ContainsKey(i.RangeLegacy) ? renge[i.RangeLegacy] : 0,
                DeviceTypeId = deviceType.ContainsKey(i.DeviceTypeLegacy) ? deviceType[i.DeviceTypeLegacy] : 0,
                FullName = string.IsNullOrEmpty(i.ProductDescription) ? i.ProductIdentifier : $"{i.ProductIdentifier} ({i.ProductDescription})",
                Version = i.Version
            }).ToList();
        }

        /// <summary>
        /// Synchronizes the history map.
        /// </summary>
        /// <param name="attempt">The attempt.</param>
        /// <param name="status">The status.</param>
        /// <returns>SyncHistory.</returns>
        public SyncHistory SyncHistoryMap(int attempt, int status)
        {
            return new SyncHistory()
            {
                RetryCount = attempt,
                Status = (int)SyncStatus.IN_PROGRESS
            };
        }
    }
}