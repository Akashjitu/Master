﻿using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.TRComponents;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Prism.Commands;
using Prism.Events;

namespace M2C.Desktop.Modules.CollectData.Test.ViewModels
{
    [TestClass]
    public class TRSideBarTreeViewModelTest : TestBase
    {
        private Mock<IGlobalTRCommands> mockGlobalTRCommand;
        private Mock<IEventAggregator> mockEventAggregator;
        private Mock<IExcelImport> mockExcelImport;
        private Mock<IExcelExport> mockExcelExport;
        private Mock<ISharedContextService> mocksharedContextService;
        private Mock<IFileOpenDialogue> mockFileOpenDialogue;
        private Mock<IInventoryMapper> _inventoryMapper;
        [TestInitialize]
        public void TestIniTialize()
        {
            _inventoryMapper= MockRepo.Create<IInventoryMapper>();
            mockGlobalTRCommand = MockRepo.Create<IGlobalTRCommands>();
            mockGlobalTRCommand.SetupGet(x => x.AddTRNodeCommand).Returns(new CompositeCommand());
            mockGlobalTRCommand.SetupGet(x => x.ImportTRComponentCommand).Returns(new CompositeCommand());
            mockGlobalTRCommand.SetupGet(x => x.ExportTRComponenetCommand).Returns(new CompositeCommand());
            mockEventAggregator = MockRepo.Create<IEventAggregator>();
            mockExcelImport = MockRepo.Create<IExcelImport>();
            mockExcelExport = MockRepo.Create<IExcelExport>();
            mocksharedContextService = MockRepo.Create<ISharedContextService>();
            mockFileOpenDialogue = MockRepo.Create<IFileOpenDialogue>();
            
        }

        [TestMethod]
        public void TRSideBarTreeViewModelObjectTest()
        {
            mockEventAggregator.Setup(t => t.GetEvent<ProjectChangeEvent>()).Returns(new ProjectChangeEvent());
            TRSideBarTreeViewModel trSideBarTreeViewModel = new TRSideBarTreeViewModel(mockGlobalTRCommand.Object, mocksharedContextService.Object, mockEventAggregator.Object, mockExcelImport.Object, mockFileOpenDialogue.Object, mockExcelExport.Object, _inventoryMapper.Object);
            if (trSideBarTreeViewModel.ComponentsCommand != null)
                Assert.IsTrue(true, "SideBarTreeViewModel Created");
        }

        [TestMethod]
        public void OnImportTRComponentTest()
        {
            mockEventAggregator.Setup(t => t.GetEvent<ProjectChangeEvent>()).Returns(new ProjectChangeEvent());
            mocksharedContextService.Setup(x => x.Get<ProjectContextModel>(It.IsAny<string>())).Returns(new ProjectContextModel()); 
            TRSideBarTreeViewModel trSideBarTreeViewModel = new TRSideBarTreeViewModel(mockGlobalTRCommand.Object, mocksharedContextService.Object, mockEventAggregator.Object, mockExcelImport.Object, mockFileOpenDialogue.Object, mockExcelExport.Object, _inventoryMapper.Object);
            mockFileOpenDialogue.Setup(x => x.ShowDialog()).Returns(true);
            mockFileOpenDialogue.Setup(x => x.FileName).Returns(@"MOCK\StockLatest.xlsx"); 
            mockExcelImport.Setup(x => x.TRBaseNodeImport(@"MOCK\StockLatest.xlsx")).Returns(new TRNode());
            Assert.IsNotNull(trSideBarTreeViewModel.ComponentsCommand.ImportTRComponentCommand);
            trSideBarTreeViewModel.OnImportTrComponent();
        }
    }
}