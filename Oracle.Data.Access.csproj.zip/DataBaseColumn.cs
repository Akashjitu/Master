﻿using System;

namespace Oracle.Data.Access
{
    public class Columns : Attribute
    {
        public string DataBaseColumnName;

        public Columns(string dataBaseColumnName)
        {
            DataBaseColumnName = dataBaseColumnName;
        }

    }
}
