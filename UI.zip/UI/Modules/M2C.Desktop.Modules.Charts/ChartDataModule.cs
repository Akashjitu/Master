﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-06-2020
// ***********************************************************************
// <copyright file="ExportReportDataModule.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************

using M2C.Desktop.Modules.Charts.ElementProvides;
using Prism.Ioc;
using Prism.Modularity;

namespace M2C.Desktop.Modules.Charts.ReportData
{
    /// <summary>
    /// Class ChartDataModule.
    /// Implements the <see cref="Prism.Modularity.IModule" />
    /// </summary>
    /// <seealso cref="Prism.Modularity.IModule" />
    public class ChartDataModule : IModule
    {
        /// <summary>
        /// Notifies the module that it has been initialized.
        /// </summary>
        /// <param name="containerProvider">The container provider.</param>
        public void OnInitialized(IContainerProvider containerProvider)
        {
        }

        /// <summary>
        /// Registers the types.
        /// </summary>
        /// <param name="containerRegistry">The container registry.</param>
        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<IBarElementProvider, BarElementProvider>();
            containerRegistry.Register<IConfigMappingElementProvider, ConfigMappingElementProvider>();
            containerRegistry.Register<IMappingElementProvider, MappingElementProvider>();
            containerRegistry.Register<IObsolescenceElementProvider, ObsolescenceElementProvider>();
            containerRegistry.Register<IObsolescenceMappingElementProvider, ObsolescenceMappingElementProvider>();
            containerRegistry.Register<ICriticalityElementProvider, CriticalityElementProvider>();
        }
    }
}