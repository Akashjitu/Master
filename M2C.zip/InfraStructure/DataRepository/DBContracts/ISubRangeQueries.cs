﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ISubRangeQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface ISubRangeQueries
    /// </summary>
    public interface ISubRangeQueries
    {
        /// <summary>
        /// Saves the sub ranges.
        /// </summary>
        /// <param name="subRanges">The sub ranges.</param>
        void SaveSubRanges(List<SubRange> subRanges);

        /// <summary>
        /// Loads the sub ranges.
        /// </summary>
        /// <param name="subRange">The sub range.</param>
        /// <returns>List&lt;SubRange&gt;.</returns>
        List<SubRange> LoadSubRanges(SubRange subRange);

        /// <summary>
        /// Loads the sub ranges.
        /// </summary>
        /// <returns>List&lt;SubRange&gt;.</returns>
        List<SubRange> LoadSubRanges();
    }
}