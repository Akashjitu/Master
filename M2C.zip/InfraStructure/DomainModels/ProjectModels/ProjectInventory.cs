﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProjectInventory.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class ProjectInventory.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ProjectInventory
    {
        /// <summary>
        /// Gets or sets the ProjectInventory
        /// </summary>
        /// <value>The identifier.</value>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Get set Product id
        /// </summary>
        /// <value>The project identifier.</value>
        public int ProjectId { get; set; }

        /// <summary>
        /// Gets or sets the  project Id.
        /// </summary>
        /// <value>The project.</value>
        [ForeignKey("ProjectId")]
        public Project Project { get; set; }

        /// <summary>
        /// The sub range identifier
        /// </summary>
        /// <value>The sub range identifier.</value>
        public int SubRangeId { get; set; }

        /// <summary>
        /// Gets or sets the MaintenanceZone for Stock.
        /// </summary>
        /// <value>The factory.</value>
        public string MaintenanceZone { get; set; }

        /// <summary>
        /// Gets or sets the MaintenanceZone Id for Stock.
        /// </summary>
        /// <value>The maintenance zone identifier.</value>
        public int MaintenanceZoneId { get; set; }

        /// <summary>
        /// Gets or sets the factory Id.
        /// </summary>
        /// <value>The factory identifier.</value>
        public int FactoryId { get; set; }

        /// <summary>
        /// Gets or sets the factory.
        /// </summary>
        /// <value>The factory.</value>
        public string Factory { get; set; }


        /// <summary>
        /// Gets or sets the workshop Id.
        /// </summary>
        /// <value>The workshop identifier.</value>
        public int WorkshopId { get; set; }

        /// <summary>
        /// Gets or sets the workshop.
        /// </summary>
        /// <value>The workshop.</value>
        public string Workshop { get; set; }

        /// <summary>
        /// Gets or sets the Line Id.
        /// </summary>
        /// <value>The line identifier.</value>
        public int LineId { get; set; }

        /// <summary>
        /// Gets or sets the line.
        /// </summary>
        /// <value>The line.</value>
        public string Line { get; set; }


        /// <summary>
        /// Gets or sets the Machine Id.
        /// </summary>
        /// <value>The machine identifier.</value>
        public int MachineId { get; set; }

        /// <summary>
        /// Gets or sets the machine.
        /// </summary>
        /// <value>The machine.</value>
        public string Machine { get; set; }

        /// <summary>
        /// Gets or sets the Configuration Id.
        /// </summary>
        /// <value>The configuration identifier.</value>
        public int ConfigurationId { get; set; }

        /// <summary>
        /// Gets or sets the configuration.
        /// </summary>
        /// <value>The configuration.</value>
        public string Configuration { get; set; }

        /// <summary>
        /// Gets or sets the type of the device.
        /// </summary>
        /// <value>The type of the device.</value>
        public string DeviceType { get; set; }

        /// <summary>
        /// Gets or sets the range.
        /// </summary>
        /// <value>The range.</value>
        public string Range { get; set; }

        /// <summary>
        /// Gets or sets the sub range.
        /// </summary>
        /// <value>The sub range.</value>
        public string SubRange { get; set; }

        /// <summary>
        /// Gets or sets the reference.
        /// </summary>
        /// <value>The reference.</value>
        public string Reference
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        public int Quantity { get; set; }

        /// <summary>
        /// Gets or sets the pv number.
        /// </summary>
        /// <value>The pv number.</value>
        public string PvNumber { get; set; }

        /// <summary>
        /// Gets or sets the sv number.
        /// </summary>
        /// <value>The sv number.</value>
        public string SvNumber { get; set; }

        /// <summary>
        /// Gets or sets the unit price.
        /// </summary>
        /// <value>The unit price.</value>
        public string UnitPrice
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the strategic.
        /// </summary>
        /// <value>The strategic.</value>
        public string Strategic { get; set; }

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public string Brand { get; set; }

        /// <summary>
        /// Gets or sets the year.
        /// </summary>
        /// <value>The year.</value>
        public string Year
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year1.
        /// </summary>
        /// <value>The year1.</value>
        public string Year1
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year2.
        /// </summary>
        /// <value>The year2.</value>
        public string Year2
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year3.
        /// </summary>
        /// <value>The year3.</value>
        public string Year3
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year4.
        /// </summary>
        /// <value>The year4.</value>
        public string Year4
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the dosa.
        /// </summary>
        /// <value>The dosa.</value>
        public string Dosa
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the do s.
        /// </summary>
        /// <value>The do s.</value>
        public string DoS
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the eo s.
        /// </summary>
        /// <value>The eo s.</value>
        public string EoS
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        public string Comment { get; set; }

        /// <summary>
        /// Gets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int BrandId { get;  set; }

        /// <summary>
        /// Gets the range identifier.
        /// </summary>
        /// <value>The range identifier.</value>
        public int RangeId { get;  set; }

        /// <summary>
        /// Gets the device type identifier.
        /// </summary>
        /// <value>The device type identifier.</value>
        public int DeviceTypeId { get;  set; }

        /// <summary>
        /// Get the criticality
        /// </summary>
        /// <value>The criticality.</value>
        public string Criticality { get; set; }

        /// <summary>
        /// Gets the Config type
        /// </summary>
        /// <value>The type of the configuration.</value>
        public string ConfigType { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public int Version { get; set; }

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public static void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProjectInventory>().Property(a => a.Id).ValueGeneratedOnAdd();
        }
    }
}