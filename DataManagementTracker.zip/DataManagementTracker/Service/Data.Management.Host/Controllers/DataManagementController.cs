﻿using DataManagement.Data.Models;
using Data.Management.Services;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Data.Management.Host.Controllers
{
    public class DataManagementController : ApiController
    {
        private readonly IDataManagementServices _dataManagementServices;

        public DataManagementController(IDataManagementServices dataManagementServices)
        {
            _dataManagementServices = dataManagementServices;
        }

        [HttpGet]
        public HttpResponseMessage LoadAllDataManagements()
        {

            var data= _dataManagementServices.LoadAllDataManagements();

            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }
        [HttpGet]
       public  HttpResponseMessage LoadById(int id)
        {
            var data = _dataManagementServices.LoadById(id);
            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpGet]
        public HttpResponseMessage LoadByDate(DateTime created)
        {
            var data = _dataManagementServices.LoadByDate(created);
            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }

        [HttpPost]
        public  HttpResponseMessage AddNew(DataManagementTrack dataManagement)
        {
            var data = _dataManagementServices.AddNew(dataManagement);
            return Request.CreateResponse(HttpStatusCode.OK, data, JsonMediaTypeFormatter.DefaultMediaType);
        }
    }
}