﻿using M2C.Business.Implementations;
using M2C.Business.Models;
using M2C.Business.Models.Chart;
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    /// <summary>
    /// Provide Obsolescence Chart Elements
    /// </summary>
    public class ObsolescenceElementProvider : IObsolescenceElementProvider
    {
        /// <summary>
        /// Provide Colors
        /// </summary>
        private readonly IStatusColorProvider _colorProvider;

        public ObsolescenceElementProvider(IStatusColorProvider colorProvider)
        {
            _colorProvider = colorProvider;
        }

        /// <summary>
        /// Get Obsolescence Chart Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetObsolescenceChartElements(ChartParameter chartParameter, NodeType type = NodeType.OPEN_CONFIG)
        {
            var elements = new ChartBarElements();
            var currentDate = DateTime.Today;
            elements.GreenChartElements.Clear();
            elements.RedChartElements.Clear();
            elements.YellowChartElements.Clear();

            var yearGaps = chartParameter.SelectedYear - currentDate.Year;
            var allConfigurationInventories = chartParameter.AllParameterNodes
                .Where(conf => conf.NodeType == type).SelectMany(i => i.Nodes.SelectMany(k => k.Inventories)).ToList();

            if (yearGaps < 0)
            {
                for (int i = yearGaps; i <= 0; i++)
                    FillObsolescenceCollection(allConfigurationInventories, currentDate.AddYears(i).Year, elements);
            }
            else
            {
                // for (var i = yearGaps; i >= 0; i--)
                for (var i = 0; i <= yearGaps; i++)
                    FillObsolescenceCollection(allConfigurationInventories, currentDate.AddYears(i).Year, elements);
            }

            return elements;
        }

        /// <summary>
        /// Fills the obsolescence collection.
        /// </summary>
        /// <param name="allConfigurationInventories">All configuration inventories.</param>
        /// <param name="xYear">The x year.</param>
        private void FillObsolescenceCollection(IEnumerable<Inventory> allConfigurationInventories, int xYear, ChartBarElements chartBarElements)
        {
            foreach (var inventory in allConfigurationInventories)
            {
                var color = _colorProvider.GetYearColor(xYear,
                    int.TryParse(inventory.Dosa, out var dosa) ? dosa : (int?)null,
                    int.TryParse(inventory.DoS, out var dos) ? dos : (int?)null,
                    int.TryParse(inventory.EoS, out var eos) ? eos : (int?)null);

                var redElement = chartBarElements.RedChartElements.FirstOrDefault(l => l.Name == xYear.ToString());
                if (redElement == null)
                {
                    redElement = new ChartBarElement() { Name = xYear.ToString() };
                    chartBarElements.RedChartElements.Add(redElement);
                }
                var yellowElement = chartBarElements.YellowChartElements.FirstOrDefault(l => l.Name == xYear.ToString());
                if (yellowElement == null)
                {
                    yellowElement = new ChartBarElement() { Name = xYear.ToString() };
                    chartBarElements.YellowChartElements.Add(yellowElement);
                }

                var greenElement = chartBarElements.GreenChartElements.FirstOrDefault(l => l.Name == xYear.ToString());
                if (greenElement == null)
                {
                    greenElement = new ChartBarElement() { Name = xYear.ToString() };
                    chartBarElements.GreenChartElements.Add(greenElement);
                }

                switch (color)
                {
                    //Red
                    case "#FFDC0A0A":
                        redElement.ConfigCount += inventory.Quantity;
                        break;
                    //Yellow
                    case "#FFFFD100":
                        yellowElement.ConfigCount += inventory.Quantity;
                        break;
                    //Green
                    case "#FF3DCD58":
                        greenElement.ConfigCount += inventory.Quantity;
                        break;
                }
            }
        }
    }
}