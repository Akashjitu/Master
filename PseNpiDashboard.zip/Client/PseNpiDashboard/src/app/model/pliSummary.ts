export interface PliSummary{
    keyCode: string;
    programName: string;
    programPM: string;
    sbu: string;
    gbe: string;
    ipdsPhase: string;
    irfHealth: string;
    crfHealth:string;
    eseHealth: string;
    rtyhealth: string;
    upc: string;
    apqpHealth: string;
    pliRating: string;
    otlCommnets: string;
    createdDate: Date;
    createdBy: string;
    updatedBy: string;
    active: string;
    updatedDate: Date;
    id: number;
    noOfNewParts: string;
    noOfNewPartsOnContract: string;
    eseNewVersion: string;
    irf: string;
    crf: string;
    eceEscapes: string;
}