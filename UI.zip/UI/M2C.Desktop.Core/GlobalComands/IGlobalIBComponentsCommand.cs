﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="IGlobalIBComponentsCommand.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Commands;

namespace M2C.Desktop.Core.GlobalComands
{
    /// <summary>
    /// Global command across all modules
    /// These commands for IB tree-view activities
    /// </summary>
    public interface IGlobalIBComponentsCommand
    {
        /// <summary>
        /// Gets the add node command.
        /// </summary>
        /// <value>The add node command.</value>
        CompositeCommand AddNodeCommand { get; }
        /// <summary>
        /// Gets the import ib componenet command.
        /// </summary>
        /// <value>The import ib componenet command.</value>
        CompositeCommand ImportIBComponenetCommand { get; }

        /// <summary>
        /// Gets the export ib componenet command.
        /// </summary>
        /// <value>The export ib componenet command.</value>
        CompositeCommand ExportIBComponenetCommand { get; }

        /// <summary>
        /// Gets the export ib Obsolescence command.
        /// </summary>
        /// <value>The export ib obsolescence command.</value>
        CompositeCommand ExportIBObsolescenceCommand { get; }

    }

    /// <summary>
    /// Class GlobalIBComponentsCommand.
    /// Implements the <see cref="M2C.Desktop.Core.GlobalComands.IGlobalIBComponentsCommand" />
    /// </summary>
    /// <seealso cref="M2C.Desktop.Core.GlobalComands.IGlobalIBComponentsCommand" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class GlobalIBComponentsCommand : IGlobalIBComponentsCommand
    {
        /// <summary>
        /// Gets the add node command.
        /// </summary>
        /// <value>The add node command.</value>
        public CompositeCommand AddNodeCommand { get; } = new CompositeCommand();
        /// <summary>
        /// Gets the import ib componenet command.
        /// </summary>
        /// <value>The import ib componenet command.</value>
        public CompositeCommand ImportIBComponenetCommand { get; } = new CompositeCommand();
        /// <summary>
        /// Gets the export ib componenet command.
        /// </summary>
        /// <value>The export ib componenet command.</value>
        public CompositeCommand ExportIBComponenetCommand { get; } = new CompositeCommand();

        /// <summary>
        /// Gets the export ib Obsolescence command.
        /// </summary>
        /// <value>The export ib obsolescence command.</value>
        public CompositeCommand ExportIBObsolescenceCommand { get; } = new CompositeCommand();
    }
}