import { DatePipe } from '@angular/common';

export class OtlDispositionColumns {
constructor(private datePipe: DatePipe){}

    static  columns =
     [
        { field: 'id',                              colId: 	    'id',	                   		hide: true,	    headerName: 	'Id',	},
        { field: 'productSbu',                      colId: 	'   productSbu',	       			hide: false,	headerName: 	'Product SBU',	},
        { field: 'programName',                     colId: 	    'programName',			        hide: false,	headerName: 	'Program Name',	},
        { field: 'heatmapKc',                        colId: 	'heatmapKc',	               	hide: false,	headerName: 	'Heatmap Key Code',	},
        { field: 'reasoning',                        colId: 	'reasoning',	               	hide: false,	    headerName: 	'Reasoning',	},
        { field: 'ipds',                             colId: 	'ipds',			                hide: false,	headerName: 	'IPDS',	},
        { field: 'pm',                               colId: 	 'pm',	       			        hide: true,	headerName: 	'PM',	},
        { field: 'gbe',                               colId: 	'gbe',	   			            hide: true,	headerName: 	'GBE',	},
        { field: 'otlDisposition',                    colId: 	'otlDisposition',	            hide: false,	headerName: 	'Otl Disposition',	},
        { field: 'scope',                             colId: 	'scope',			                hide: true,	headerName: 	'Scope',	},
        { field: 'productionSite',                               colId: 	 'productionSite',	       			        hide: true,	headerName: 	'Production Site',	},
        { field: 'actions',                               colId: 	'actions',	   			            hide: true,	headerName: 	'Actions',	},
        { field: 'engineeringSite',                    colId: 	'engineeringSite',	            hide: true,	headerName: 	'EngineeringSite',	},
        { field: 'pe',                    colId: 	'pe',	            hide: true,	headerName: 	'PE',	},
        { field: 'otlDispositionFinalReview',                    colId: 	'otlDispositionFinalReview',	            hide: true,	headerName: 	'Otl Disposition Final Review',	},
        { field: 'createdDate',                    colId: 	'createdDate',	            hide: true,	headerName: 	'Created Date',	},
        { field: 'updatedBy',                    colId: 	'updatedBy',	            hide: true,	headerName: 	'Updated By',	},
        { field: 'updateDate',                    colId: 	'updateDate',	            hide: true,	headerName: 	'Update Date',	},
        { field: 'ame',                    colId: 	'ame',	            hide: true,	headerName: 	'AMEme',	},
    ];

}