import { Action } from '@ngrx/store';
import { OtlGraduates } from 'src/app/model/otlGraduates';
export const ADD_OTL_GRADUATES = 'ADD_OTL_GRADUATES';
export const LOAD_OTL_GRADUATES  = 'LOAD_OTL_GRADUATES';
export const REMOVE_OTL_GRADUATES  = 'REMOVE_OTL_GRADUATES';
export const UPDATE_OTL_GRADUATES : string = 'UPDATE_OTL_GRADUATES';



export class LoadOtlGraduates implements Action {
    readonly type = LOAD_OTL_GRADUATES;

    constructor(public payload: any) {
    }
}

export class AddOtlGraduates implements Action {
    readonly type = ADD_OTL_GRADUATES;

    constructor(public payload: OtlGraduates) { }
}

export class UpdateOOtlGraduates implements Action {
    readonly type = UPDATE_OTL_GRADUATES;

    constructor(public payload: OtlGraduates) { }
}

export class RemoveOtlGraduates implements Action {
    readonly type = REMOVE_OTL_GRADUATES;

    constructor(public payload: number) { }
}


export type Actions = AddOtlGraduates | RemoveOtlGraduates | LoadOtlGraduates;
