﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="LineNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using DomainModels.ProjectModels;
using M2C.Business.Contracts;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Data;
using M2C.Business.GlobalFields;
using static System.String;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Class LineNode.
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class LineNode : Node, IChildNode, ICloneable, IDelete
    {
        /// <summary>
        /// The machine nodes
        /// </summary>
        private ObservableCollection<MachineNode> _machineNodes;

        /// <summary>
        /// Initializes a new instance of the <see cref="LineNode" /> class.
        /// </summary>
        public LineNode()
        {
            this.NodeType = NodeType.LINE;
            _machineNodes = new ObservableCollection<MachineNode>();
            MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LineNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public LineNode(string name)
        {
            this.NodeType = NodeType.LINE;
            this.Name = name;
            _machineNodes = new ObservableCollection<MachineNode>();
            MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LineNode" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="parentNode">The parent node.</param>
        public LineNode(int id, string name, INode parentNode)
        {
            Id = id;
            ParentNode = parentNode;
            NodeType = NodeType.LINE;
            Name = name;
            _machineNodes = new ObservableCollection<MachineNode>();
            MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;
        }

        /// <summary>
        /// Handles the CollectionChanged event of the MachineNodes control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void MachineNodes_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Gets or sets the machine nodes.
        /// </summary>
        /// <value>The machine nodes.</value>
        public ObservableCollection<MachineNode> MachineNodes { get => _machineNodes; set => SetProperty(ref _machineNodes, value); }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        public CompositeCollection ChildNodes
        {
            get
            {
                return new CompositeCollection()
                    {
                        new CollectionContainer() { Collection = MachineNodes }
                    };
            }
        }

        /// <summary>
        /// Adds the child.
        /// </summary>
        /// <param name="components">The components.</param>
        internal void AddChild(List<IBProjectComponent> components)
        {
            var machineComponents = components.Where(x => (x.IBComponenetType.ComponentTypeID == 5) && x.ParentID == this.Id).ToList();

            foreach (var c in machineComponents)
            {
              var  machineNode = new MachineNode(c.NodeID, c.ComponentName, this);
                machineNode.AddChild(components);
                MachineNodes.Add(machineNode);
            }
        }

        /// <summary>
        /// Creates a new object that is a copy of the current instance.
        /// </summary>
        /// <returns>A new object that is a copy of this instance.</returns>
        public object Clone()
        {
            LineNode cloneNode = this.MemberwiseClone() as LineNode;
            if (cloneNode != null)
            {
                cloneNode.ParentNode = null;
                cloneNode.Id = null;

                cloneNode.MachineNodes = new ObservableCollection<MachineNode>();
                cloneNode.MachineNodes.CollectionChanged += MachineNodes_CollectionChanged;

                foreach (var c in this.MachineNodes)
                {
                    var machine = c.Clone() as MachineNode;
                    machine.Id = GlobalFiled.GenerateRandomId();
                    cloneNode.MachineNodes.Add(machine);
                    if (machine != null) machine.ParentNode = cloneNode;
                }

                return cloneNode;
            }
            return cloneNode;
        }

        /// <summary>
        /// Deletes this instance.
        /// </summary>
        public void Delete()
        {
            (this.ParentNode as WorkShopNode)?.LineNodes.Remove(this);
        }
    }

    /// <summary>
    /// extension class for adding machine node for the line
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class LinepExt
    {
        /// <summary>
        /// Imports the Machine.
        /// </summary>
        /// <param name="line">The line.</param>
        /// <param name="IBComponenets">The ib componenets.</param>
        public static void ImportMachine(this LineNode line, List<IBImportModel> IBComponenets)
        {
            var row = IBComponenets.Where(x => x.Line == line.Name);

            var machineInfo = row.
         Select(i => new
         {
             Machine = i.Machine,
             Criticality = i.MachineCriticity,
         }).Distinct().ToList();

            foreach (var machines in machineInfo)
            {
                var machineNod = new MachineNode(GlobalFiled.GenerateRandomId(), machines.Machine, line);

                string machinesCriticality = machines.Criticality;
                if (!IsNullOrEmpty(machinesCriticality) && machinesCriticality.Any(char.IsDigit))
                {
                    machinesCriticality = machines.Criticality.Remove(0, 3);
                }
                if (!IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Not defined")
                {
                    machinesCriticality = CriticalitystringValues.NotCritical;
                }
                //Update Criticality values if file will open from old tool. 
                if (!IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Not critical")
                {
                    machinesCriticality = CriticalitystringValues.NotCritical;
                }
                if (!IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Somewhat critical")
                {
                    machinesCriticality = CriticalitystringValues.SomewhatCritical;
                }
                if (!IsNullOrEmpty(machinesCriticality) && machinesCriticality == "Very critical")
                {
                    machinesCriticality = CriticalitystringValues.VeryCritical;
                }
                if(IsNullOrEmpty(machinesCriticality))
                {
                    machinesCriticality = CriticalitystringValues.NotCritical ;
                }
                //var criticality = new CriticalityModel() { SelectedValue = machines.Criticality };
                var criticality = new CriticalityModel()
                {
                    SafetyIssue = CriticalitystringValues.LOW_RISK,
                    QualityIssue = CriticalitystringValues.LOW_IMPACT,
                    LeadTimeIssue = CriticalitystringValues.LOW_IMPACT,
                    CostsIssue = CriticalitystringValues.LOW_IMPACT,
                    SelectedValue = machinesCriticality
                };
                //var criticality = new CriticalityModel() { SelectedValue = machines.Criticality };
                //machineNod.ParentNode = line;
                machineNod.CriticalityParameters = criticality;
                machineNod.CriticalityParams = criticality;
                machineNod.Inventories.SelectMany(x => x.Criticality = criticality.SelectedValue);

                var ibComponents = IBComponenets.Where(i =>
                    Compare(i.Machine, machines.Machine, StringComparison.OrdinalIgnoreCase) == 0).ToList();
                //Import should be done to attached node only, Node ID is mandatory for filtering
                line.MachineNodes.Add(machineNod);
                //Update Criticality values of all Machine Node if file will open from old tool. 
                foreach (var ibComponent in ibComponents)
                {
                    ibComponent.MachineCriticity = FindCriticalString(ibComponent.MachineCriticity);
                }
                machineNod.ImportConfig(ibComponents);
            }
        }
        /// <summary>
        /// Finds the critical string.
        /// </summary>
        /// <param name="criticalData">The critical data.</param>
        /// <returns>System.String.</returns>
        private static string FindCriticalString(string criticalData)
        {
            if (string.IsNullOrEmpty(criticalData))
                return CriticalitystringValues.NotCritical;

            switch (criticalData.Trim().ToUpper())
            {
                case "0. NOT DEFINED":
                    return CriticalitystringValues.NotCritical;
                case "1. NOT CRITICAL":
                case "NOT CRITICAL":
                    return CriticalitystringValues.NotCritical;
                case "2. SOMEWHAT CRITICAL":
                case "SOMEWHAT CRITICAL":
                    return CriticalitystringValues.SomewhatCritical;
                case "3. CRITICAL":
                case "CRITICAL":
                    return CriticalitystringValues.Critical;
                case "4. VERY CRITICAL":
                case "VERY CRITICAL":
                    return CriticalitystringValues.VeryCritical;
                default: return CriticalitystringValues.NotCritical;
            }
        }

        /// <summary>
        /// Gets all nodes.
        /// </summary>
        /// <param name="line">The line.</param>
        /// <returns>List&lt;Node&gt;.</returns>
        public static List<Node> GetAllNodes(this LineNode line)
        {
            List<Node> nodes = new List<Node>();

            foreach (var n in line.MachineNodes)
            {
                nodes.Add(n);
                nodes.AddRange(n.GetAllNodes());
            }

            return nodes;
        }
    }
}