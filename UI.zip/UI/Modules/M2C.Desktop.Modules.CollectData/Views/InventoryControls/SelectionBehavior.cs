// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-27-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SelectionBehavior.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interactivity;

namespace M2C.Desktop.Modules.CollectData.Views.InventoryControls
{
    /// <summary>
    /// Selection Behavior for DropDown
    /// </summary>
    public class SelectionBehavior : Behavior<UIElement>
    {
        /// <summary>
        /// Called when [attached].
        /// </summary>
        protected override void OnAttached()
        {
            AssociatedObject.PreviewKeyDown += UiElement_PreviewKeyDown;
            base.OnAttached();
        }

        /// <summary>
        /// Called when [detaching].
        /// </summary>
        protected override void OnDetaching()
        {
            AssociatedObject.PreviewKeyDown -= UiElement_PreviewKeyDown;
            base.OnDetaching();
        }

        /// <summary>
        /// Set the Focus
        /// </summary>
        private static bool isFocus = false;

        /// <summary>
        /// On Key Down on Drop Down Box
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="KeyEventArgs" /> instance containing the event data.</param>
        private static void UiElement_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (sender is ComboBox)
            {
                if ((e.OriginalSource is TextBox) && e.Key != Key.Down)
                    isFocus = false;
                else if (!isFocus && e.Key == Key.Down)
                {
                    var next = new TraversalRequest(FocusNavigationDirection.Next);
                    var el = Keyboard.FocusedElement as UIElement;
                    if (el is TextBox box && box.Name == "editableText")
                    {
                        box.MoveFocus(next);
                        isFocus = true;
                    }
                }
            }
            else
            {
                isFocus = false;
            }
        }
    }
}