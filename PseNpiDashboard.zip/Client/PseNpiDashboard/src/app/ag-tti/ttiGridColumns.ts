import { DatePipe } from '@angular/common';

export class TtiGridColumns {
    constructor(private datePipe: DatePipe){}



    static  columns =[
        {
          headerName: "#",
          colId: "rowNum",
          valueGetter: "node.id",
          pinned: "left", hide: true,
          sortingOrder: ["asc", "desc"]
        },
        {
          headerName: "Id",
          field: "id",
          pinned: "left",
          colId: "id",
          hide: true,
          sortingOrder: ["asc", "desc"]
        },
        {
          field: "accolade_KC",
          headerName: "Accolade KC",
          pinned: "left",
          suppressSizeToFit: true, hide: false,
          colId: "accolade_KC",
        },
        {
          field: "heatmap_KC",
          headerName: "Heatmap KC",
          editable: false,
          colId: "heatmap_KC",
          suppressSizeToFit: true, hide: false,
          sortingOrder: ["asc", "desc"]
        },
        {
          field: "program_Name",
          headerName: "Program Name",
          colId: "program_Name",
          sortingOrder: ["asc", "desc"], hide: false,
          suppressSizeToFit: true
        },
        {
          field: "ipdS_Current_Phase",
          headerName: "IPDS Current Phase",
          colId: "ipdS_Current_Phase",
          sortingOrder: ["asc", "desc"],
          suppressSizeToFit: true,
          hide: true,
        },
        {
          field: "prod_SBU",
          headerName: "SBU",
          colId: "prod_SBU",
          suppressSizeToFit: false,
          hide: true,
        },
        {
          headerName: "GBE",
          colId: "gbe",
          field: "gbe",
          hide: true,
        },
        {
          field: "pac",
          colId: "pac",
          headerName: "PAC",
          hide: true,
        },
        {
          field: "honeywell_Part_Number",
          colId: "part",
          headerName: "Part", hide: false,
        },
        {
          field: "otL_Baseline_Date",
          colId: "otL_Baseline_Date",
          headerName: "OTL Baseline", hide: false,
        }
  
        ,
        {
          field: "otL_Forecast_Date",
          colId: "otL_Forecast_Date",
          headerName: "OTL Forecast", hide: true,
        },
        {
          field: "otL_Baseline_Date_refresh",
          colId: "otL_Baseline_Date_refresh",
          headerName: "OTL Baseline Refresh", hide: true,
        },
        {
          field: "otL_Forecast_Data_refresh",
          colId: "otL_Forecast_Data_refresh",
          headerName: "OTL Forecast Refresh", hide: true,
        },
        {
          field: "part_Description",
          colId: "part_Description",
          headerName: "Part Description", hide: false,
        },
        {
          field: "end_Item_LRU",
          colId: "end_Item_LRU",
          headerName: "End Item LRU", hide: true,
        },
        {
          field: "make_Buy",
          colId: "make_Buy",
          headerName: "Make & Buy",
          hide: true,
        },
        {
          field: "production_Site",
          colId: "production_Site",
          headerName: "Production Site",
          hide: true,
  
        }
        ,
        {
          field: "pm",
          colId: "pm",
          headerName: "Program Manager",
          hide: true,
        },
        {
          field: "pe",
          colId: "pe",
          headerName: "Project Engineer", hide: true,
  
        },
        {
          field: "qty_Per_Shipset",
          colId: "qty_Per_Shipset",
          headerName: "Qty Per Shipset", hide: true,
  
        },
        {
          field: "actibe",
          colId: "actibe",
          headerName: "Actibe", hide: true,
        }
        ,
        {
          field: "added_Removed_from_OTL_TTI",
          colId: "added_Removed_from_OTL_TTI",
          headerName: "Added/Removed From OTL TTI", hide: true,
        }
        ,
        {
          field: "added_Removed_from_RTY_TTI",
          colId: "added_Removed_from_RTY_TTI",
          headerName: "Added/Removed From RTY TTI", hide: true,
        },
        {
          field: "added_to_PPM_TTI",
          colId: "added_to_PPM_TTI",
          headerName: "Added To PPM TTI", hide: true,
        },
  
        ,
        {
          field: "amE_NPD_Engineer",
          colId: "amE_NPD_Engineer",
          headerName: "AME NPD Engineer", hide: true,
        },
        {
          field: "apqP_Level",
          colId: "apqP_Level",
          headerName: "APQP Level", hide: true,
  
        },
        {
          field: "end_Item_LRU",
          colId: "end_Item_LRU",
          headerName: "End Item LRU Level", hide: true,
  
        },
        /////
  
        {
          field: "eng_Chief",
          colId: "eng_Chief",
          headerName: "Eng Chief", hide: true,
        },
  
  
        {
          field: "eseBaseLine",
          colId: "eseBaseLine",
          headerName: "Ese BaseLine", hide: false,
        },
  
  
        {
          field: "eseForecast",
          colId: "eseForecast",
          headerName: "Ese Forecast", hide: true,
        },
  
  
        {
          field: "index_Record_ID",
          colId: "index_Record_ID",
          headerName: "Record ID", hide: true,
        },
        {
          field: "infoCreatedDate",
          colId: "infoCreatedDate",
          headerName: "Created Date", hide: true,
        },
        {
          field: "infoUpdateDate",
          colId: "infoUpdateDate",
          headerName: "Update Date", hide: true,
        },
  
        {
          field: "notes",
          colId: "notes",
          headerName: "Notes", hide: true,
        },
  
  
        {
          field: "pG5_Exit_Date",
          colId: "pG5_Exit_Date",
          headerName: "PG Exit Date", hide: true,
        },
        {
          field: "partOfBaseline",
          colId: "partOfBaseline",
          headerName: "Part Of Baseline", hide: true,
        },
        {
          field: "part_Description",
          colId: "part_Description",
          headerName: "Part Description", hide: true,
        },
  
        {
          field: "part_of_OTL_TTI",
          colId: "part_of_OTL_TTI",
          headerName: "Part Of OTL TTI", hide: false,
        },
  
        {
          field: "part_of_PPM_TTI",
          colId: "part_of_PPM_TTI",
          headerName: "Part Of PPM TTI", hide: true,
        },
  
        {
          field: "part_of_RTY_TTI",
          colId: "part_of_RTY_TTI",
          headerName: "Part Of RTY TTI", hide: false,
        },
        {
          field: "pgExit",
          colId: "pgExit",
          headerName: "PG Exit", hide: true,
        },
        ,
        {
          field: "record_Number",
          colId: "record_Number",
          headerName: "Record Number", hide: true,
        },
        {
          field: "rtY_Validation_Method",
          colId: "rtY_Validation_Method",
          headerName: "RTY Validation Method",
          hide: true,
        },
        {
          field: "sourcing",
          colId: "sourcing",
          headerName: "Sourcing",
          hide: true,
        },
  
        {
          field: "successfulEse",
          colId: "successfulEse",
          headerName: "Successful Ese",
          hide: false,
        },
        {
          field: "successfulOtl",
          colId: "successfulOtl",
          headerName: "Successful Otl",
          hide: false,
        },
        {
          field: "successfulPpm",
          colId: "successfulPpm",
          headerName: "Successful PPM",
          hide: true,
        },
        {
          field: "successfulRty",
          colId: "successfulRty",
          headerName: "Successful Rty",
          hide: false,
        },
        {
          field: "successfulUpc",
          colId: "successfulUpc",
          headerName: "Successful UPC",
          hide: true,
        },
        {
          field: "updateBy",
          colId: "updateBy",
          headerName: "Update By",
          hide: true,
        },
      ];
    }
    