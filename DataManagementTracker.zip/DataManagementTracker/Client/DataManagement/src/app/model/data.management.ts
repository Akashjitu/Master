export interface DataManagement {
    id: number;
    requestor : string;
    requestReceivedDate : Date;
    site : string;
    siteId: number,
    documentPartNumber : string;
    revision: string ;
    documentTitle : string;
    ecn : string;
    customerName : string;
    customerId : number,
    programNames : string;
    programId :number,
    priority : string;
    dataManager : string;
    cm : string;
    requestorComments : string;
    documentType : string;
    endItemPartNumber : string;
    categoryOfChange : string;
    scnNumber : string;
    cmComments : string;
    sdrlNumber : string;
    sdrlTitle : string;
    nomenclature : string;
    customerReferenceNumber : string;
    honeywellTransmittalLetter : string;
    dmDateSentToCustomer : Date;
    honStatus : string;
    requiredDispositionDate : string;
    dispositionStatus : string;
    customerStatus : string;
    apProgram : string;
    exportDisclosure:string;
    impactedPoDate : string;
    bcaPrimaryReviewerEngineer : string;
    bcaPa : string;
    dmComments : string;
    honeywellComments : string;
    createdBy : string;
    createdDate : Date;
    updatedBy : string;
    updatedDate : Date;
    isActive : string;
    requestorId:string;
  }