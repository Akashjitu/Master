﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="InventoryModelEvent.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using M2C.Business.Models;
using M2C.Desktop.Modules.CollectData.UIModels;
using Prism.Events;

namespace M2C.Desktop.Modules.CollectData.Events
{
    /// <summary>
    /// Event class use for Provide data to Grid
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{Inventory}" />
    public class InventoryModelEvent : PubSubEvent<List<Inventory>>
    {
    }
}