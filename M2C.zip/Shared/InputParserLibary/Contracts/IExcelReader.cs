﻿// ***********************************************************************
// Assembly         : InputParserLibary
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IExcelReader.cs" company="InputParserLibary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace InputParserLibary.Contracts
{
    /// <summary>
    /// Interface IExcelReader
    /// </summary>
    public interface IExcelReader
    {
        /// <summary>
        /// function to open the file
        /// </summary>
        /// <param name="sourcePath">The source path.</param>
        void openAsNewFile(string sourcePath);
    }
}
