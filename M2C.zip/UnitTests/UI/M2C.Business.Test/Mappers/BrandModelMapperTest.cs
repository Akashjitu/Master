﻿using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace M2C.Business.Mappers
{
    [TestClass]
    public class BrandModelMapperTest
    {
        private BrandModelMapper brandModelMapper;

        [TestInitialize]
        public void Setup()
        {
            brandModelMapper = new BrandModelMapper();
        }

        [TestMethod]
        public void ShouldReturnBrandModel()
        {
            var brandModels = brandModelMapper.Map(MockProvider.GetBrands());
            Assert.IsNotNull(brandModels);
            Assert.IsTrue(brandModels.Count > 0);
        }
    }
}