﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="InstalledBase.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using DomainModels.ProjectModels;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Data;
using M2C.Business.GlobalFields;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Class InstalledBase.
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class InstalledBase : Node, IChildNode
    {
        /// <summary>
        /// The factories
        /// </summary>
        private ObservableCollection<FactoryNode> _factories;

        /// <summary>
        /// Initializes a new instance of the <see cref="InstalledBase" /> class.
        /// </summary>
        public InstalledBase()
        {
            this.Id = 0;
            _factories = new ObservableCollection<FactoryNode>();
            this.ParentNode = null;
            this.Name = "Installed Base";
            this.NodeType = NodeType.INSTALLEDBASE;
            Factories.CollectionChanged += Factories_CollectionChanged;
        }

        /// <summary>
        /// Handles the CollectionChanged event of the Factories control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void Factories_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Gets or sets the factories.
        /// </summary>
        /// <value>The factories.</value>
        public ObservableCollection<FactoryNode> Factories { get => _factories; set => SetProperty(ref _factories, value); }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        public CompositeCollection ChildNodes
        {
            get
            {
                return new CompositeCollection()
                    {
                        new CollectionContainer() { Collection = Factories }
                    };
            }
        }

        /// <summary>
        /// Adds the child.
        /// </summary>
        /// <param name="components">The components.</param>
        public void AddChild(List<IBProjectComponent> components)
        {
            foreach (IBProjectComponent c in components.Where(x => x.IBComponenetType.ComponentTypeID == 2 && x.ParentID == this.Id).ToList())
            {
                var fc = new FactoryNode(c.NodeID, c.ComponentName, this);

                fc.AddChild(components);

                Factories.Add(fc);
            }
        }
    }

    /// <summary>
    /// Extension class for the installedBase to add node for workshop
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class InstalledBaseExt
    {
        /// <summary>
        /// Imports the factories.
        /// </summary>
        /// <param name="installedBase">The installed base.</param>
        /// <param name="IBComponenets">The ib componenets.</param>
        public static void ImportFactories(this InstalledBase installedBase, List<IBImportModel> IBComponenets)
        {
            if (IBComponenets != null)
            {
                var factories = IBComponenets.Select(x => x.Factory).Distinct();

                foreach (var factory in factories)
                {
                    if (factory == null) continue;
                    var factoryNode = new FactoryNode(GlobalFiled.GenerateRandomId(), factory, installedBase);
                    var ibComponents = IBComponenets.Where(i =>
                        string.Compare(i.Factory, factory, StringComparison.OrdinalIgnoreCase) == 0).ToList();
                    installedBase.Factories.Add(factoryNode);
                    factoryNode.ImportWorkShop(ibComponents);
                }
            }
        }

        /// <summary>
        /// Gets all Child nodes.
        /// </summary>
        /// <param name="installedBase">The installed base.</param>
        /// <returns>List&lt;Node&gt;.</returns>
        public static List<Node> GetAllNodes(this InstalledBase installedBase)
        {
            var nodes = new List<Node> { installedBase };
            foreach (var node in installedBase.Factories)
            {
                nodes.Add(node);
                nodes.AddRange(node.getAllNodes());
            }

            return nodes;
        }
    }
}