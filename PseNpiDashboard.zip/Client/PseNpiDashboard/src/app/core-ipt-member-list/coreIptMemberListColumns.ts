
import { DatePipe } from '@angular/common';

export class CoreIptMemberListColumns {
constructor(private datePipe: DatePipe){}

    static  columns =
     [
        { field: 'id',                              colId: 	    'id',	                   		hide: true,	    headerName: 	'Id',	},
        { field: 'keyCode',                        colId: 	'keyCode',	               	hide: false,	headerName: 	'Key Code',	},
        { field: 'ipdsCurrentPhase',                      colId: 	'ipdsCurrentPhase',	       			hide: true,	headerName: 	'IPDS Current Phase',	},
        { field: 'coupledDeCoupled',                      colId: 	'coupledDeCoupled',	       			hide: true,	headerName: 	'Coupled-DeCoupled',	},
        { field: 'hwDevelopmentScop',                    colId: 	'hwDevelopmentScop',	            hide: true,	headerName: 	'H/W Development Scop',	},
        { field: 'swDevelopmentScop',                      colId: 	'swDevelopmentScop',	       			hide: true,	headerName: 	'S/W Development Scop',	},
        { field: 'productManager',                        colId: 	'productManager',	               	hide: true,	headerName: 	'Product Manager',	},
        { field: 'programManager',                      colId: 	'programManager',	       			hide: false,	headerName: 	'Program Manager',	},
        { field: 'ppC',                                 colId: 	'ppC',	       			hide: true,	headerName: 	'PP & C',	},
        { field: 'projectEngineer',                    colId: 	'projectEngineer',	            hide: false,	headerName: 	'Project Engineer',	},
        { field: 'advanceManufacturingEngineer',                      colId: 	'advanceManufacturingEngineer',	       			hide: false,	headerName: 	'Advance Manufacturing Engineer',	},
        { field: 'pseLaunchEngineer',                        colId: 	'pseLaunchEngineer',	  	hide: false,	headerName: 	'PSE Launch Engineer',	},
        { field: 'apqpEngineer',                        colId: 	'apqpEngineer',	       			hide: false,	headerName: 	'APQP Engineer',	},
        { field: 'sourcingPm',                          colId: 	'sourcingPm',	       			hide: false,	headerName: 	'Sourcing PM',	},
        { field: 'contracts',                            colId: 	'contracts',	            hide: true,	headerName: 	'Contracts',	},
        { field: 'supplierApqp',                      colId: 	'supplierApqp',	       			hide: true,	headerName: 	'Supplier APQP',	},
        { field: 'pmChief',                        colId: 	'pmChief',	               	hide: true,	headerName: 	'PM Chief',	},
        { field: 'cps',                                 colId: 	'cps',	       			hide: true,	headerName: 	'CPS',	},
        { field: 'updatedDate',                    colId: 	'updatedDate',	            hide: true,	headerName: 	'Updated Date',	},
        { field: 'updatedBy',                               colId: 	'updatedBy',	            hide: true,	headerName: 	'Updated By',	},
        { field: 'active',                              colId: 	'active',	            hide: true,	headerName: 	'Active',	},
        { field: 'createdDate',                    colId: 	'createdDate',	            hide: true,	headerName: 	'Created Date',	},
        { field: 'createBy',                                colId: 	'createBy',	            hide: true,	headerName: 	'Create By',	},
    ];

}

      	
