﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-21-2020
// ***********************************************************************
// <copyright file="IExcelExportObsolescence.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using M2C.Business.Models;

namespace M2C.Desktop.Modules.Charts.ReportData.ChartExports
{
    /// <summary>
    /// Interface IExcelExportObsolescence
    /// </summary>
    public interface IExcelExportObsolescence
    {
        /// <summary>
        /// Exports the specified path.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <param name="sheetName">Name of the sheet.</param>
        /// <param name="inventories">The inventories.</param>
        /// <param name="TrSheetName">Name of the tr sheet.</param>
        /// <param name="TrInventories">The tr inventories.</param>
        void Export(string path, string sheetName, List<Inventory> inventories, string TrSheetName, List<Inventory> TrInventories);
    }
}
