﻿using AppConfiguration;
using M2C.Business.Contracts;
using M2C.Desktop.App.ViewModels;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Prism.Events;
using Prism.Services.Dialogs;
using WinRegistryServices.Contracts;

namespace M2C.UI.Tests.App
{
    [TestClass]
    public class MainWindowViewModelTest : TestBase
    {
        private Mock<IMyProfileLogic> mockMyProfileLogic;
        private Mock<IDialogService> mockDialogService;
        private Mock<IEventAggregator> mockEventAggregator;
        private Mock<ISharedContextService> mockSharedContextService;
        private Mock<IGlobalMenuComands> mockGlobalMenuComands;
        private Mock<IAppConfigurations> mockAppConfigurations;
        private Mock<IRegistryStoreManger> mockRegistryStoreManger;
        private Mock<IProductSync> mockIProductSync;
        protected Mock<IProjectLogic> mockIProjectLogic;

        [TestInitialize]
        public void TestIniTialize()
        {
            mockMyProfileLogic = MockRepo.Create<IMyProfileLogic>();
            mockDialogService = MockRepo.Create<IDialogService>();
            mockEventAggregator = MockRepo.Create<IEventAggregator>();
            mockSharedContextService = MockRepo.Create<ISharedContextService>();
            mockGlobalMenuComands = MockRepo.Create<IGlobalMenuComands>();
            mockAppConfigurations = MockRepo.Create<IAppConfigurations>();
            mockRegistryStoreManger = MockRepo.Create<IRegistryStoreManger>();
            mockIProductSync = MockRepo.Create<IProductSync>();
            mockIProjectLogic = MockRepo.Create<IProjectLogic>();
        }

        [TestMethod]
        public void MainWindowViewModelObjectTest()
        {
            mockEventAggregator.Setup(t => t.GetEvent<ProjectChangeEvent>()).Returns(new ProjectChangeEvent());
            mockEventAggregator.Setup(t => t.GetEvent<BusyOverlayEvent>()).Returns(new BusyOverlayEvent());
            MainWindowViewModel vm = new MainWindowViewModel(mockMyProfileLogic.Object, mockDialogService.Object, mockEventAggregator.Object
                , mockSharedContextService.Object, mockGlobalMenuComands.Object, mockAppConfigurations.Object, mockRegistryStoreManger.Object, 
                mockIProductSync.Object, mockIProjectLogic.Object);
            if (vm.Title != null)
                Assert.IsTrue(true, "MainWindowViewModel Created");
        }
    }
}