﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="BusinessConstants.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2C.Business
{
    /// <summary>
    /// Business layer Constants
    /// </summary>
    public static class BusinessConstants
    {
        /// <summary>
        /// The factory
        /// </summary>
        public const string FACTORY = "Factory";
        /// <summary>
        /// The workshop
        /// </summary>
        public const string WORKSHOP = "Workshop";
        /// <summary>
        /// The line
        /// </summary>
        public const string LINE = "Line";
        /// <summary>
        /// The machine
        /// </summary>
        public const string MACHINE = "Machine";
        /// <summary>
        /// The PLC configuration
        /// </summary>
        public const string PLC_CONFIGURATION = "PLC Configuration";
        /// <summary>
        /// The motion drive configuration
        /// </summary>
        public const string MOTION_DRIVE_CONFIGURATION = "Motion & Drive Configuration";
        /// <summary>
        /// The scada hmi configuration
        /// </summary>
        public const string SCADA_HMI_CONFIGURATION = "Scada HMI Configuration";
        /// <summary>
        /// The open configuration
        /// </summary>
        public const string OPEN_CONFIGURATION = "Open Configuration";

        /// <summary>
        /// The title
        /// </summary>
        public const string Title = "Title";
        /// <summary>
        /// The is cancel visible
        /// </summary>
        public const string IsCancelVisible = "IsCancelVisible";
        /// <summary>
        /// The message label
        /// </summary>
        public const string MessageLabel = "MessageLabel";
        /// <summary>
        /// The message collection
        /// </summary>
        public const string MessageCollection = "MessageCollection";
        /// <summary>
        /// The message
        /// </summary>
        public const string Message = "Message";

        /// <summary>
        /// The operation mod e1
        /// </summary>
        public const string OPERATION_MODE1 = "<8 hours per day";
        /// <summary>
        /// The operation mod e2
        /// </summary>
        public const string OPERATION_MODE2 = "8h <> 16h per day";
        /// <summary>
        /// The operation mod e3
        /// </summary>
        public const string OPERATION_MODE3 = "> 16 hours per day";

        /// <summary>
        /// The hourly productio n1
        /// </summary>
        public const string HOURLY_PRODUCTION1 = "<5K€/h";
        /// <summary>
        /// The hourly productio n2
        /// </summary>
        public const string HOURLY_PRODUCTION2 = "5K€/h<<10K€/h";
        /// <summary>
        /// The hourly productio n3
        /// </summary>
        public const string HOURLY_PRODUCTION3 = "10K€/h<<20K€/h";
        /// <summary>
        /// The hourly productio n4
        /// </summary>
        public const string HOURLY_PRODUCTION4 = "20K€/h<<40K€/h";
        /// <summary>
        /// The hourly productio n5
        /// </summary>
        public const string HOURLY_PRODUCTION5 = "40K€/h<<60K€/h";
        /// <summary>
        /// The hourly productio n6
        /// </summary>
        public const string HOURLY_PRODUCTION6 = "60K€/h<<80K€/h";
        /// <summary>
        /// The hourly productio n7
        /// </summary>
        public const string HOURLY_PRODUCTION7 = ">80K€/h";
        

    }
}
