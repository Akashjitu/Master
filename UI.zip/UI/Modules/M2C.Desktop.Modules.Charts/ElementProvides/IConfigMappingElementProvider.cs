﻿using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    /// <summary>
    /// Provide Configuration Mapping Binding
    /// </summary>
   public interface IConfigMappingElementProvider
   {
        /// <summary>
        /// Get Configuration Mapping Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        ChartBarElements GetConfigurationMappingElements(ChartParameter chartParameter,
           NodeType type = NodeType.OPEN_CONFIG);
   }
}
