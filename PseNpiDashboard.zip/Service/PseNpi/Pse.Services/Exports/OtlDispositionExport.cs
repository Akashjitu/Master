﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;
using System;

namespace Pse.Services.ExcelExports
{
    public class OtlDispositionExports : IOtlDispositionExports
    {
        public byte[] Export(List<OtlDispositionDetails> otlDispositions)
        {
            throw new NotImplementedException();
        }
    }
}