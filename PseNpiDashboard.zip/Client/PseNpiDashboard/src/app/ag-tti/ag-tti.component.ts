import { Component, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { AccoladeService } from '../services/accolade-service.service';
import { IAppState } from '../store/accoladeReducer';
import { HttpClient } from "@angular/common/http";
import { DatePickerComponent, IDayCalendarConfig } from 'ng2-date-picker';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { forEach } from '@angular/router/src/utils/collection';
import { TtiGridColumns } from './ttiGridColumns';

@Component({
  selector: 'app-ag-tti',
  templateUrl: './ag-tti.component.html',
  styleUrls: ['./ag-tti.component.css']
})
export class AgTtiComponent implements OnInit {

  filterSelection = 'Load All';
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  theme = 'ag-theme-balham';
  private gridApi;
  private gridColumnApi;
  selectedDate;
  columnDefs;
  defaultColDef;
  rowData: any;
  private sortingOrder;
  private autoGroupColumnDef;
  private rowSelection;
  private rowGroupPanelShow;
  private pivotPanelShow;
  searchText = '';
  @ViewChild('dateFromDp') public dateFromDp: DatePickerComponent;
  @ViewChild('dateToDp') public dateToDp: DatePickerComponent;

  filterForm: FormGroup;
  displayDate;


  dayPickerConfig = {
    locale: 'en',
    format: 'YYYY-MM-DD',
    monthFormat: 'MMMM, YYYY',
    firstDayOfWeek: 'mo'
  } as IDayCalendarConfig;


  constructor(public store: Store<IAppState>, private service: AccoladeService, private http: HttpClient, private fb: FormBuilder) {
    this.createForm();

    this.columnDefs = TtiGridColumns.columns;
    
    this.sortingOrder = ["desc", "asc", null];
    this.defaultColDef = {
      resizable: true,
      sortable: true,
      enableRowGroup: true,
      filter: true
    };

    this.rowSelection = "selectionMode";
  }

  ngOnInit() {

    this.filterForm.get('dateFrom').valueChanges.subscribe(value => {
      this.dayPickerConfig = {
        ...this.dayPickerConfig
      };
    });
  }

  createForm() {
    this.filterForm = this.fb.group({
      dateFrom: new FormControl(),
      dateTo: new FormControl(),
    });
  }
  onGridReady(params) {
    params.api.sizeColumnsToFit()
    console.log("Ag-Ready")
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.service.getAllTti();
    //params.api.sizeColumnsToFit();
    this.autoSizeAll();
    this.store.select('accoladeReducer').subscribe(data =>
      this.rowData = data);
    this.initColumnsList();
  }

  autoSizeAll() {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
      // console.log('Col - ' + column);
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  onCellValueChanged($event) {
    const selectedRows = this.gridApi.getSelectedRows();
    selectedRows[0].updateBy = "Modified";
    console.log(selectedRows);
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(this.searchText);
  }

  onSelectionChanged() {
    var selectedRows = this.gridApi.getSelectedRows();
  }

  onDateSelection(event) {
    let date = new Date(Date.parse(event));
    console.log(date);

    this.service.searchByDate(event, this.filterSelection);

  }

  onSave() {
    console.log('onSave');
    const modifieditems = this.rowData.filter(item => item.updateBy === "Modified");
    console.log(this.rowData)
    console.log(modifieditems);
    this.service.saveTti(modifieditems);
  }



  export() {
    if (this.selectedDate === undefined) {
      alert('Please select any TTI row from Grid');
    }
    this.service.reportDownload(this.selectedDate);
  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }

  initColumnsList() {
    var allColumnIds = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'colId',
      textField: 'headerName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push({ colId: column.colId, headerName: column.colId });

    });
    this.selectedItems = [
      { colId: 'accolade_KC', headerName: 'accolade_KC' },
      { colId: 'heatmap_KC', headerName: 'heatmap_KC' }
    ];

    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      if (allColumns[index].visible === true) {
        this.selectedItems.push({ colId: allColumns[index].colId, headerName: allColumns[index].colId })
      }

    }
    this.dropdownList = allColumnIds;

  }

  onItemSelect(item: any) {
    console.log(item);
    this.gridColumnApi.setColumnsVisible([item], true);

  }
  onDeSelect(item: any) {
    console.log(item);
    this.gridColumnApi.setColumnsVisible([item], false);

  }
  onSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], true);
    }
  }

  onDeSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], false);
    }
  }
  onLoadFilterChange(value) {
    this.filterSelection = value;
  }
  
  clearFilters() {
    console.log("clearFilters");
    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
}
}
