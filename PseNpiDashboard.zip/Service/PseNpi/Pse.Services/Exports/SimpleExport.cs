﻿using OfficeOpenXml;
using OfficeOpenXml.ConditionalFormatting;
using OfficeOpenXml.ConditionalFormatting.Contracts;
using OfficeOpenXml.Drawing.Chart;
using Pse.Data.Models.Attributes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Xml;

namespace Pse.Services.Exports
{
    public class SimpleExport : ISimpleExport
    {
        public byte[] Export<T>(List<T> entites, string sheetName, int pinedRightColumn)
        {
            using (var excelFile = new ExcelPackage())
            {
                var worksheet = excelFile.Workbook.Worksheets.Add(sheetName);
                worksheet.Cells["A1"].LoadFromCollection(Collection: entites, PrintHeaders: true);

                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].Style.Font.Bold = true;
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].Style.Font.Size = 14;
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].Style.Font.Color.SetColor(System.Drawing.Color.Blue);
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].AutoFilter = true;
                worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column].AutoFitColumns();


                //ExcelAddress cfAddress1 = new ExcelAddress("A2:A10");
                //var cfRule1 = worksheet.ConditionalFormatting.AddTwoColorScale(cfAddress1);

                //// Now, lets change some properties:
                //cfRule1.LowValue.Type = eExcelConditionalFormattingValueObjectType.Formula;
                //cfRule1.LowValue.Formula = "Cell Value == 'Red'";
                //cfRule1.LowValue.Color = Color.Red;
                //cfRule1.HighValue.Type = eExcelConditionalFormattingValueObjectType.Formula;
                //cfRule1.HighValue.Formula = "Cell Value == 'Red'";
                //cfRule1.HighValue.Color = Color.Red;
                //cfRule1.StopIfTrue = true;
                //cfRule1.Style.Font.Bold = true;



                //IExcelConditionalFormattingEqual condition1 = worksheet.ConditionalFormatting.AddEqual(worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column]);
              
                //condition1.Priority = 1;
                ////condition1.Formula = "= 'Red'";
                ////condition1.Node.Value = "Red";
                //condition1.Formula =  "IF(COUNTIF($A$2:$A$10, $A2) = Red, 1, '')";
                //condition1.Style.Fill.BackgroundColor.Color = Color.Red;
                //condition1.StopIfTrue = true;


                if (pinedRightColumn > 0)
                    worksheet.View.FreezePanes(1, pinedRightColumn);

                var entityType = typeof(T);
                var ColumnsAttributes = GetColumnsAttributes(entityType);

                if (ColumnsAttributes != null && ColumnsAttributes.Count > 0)
                {
                    
                    string[] hideNames = ColumnsAttributes.Where(x => x.Value.IsColumnHide == true).Select(x => x.Key).ToArray();
                    string[] removeNames = ColumnsAttributes.Where(x => x.Value.IsColumnRemoved == true).Select(x => x.Key).ToArray();

                    UpdateColumnsCaptionByName(worksheet, ColumnsAttributes);
                    HideColumns(worksheet, hideNames);
                    DeleteColumnsByName(worksheet, removeNames);
                }

                return excelFile.GetAsByteArray();
            }
        }



        public byte[] ExportChart(DataTable exportTable, string sheetName, string chartTitle, string xAxisTitle, string yAxisTitle, string xSeriePositionColumn, eChartType chartType)
        {
         
            using (var excelFile = new ExcelPackage())
            {
                var workbook = excelFile.Workbook;
                var worksheet = workbook.Worksheets.Add(sheetName);

                worksheet.Cells.LoadFromDataTable(exportTable, true);

                ExcelLineChart chart = worksheet.Drawings.AddChart(sheetName +"Chart", chartType) as ExcelLineChart;

                chart.Style = eChartStyle.Style26;
                chart.Legend.Position = eLegendPosition.Right;
                chart.SetSize(800, 500);
                chart.SetPosition(5, 0, 5, 0);
                chart.XAxis.Title.Text = xAxisTitle;
                chart.YAxis.Title.Text = yAxisTitle;
                chart.Title.Text = chartTitle;
                chart.RoundedCorners = true;


                var allHeaderColumnRange = worksheet.Cells[worksheet.Dimension.Start.Row, worksheet.Dimension.Start.Column, 1, worksheet.Dimension.End.Column];

                //Getting xSerie Position Column 
                var columnPostion = (allHeaderColumnRange as IEnumerable<ExcelRangeBase>).Where(i => i.Value.ToString() == xSeriePositionColumn).Select(i => i.End.Column).FirstOrDefault();

                // Getting Range of xSerie Position Column 
                var xSeriePostionColumn = worksheet.Cells[2, columnPostion, worksheet.Dimension.End.Row, columnPostion];


                foreach (var headerColumn in allHeaderColumnRange)
                {
                    if (headerColumn.Value.ToString() == xSeriePositionColumn) continue;

                    var singleColumnRangeForChart = worksheet.Cells[2, headerColumn.End.Column, worksheet.Dimension.End.Row, headerColumn.End.Column];
                    chart.Series.Add(singleColumnRangeForChart, xSeriePostionColumn).Header = headerColumn.Value.ToString();
                }
                

                var chartXml = chart.ChartXml;
                var nsuri = chartXml.DocumentElement.NamespaceURI;
                var nsm = new XmlNamespaceManager(chartXml.NameTable);
                nsm.AddNamespace("c", nsuri);


                var valAxisNodes = chartXml.SelectNodes("c:chartSpace/c:chart/c:plotArea/c:valAx", nsm);
                if (valAxisNodes != null && valAxisNodes.Count > 0)
                {
                    foreach (XmlNode valAxisNode in valAxisNodes)
                    {

                        if (valAxisNode.Name.Equals("c:valAx"))
                        {
                            foreach (XmlNode subitem in valAxisNode.ChildNodes)
                            {
                                if (subitem.Name.Equals("c:minorGridlines"))
                                {
                                    valAxisNode.RemoveChild(subitem);
                                    break;
                                }
                            }
                        }
                    }
                }

                var catAxisNodes = chartXml.SelectNodes("c:chartSpace/c:chart/c:plotArea/c:catAx", nsm);

                if (catAxisNodes != null && catAxisNodes.Count > 0)
                {
                    foreach (XmlNode catAxisNode in catAxisNodes)
                    {

                        if (catAxisNode.Name.Equals("c:valAx"))
                        {
                            foreach (XmlNode subitem in catAxisNode.ChildNodes)
                            {
                                if (subitem.Name.Equals("c:minorGridlines"))
                                {
                                    catAxisNode.RemoveChild(subitem);
                                    break;
                                }
                            }
                        }
                    }
                }

                return excelFile.GetAsByteArray();
            }
        }

        private void HideColumns(ExcelWorksheet sheet, string[] listofColumn)
        {
            if (listofColumn == null || listofColumn.Length == 0)
                return;
            var column = sheet.Cells[sheet.Dimension.Start.Row, sheet.Dimension.Start.Column, 1, sheet.Dimension.End.Column];

            foreach (var col in column)
            {
                string columnText = col.Text.Trim();
                columnText = columnText.Replace(" ", "_");
                var position = col.End.Column;
                sheet.Column(position).Hidden = listofColumn.Any(i => string.Compare(i, columnText, System.StringComparison.OrdinalIgnoreCase) == 0);
            }
        }

        private void DeleteColumnsByName(ExcelWorksheet sheet, string[] listofColumn)
        {
            if (listofColumn == null || listofColumn.Length == 0)
                return;

            var column = sheet.Cells[sheet.Dimension.Start.Row, sheet.Dimension.Start.Column, 1, sheet.Dimension.End.Column];

            foreach (var col in column)
            {
                string columnText = col.Text.Trim();
                columnText = columnText.Replace(" ", "_");
                var position = col.End.Column;
                if (listofColumn.Any(i => string.Compare(i, columnText, StringComparison.OrdinalIgnoreCase) == 0))
                    sheet.DeleteColumn(position);
                
            }
        }

        private void UpdateColumnsCaptionByName(ExcelWorksheet sheet, Dictionary<string, ExportColumn> columnsAttributes)
        {
            if (columnsAttributes == null || columnsAttributes.Count == 0)
                return;

            var column = sheet.Cells[sheet.Dimension.Start.Row, sheet.Dimension.Start.Column, 1, sheet.Dimension.End.Column];

            foreach (var col in column)
            {
                string columnText = col.Text.Trim();
                columnText = columnText.Replace(" ", "_");

                if (columnsAttributes.ContainsKey(columnText) && !String.IsNullOrEmpty(columnsAttributes[columnText].ColumnCaption))
                    col.Value = columnsAttributes[columnText].ColumnCaption;
            }
        }

        private Dictionary<string, ExportColumn> GetColumnsAttributes(Type entityType)
        {
            var properties = entityType.GetProperties();

            var sColumns = properties.Select(l => new
            {
                exportColumn = l.GetCustomAttributes(false).Where(i => (i is ExportColumn)).Select(i => (i as ExportColumn)).ToList(),
                name = l.Name
            }).ToList();

            return sColumns.Where(i => i.exportColumn != null && i.exportColumn.Count > 0).ToDictionary(l => l.name, k => k.exportColumn[0]);
        }
    }
}