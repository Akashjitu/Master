import { AngularEditorConfig, } from '@kolkov/angular-editor';
import { Component, OnInit, TemplateRef, ViewChild, ElementRef } from '@angular/core';

import { FeedbackService } from '../services/feedbackService';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.sass']
})
export class FeedbackComponent implements OnInit {
  gridApi;
  gridColumnApi;
  columnDefs: any;
  defaultColDef;
  rowData:any;
  feedbackComments: any;
  selectedRow:any;

  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '30rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',
    uploadUrl: 'v1/images', // if needed,
    fonts: [{ class: 'arial', name: 'Arial' },
    { class: 'times-new-roman', name: 'Times New Roman' },
    { name: "Comic Sans MS", class: "comic-sans-ms" },
    { name: "Courier New", class: "courier-new" },
    { name: "Georgia", class: "georgia" },
    { name: "Verdana", class: "verdana" },
    { name: "Impact", class: "impact" },
    ], showToolbar: true,
    enableToolbar: true
  };


  constructor(private service: FeedbackService) { }

  ngOnInit() {
    this.columnDefs =
      [
        { field: 'id', colId: 'id', hide: true, headerName: 'Id', },
        { field: 'feedback', colId: 'feedback', hide: false, headerName: 'Feedback',},
        { field: 'comments', colId: 'comments',    hide: false, headerName: 'Comments',  },
        { field: 'status', colId: 'status', hide: false, headerName: 'status', editable: true }
      ];
      this.defaultColDef = {
        resizable: true,
        sortable: true,
        enableFilter: true,
        //width: 100,
       // editable: true,
        filter: true
      };
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();

    // this.store.select('dataManagementReducer').subscribe(data => {
    //   this.rowData = data;
    // });

    // this.store.select('referenceReducer').subscribe(data => {
    //   this.referenceData = data;
    //   console.log('reference ' + data);
    // });

    
  }

  autoSizeAll() {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  clearFilters() {
    console.log("clearFilters");
    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }

  onSelectionChanged() {
    var selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows != null) {
      this.selectedRow = selectedRows[0] ;
    }
  }

  onSubmit(){
    this.service.sendFeedback({
        "feedbackBody": this.feedbackComments});
  }

}
