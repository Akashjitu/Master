﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class ComplianceDataAccess : IComplianceDataAccess
    {
        public List<Compliance> LoadCompliance()
        {
            using (var dao = new DataAccessObject<Data.Models.Compliance>())
            {
                var data = dao.Load("PK_PSE_COMPLIANCE.SP_LOAD_COMPLIANCE");
                var returndata = new List<Data.Models.Compliance>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public int AddCompliance(Compliance compliance)
        {
            using (var dao = new DataAccessObject<Compliance>())
            {
                var data = dao.Post(compliance, "PK_PSE_COMPLIANCE.SP_ADD_COMPLIANCE");
                return data;
            }
        }

        public int DeleteCompliance(Compliance compliance)
        {
            using (var dao = new DataAccessObject<Compliance>())
            {
                var data = dao.Delete(compliance, "PK_PSE_COMPLIANCE.SP_REMOVE_COMPLIANCE");
                return data;
            }
        }

        public int UpdateCompliance(Compliance compliance)
        {
            using (var dao = new DataAccessObject<Compliance>())
            {
                var data = dao.Put(compliance, "PK_PSE_COMPLIANCE.SP_UPDATE_COMPLIANCE");
                return data;
            }
        }
    }
}