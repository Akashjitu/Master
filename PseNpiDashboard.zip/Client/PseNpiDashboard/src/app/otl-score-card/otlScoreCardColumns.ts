
import { DatePipe } from '@angular/common';

export class OtlScoreCardColumns {
constructor(private datePipe: DatePipe){}

       

    static  columns =
     [
        { field: 'id',                              colId: 	    'id',	                   		hide: true,	    headerName: 	'Id',	},
        { field: 'keyCode',                        colId: 	'keyCode',	               	hide: false,	headerName: 	'Key Code',	},
        { field: 'partNumber',                     colId: 	    'partNumber',			        hide: false,	headerName: 	'Part Number',	},
        { field: 'otlBaselineDate',                      colId: 	'otlBaselineDate',	       			hide: false,	headerName: 	'OTL Baseline',	},
        { field: 'lru',                        colId: 	'lru',	               	hide: false,	    headerName: 	'LRU',	},
        { field: 'productionSite',                             colId: 	'productionSite',			                hide: false,	headerName: 	'Production Site',	},
        { field: 'apqpLvl',                               colId: 	 'apqpLvl',	       			        hide: true,	headerName: 	'APQP Lvl',	},
        { field: 'plannedQty',                               colId: 	'plannedQty',	   			            hide: true,	headerName: 	'Planned Qty',	},
        { field: 'erpSystemLoad',                    colId: 	'erpSystemLoad',	            hide: true,	headerName: 	'ERP System Load',	},
        { field: 'plan',                             colId: 	'plan',			                hide: false,	headerName: 	'Plan',	},
        { field: 'actuals',                    colId: 	 'actuals',	       			        hide: false,	headerName: 	'Actuals',	},
        { field: 'forecast',                           colId: 	'forecast',	   			            hide: false,	headerName: 	'Forecast',	},
       
        { field: 'upcIndex',                    colId: 	'upcIndex',	            hide: false,	headerName: 	'UPC Index',	
         cellStyle: function (params) {

          var color='';
          if(params.value==null || params.value== undefined || params.value=='')
          {
            color = '';
          }
          else if(params.value > 1.0)
          {
            color='red';
          }
          else if(params.value <= 1.0)
          {
            color='green';
          } 

            return { "background-color": color,  'border-style': 'solid', 'border-color': 'white' };
          //  return { "background-color": params.value > 1.0 ? 'red':'green' ,  'border-style': 'solid', 'border-color': 'white' };
          }},
       
       
        { field: 'ese',                                colId: 	'ese',	            hide: false,	headerName: 	'ESE',  
        cellStyle: function (params) {

          var color='';
          if(params.value==null || params.value== undefined || params.value=='')
          {
            color = '';
          }
          else if(params.value > 1.0)
          {
            color='red';
          }
          else if(params.value <= 1.0)
          {
            color='green';
          } 

            return { "background-color": color,  'border-style': 'solid', 'border-color': 'white' };
          }	},
       
        { field: 'ece',                    colId: 	'ece',	            hide: false,	headerName: 	'ECE',	 cellStyle: function (params) {
            return { "background-color": params.value, 'color': params.value, 'border-style': 'solid', 'border-color': 'white' };
          }},


        { field: 'ppap',                    colId: 	'ppap',	            hide: false,	headerName: 	'PPAP',	},
        { field: 'prr',                    colId: 	'prr',	            hide: false,	headerName: 	'PRR',	},
        { field: 'mra',                    colId: 	'mra',	            hide: false,	headerName: 	'MRA',	},
        { field: 'updatedDate',                    colId: 	'updatedDate',	            hide: true,	headerName: 	'Updated Date',	},
        { field: 'updatedBy',                    colId: 	'updatedBy',	            hide: true,	headerName: 	'Updated By',	},
        { field: 'active',                    colId: 	'active',	            hide: true,	headerName: 	'Active',	},
        { field: 'createdDate',                    colId: 	'createdDate',	            hide: true,	headerName: 	'Created Date',	},
        { field: 'createBy',                    colId: 	'createBy',	            hide: true,	headerName: 	'Create By',	},
    ];

}

      	
