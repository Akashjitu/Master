﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="RangeModelMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using M2C.Business.Models;
using Schneider.M2C.OpenExcel.Parser.Model;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Class RangeModelMapper.
    /// Implements the <see cref="M2C.Business.Mappers.IRangeModelMapper" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.IRangeModelMapper" />
    public class RangeModelMapper : IRangeModelMapper
    {
        /// <summary>
        /// Maps the specified ranges.
        /// </summary>
        /// <param name="ranges">The ranges.</param>
        /// <returns>List&lt;RangeModel&gt;.</returns>
        public List<RangeModel> Map(List<Range> ranges)
        {
            if (ranges == null)
                return new List<RangeModel>();

            return ranges.Select(i => new RangeModel
            {
                Id = i.Id,
                Name = i.Name,
                OpsDescription = i.OpsDescription,
                CreatedDate = i.CreatedDate,
                UpdatedDate = i.UpdatedDate,
            }).ToList();
        }

        /// <summary>
        /// Maps the specified range.
        /// </summary>
        /// <param name="range">The range.</param>
        /// <returns>RangeModel.</returns>
        public RangeModel Map(Range range)
        {
            return new RangeModel
            {
                Id = range.Id,
                Name = range.Name,
                OpsDescription = range.OpsDescription,
                CreatedDate = range.CreatedDate,
                UpdatedDate = range.UpdatedDate,
            };
        }

        /// <summary>
        /// Maps the specified one ib catalogs.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        public List<Range> Map(params OneIbCatalog[] oneIbCatalogs)
        {
            var dic = oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.RangeLegacy)).GroupBy(i => i.RangeLegacy).ToDictionary(i => i.Key, k => k.ToList());
            return dic.Select(i => new Range
            {
                Name = i.Key,
                OpsDescription = i.Value.FirstOrDefault(x => !string.IsNullOrEmpty(x.OpsRangeDescription))?.OpsRangeDescription,
            }).ToList();
        }
    }
}