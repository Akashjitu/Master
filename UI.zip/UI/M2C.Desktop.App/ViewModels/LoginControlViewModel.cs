﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="LoginControlViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using AuthMiddleWare.Contracts;
using AuthMiddleWare.Models;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.Utils;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Timers;
using System.Web;
using System.Windows;
using System.Windows.Navigation;
using System.Windows.Threading;
using WinRegistryServices.Contracts;

namespace M2C.Desktop.App.ViewModels
{
    /// <summary>
    /// LoginControl ViewModel
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <summary>
    /// Class LoginControlViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    /// <summary>
    /// Class LoginControlViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    public class LoginControlViewModel : BindableBase, IDialogAware
    {
        /// <summary>
        /// The application configurations
        /// </summary>
        /// <summary>
        /// The application configurations
        /// </summary>
        private readonly IAppConfigurations appConfigurations;
        /// <summary>
        /// The registry store
        /// </summary>
        /// <summary>
        /// The registry store
        /// </summary>
        private readonly IRegistryStoreManger registryStore;
        /// <summary>
        /// The authentication
        /// </summary>
        private readonly IAuthentication authentication;
        /// <summary>
        /// The authorization
        /// </summary>
        private readonly IAuthorization authorization;

        /// <summary>
        /// Gets or sets the access token.
        /// </summary>
        /// <value>The access token.</value>
        private string AccessToken { get; set; }
        /// <summary>
        /// The UI dispacter
        /// </summary>
        private Dispatcher _uiDispacter = null;
        /// <summary>
        /// The web address
        /// </summary>
        private string webAddress;
        /// <summary>
        /// The progres bar visible
        /// </summary>
        private bool progresBarVisible = false;

        /// <summary>
        /// Occurs when [authentication code received].
        /// </summary>
        private event Action<string> AuthCodeReceived;

        #region PUBLIC PPROPERTIES

        /// <summary>
        /// Gets or sets the web address.
        /// </summary>
        /// <value>The web address.</value>
        public string WebAddress { get => webAddress; set => SetProperty(ref webAddress, value); }

        /// <summary>
        /// Gets or sets the load completed command.
        /// </summary>
        /// <value>The load completed command.</value>
        public DelegateCommand<object> LoadCompletedCommand { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [progres bar visible].
        /// </summary>
        /// <value><c>true</c> if [progres bar visible]; otherwise, <c>false</c>.</value>
        public bool ProgresBarVisible { get => progresBarVisible; set => SetProperty(ref progresBarVisible, value); }

        /// <summary>
        /// Gets or sets the navigating command.
        /// </summary>
        /// <value>The navigating command.</value>
        public DelegateCommand<object> NavigatingCommand { get; set; }

        #endregion PUBLIC PPROPERTIES

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginControlViewModel" /> class.
        /// </summary>
        /// <param name="appConfigurations">The application configurations.</param>
        /// <param name="registryStore">The registry store.</param>
        /// <param name="authorization">The authorization.</param>
        /// <param name="authentication">The authentication.</param>
        public LoginControlViewModel(IAppConfigurations appConfigurations, IRegistryStoreManger registryStore,
            IAuthorization authorization, IAuthentication authentication)
        {
            this.appConfigurations = appConfigurations;
            this.registryStore = registryStore;
            this.authentication = authentication;
            this.authorization = authorization;
            this.LoadCompletedCommand = new DelegateCommand<object>(onLoadCompletedCommand);
            this.NavigatingCommand = new DelegateCommand<object>(onNavigating);
            AuthCodeReceived += LoginControlViewModel_AuthCodeReceived;
        }

        /// <summary>
        /// Logins the control view model authentication code received.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void LoginControlViewModel_AuthCodeReceived(string obj)
        {
            AccessToken = authentication.getAccessToken(obj);
            if (!string.IsNullOrEmpty(this.AccessToken))
            {
                TokenJsonModel jsonToken = authorization.GetDecodedToken(AccessToken);

                if (!string.IsNullOrEmpty(jsonToken.Email))
                {
                    this.registryStore.SetValue(UIConstants.ACCESSTOKEN, AccessToken);

                    CloseOnSuccess(jsonToken);
                }
                else
                {
                    MessageBox.Show("Invalid Token", "Alert", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    this.registryStore.DeleteKey(UIConstants.ACCESSTOKEN);

                    getAbortTimer(500).Start();
                }
            }
            else
            {
                MessageBox.Show("Failed to Authorize", "Alert", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                getAbortTimer(500).Start();
            }
        }

        #region IDialogAware

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => UIConstants.M2C_LOGIN;

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            if (string.IsNullOrEmpty(this.AccessToken))
            {
                if (NetworkHelper.IsConnectedToInternet())
                {
                    if (MessageBox.Show("Login is not valid, Do you want to close application?", "Alert", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) == MessageBoxResult.Yes)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Offline login is not possible, you need to close the application", "Offline: Alert", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return true;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
        }

        /// <summary>
        /// Called when the dialog is opened.
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            _uiDispacter = Dispatcher.CurrentDispatcher;
            AccessToken = registryStore.GetValue(UIConstants.ACCESSTOKEN);
            if (!ValidateToken())
            {
                MessageBox.Show("Token Expired", "Authorization Error",
                        MessageBoxButton.OK, MessageBoxImage.Exclamation);
                this.registryStore.DeleteKey(UIConstants.ACCESSTOKEN);
                if (!NetworkHelper.IsConnectedToInternet())
                {
                    if (MessageBox.Show("Need Internet connection for login, (restart the tool after enabling Internet.)", "Network Error",
                        MessageBoxButton.OK, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
                    {
                        getAbortTimer(500).Start();
                    }
                }
                else
                {
                    WebAddress = authentication.GetLoginPath();
                }
            }
            else
            {
                getOKTimer(500).Start();
            }
        }

        /// <summary>
        /// Validates the token.
        /// </summary>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ValidateToken()
        {
            if (string.IsNullOrEmpty(AccessToken))
            {
                return false;
            }

            return authorization.ValidateToken(AccessToken);
        }

        /// <summary>
        /// Aborts this instance.
        /// </summary>
        private void Abort()
        {
            RaiseRequestClose(new DialogResult(ButtonResult.Abort));
        }

        /// <summary>
        /// Gets the timer.
        /// </summary>
        /// <param name="interval">The interval.</param>
        /// <returns>System.Timers.Timer.</returns>
        private System.Timers.Timer getAbortTimer(double interval)
        {
            Timer timer = new System.Timers.Timer(interval);
            timer.Elapsed += Timer_Elapsed;
            timer.AutoReset = false;
            return timer;
        }

        /// <summary>
        /// Gets the ok timer.
        /// </summary>
        /// <param name="interval">The interval.</param>
        /// <returns>System.Timers.Timer.</returns>
        private System.Timers.Timer getOKTimer(double interval)
        {
            Timer timer = new System.Timers.Timer(interval);
            timer.Elapsed += OKTimer_Elapsed; ;
            timer.AutoReset = false;
            return timer;
        }

        /// <summary>
        /// Handles the Elapsed event of the OKTimer control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ElapsedEventArgs" /> instance containing the event data.</param>
        private void OKTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _uiDispacter?.Invoke(() => { CloseOnSuccess(authorization.GetDecodedToken(AccessToken)); }); ;
        }

        /// <summary>
        /// Handles the Elapsed event of the Timer control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ElapsedEventArgs" /> instance containing the event data.</param>
        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _uiDispacter?.Invoke(() => { Abort(); });
        }

        #endregion IDialogAware

        #region PRIVATE FUNCTIONS

        /// <summary>
        /// Ons the load completed command.
        /// </summary>
        /// <param name="sender">The sender.</param>
        private void onLoadCompletedCommand(object sender)
        {
            ProgresBarVisible = false;
            if (sender is System.Windows.Navigation.NavigationEventArgs)
            {
                NavigationEventArgs args = sender as System.Windows.Navigation.NavigationEventArgs;

                string AuthCode = HttpUtility.ParseQueryString(args.Uri.Query).Get(UIConstants.CODE);

                if (AuthCode != null)
                {
                    AuthCodeReceived?.Invoke(AuthCode);
                }
                else
                {
                    string error = HttpUtility.ParseQueryString(args.Uri.Query).Get(UIConstants.IDMSERROR);
                    if (!string.IsNullOrWhiteSpace(error))
                    {
                        MessageBox.Show(error, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        getAbortTimer(500).Start();
                    }
                }
            }
        }

        /// <summary>
        /// Ons the navigating.
        /// </summary>
        /// <param name="sender">The sender.</param>
        private void onNavigating(object sender)
        {
            ProgresBarVisible = true;
        }

        /// <summary>
        /// Closes the on success.
        /// </summary>
        /// <param name="jsonToken">The json token.</param>
        private void CloseOnSuccess(object jsonToken)
        {
            IDialogParameters loginParam = new DialogParameters();
            loginParam.Add("TokenData", jsonToken);
            DialogResult result = new DialogResult(ButtonResult.OK, loginParam);
            RaiseRequestClose(result);
        }

        #endregion PRIVATE FUNCTIONS
    }
}