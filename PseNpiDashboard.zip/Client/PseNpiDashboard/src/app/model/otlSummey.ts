export interface OtlSummery {
    keyCode: string;
    programName:  string;
    productSbu:  string;
    hmrBaseline:  Date;
    rty:  string;
    upc:  string;
    escapes:  string;
    ppap:  string;
    prr:  string;
    mra:  string;
    otlHealth:  string;
    createdDate:  Date;
    createdBy:  string;
    updatedBy:  string;
    active:  string;
    updatedDate:  string;
    updatedByDashBoard: boolean;
    id:  number;
}