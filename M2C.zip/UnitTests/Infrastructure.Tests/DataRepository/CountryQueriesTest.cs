﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.Common;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class CountryQueriesTest : TestBase
    {
        private IQueryable<Country> countryList;
        private Mock<DbSet<Country>> countryMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            Country countryObj = new Country() { Id = 1, Name = "Name1" };
            List<Country> country = new List<Country>() { countryObj };
            countryList = country.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProjectDbContextMock = MockRepo.Create<IProjectDbContext>();

            countryMock = MockRepo.Create<DbSet<Country>>();
            countryMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(countryList.Provider);
            countryMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(countryList.Expression);
            countryMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(countryList.ElementType);
            countryMock.As<IQueryable<Country>>().Setup(m => m.GetEnumerator()).Returns(countryList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.Countries).Returns(countryMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);
        }

        [TestMethod]
        public void CountryQueriesConstructorTest()
        {
            ICountryQueries country = new ProjectQueries(IDbContextFactoryMock.Object);
            country.Should().NotBeNull();
            ((IDisposable)country).Dispose();
        }

        [TestMethod]
        public void CountryQueriesLoadCountriesTest()
        {
            ICountryQueries country = new ProjectQueries(IDbContextFactoryMock.Object);
            List<Country> countryRes = country.LoadCountries();
            countryRes.Should().HaveCount(1);
            ((IDisposable)country).Dispose();
        }
    }
}