﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="XrefProduct.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace DomainModels.ProjectModels
{
    /// <summary>
    /// Class XrefProduct.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class XrefProduct
    {
        /// <summary>
        /// Gets or sets the product identifier.
        /// </summary>
        /// <value>The product identifier.</value>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductID { get; set; }

        /// <summary>
        /// Gets or sets the ib catalogue identifier.
        /// </summary>
        /// <value>The ib catalogue identifier.</value>
        [Required]
        public int IBCatalogueID { get; set; }
        /// <summary>
        /// Gets or sets the pv number.
        /// </summary>
        /// <value>The pv number.</value>
        public string PVNumber { get; set; }
        /// <summary>
        /// Gets or sets the sv number.
        /// </summary>
        /// <value>The sv number.</value>
        public string SVNumber { get; set; }
        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        public int Quantity { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        [ForeignKey("ComponentId")]
        public IBProjectComponent IBProjectComponent { get; set; }

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        [ForeignKey("CommentId")]
        public virtual Comment Comment { get; set; }

        /// <summary>
        /// Called when [model creating].
        /// </summary>
        /// <param name="builder">The builder.</param>
        public static void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<XrefProduct>(entity =>
            {
                entity.Property(e => e.Quantity).HasDefaultValue<int>(0);
            });
        }
    }
}