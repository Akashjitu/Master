﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.Common;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class PositionQueriesTest : TestBase
    {
        private IQueryable<Position> positionList;
        private Mock<DbSet<Position>> positionMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            Position positionObj = new Position() { Id = 1, Name = "Name1" };
            List<Position> position = new List<Position>() { positionObj };
            positionList = position.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProjectDbContextMock = MockRepo.Create<IProjectDbContext>();

            positionMock = MockRepo.Create<DbSet<Position>>();
            positionMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(positionList.Provider);
            positionMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(positionList.Expression);
            positionMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(positionList.ElementType);
            positionMock.As<IQueryable<Position>>().Setup(m => m.GetEnumerator()).Returns(positionList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.Positions).Returns(positionMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);
        }

        [TestMethod]
        public void PositionQueriesConstructorTest()
        {
            IPositionQueries position = new ProjectQueries(IDbContextFactoryMock.Object);
            position.Should().NotBeNull();
            ((IDisposable)position).Dispose();
        }

        [TestMethod]
        public void PositionQueriesLoadPositionsTest()
        {
            IPositionQueries position = new ProjectQueries(IDbContextFactoryMock.Object);
            List<Position> positionRes = position.LoadPositions();
            positionRes.Should().HaveCount(1);
            ((IDisposable)position).Dispose();
        }
    }
}