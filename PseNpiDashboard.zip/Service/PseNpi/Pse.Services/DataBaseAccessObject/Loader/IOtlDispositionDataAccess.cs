﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IOtlDispositionDataAccess
    {
        List<OtlDispositionDetails> LoadOtlDispositionById(OtlDispositionDetails otlDisposition);

        List<OtlDispositionDetails> LoadOtlDispositionByDate(OtlDispositionDetails otlDisposition);

        List<OtlDispositionDetails> LoadOtlDispositionByKeyCode(OtlDispositionDetails otlDisposition);

        int UpdateOtlDispositionByID(OtlDispositionDetails otlDisposition);
    }
}