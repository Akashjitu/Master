﻿using System.Collections.Generic;


namespace Data.Management.Data.Models
{
  public  class EmployeeAccessRight
    {
      public  List<EmployeeInfo> EmployeeInfos { get; set; }

        public EmployeeInfo CurrentUserAccess { get; set; }
    }
}
