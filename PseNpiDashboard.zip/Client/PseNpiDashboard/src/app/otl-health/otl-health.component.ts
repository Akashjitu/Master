import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otl-health',
  templateUrl: './otl-health.component.html',
  styleUrls: ['./otl-health.component.css']
})
export class OtlHealthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
