import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-compliance',
  templateUrl: './data-compliance.component.html',
  styleUrls: ['./data-compliance.component.css']
})
export class DataComplianceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
