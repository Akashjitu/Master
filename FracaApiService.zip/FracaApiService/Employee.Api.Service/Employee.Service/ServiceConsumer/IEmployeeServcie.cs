﻿using ActiveDirectoryHelper;
using System.Collections.Generic;


namespace Fraca.Service.ServiceConsumer
{
    public interface IEmployeeServcie
    {
        List<ADUserDetail> GetEmployeeInfo(string eid);
    }
}
