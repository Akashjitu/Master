﻿using M2C.Business.Contracts;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Modules.ProjectPane.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;

namespace M2C.UI.Tests.ProjectPaneModule
{
    [TestClass]
    public class ProjectScreenViewModelTest : TestBase
    {
        private Mock<IGlobalMenuComands> mockGlobalMenuComands;
        private Mock<IRegionManager> mockIRegionManager;
        private Mock<ISharedContextService> mockSharedContextService;
        private Mock<IProjectLogic> MockprojectLogic;
        private Mock<IEventAggregator> MockIEventAggregator;

        [TestInitialize]
        public void TestIniTialize()
        {
            mockGlobalMenuComands = MockRepo.Create<IGlobalMenuComands>();
            mockIRegionManager = MockRepo.Create<IRegionManager>();
            mockSharedContextService = MockRepo.Create<ISharedContextService>();
            MockprojectLogic = MockRepo.Create<IProjectLogic>();
            MockIEventAggregator = MockRepo.Create<IEventAggregator>();
            mockGlobalMenuComands.SetupGet(x => x.NewProjectCommand).Returns(new CompositeCommand());
            mockGlobalMenuComands.SetupGet(x => x.SaveCommand).Returns(new CompositeCommand());
            mockGlobalMenuComands.SetupGet(x => x.ExportProjectCommand).Returns(new CompositeCommand());
        }

        [TestMethod]
        public void ProjectScreenViewModelObjectTest()
        {
            ProjectScreenViewModel vm = new ProjectScreenViewModel(mockGlobalMenuComands.Object, mockIRegionManager.Object, 
                mockSharedContextService.Object, MockprojectLogic.Object, MockIEventAggregator.Object);
            if (vm.SaveCommand != null)
            {
                Assert.IsTrue(true, "MainWindowViewModel Created");
            }
        }
    }
}