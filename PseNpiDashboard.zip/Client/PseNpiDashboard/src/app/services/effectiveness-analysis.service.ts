import { Injectable } from '@angular/core';
import { saveAs } from 'file-saver';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/accoladeReducer';
import * as EffectivenessAnalysisAction from './../store/effectivenessAnalysis/effectivenessAnalysisAction';


@Injectable({
  providedIn: 'root'
})
export class EffectivenessAnalysisService {

  headers: any;

  constructor(private http: HttpClient, private store: Store<IAppState>, ) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
      withCredentials: 'true',
    });
  }


  reportDownload(date) {
    console.log(date);
    this.http.get('http://localhost:49855/effectivenesanalysis?date=' + date, { responseType: 'blob', headers: this.headers })
      .subscribe(response => {
        saveAs(response, 'EffectivenessAnalysis-' + date + '.xlsx',
          { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
      },
        err => {
          console.log(`ERROR: ${err}`),
          console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service');
        });
  }

  getCompliance(date) {
    console.log('http://localhost:49855/api/EffectivenessAnalysis?date=');
    this.http.get<any>('http://localhost:49855/api/EffectivenessAnalysis?date=' + date)
      .subscribe(values => this.store.dispatch(new EffectivenessAnalysisAction.LoadEffectivenessAnalysis(values),
      ),
        err => { console.log(`ERROR: ${err}`); });
  }


  saveCompliance(modifieditems) {
    console.log('saveCompliance' + modifieditems );
    return this.http.post('http://localhost:49855/api/EffectivenessAnalysis', modifieditems,  { headers: this.headers})
      .subscribe(infoData => console.log(infoData)      );
  }

}
