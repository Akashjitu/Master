﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogFilter;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class FilterIbCatalogProductCategoryQueriesTest : TestBase
    {
        private IQueryable<FilterIbCatalogProductCategory> filterList;
        private Mock<DbSet<FilterIbCatalogProductCategory>> filterMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            FilterIbCatalogProductCategory filterObj = new FilterIbCatalogProductCategory() { Id = 1, Name = "Name1" };
            List<FilterIbCatalogProductCategory> filter = new List<FilterIbCatalogProductCategory>() { filterObj };
            filterList = filter.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();

            filterMock = MockRepo.Create<DbSet<FilterIbCatalogProductCategory>>();
            filterMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(filterList.Provider);
            filterMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(filterList.Expression);
            filterMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(filterList.ElementType);
            filterMock.As<IQueryable<FilterIbCatalogProductCategory>>().Setup(m => m.GetEnumerator()).Returns(filterList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.FilterIbCatalogProductCategories).Returns(filterMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void FilterIbCatalogProductCategoryQueriesConstructorTest()
        {
            IFilterIbCatalogProductCategoryQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            filter.Should().NotBeNull();
            ((IDisposable)filter).Dispose();
        }

        [TestMethod]
        public void FilterIbCatalogProductCategoryQueriesFilterIbCatalogProductCategoriesTest()
        {
            IFilterIbCatalogProductCategoryQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            List<FilterIbCatalogProductCategory> filterRes = filter.FilterIbCatalogProductCategories();
            filterRes.Should().HaveCount(1);
            ((IDisposable)filter).Dispose();
        }

        [TestMethod]
        public void FilterIbCatalogProductCategoryQueriesFilterIbCatalogProductCategoriesbyFilterTest()
        {
            FilterIbCatalogProductCategory filters = null;
            IFilterIbCatalogProductCategoryQueries filter = new ProductQueries(IDbContextFactoryMock.Object);
            List<FilterIbCatalogProductCategory> filterRes = filter.FilterIbCatalogProductCategories(filters);
            filterRes.Should().BeNull();
            filters = new FilterIbCatalogProductCategory() { Id = 1, Name = "Name1" };
            filterRes = filter.FilterIbCatalogProductCategories(filters);
            filterRes.Should().HaveCount(1);
            ((IDisposable)filter).Dispose();
        }
    }
}