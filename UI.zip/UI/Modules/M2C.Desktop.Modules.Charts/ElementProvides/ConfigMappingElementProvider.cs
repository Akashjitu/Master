﻿using System.Collections.Generic;
using System.Linq;
using M2C.Business;
using M2C.Business.Models;
using M2C.Business.Models.Chart;
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    /// <summary>
    /// Provide Configuration Mapping Binding
    /// </summary>
    public class ConfigMappingElementProvider : IConfigMappingElementProvider
    {
        /// <summary>
        /// Get Configuration Mapping Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetConfigurationMappingElements(ChartParameter chartParameter, NodeType type = NodeType.OPEN_CONFIG)
        {
            var elements = new ChartBarElements();
            var nodeType = chartParameter.SelectedParameterNode.NodeType;
            var selectedNodes = chartParameter.SelectedParameterNode.Nodes;

            var allConfigurationNodes = chartParameter.AllParameterNodes
                .Where(conf => conf.NodeType == type).SelectMany(i => i.Nodes).ToList();

            var numberString = chartParameter.SelectedElementNumber; // total number selected by user...
            if (numberString == "All")
            {
                if (nodeType == type)
                {
                    foreach (var node in allConfigurationNodes)
                    {
                        BindNormalMapping(node.Name, node.Inventories, elements);
                    }
                }
                else
                {
                    foreach (var node in selectedNodes)
                    {
                        var inventories = allConfigurationNodes.Where(i =>
                            i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                            i.ParentNodeAndNodeType[nodeType].Id == node.Id).SelectMany(i => i.Inventories).ToList();
                        BindNormalMapping(node.Name, inventories, elements);
                    }
                }
            }
            else // find the user selection and loop till selection & rest added on Others
            {
                int.TryParse(numberString, out var num);
                var tempNum = 1;
                if (nodeType == type)
                {
                    foreach (var node in allConfigurationNodes)
                    {
                        BindNormalMapping(tempNum < num ? node.Name : "Others", node.Inventories, elements);
                        tempNum++;
                    }
                }
                else
                {
                    foreach (var node in selectedNodes)
                    {
                        var inventories = allConfigurationNodes.Where(i =>
                            i.ParentNodeAndNodeType.ContainsKey(nodeType) &&
                            i.ParentNodeAndNodeType[nodeType].Id == node.Id).SelectMany(i => i.Inventories).ToList();
                        BindNormalMapping(tempNum < num ? node.Name : "Others", inventories, elements);
                        tempNum++;
                    }
                }
            }

            return elements;
        }

        /// <summary>
        /// Binds the Config mapping.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="inventories">The inventories.</param>
        /// <param name="elements">The inventories.</param>
        private static void BindNormalMapping(string name, ICollection<Inventory> inventories, ChartBarElements elements)
        {

            var plcInventories = inventories.Where(i => i.ConfigType == BusinessConstants.PLC_CONFIGURATION).ToList();
            var hmiInventories = inventories.Where(i => i.ConfigType == BusinessConstants.SCADA_HMI_CONFIGURATION).ToList();
            var motiaonInventories = inventories.Where(i => i.ConfigType == BusinessConstants.MOTION_DRIVE_CONFIGURATION).ToList();
            var openInventories = inventories.Where(i => i.ConfigType == BusinessConstants.OPEN_CONFIGURATION).ToList();



            var chartPlcBarElement = new ChartBarElement { ConfigCount = plcInventories.Sum(k => k.Quantity), Name = name };
            var isPlcChartBarElement = elements.PlcChartElements.FirstOrDefault(i => i.Name == chartPlcBarElement.Name);
            if (isPlcChartBarElement == null) elements.PlcChartElements.Add(chartPlcBarElement); else isPlcChartBarElement.ConfigCount += chartPlcBarElement.ConfigCount;

            var chartHmiBarElement = new ChartBarElement { ConfigCount = hmiInventories.Sum(k => k.Quantity), Name = name };
            var isHmiChartBarElement = elements.HmiChartElements.FirstOrDefault(i => i.Name == chartHmiBarElement.Name);
            if (isHmiChartBarElement == null) elements.HmiChartElements.Add(chartHmiBarElement); else isHmiChartBarElement.ConfigCount += chartHmiBarElement.ConfigCount;


            var chartMotiaonBarElement = new ChartBarElement { ConfigCount = motiaonInventories.Sum(k => k.Quantity), Name = name };
            var isMotiaonChartBarElement = elements.MotionChartElements.FirstOrDefault(i => i.Name == chartMotiaonBarElement.Name);
            if (isMotiaonChartBarElement == null) elements.MotionChartElements.Add(chartMotiaonBarElement); else isMotiaonChartBarElement.ConfigCount += chartMotiaonBarElement.ConfigCount;

            var chartOpenBarElement = new ChartBarElement { ConfigCount = openInventories.Sum(k => k.Quantity), Name = name };
            var isOpenChartBarElement = elements.OpenChartElements.FirstOrDefault(i => i.Name == chartOpenBarElement.Name);
            if (isOpenChartBarElement == null) elements.OpenChartElements.Add(chartOpenBarElement); else isOpenChartBarElement.ConfigCount += chartOpenBarElement.ConfigCount;
        }
    }
}