﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="CompetenciesNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project.IBComponents;
using System;
using System.Collections.Generic;
using System.Text;

namespace M2C.Business.Models.Project.TRComponents
{
    /// <summary>
    /// Competencies node Business Model
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.TRComponents.TRBaseNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CompetenciesNode : Node
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompetenciesNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public CompetenciesNode(string name)
        {
            this.Name = name;
            this.NodeType = NodeType.COMPETENCIES;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CompetenciesNode" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="parentNode">The parent node.</param>
        public CompetenciesNode(int id, string name, INode parentNode)
        {
            Id = id;
            ParentNode = parentNode;
            this.Name = name;
            this.NodeType = NodeType.COMPETENCIES;
        }
    }
}
