﻿using Pse.Data.Models;
using Pse.Services.DataBaseAccessObject.Loader;
using System;
using System.Collections.Generic;

namespace Pse.Services.Manager
{
    public class OtlScoreCardManager : IOtlScoreCardManager
    {
        private IOtlScoreCardDataAccess _dataAccessr;

        public OtlScoreCardManager(IOtlScoreCardDataAccess dataAccessr)
        {
            _dataAccessr = dataAccessr;
        }

        public OtlScoreCard AddOtlScoreCard(OtlScoreCard otlScoreCard)
        {
            return _dataAccessr.AddOtlScoreCard(otlScoreCard);
        }

        public List<OtlScoreCard> LoadAllOtlScoreCards()
        {
            return _dataAccessr.LoadAllOtlScoreCards();
        }

        public List<OtlScoreCard> LoadLatestOtlScoreCard(string keycode)
        {
            return _dataAccessr.LoadLatestOtlScoreCard(keycode);
        }

        public List<OtlScoreCard> LoadOtlScoreCardByBaseLineDate(DateTime baselineDate)
        {
            return _dataAccessr.LoadOtlScoreCardByBaseLineDate(baselineDate);
        }

        public List<OtlScoreCard> LoadOtlScoreCardById(int Id)
        {
            return _dataAccessr.LoadOtlScoreCardById(Id);
        }

        public List<OtlScoreCard> LoadOtlScoreCardByKeyCode(string keycode)
        {
            return _dataAccessr.LoadOtlScoreCardByKeyCode(keycode);
        }

        public List<OtlScoreCard> LoadScoreCardByCreationDate(DateTime creationDate)
        {
            return _dataAccessr.LoadScoreCardByCreationDate(creationDate);
        }

        public OtlScoreCard UpdateOtlScoreCard(OtlScoreCard otlScoreCard)
        {
            return _dataAccessr.UpdateOtlScoreCard(otlScoreCard);
        }
    }
}