﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IExcelImport.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using System.Collections.Generic;

namespace M2C.Business.Contracts
{
    /// <summary>
    /// Interface for the excel import
    /// </summary>
    public interface IExcelImport
    {
        /// <summary>
        /// Trs the base node import.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <returns>TRNode.</returns>
        TRNode TRBaseNodeImport(string filePath);

        /// <summary>
        /// Trs the base node import.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <param name="trNode">The tr node.</param>
        void TRBaseNodeImport(string filePath, TRNode trNode);

        /// <summary>
        /// Ibs the component import.
        /// </summary>
        /// <param name="filepath">The filepath.</param>
        /// <param name="installedBase">The installed base.</param>
        void IBComponentImport(string filepath, InstalledBase installedBase);

        /// <summary>
        /// Inventory Import
        /// </summary>
        /// <param name="filepath">The filepath.</param>
        /// <param name="configNodes">The configuration nodes.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        List<Inventory> IbInventoryImport(string filepath, List<Node> configNodes);

        /// <summary>
        /// TR Inventory
        /// </summary>
        /// <param name="filepath">The filepath.</param>
        /// <param name="stockNodes">The stock nodes.</param>
        /// <returns>List&lt;Inventory&gt;.</returns>
        List<Inventory> TrInventoryImport(string filepath, List<StockNode> stockNodes);
    }
}