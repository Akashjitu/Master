﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.IO;
using System.Reflection;
using System.Configuration;

namespace Pse.Npi.Host.Logs
{
    public class LogWriter
    {
        private static string m_exePath = @"C:\IIS_Logs\Service\Logs";
        //public LogWriter(string logMessage)
        //{
        //    LogWrite(logMessage);
        //}

             
        public static void LogWrite(string logMessage)
        {
            bool isLogEnable = false;
            bool.TryParse(ConfigurationManager.AppSettings["ENABLE_LOG"], out isLogEnable);

            if (isLogEnable == false)
                return;
            m_exePath = ConfigurationManager.AppSettings["LOG_FILE_DIRECTORY"];

            // m_exePath = Path.GetDirectoryName(typeof(LogWriter).Assembly.Location);
            //Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (!Directory.Exists(m_exePath))
            {
                Directory.CreateDirectory(m_exePath);
            }
            try
            {
                lock (m_exePath)
                {
                    using (StreamWriter w = File.AppendText(m_exePath + "\\" + ConfigurationManager.AppSettings["LOG_FILE_NAME"]+"_" + DateTime.Today.ToString("yyyy-MM-dd") + ".txt"))
                    {
                        Log(logMessage, w);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public  static void Log(string logMessage, TextWriter txtWriter)
        {
            try
            {
                txtWriter.Write("\r\nLog Entry : ");
                txtWriter.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(),
                    DateTime.Now.ToLongDateString());
                txtWriter.WriteLine("  :");
                txtWriter.WriteLine("  :{0}", logMessage);
                txtWriter.WriteLine("-------------------------------");
            }
            catch (Exception ex)
            {

            }
        }
    }
}