﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class OtlAnalysisDataAccess : IOtlAnalysisDataAccess
    {
        public int AddOtlAnalysisById(OtlAnalysis otl)
        {
            using (var dao = new DataAccessObject<OtlAnalysis>())
            {
                return dao.Post(otl, "PK_PSE_OTL_ANALYSIS.SP_ADD");
            }
        }

        public List<OtlAnalysis> LoadOtlAnalysis()
        {
            using (var dao = new DataAccessObject<OtlAnalysis>())
            {
                var data = dao.Load("PK_PSE_OTL_ANALYSIS.SP_LOAD");
                var returndata = new List<OtlAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlAnalysis> LoadOtlAnalysisByDate(OtlAnalysis otl)
        {
            using (var dao = new DataAccessObject<OtlAnalysis>())
            {
                var data = dao.Load("PK_PSE_OTL_ANALYSIS.SP_LOAD_BY_DATE");
                var returndata = new List<OtlAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlAnalysis> LoadOtlAnalysisById(OtlAnalysis otl)
        {
            using (var dao = new DataAccessObject<OtlAnalysis>())
            {
                var data = dao.Load("PK_PSE_OTL_ANALYSIS.SP_LOAD_BY_ID");
                var returndata = new List<OtlAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<OtlAnalysis> LoadOtlAnalysisByKeyCode(OtlAnalysis otl)
        {
            using (var dao = new DataAccessObject<OtlAnalysis>())
            {
                var data = dao.Load("PK_PSE_OTL_ANALYSIS.SP_LOAD_KEY_CODE");
                var returndata = new List<OtlAnalysis>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public int UpdateOtlAnalysisById(OtlAnalysis otl)
        {
            using (var dao = new DataAccessObject<OtlAnalysis>())
            {
                return  dao.Put(otl, "PK_PSE_OTL_ANALYSIS.SP_UPDATE");
            }
        }
    }
}