﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProfileQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.Common;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IProfileQueries
    /// </summary>
    public interface IProfileQueries
    {
        /// <summary>
        /// Saves the profile.
        /// </summary>
        /// <param name="profile">The profile.</param>
        void SaveProfile(Profile profile);

        /// <summary>
        /// Removes the profile.
        /// </summary>
        /// <param name="profileId">The profile identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool RemoveProfile(int profileId);

        /// <summary>
        /// Gets the profile.
        /// </summary>
        /// <returns>Profile.</returns>
        Profile GetProfile();
    }
}