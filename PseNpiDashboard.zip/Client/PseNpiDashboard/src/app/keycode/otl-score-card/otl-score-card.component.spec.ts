import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtlScoreCardComponent } from './otl-score-card.component';

describe('OtlScoreCardComponent', () => {
  let component: OtlScoreCardComponent;
  let fixture: ComponentFixture<OtlScoreCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtlScoreCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtlScoreCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
