﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CommentModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace M2C.Business.Models.Project
{
    /// <summary>
    /// Class CommentModel.
    /// </summary>
    public class CommentModel
    {
        /// <summary>
        /// Gets or sets the comment identifier.
        /// </summary>
        /// <value>The comment identifier.</value>
        public int CommentId { get; set; }

        /// <summary>
        /// Gets or sets the comment data.
        /// </summary>
        /// <value>The comment data.</value>
        public string CommentData { get; set; }
    }
}
