export interface Compliance {
    id: number;
    Keycode: string;
    HeatmapValid: string;
    HeatmapComment: string;
    OTLValid: string;
    OTLComment: string;
    ESEValid: string;
    ESEComment: string;
    APQPPlanValid: string;
    APQPPlanComment: string;
    SimPartValid: string;
    SimilarPartComment: string;
    IPTValid: string;
    IPTComment: string;
    PartValid: string;
    PartComment: string;
    RTYValid: string;
    RTYComment: string;
    UPCValid: string;
    UPCComment: string;
    CreatedBy: string;
    CreateDon: Date;
    UpdartedBy: string;
    UpdateDon: Date;
    IsActive: number;
}
