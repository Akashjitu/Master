﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.ExcelExports
{
    public interface ITtiExports
    {
        byte[] Export(List<TtiPartAlignment> ttiPartAlignment);
    }
}