﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pse.Services.Manager
{
   public interface IOtlSummeryManager
    {
        List<OtlSummery> LoadAllOtlSummery();

        List<OtlSummery> LoadOtlSummeryByCreatedDate(DateTime created);

        List<OtlSummery> LoadOtlSummeryByBaseLine(DateTime baseLine);

        List<OtlSummery> LoadOtlSummeryByKeyCode(string keycode);
        List<OtlSummery> LoadOtlSummeryByID(int id);

        OtlSummery UpdateOtlSummery(OtlSummery otlSummery);

        OtlSummery AddOtlSummery(OtlSummery otlSummery);
    }
}
