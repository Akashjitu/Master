import { Action } from '@ngrx/store';
import * as PliSummaryAction from './pliSummaryAction';
import { PliSummary } from 'src/app/model/pliSummary';


export interface IAppState {
    readonly compliance: PliSummary[];
}


export function pliSummaryReducer(state: PliSummary[] = [], action: PliSummaryAction.Actions) {

    switch (action.type) {

        case PliSummaryAction.ADD_PLI_SUMMARY: {
            return [...state, action.payload]

        }

        case PliSummaryAction.LOAD_PLI_SUMMARY: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case PliSummaryAction.UPDATE_PLI_SUMMARY: {
            const tti = (action.payload as PliSummary);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            
            return state.slice();
        }



        default:
            return state;
    }
}