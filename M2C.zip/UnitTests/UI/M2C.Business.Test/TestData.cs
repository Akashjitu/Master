﻿using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2C.Business.Test
{
    public class TestData
    {

        public static List<IBImportModel> GetIBData()
        {
            return new List<IBImportModel>()
            {
                new IBImportModel(){Factory="Factory1",Workshop="Workshop1",Line="Line1", Machine="Machine1",ConfigurationName="PLC Configuration",ConfigurationType="PLC" ,Reference="Refernce1", Brand="Brand1", MachineCriticity="MachineCriticity1", PV="PV1", SV="SV1",Description="DESC1", Quantity="Q1", Comment="comment1"},
                new IBImportModel(){Factory="Factory2",Workshop="Workshop2",Line="Line2", Machine="Machine2",ConfigurationName="PLC Configuration",ConfigurationType="PLC",Reference="Refernce2", Brand="Brand2", MachineCriticity="MachineCriticity2", PV="PV2", SV="SV2",Description="DESC2", Quantity="Q2", Comment="comment2" },

            };
        }

        public static List<TRImportModel> GetTRData()
        {
            return new List<TRImportModel>()
            {
                new TRImportModel(){Maintenancezone="Maintenance",Configuration="Stock1", Brand="Brand1", Quantity="Q1", Description="Desc1", Reference="Reference1", PV="PV1", SV="SV1", Comment="comment1" },
                new TRImportModel(){Maintenancezone="Maintenance",Configuration="Stock2" , Brand="Brand2", Quantity="Q2", Description="Desc2", Reference="Reference2", PV="PV2", SV="SV2", Comment="comment2" }

            };
        }

        public static List<OneIbCatalog> GetIBCatalogueData()
        {
            return new List<OneIbCatalog>()
            {
                new OneIbCatalog(){ Bu="BU1", BrandLegacy="BLegacy1", RangeLegacy="RLegacy1"},
                new OneIbCatalog(){ Bu="BU2", BrandLegacy="BLegacy2", RangeLegacy="RLegacy2"}
            };
        }
    }
}
