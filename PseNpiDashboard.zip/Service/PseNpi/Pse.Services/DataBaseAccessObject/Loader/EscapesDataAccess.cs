﻿using Oracle.Data.Access;
using Pse.Data.Models;
using Pse.Services.Constants;
using System;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class EscapesDataAccess : IEscapesDataAccess
    {
        public List<Escapes> LoadEscapesData()
        {
            using (var dao = new DataAccessObject<Escapes>())
            {
                var data = dao.Load("PK_PSE_ESCAPES.SP_LOAD_ESCAPES");
                var returndata = new List<Escapes>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Escapes> LoadEscapesDataByDate(Escapes escapes)
        {
            using (var dao = new DataAccessObject<Escapes>())
            {
                var data = dao.LoadByInput(escapes, "PK_PSE_ESCAPES.SP_LOAD_ESCAPES_BY_MO_YY");
                var returndata = new List<Escapes>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Escapes> LoadEscapesDataById(Escapes escapes)
        {
            using (var dao = new DataAccessObject<Escapes>())
            {
                var data = dao.LoadByInput(escapes, "PK_PSE_ESCAPES.SP_LOAD_ESCAPES_BY_ID");
                var returndata = new List<Escapes>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Escapes> LoadEscapesDataByPart(Escapes escapes)
        {
            using (var dao = new DataAccessObject<Escapes>())
            {
                var data = dao.LoadByInput(escapes, "PK_PSE_ESCAPES.SP_LOAD_ESCAPES_BY_PART");
                var returndata = new List<Escapes>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Escapes> LoadEscapesDataBtweenShipDate(DateTime toShipDate, DateTime fromShipDate)
        {
            using (var dao = new DataAccessObject<Escapes>())
            {
                var data = dao.LoaderByQuery(string.Format(ServiceConstant.LoadBtweenShipDate, toShipDate, fromShipDate));
                var returndata = new List<Escapes>();
                returndata.AddRange(data);
                return returndata;
            }
        }
    }
}