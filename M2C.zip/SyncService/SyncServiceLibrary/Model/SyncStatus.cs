﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SyncStatus.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace SyncServiceLibrary.Model
{
    /// <summary>
    /// Enum SyncStatus
    /// </summary>
    public enum SyncStatus
    {
        /// <summary>
        /// The none
        /// </summary>
        NONE = 0,
        /// <summary>
        /// The in progress
        /// </summary>
        IN_PROGRESS,
        /// <summary>
        /// The retrying
        /// </summary>
        RETRYING,
        /// <summary>
        /// The success
        /// </summary>
        SUCCESS,
        /// <summary>
        /// The failed
        /// </summary>
        FAILED
    }
}