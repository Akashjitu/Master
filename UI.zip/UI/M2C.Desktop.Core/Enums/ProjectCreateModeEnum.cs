﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 03-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProjectCreateModeEnum.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Desktop.Core.Enums
{
    /// <summary>
    /// Enum ProjectCreateModes
    /// </summary>
    public enum ProjectCreateModes
    {
        /// <summary>
        /// The none
        /// </summary>
        NONE = 0,
        /// <summary>
        /// The new
        /// </summary>
        NEW = 1,
        /// <summary>
        /// The edit
        /// </summary>
        EDIT = 2
    }
}