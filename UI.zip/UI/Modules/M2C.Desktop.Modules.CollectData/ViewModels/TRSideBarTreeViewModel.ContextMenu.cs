﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="TRSideBarTreeViewModel.ContextMenu.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.GlobalFields;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using M2C.Desktop.Core.GlobalEvents;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class TRSideBarTreeViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="System.IDisposable" />
    public partial class TRSideBarTreeViewModel : BindableBase, IDisposable
    {
        /// <summary>
        /// The clipboard node
        /// </summary>
        private Node _clipboardNode;

        /// <summary>
        /// The selected node type changed
        /// </summary>
        private NodeType _selectedNodeTypeChanged;

        /// <summary>
        /// The is action cut
        /// </summary>
        private bool isActionCut = false;

        #region PROPERTISE

        /// <summary>
        /// Gets or sets the clip board node.
        /// </summary>
        /// <value>The clip board node.</value>
        private Node ClipBoardNode { get => _clipboardNode; set => SetProperty(ref _clipboardNode, value); }

        /// <summary>
        /// Gets or sets the selected node type changed.
        /// </summary>
        /// <value>The selected node type changed.</value>
        private NodeType SelectedNodeTypeChanged { get => _selectedNodeTypeChanged; set => SetProperty(ref _selectedNodeTypeChanged, value); }

        /// <summary>
        /// Gets or sets the clip board node reference.
        /// </summary>
        /// <value>The clip board node reference.</value>
        private Node ClipBoardNodeRef { get; set; }

        #endregion PROPERTISE

        #region COMMANDS

        /// <summary>
        /// Gets or sets the node rename command.
        /// </summary>
        /// <value>The node rename command.</value>
        public DelegateCommand NodeRenameCommand { get; set; }

        /// <summary>
        /// Gets or sets the node cut command.
        /// </summary>
        /// <value>The node cut command.</value>
        public DelegateCommand NodeCutCommand { get; set; }

        /// <summary>
        /// Gets or sets the node copy command.
        /// </summary>
        /// <value>The node copy command.</value>
        public DelegateCommand NodeCopyCommand { get; set; }

        /// <summary>
        /// Gets or sets the node paste command.
        /// </summary>
        /// <value>The node paste command.</value>
        public DelegateCommand NodePasteCommand { get; set; }

        /// <summary>
        /// Gets or sets the node delete command.
        /// </summary>
        /// <value>The node delete command.</value>
        public DelegateCommand NodeDeleteCommand { get; set; }

        #endregion COMMANDS

        /// <summary>
        /// Trs the side bar TreeView model context menu initialize.
        /// </summary>
        private void TRSideBarTreeViewModel_ContextMenu_init()
        {
            NodeRenameCommand = new DelegateCommand(onNodeRename);

            NodeCutCommand = new DelegateCommand(onNodeCutCommand, canCutCommand).ObservesProperty(() => SelectedNodeTypeChanged);

            NodeCopyCommand = new DelegateCommand(onNodeCopyCommand, canCopyCommand).ObservesProperty(() => SelectedNodeTypeChanged);

            NodePasteCommand = new DelegateCommand(onPasteCommand, canPasteCommand)
                .ObservesProperty(() => SelectedNodeTypeChanged).ObservesProperty(() => ClipBoardNodeRef);

            NodeDeleteCommand = new DelegateCommand(onDeleteCommand, canDeleteCommand)
                .ObservesProperty(() => SelectedNodeTypeChanged);

            _eventAggregator.GetEvent<TRTreeViewChangeEvent>().Subscribe(onSelectedNodeChange);

            ClipBoardNodeRef = null;
        }

        #region PRIVATE FUNCTIONS

        /// <summary>
        /// Ons the node rename.
        /// </summary>
        private void onNodeRename()
        {
            if (SelectedNode != null)
            {
                var n = (SelectedNode as Node);
                if (n != null) n.IsEditable = !n.IsEditable;
            }
        }

        /// <summary>
        /// Determines whether this instance [can cut d command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can cut d command]; otherwise, <c>false</c>.</returns>
        private bool canCutCommand()
        {
            if (SelectedNode != null && SelectedNode is IDelete)
            {
                return true;
            }
            {
                return false;
            }
        }

        /// <summary>
        /// Ons the node cut command.
        /// </summary>
        private void onNodeCutCommand()
        {
            ClipBoardNodeRef = SelectedNode;
            ClipBoardNode = (SelectedNode as ICloneable)?.Clone() as Node;
            isActionCut = true;
        }

        /// <summary>
        /// Determines whether this instance [can copy command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can copy command]; otherwise, <c>false</c>.</returns>
        private bool canCopyCommand()
        {
            if (SelectedNode != null && SelectedNode is ICloneable)
            {
                return true;
            }
            {
                return false;
            }
        }

        /// <summary>
        /// Ons the node copy command.
        /// </summary>
        private void onNodeCopyCommand()
        {
            ClipBoardNodeRef = SelectedNode;
            ClipBoardNode = (SelectedNode as ICloneable)?.Clone() as Node;

            isActionCut = false;
        }

        /// <summary>
        /// Determines whether this instance [can paste command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can paste command]; otherwise, <c>false</c>.</returns>
        private bool canPasteCommand()
        {
            if (ClipBoardNode != null && SelectedNode != null)
            {
                Node n = ClipBoardNode as Node;
                if (n.NodeType == NodeType.STOCK)
                {
                    return SelectedNodeTypeChanged == NodeType.MAINTENANCEZONE;
                }
            }
            {
                return false;
            }
        }

        /// <summary>
        /// Ons the paste command.
        /// </summary>
        private void onPasteCommand()
        {
           
            Node n = ClipBoardNode as Node;
            switch (n.NodeType)
            {
                case NodeType.STOCK:
                    {
                        MaintenanceNode mNode = _selectedNode as MaintenanceNode;
                        if (ClipBoardNode is StockNode stackNode)
                        {
                            stackNode.Id = GlobalFiled.GenerateRandomId();
                            if (!isActionCut)
                                stackNode.Name = $"Copy of {stackNode.Name}";
                            stackNode.ParentNode = _selectedNode as INode;
                            mNode?.StockNodes.Add(stackNode);
                            SetCopiedInventories(new List<INode>() { stackNode });
                        }
                    }
                    break;
            }

            if (isActionCut)
            {
                if ((_selectedNode as Node)?.Id == ClipBoardNodeRef.ParentNode.Id)
                {
                    if (ClipBoardNode is StockNode stackNode)
                    {
                        stackNode.Name = $"Copy of {stackNode.Name}";
                    }
                }
                else
                {
                    RemoveNode(ClipBoardNodeRef);
                }

                isActionCut = false;
            }
            else
            {
                ClipBoardNode = (ClipBoardNode as ICloneable)?.Clone() as Node;

                if (ClipBoardNode != null && !ClipBoardNode.Name.Contains("Copy of"))
                {
                    ClipBoardNode.Name = $"Copy of {ClipBoardNode.Name}";
                }
            }
        }

        /// <summary>
        /// Removes the node.
        /// </summary>
        /// <param name="node">The node.</param>
        private void RemoveNode(INode node)
        {
            var inventories = new List<Inventory>();
            switch (node.NodeType)
            {
                case NodeType.MAINTENANCEZONE:
                    inventories = node.MasterInventories.Where(i => i.MaintenanceZoneId == node.Id).ToList();
                    break;

                case NodeType.STOCK:
                    inventories = node.MasterInventories.Where(i => i.MaintenanceZoneId == node.ParentNode.Id && i.ConfigurationId == node.Id).ToList();
                    break;
            }

            foreach (var inventory in inventories)
                node.MasterInventories.Remove(inventory);

            CollectionViewSource.GetDefaultView(node.MasterInventories).Refresh();
            (node as IDelete)?.Delete();
        }

        /// <summary>
        /// Sets the copied inventories.
        /// </summary>
        /// <param name="configNode">The configuration node.</param>
        private void SetCopiedInventories(List<INode> configNode)
        {
            if (!(_selectedNode is INode node)) return;
            foreach (var confNode in configNode)
            {
                node.MasterInventories.AddRange(_inventoryMapper.TargetNodeMap(confNode, confNode));

                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.MAINTENANCEZONE))
                    confNode.ParentNodeAndNodeType[NodeType.MAINTENANCEZONE].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.STOCK))
                    confNode.ParentNodeAndNodeType[NodeType.STOCK].MasterInventories = node.MasterInventories;

                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.FACTORY))
                    confNode.ParentNodeAndNodeType[NodeType.FACTORY].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.MACHINE))
                    confNode.ParentNodeAndNodeType[NodeType.MACHINE].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.WORKSHOP))
                    confNode.ParentNodeAndNodeType[NodeType.WORKSHOP].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.OPEN_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.OPEN_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.MD_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.MD_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.SHMI_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.SHMI_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.PLC_CONFIG))
                    confNode.ParentNodeAndNodeType[NodeType.PLC_CONFIG].MasterInventories = node.MasterInventories;
                if (confNode.ParentNodeAndNodeType.ContainsKey(NodeType.LINE))
                    confNode.ParentNodeAndNodeType[NodeType.LINE].MasterInventories = node.MasterInventories;
            }
            CollectionViewSource.GetDefaultView(node.MasterInventories).Refresh();
        }

        /// <summary>
        /// Ons the selected node change.
        /// </summary>
        /// <param name="node">The node.</param>
        private void onSelectedNodeChange(INode node)
        {
            if (node != null)
            {
                SelectedNodeTypeChanged = node.NodeType;
            }
        }

        /// <summary>
        /// Determines whether this instance [can delete command].
        /// </summary>
        /// <returns><c>true</c> if this instance [can delete command]; otherwise, <c>false</c>.</returns>
        private bool canDeleteCommand()
        {
            return (SelectedNode != null && SelectedNode is IDelete);
        }

        /// <summary>
        /// Ons the delete command.
        /// </summary>
        private void onDeleteCommand()
        {
            if (MessageBox.Show($"Do you want to delete the {(SelectedNode as INode)?.Name} ?", "M2C Renewal", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                RemoveNode(SelectedNode);
        }

        #endregion PRIVATE FUNCTIONS
    }
}