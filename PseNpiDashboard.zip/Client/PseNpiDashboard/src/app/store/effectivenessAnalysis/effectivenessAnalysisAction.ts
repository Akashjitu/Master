
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';

import { Compliance } from 'src/app/model/compliance';
import { EffectivenessAnalysis } from 'src/app/model/effectivenessAnalysis';
export const ADD_EFFECTIVENESS_ANALYSIS = 'ADD_EFFECTIVENESS_ANALYSIS';
export const LOAD_EFFECTIVENESS_ANALYSIS = 'LOAD_EFFECTIVENESS_ANALYSIS';
export const REMOVE_EFFECTIVENESS_ANALYSIS = 'REMOVE_EFFECTIVENESS_ANALYSIS';
export const UPDATE_EFFECTIVENESS_ANALYSIS: string = 'UPDATE_EFFECTIVENESS_ANALYSIS';



export class LoadEffectivenessAnalysis implements Action {
    readonly type = LOAD_EFFECTIVENESS_ANALYSIS;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddEffectivenessAnalysis implements Action {
    readonly type = ADD_EFFECTIVENESS_ANALYSIS;

    constructor(public payload: EffectivenessAnalysis) { }
}

export class UpdateEffectivenessAnalysis implements Action {
    readonly type = UPDATE_EFFECTIVENESS_ANALYSIS;

    constructor(public payload: EffectivenessAnalysis) { }
}

export class RemoveEffectivenessAnalysis implements Action {
    readonly type = REMOVE_EFFECTIVENESS_ANALYSIS;

    constructor(public payload: number) { }
}


export type Actions = AddEffectivenessAnalysis | RemoveEffectivenessAnalysis | LoadEffectivenessAnalysis;
