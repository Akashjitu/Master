﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="FilterNodeInventory.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using System;
using System.Collections.ObjectModel;
using System.Linq;

namespace M2C.Business.Filters
{
    /// <summary>
    /// Class FilterNodeInventory.
    /// Implements the <see cref="M2C.Business.Filters.IFilterNodeInventory" />
    /// </summary>
    /// <seealso cref="M2C.Business.Filters.IFilterNodeInventory" />
    public class FilterNodeInventory : IFilterNodeInventory
    {
        /// <summary>
        /// Gets the name of the filter node inventories by.
        /// </summary>
        /// <param name="currentNode">The current node.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        public ObservableCollection<Inventory> GetFilterNodeInventoriesByName(INode currentNode)
        {
            var inventories = new ObservableCollection<Inventory>();
            var masterInventories = currentNode.MasterInventories;
            var parentNodeTypeAndName = currentNode.NodeParentNameAndNodeType;
            if (masterInventories == null) return inventories;
            switch (currentNode.NodeType)
            {
                case NodeType.INSTALLEDBASE:
                    inventories.AddRange(masterInventories);
                    break;

                case NodeType.FACTORY:
                    inventories.AddRange(masterInventories.Where(i => string.Compare(i.Factory, currentNode.Name, StringComparison.OrdinalIgnoreCase) == 0));
                    break;

                case NodeType.WORKSHOP:

                    var workshop = masterInventories.Where(i => parentNodeTypeAndName.ContainsKey(NodeType.FACTORY) &&
                        string.Compare(i.Factory, parentNodeTypeAndName[NodeType.FACTORY],
                            StringComparison.OrdinalIgnoreCase) == 0 &&
                        string.Compare(i.Workshop, currentNode.Name, StringComparison.OrdinalIgnoreCase) == 0);
                    inventories.AddRange(workshop);
                    break;

                case NodeType.LINE:
                    var line = masterInventories.Where(i => parentNodeTypeAndName.ContainsKey(NodeType.FACTORY) &&
                                                            parentNodeTypeAndName.ContainsKey(NodeType.WORKSHOP) &&
                                                            string.Compare(i.Factory, parentNodeTypeAndName[NodeType.FACTORY],
                                                                StringComparison.OrdinalIgnoreCase) == 0 &&
                                                            string.Compare(i.Workshop, parentNodeTypeAndName[NodeType.WORKSHOP],
                                                                StringComparison.OrdinalIgnoreCase) == 0 &&
                                                            string.Compare(i.Line, currentNode.Name, StringComparison.OrdinalIgnoreCase) == 0);
                    inventories.AddRange(line);
                    break;

                case NodeType.MACHINE:
                    var machineInventories = masterInventories.Where(i => parentNodeTypeAndName.ContainsKey(NodeType.FACTORY) &&
                                                               parentNodeTypeAndName.ContainsKey(NodeType.WORKSHOP) &&
                                                              string.Compare(i.Factory, parentNodeTypeAndName[NodeType.FACTORY],
                                                                  StringComparison.OrdinalIgnoreCase) == 0 &&
                                                              string.Compare(i.Workshop, parentNodeTypeAndName[NodeType.WORKSHOP],
                                                                  StringComparison.OrdinalIgnoreCase) == 0 &&
                                                              string.Compare(i.Machine, currentNode.Name, StringComparison.OrdinalIgnoreCase) == 0);

                    inventories.AddRange(machineInventories);
                    break;


                case NodeType.PLC_CONFIG:
                case NodeType.MD_CONFIG:
                case NodeType.OPEN_CONFIG:
                case NodeType.SHMI_CONFIG:
                    var config = masterInventories.Where(i => parentNodeTypeAndName.ContainsKey(NodeType.FACTORY) &&
                                                              parentNodeTypeAndName.ContainsKey(NodeType.WORKSHOP) &&
                                                              parentNodeTypeAndName.ContainsKey(NodeType.MACHINE) &&
                                                             string.Compare(i.Factory, parentNodeTypeAndName[NodeType.FACTORY],
                                                                 StringComparison.OrdinalIgnoreCase) == 0 &&
                                                             string.Compare(i.Workshop, parentNodeTypeAndName[NodeType.WORKSHOP],
                                                                 StringComparison.OrdinalIgnoreCase) == 0 &&
                                                             string.Compare(i.Machine, parentNodeTypeAndName[NodeType.MACHINE],
                                                                 StringComparison.OrdinalIgnoreCase) == 0 &&
                                                             string.Compare(i.Configuration, currentNode.Name, StringComparison.OrdinalIgnoreCase) == 0);
                    inventories.AddRange(config);
                    break;

                case NodeType.TECHNICALRESOURCE:
                    inventories.AddRange(masterInventories);
                    break;

                case NodeType.MAINTENANCEZONE:
                    inventories.AddRange(masterInventories.Where(i => string.Compare(i.MaintenanceZone, currentNode.Name, StringComparison.OrdinalIgnoreCase) == 0));
                    break;

                case NodeType.STOCK:
                    var stock = masterInventories.Where(i => parentNodeTypeAndName.ContainsKey(NodeType.MAINTENANCEZONE) &&
                                                                 string.Compare(i.MaintenanceZone, parentNodeTypeAndName[NodeType.MAINTENANCEZONE],
                                                                     StringComparison.OrdinalIgnoreCase) == 0 &&
                                                                 string.Compare(i.Configuration, currentNode.Name, StringComparison.OrdinalIgnoreCase) == 0);
                    inventories.AddRange(stock);
                    break;

                case NodeType.NONE:
                    return inventories;
            }
            return inventories;
        }


        /// <summary>
        /// Gets the filter node inventories by identifier.
        /// </summary>
        /// <param name="currentNode">The current node.</param>
        /// <returns>ObservableCollection&lt;Inventory&gt;.</returns>
        public ObservableCollection<Inventory> GetFilterNodeInventoriesById(INode currentNode)
        {
            var inventories = new ObservableCollection<Inventory>();
            var masterInventories = currentNode.MasterInventories;
            var parentNodeTypeAndNode = currentNode.ParentNodeAndNodeType;
            if (masterInventories == null) return inventories;
            switch (currentNode.NodeType)
            {
                case NodeType.INSTALLEDBASE:
                    inventories.AddRange(masterInventories);
                    break;

                case NodeType.FACTORY:
                    inventories.AddRange(masterInventories.Where(i =>
                        i.FactoryId == parentNodeTypeAndNode[NodeType.FACTORY].Id));
                    break;

                case NodeType.WORKSHOP:

                    var workshop = masterInventories.Where(i => parentNodeTypeAndNode.ContainsKey(NodeType.FACTORY) &&
                        (i.FactoryId == parentNodeTypeAndNode[NodeType.FACTORY].Id) &&
                        (i.WorkshopId == currentNode.Id));
                    inventories.AddRange(workshop);
                    break;

                case NodeType.LINE:
                    var line = masterInventories.Where(i => parentNodeTypeAndNode.ContainsKey(NodeType.FACTORY) &&
                                                            parentNodeTypeAndNode.ContainsKey(NodeType.WORKSHOP) &&
                                                            (i.FactoryId == parentNodeTypeAndNode[NodeType.FACTORY].Id) &&
                                                            (i.WorkshopId == parentNodeTypeAndNode[NodeType.WORKSHOP].Id) &&
                                                            (i.LineId == currentNode.Id));
                    inventories.AddRange(line);
                    break;

                case NodeType.MACHINE:
                    var machineInventories = masterInventories.Where(i => parentNodeTypeAndNode.ContainsKey(NodeType.FACTORY) &&
                                                               parentNodeTypeAndNode.ContainsKey(NodeType.WORKSHOP) &&
                                                               (i.FactoryId == parentNodeTypeAndNode[NodeType.FACTORY].Id) &&
                                                               (i.WorkshopId == parentNodeTypeAndNode[NodeType.WORKSHOP].Id) &&
                                                              (i.MachineId == currentNode.Id));

                    inventories.AddRange(machineInventories);
                    break;


                case NodeType.PLC_CONFIG:
                case NodeType.MD_CONFIG:
                case NodeType.OPEN_CONFIG:
                case NodeType.SHMI_CONFIG:
                    var config = masterInventories.Where(i => parentNodeTypeAndNode.ContainsKey(NodeType.FACTORY) &&
                                                              parentNodeTypeAndNode.ContainsKey(NodeType.WORKSHOP) &&
                                                              parentNodeTypeAndNode.ContainsKey(NodeType.MACHINE) &&
                                                              (i.FactoryId == parentNodeTypeAndNode[NodeType.FACTORY].Id) &&
                                                              (i.WorkshopId == parentNodeTypeAndNode[NodeType.WORKSHOP].Id) &&
                                                             (i.MachineId == parentNodeTypeAndNode[NodeType.MACHINE].Id) &&
                                                             (i.ConfigurationId == currentNode.Id));
                    inventories.AddRange(config);
                    break;

                case NodeType.TECHNICALRESOURCE:
                    inventories.AddRange(masterInventories);
                    break;

                case NodeType.MAINTENANCEZONE:
                    inventories.AddRange(masterInventories.Where(i => i.MaintenanceZoneId == currentNode.Id));
                    break;

                case NodeType.STOCK:
                    var stock = masterInventories.Where(i => parentNodeTypeAndNode.ContainsKey(NodeType.MAINTENANCEZONE) &&
                                                                 (i.MaintenanceZoneId == parentNodeTypeAndNode[NodeType.MAINTENANCEZONE].Id) &&
                                                                 i.ConfigurationId == currentNode.Id);
                    inventories.AddRange(stock);
                    break;

                case NodeType.NONE:
                    return inventories;
            }
            return inventories;
        }
    }
}