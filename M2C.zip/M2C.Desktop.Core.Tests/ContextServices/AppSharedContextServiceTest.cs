﻿using FluentAssertions;
using M2C.Desktop.Core.ContextServices;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace M2C.Desktop.Core.Tests.ContextServices
{
    [TestClass]
    public class AppSharedContextServiceTest
    {
        private AppSharedContextService obj;

        [TestMethod]
        public void AppSharedContextServiceConstructorTest()
        {
            obj = new AppSharedContextService();
            obj.Should().NotBeNull();
        }

        [TestMethod]
        public void AddUpdateRemoveTest()
        {
            obj = new AppSharedContextService();
            Action acts = () => obj.Add<string>("Sample", "add");

            acts.Should().NotThrow();

            string result = obj.Get<string>("Sample");
            result.Should().NotBeNullOrEmpty();

            bool resultUpdate = obj.Update<string>("Sample", "update");
            resultUpdate.Should().BeTrue();

            acts = () => obj.Remove("Sample");
            acts.Should().NotThrow();

            resultUpdate = obj.Update<string>("Sample", "update");
            resultUpdate.Should().BeFalse();
        }
    }
}