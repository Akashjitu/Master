
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';

import { Compliance } from 'src/app/model/compliance';
import { Effectiveness } from 'src/app/model/effectiveness';
export const ADD_EFFECTIVENESS = 'ADD_EFFECTIVENESS';
export const LOAD_EFFECTIVENESS = 'LOAD_EFFECTIVENESS';
export const REMOVE_EFFECTIVENESS = 'REMOVE_EFFECTIVENESS';
export const UPDATE_EFFECTIVENESS: string = 'UPDATE_EFFECTIVENESS';



export class LoadEffectiveness implements Action {
    readonly type = LOAD_EFFECTIVENESS;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddEffectiveness implements Action {
    readonly type = ADD_EFFECTIVENESS;

    constructor(public payload: Effectiveness) { }
}

export class UpdateEffectiveness implements Action {
    readonly type = UPDATE_EFFECTIVENESS;

    constructor(public payload: Effectiveness) { }
}

export class RemoveEffectiveness implements Action {
    readonly type = REMOVE_EFFECTIVENESS;

    constructor(public payload: number) { }
}


export type Actions = AddEffectiveness | RemoveEffectiveness | LoadEffectiveness;
