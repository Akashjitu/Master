import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { FracaInfo } from '../Models/fraca-info';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/fracaReducer';
import { FracaService } from '../service/fraca-service.service';
import { ShareDataService } from '../service/share-data.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator,  MatTableDataSource, MatSort, } from '@angular/material';

@Component({
  selector: 'app-grid-view',
  templateUrl: './grid-view.component.html',
  styleUrls: ['./grid-view.component.scss']
})
export class GridViewComponent implements OnInit {

  dataSource = new MatTableDataSource();
  selection = new SelectionModel<FracaInfo>(false, []);
  displayedColumns: string[] = ['fracaNo', 'partNo', 'openDate', 'closeDate', 'failedDate', 'originator', 'closedBy'];
  rowData: Observable<FracaInfo>;

  selectedRow: any;
  modalRef: BsModalRef;
  message: any;
  lastSelection: any;
   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;


  constructor(public store: Store<IAppState>,
              private service: FracaService,
              private modalService: BsModalService, private shareDataService: ShareDataService ) {

    // this.rowData = this.store.select('fracaReducer');
    this.store.select('fracaReducer').subscribe(data => this.dataSource.data = data);
  }

  ngOnInit() {
    this.service.getAllFraca();
    this.shareDataService.currentMessage.subscribe( message => this.message = message);
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  applyFilter(filterValue: string) {
    console.log(filterValue);
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  SelectedRow(selectedRow) {

    if (this.lastSelection == null) {
      this.lastSelection = selectedRow;
    }
    this.lastSelection.highlighted = false;
    this.lastSelection = selectedRow;
    selectedRow.highlighted = true;
    this.selection.clear();
    this.selection.toggle(selectedRow);
    this.selectedRow = selectedRow;
    console.log('selection + : ' + JSON.stringify(selectedRow));
  }

  onRowDoubleClicked(template: TemplateRef<any>) {
    this.shareDataService.changeMessage( this.selectedRow );
    this.modalRef = this.modalService.show(template, { class: 'my-modal' });
  }

  download() {
    if (this.selectedRow == undefined) {
    alert('Please select any Fraca row from Grid');
    }
    this.service.reportDownload(( this.selectedRow as FracaInfo).FracaNo);
  }
}
