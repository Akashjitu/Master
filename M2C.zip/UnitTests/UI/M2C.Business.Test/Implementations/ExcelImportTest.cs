﻿using FluentAssertions;
using M2C.Business.Contracts;
using M2C.Business.Implementations;
using M2C.Business.Mappers;
using M2C.Business.Models.Project.IBComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Prism.Services.Dialogs;
using Schneider.M2C.OpenExcel.Parser;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;

namespace M2C.Business.Test.Implementations
{
    [TestClass]
    public class ExcelImportTest : TestBase
    {
        protected Mock<IExcelParser> ExcelParserMock { get; set; }
        protected Mock<IInventoryMapper> InventoryMapperMock { get; set; }
        protected Mock<IDialogService> IDialogServiceMock { get; set; }

        [TestInitialize]
        public void TestIniTialize()
        {
            InventoryMapperMock = MockRepo.Create<IInventoryMapper>();
            ExcelParserMock = MockRepo.Create<IExcelParser>();
            IDialogServiceMock = MockRepo.Create<IDialogService>();
        }

        [TestMethod]
        public void ExcelImportConstructorTest()
        {
            IExcelImport excelimport = new ExcelImport(ExcelParserMock.Object, InventoryMapperMock.Object, IDialogServiceMock.Object);
            excelimport.Should().NotBeNull();
        }

        [TestMethod]
        public void IBComponentImportTest()
        {
            ExcelParserMock.Setup(x => x.GetModelFromExcel<IBImportModel>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<int>(), It.IsAny<int>())).Returns(TestData.GetIBData());

            IExcelImport excelimport = new ExcelImport(ExcelParserMock.Object, InventoryMapperMock.Object, IDialogServiceMock.Object);
            excelimport.IBComponentImport("filePath", new InstalledBase());
        }

        [TestMethod]
        public void IBComponentImportNegativeTest()
        {
            ExcelParserMock.Setup(x => x.GeModelsFromExcel<IBImportModel>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Throws<System.Exception>();

            IExcelImport excelimport = new ExcelImport(ExcelParserMock.Object, InventoryMapperMock.Object, IDialogServiceMock.Object);

            Action act = () => excelimport.IBComponentImport("filePath", new InstalledBase());
            act.Should().Throw<Exception>();
        }

        [TestMethod]
        public void TRBaseNodeImportTest()
        {
            ExcelParserMock.Setup(x => x.GeModelsFromExcel<TRImportModel>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Returns(TestData.GetTRData());
            IExcelImport excelimport = new ExcelImport(ExcelParserMock.Object, InventoryMapperMock.Object, IDialogServiceMock.Object);
            var TRDetails = excelimport.TRBaseNodeImport("filePath");
            Assert.IsNotNull(TRDetails);
        }

        [TestMethod]
        public void TRBaseNodeImportNegativeTest()
        {
            ExcelParserMock.Setup(x => x.GeModelsFromExcel<TRImportModel>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).Throws<System.Exception>();

            IExcelImport excelimport = new ExcelImport(ExcelParserMock.Object, InventoryMapperMock.Object, IDialogServiceMock.Object);

            Action act = () => excelimport.TRBaseNodeImport("filePath");
            act.Should().Throw<Exception>();
        }
    }
}