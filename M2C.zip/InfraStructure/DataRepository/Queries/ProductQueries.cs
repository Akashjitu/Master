﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="ProductQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DomainModels.IbCatalogFilter;
using DomainModels.IbCatalogModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataRepository.Queries
{
    /// <summary>
    /// Product Queries
    /// </summary>
    /// <seealso cref="DataRepository.DBContracts.IFilterIbCatalogProductCategoryQueries" />
    /// <seealso cref="DataRepository.DBContracts.IFilterIbCatalogStatusIpCreationQueries" />
    /// <seealso cref="DataRepository.DBContracts.IFilterIbCatalogBuQueries" />
    /// <seealso cref="DataRepository.DBContracts.IBrandQueries" />
    /// <seealso cref="DataRepository.DBContracts.IDeviceTypeQueries" />
    /// <seealso cref="DataRepository.DBContracts.ISubRangeQueries" />
    /// <seealso cref="DataRepository.DBContracts.IRangeQueries" />
    /// <seealso cref="DataRepository.DBContracts.IProductQueries" />
    /// <seealso cref="System.IDisposable" />
    public class ProductQueries : IFilterIbCatalogProductCategoryQueries, IFilterIbCatalogStatusIpCreationQueries, IFilterIbCatalogBuQueries
        , IBrandQueries, IDeviceTypeQueries, ISubRangeQueries, IRangeQueries,
         IProductQueries, ISyncServiceQueries, IDisposable
    {
        /// <summary>
        /// Gets the database context factory.
        /// </summary>
        /// <value>The database context factory.</value>
        private IDbContextFactory _dbContextFactory { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApplicationQueries" /> class.
        /// </summary>
        /// <param name="dbContextFactory">The database context factory.</param>
        public ProductQueries(IDbContextFactory dbContextFactory)
        {
            _dbContextFactory = dbContextFactory;
        }

        /// <summary>
        /// Filters the ib catalog bu.
        /// </summary>
        /// <param name="filterIbCatalogBu">The filter ib catalog bu.</param>
        /// <returns>List&lt;FilterIbCatalogBu&gt;.</returns>
        public List<FilterIbCatalogBu> FilterIbCatalogBu(FilterIbCatalogBu filterIbCatalogBu)
        {
            if (filterIbCatalogBu == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.FilterIbCatalogBus.Where(i => i.Id == filterIbCatalogBu.Id || i.Name == filterIbCatalogBu.Name).ToList();
            }
        }

        /// <summary>
        /// Filters the ib catalog bu.
        /// </summary>
        /// <returns>List&lt;FilterIbCatalogBu&gt;.</returns>
        public List<FilterIbCatalogBu> FilterIbCatalogBu()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.FilterIbCatalogBus.ToList();
        }

        /// <summary>
        /// Filters the ib catalog product categories.
        /// </summary>
        /// <param name="filterIbCatalogProductCategory">The filter ib catalog product category.</param>
        /// <returns>List&lt;FilterIbCatalogProductCategory&gt;.</returns>
        public List<FilterIbCatalogProductCategory> FilterIbCatalogProductCategories(FilterIbCatalogProductCategory filterIbCatalogProductCategory)
        {
            if (filterIbCatalogProductCategory == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.FilterIbCatalogProductCategories.Where(i => i.Id == filterIbCatalogProductCategory.Id || i.Name == filterIbCatalogProductCategory.Name).ToList();
            }
        }

        /// <summary>
        /// Filters the ib catalog product categories.
        /// </summary>
        /// <returns>List&lt;FilterIbCatalogProductCategory&gt;.</returns>
        public List<FilterIbCatalogProductCategory> FilterIbCatalogProductCategories()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.FilterIbCatalogProductCategories.ToList();
        }

        /// <summary>
        /// Filters the ib catalog status ip creations.
        /// </summary>
        /// <param name="filterIbCatalogStatusIpCreation">The filter ib catalog status ip creation.</param>
        /// <returns>List&lt;FilterIbCatalogStatusIpCreation&gt;.</returns>
        public List<FilterIbCatalogStatusIpCreation> FilterIbCatalogStatusIpCreations(FilterIbCatalogStatusIpCreation filterIbCatalogStatusIpCreation)
        {
            if (filterIbCatalogStatusIpCreation == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.FilterIbCatalogStatusIpCreations.Where(i => i.Id == filterIbCatalogStatusIpCreation.Id || i.Name == filterIbCatalogStatusIpCreation.Name).ToList();
            }
        }

        /// <summary>
        /// Filters the ib catalog status ip creations.
        /// </summary>
        /// <returns>List&lt;FilterIbCatalogStatusIpCreation&gt;.</returns>
        public List<FilterIbCatalogStatusIpCreation> FilterIbCatalogStatusIpCreations()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.FilterIbCatalogStatusIpCreations.ToList();
        }

        /// <summary>
        /// Gets the range by device identifier.
        /// </summary>
        /// <param name="deviceId">The device identifier.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        public List<Range> GetRangeByDeviceId(int deviceId)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.Range).Where(i => deviceId == i.DeviceTypeId).Select(i => i.Range).Distinct().ToList();
        }

        /// <summary>
        /// Gets the product by ids.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="rangeId">The range identifier.</param>
        /// <param name="deviceId">The device identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> GetProductByIds(int brandId, int rangeId, int deviceId)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.DeviceType).
                    Include(i => i.Range).Include(i => i.Brand).
                    Where(i =>
                    i.BrandId == brandId && i.RangeId == rangeId && i.DeviceTypeId == deviceId).ToList();
        }

        /// <summary>
        /// Gets the products by device identifier and range identifier.
        /// </summary>
        /// <param name="rangeId">The range identifier.</param>
        /// <param name="deviceId">The device identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> GetProductsByDeviceIdAndRangeId(int rangeId, int deviceId)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.DeviceType).
                    Include(i => i.Range).Include(i => i.Brand).
                    Where(i =>
                         i.RangeId == rangeId && i.DeviceTypeId == deviceId).ToList();
        }

        /// <summary>
        /// Gets the range by brand.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        public List<Range> GetRangeByBrand(int brandId)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.Range).Where(i => brandId == i.BrandId).Select(i => i.Range).Distinct().ToList();
        }

        /// <summary>
        /// Gets the device types by brand and range identifier.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="rangId">The rang identifier.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        public List<DeviceType> GetDeviceTypesByBrandAndRangeId(int brandId, int rangId)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.DeviceType).Where(i => brandId == i.BrandId && rangId == i.RangeId).Select(i => i.DeviceType).Distinct().ToList();
        }

        /// <summary>
        /// Gets the device types by brand identifier.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        public List<DeviceType> GetDeviceTypesByBrandId(int brandId)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.DeviceType).Where(i => brandId == i.BrandId).Select(i => i.DeviceType).Distinct().ToList();
        }

        /// <summary>
        /// Gets the device types by brand Id config Node Type.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="nodeType">Config Node Type</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceType> GetDeviceTypesByBrandIdAndNodeType(int brandId, string nodeType)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                if (!context.DeviceTypes.Any(i => i.ConfigType == nodeType))
                    return GetDeviceTypesByBrandId(brandId);
                return context.Products.Include(i => i.DeviceType)
                    .Where(i => brandId == i.BrandId && i.DeviceType.ConfigType == nodeType)
                    .Select(i => i.DeviceType).Distinct().ToList();
            }
        }

        /// <summary>
        /// Gets the range by brand and device type ids.
        /// </summary>
        /// <param name="brandId">The brand identifier.</param>
        /// <param name="deviceTypeId">The device type identifier.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        public List<Range> GetRangeByBrandAndDeviceTypeIds(int brandId, int deviceTypeId)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.Range).Where(i => brandId == i.BrandId && deviceTypeId == i.DeviceTypeId).Select(i => i.Range).Distinct().ToList();
        }

        /// <summary>
        /// Loads the brands.
        /// </summary>
        /// <param name="brand">The brand.</param>
        /// <returns>List&lt;Brand&gt;.</returns>
        public List<Brand> LoadBrands(Brand brand)
        {
            if (brand == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.Brands.Include(i => i.Products).Where(i => i.Id == brand.Id || i.Name == brand.Name).ToList();
            }
        }

        /// <summary>
        /// Loads the brands.
        /// </summary>
        /// <returns>List&lt;Brand&gt;.</returns>
        public List<Brand> LoadBrands()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Brands.Include(i => i.Products).ToList();
        }

        /// <summary>
        /// Loads the device types.
        /// </summary>
        /// <param name="deviceType">Type of the device.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        public List<DeviceType> LoadDeviceTypes(DeviceType deviceType)
        {
            if (deviceType == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.DeviceTypes.Include(i => i.Products).Where(i => i.Id == deviceType.Id || i.Type == deviceType.Type).ToList();
            }
        }

        /// <summary>
        /// Loads the brands.
        /// </summary>
        /// <param name="name">The name.</param>
        ///  <param name="isSe">Check Se Brand</param>
        /// <returns>List&lt;Brand&gt;.</returns>
        public List<Brand> LoadBrands(string name, bool isSe=true)
        {
            var isSeBrand = isSe ? "YES" : "NO";
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.Brands.Where(i=>i.IsSeBrand.ToUpper() == isSeBrand).OrderBy(i => i.Name).ToList();
            }
            //if (string.IsNullOrEmpty(name))
            //    return new List<Brand>();
            //name = name.ToUpper().Trim();
            //using (var context = new IbCatalogSqliteContext())
            //{
            //    return name.Length < 2 ? context.Brands.Where(i => i.Name.ToUpper().StartsWith(name)).Take(100).ToList() : context.Brands.Where(i => i.Name.ToUpper().StartsWith(name)).ToList();
            //}
        }

        /// <summary>
        /// Loads the device types.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        public List<DeviceType> LoadDeviceTypes(string type)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.DeviceTypes.OrderBy(i => i.Type).ToList();
            }
            //if (string.IsNullOrEmpty(type))
            //    return new List<DeviceType>();
            //type = type.ToUpper().Trim();
            //using (var context = new IbCatalogSqliteContext())
            //{
            //    return type.Length < 2 ? context.DeviceTypes.Include(i => i.Products).Where(i => i.Type.ToUpper().StartsWith(type)).Take(100).ToList() : context.DeviceTypes.Include(i => i.Products).Where(i => i.Type.ToUpper().StartsWith(type)).ToList();
            //}
        }

        /// <summary>
        /// Gets the device types with Config Node Type.
        /// </summary>
        /// <param name="configNodeType">Type of the configuration node.</param>
        /// <returns>List&lt;DeviceTypeModel&gt;.</returns>
        public List<DeviceType> GetDeviceTypesByNodeType(string configNodeType)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                if (!context.DeviceTypes.Any(i => i.ConfigType == configNodeType))
                    return context.DeviceTypes.OrderBy(i => i.Type).ToList();
                return context.DeviceTypes.Where(i => i.ConfigType == configNodeType).OrderBy(i => i.Type).ToList();
            }
        }

        /// <summary>
        /// Loads the device types.
        /// </summary>
        /// <returns>List&lt;DeviceType&gt;.</returns>
        public List<DeviceType> LoadDeviceTypes()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.DeviceTypes.Include(i => i.Products).ToList();
        }

        /// <summary>
        /// Gets the products Start With Identifier
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<Product> GetProductsStartWithIdentifier(string identifier)
        {
            if (string.IsNullOrEmpty(identifier))
                return new List<Product>();
            identifier = identifier.ToUpper().Trim();
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return identifier.Length < 4
                    ? context.Products.Include(i => i.ProductEntries).Include(i => i.Brand).Include(i => i.DeviceType)
                        .Include(i => i.Range).Where(i => i.Identifier.ToUpper().StartsWith(identifier)).Take(100)
                        .ToList()
                    : context.Products.Include(i => i.ProductEntries).Include(i => i.Brand).Include(i => i.DeviceType)
                        .Include(i => i.Range).Where(i => i.Identifier.ToUpper().StartsWith(identifier)).ToList();
            }
        }

        /// <summary>
        /// Gets the products Start With Identifier and Config Node
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <param name="configNodeType">Type of the node.</param>
        /// <param name="isSe">check brand</param>
        /// <returns>List&lt;ProductModel&gt;.</returns>
        public List<Product> GetProductsStartWithIdentifier(string identifier, string configNodeType, bool isSe = true)
        {
            if (string.IsNullOrEmpty(identifier))
                return new List<Product>();
            var isSeBrand = isSe ? "YES" : "NO";
            identifier = identifier.ToUpper().Trim();
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                if (!context.DeviceTypes.Any(i => i.ConfigType == configNodeType))
                    return GetProductsStartWithIdentifier(identifier);

                return identifier.Length < 4
                    ? context.Products.Include(i => i.ProductEntries).Include(i => i.Brand).Include(i => i.DeviceType)
                        .Include(i => i.Range)
                        .Where(i => i.Identifier.ToUpper().StartsWith(identifier) &&
                                     !string.IsNullOrEmpty(i.Brand.IsSeBrand) &&
                                    i.Brand.IsSeBrand.ToUpper() == isSeBrand &&
                                    i.DeviceType.ConfigType == configNodeType).Take(100).ToList()
                    : context.Products.Include(i => i.ProductEntries).Include(i => i.Brand).Include(i => i.DeviceType)
                        .Include(i => i.Range).Where(i =>
                            i.Identifier.ToUpper().StartsWith(identifier) &&
                            !string.IsNullOrEmpty(i.Brand.IsSeBrand) &&
                            i.Brand.IsSeBrand.ToUpper() == isSeBrand &&
                            i.DeviceType.ConfigType == configNodeType)
                        .ToList();
            }
        }

        /// <summary>
        /// Gets the products by identifier.
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>Product.</returns>
        public Product GetProductsByIdentifier(string identifier)
        {
            if (string.IsNullOrEmpty(identifier))
                return null;
            identifier = identifier.ToUpper().Trim();
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                var product = context.Products.FirstOrDefault(i => i.Identifier.ToUpper() == identifier);
                if (product == null)
                    return null;
                var brand = context.Brands.FirstOrDefault(i => i.Id == product.BrandId);
                var deviceType = context.DeviceTypes.FirstOrDefault(i => i.Id == product.DeviceTypeId);
                var range = context.Ranges.FirstOrDefault(i => i.Id == product.RangeId);

                product.Brand = brand;
                product.DeviceType = deviceType;
                product.Range = range;

                return product;
            }
        }

        /// <summary>
        /// Loads the products.
        /// </summary>
        /// <param name="product">The product.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> GetProductsByIdOrIdentifier(Product product)
        {
            if (product == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.Products.Include(i => i.ProductEntries).Include(i => i.Brand).Include(i => i.DeviceType).Include(i => i.Range).Where(i => i.Id == product.Id || i.Identifier == product.Identifier).ToList();
            }
        }

        /// <summary>
        /// Loads the products.
        /// </summary>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> LoadProducts()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Include(i => i.ProductEntries).Include(i => i.Brand).Include(i => i.DeviceType).Include(i => i.Range).ToList();
        }

        /// <summary>
        /// Get the Products Only
        /// </summary>
        /// <param name="identifier">The identifier.</param>
        /// <returns>List&lt;Product&gt;.</returns>
        public List<Product> GetProducts(string identifier)
        {
            if (string.IsNullOrEmpty(identifier))
                return new List<Product>();
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.Products
                    .Where(i => i.Identifier == identifier).ToList();
            }
        }

        /// <summary>
        /// Get the First Product only by Count
        /// </summary>
        /// <param name="count">How many product, you want to Get</param>
        /// <returns>Collection Of Product</returns>
        public List<Product> GetProductsByCount(int count = 2)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Products.Take(count).ToList();
        }

        /// <summary>
        /// Loads the ranges.
        /// </summary>
        /// <param name="range">The range.</param>
        /// <returns>List&lt;Range&gt;.</returns>
        public List<Range> LoadRanges(Range range)
        {
            if (range == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                var ranges = context.Ranges.Include(blog => blog.SubRanges).Where(i => i.Id == range.Id || i.Name == range.Name).ToList();
                return ranges;
            }
        }

        /// <summary>
        /// Loads the ranges.
        /// </summary>
        /// <returns>List&lt;Range&gt;.</returns>
        public List<Range> LoadRanges()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.Ranges.Include(blog => blog.SubRanges).ToList();
        }

        /// <summary>
        /// Loads the sub ranges.
        /// </summary>
        /// <param name="subRange">The sub range.</param>
        /// <returns>List&lt;SubRange&gt;.</returns>
        public List<SubRange> LoadSubRanges(SubRange subRange)
        {
            if (subRange == null)
                return null;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                return context.SubRanges.Include(blog => blog.Range).Where(i => i.Id == subRange.Id || i.Name == subRange.Name).ToList();
            }
        }

        /// <summary>
        /// Loads the sub ranges.
        /// </summary>
        /// <returns>List&lt;SubRange&gt;.</returns>
        public List<SubRange> LoadSubRanges()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
                return context.SubRanges.Include(i => i.Range).ToList();
        }

        /// <summary>
        /// Saves the brands.
        /// </summary>
        /// <param name="brands">The brands.</param>
        public void SaveBrands(List<Brand> brands)
        {
            var currentDateTime = DateTime.Now;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                if (brands == null)
                    return;

                foreach (var brand in brands)
                {
                    var updateBrand = context.Brands.FirstOrDefault(i => i.Id == brand.Id || i.Name == brand.Name);

                    if (updateBrand == null)
                        continue;
                    updateBrand.Name = brand.Name;
                    updateBrand.UpdatedDate = currentDateTime;

                    if (brand.Products != null)
                        updateBrand.Products = brand.Products;
                }
                var addBrands = brands.Where(i => i.Id == 0 && !context.Brands.Any(k => k.Name == i.Name)).ToList();
                if (addBrands.Count > 0)
                {
                    addBrands.ForEach(i => i.CreatedDate = currentDateTime);
                    context.Brands.AddRange(addBrands);
                }

                context.SaveChanges();
            }
        }

        /// <summary>
        /// Saves the device types.
        /// </summary>
        /// <param name="deviceTypes">The device types.</param>
        public void SaveDeviceTypes(List<DeviceType> deviceTypes)
        {
            var currentDateTime = DateTime.Now;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                if (deviceTypes == null)
                    return;

                foreach (var deviceType in deviceTypes)
                {
                    var updateDeviceType = context.DeviceTypes.FirstOrDefault(i => i.Id == deviceType.Id || i.Type == deviceType.Type);

                    if (updateDeviceType == null)
                        continue;

                    updateDeviceType.Type = deviceType.Type;
                    updateDeviceType.OpsTypeDescription = deviceType.OpsTypeDescription;
                    updateDeviceType.UpdatedDate = currentDateTime;

                    if (deviceType.Products != null)
                        updateDeviceType.Products = deviceType.Products;
                }

                var addDeviceTypes = deviceTypes.Where(i => i.Id == 0 && !context.DeviceTypes.Any(k => k.Type == i.Type)).ToList();
                if (addDeviceTypes.Count > 0)
                {
                    addDeviceTypes.ForEach(i => i.CreatedDate = currentDateTime);
                    context.DeviceTypes.AddRange(addDeviceTypes);
                }
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Saves the products.
        /// </summary>
        /// <param name="products">The products.</param>
        public void SaveProducts(List<Product> products)
        {
            var currentDateTime = DateTime.Now;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                if (products == null)
                    return;

                foreach (var product in products)
                {
                    var updateProduct = context.Products.FirstOrDefault(i => i.Id == product.Id || i.Identifier == product.Identifier);
                    if (updateProduct == null)
                        continue;

                    updateProduct.Identifier = product.Identifier;
                    updateProduct.IdentifierCategory = product.IdentifierCategory;
                    updateProduct.Description = product.Description;
                    updateProduct.Serviceable = product.Serviceable;
                    updateProduct.Traceable = product.Traceable;
                    updateProduct.ServiceBusinessValue = product.ServiceBusinessValue;
                    updateProduct.ObsolescenceYear = product.ObsolescenceYear;
                    updateProduct.EndProductionOrPhaseOut = product.EndProductionOrPhaseOut;
                    updateProduct.EndCommercialization = product.EndCommercialization;
                    updateProduct.EndServicesWithdrawalSupport = product.EndServicesWithdrawalSupport;
                    updateProduct.DefaultUnitPrice = product.DefaultUnitPrice;
                    updateProduct.LatestProductVersion = product.LatestProductVersion;
                    updateProduct.LatestSoftwareVersion = product.LatestSoftwareVersion;
                    updateProduct.LatestHardwareVersion = product.LatestHardwareVersion;
                    updateProduct.IncludeInReport = product.IncludeInReport;
                    updateProduct.IncludeInCalc = product.IncludeInCalc;
                    updateProduct.Configuration = product.Configuration;
                    updateProduct.UpdatedDate = currentDateTime;
                    updateProduct.Version = product.Version;
                    if (product.ProductEntries != null)
                        updateProduct.ProductEntries = product.ProductEntries;
                }
                var addProducts = products.Where(i => i.Id == 0 && !string.IsNullOrEmpty(i.Identifier) && !context.Products.Any(k => k.Identifier == i.Identifier)).ToList();
                if (addProducts.Count > 0)
                {
                    addProducts.ForEach(i => i.CreatedDate = currentDateTime);
                    context.Products.AddRange(addProducts);
                }
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Saves the ranges.
        /// </summary>
        /// <param name="ranges">The ranges.</param>
        public void SaveRanges(List<Range> ranges)
        {
            var currentDateTime = DateTime.Now;
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                if (ranges == null)
                    return;

                foreach (var range in ranges)
                {
                    var updateRange = context.Ranges.FirstOrDefault(i => i.Id == range.Id || i.Name == range.Name);

                    if (updateRange == null)
                        continue;
                    updateRange.Name = range.Name;
                    updateRange.OpsDescription = range.OpsDescription;
                    updateRange.UpdatedDate = currentDateTime;
                    if (range.Products != null)
                        updateRange.Products = range.Products;

                    if (range.SubRanges != null)
                        updateRange.SubRanges = range.SubRanges;
                }

                var addRanges = ranges.Where(i => i.Id == 0 && !context.Ranges.Any(k => k.Name == i.Name)).ToList();
                if (addRanges.Count > 0)
                {
                    addRanges.ForEach(i => i.CreatedDate = currentDateTime);
                    context.Ranges.AddRange(addRanges);
                }

                context.SaveChanges();
            }
        }

        /// <summary>
        /// Saves the sub ranges.
        /// </summary>
        /// <param name="subRanges">The sub ranges.</param>
        public void SaveSubRanges(List<SubRange> subRanges)
        {
            if (subRanges == null || subRanges.Count == 0)
                return;
            var currentDateTime = DateTime.Now;

            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                foreach (var subRange in subRanges)
                {
                    var updateSubRange = context.SubRanges.FirstOrDefault(i => i.Id == subRange.Id || i.SdhDescription == subRange.SdhDescription);

                    if (updateSubRange == null)
                        continue;

                    updateSubRange.Name = subRange.Name;
                    updateSubRange.SdhCode = subRange.SdhCode;
                    updateSubRange.SdhDescription = subRange.SdhDescription;
                    updateSubRange.UpdatedDate = currentDateTime;
                }
                var addSubRanges = subRanges.Where(i => i.Id == 0 && !context.SubRanges.Any(k => k.SdhDescription == i.SdhDescription)).ToList();
                if (addSubRanges.Count > 0)
                {
                    addSubRanges.ForEach(i => i.CreatedDate = currentDateTime);
                    context.SubRanges.AddRange(addSubRanges);
                }

                context.SaveChanges();
            }
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
        }

        /// <summary>
        /// Gets the last synchronize date.
        /// </summary>
        /// <returns>System.Nullable&lt;DateTime&gt;.</returns>
        public DateTime? GetLastSyncDate()
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                var histroy = context.SyncHistories.Where(i => i.Status == 3).OrderByDescending(s => s.ID).FirstOrDefault();
                if (histroy?.SyncId != null)
                {
                    return histroy.SyncDate;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Saves the synchronize history.
        /// </summary>
        /// <param name="syncData">The synchronize data.</param>
        /// <returns>SyncHistory.</returns>
        public SyncHistory SaveSyncHistory(SyncHistory syncData)
        {
            if (syncData == null)
            {
                return null;
            }
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                SyncHistory lastUpdatedData = context.SyncHistories.OrderByDescending(s => s.SyncDate).FirstOrDefault();

                if (lastUpdatedData != null)
                {
                    syncData.ID = lastUpdatedData.ID + 1;
                    syncData.Version = lastUpdatedData.Version;
                }
                else
                {
                    syncData.ID = 1;
                    syncData.Version = 1;
                }

                context.SyncHistories.Add(syncData);
                context.SaveChanges();
                return syncData;
            }
        }

        /// <summary>
        /// Updates the synchronize history.
        /// </summary>
        /// <param name="syncData">The synchronize data.</param>
        /// <returns>SyncHistory.</returns>
        public SyncHistory UpdateSyncHistory(SyncHistory syncData)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                SyncHistory UpdateSyn = context.SyncHistories.FirstOrDefault(i => i.SyncId == syncData.SyncId);
                if (UpdateSyn != null)
                {
                    UpdateSyn.Status = syncData.Status;
                    UpdateSyn.RetryCount = syncData.RetryCount;
                    UpdateSyn.SyncDate = DateTime.Now;
                    if (syncData.Status == 3)
                    {
                        UpdateSyn.Version = ++UpdateSyn.Version;
                    }

                    context.SyncHistories.Update(UpdateSyn);
                    context.SaveChanges();

                    return UpdateSyn;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Gets all synchronize history.
        /// </summary>
        /// <param name="StatusFilter"></param>
        /// <returns></returns>
        public List<SyncHistory> GetAllSyncHistory(int? StatusFilter)
        {
            using (var context = _dbContextFactory.Create<IProductDbContext>())
            {
                IOrderedQueryable<SyncHistory> histroy = null;
                if (StatusFilter != null)
                {
                    histroy = context.SyncHistories.Where(i => i.Status == StatusFilter).OrderByDescending(s => s.ID);
                }
                else
                {
                    histroy = context.SyncHistories.OrderByDescending(s => s.ID);
                }


                if (histroy.Any())
                {
                    return histroy.ToList();
                }
                else
                {
                    return null;
                }
            }
        }
    }
}