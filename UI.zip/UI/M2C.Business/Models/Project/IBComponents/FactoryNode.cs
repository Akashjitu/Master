﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="FactoryNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using M2C.Business.Contracts;
using M2C.Business.GlobalFields;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Data;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Class FactoryNode.
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class FactoryNode : Node, IChildNode, IDelete
    {
        /// <summary>
        /// The work shop nodes
        /// </summary>
        private ObservableCollection<WorkShopNode> _workShopNodes;

        /// <summary>
        /// Initializes a new instance of the <see cref="FactoryNode" /> class.
        /// </summary>
        public FactoryNode()
        {
            _workShopNodes = new ObservableCollection<WorkShopNode>();
            NodeType = NodeType.FACTORY;
            WorkShopNodes.CollectionChanged += WorkShopNodes_CollectionChanged;
        }

        /// <summary>
        /// Handles the CollectionChanged event of the WorkShopNodes control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void WorkShopNodes_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FactoryNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public FactoryNode(string name)
        {
            _workShopNodes = new ObservableCollection<WorkShopNode>();
            this.Name = name;
            this.NodeType = NodeType.FACTORY;
            WorkShopNodes.CollectionChanged += WorkShopNodes_CollectionChanged;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FactoryNode" /> class.
        /// </summary>
        /// <param name="id">new Id</param>
        /// <param name="name">The name.</param>
        /// <param name="parentNode">Parent Node</param>
        public FactoryNode(int id, string name, INode parentNode)
        {
            Id = id;
            Name = name;
            ParentNode = parentNode;
            _workShopNodes = new ObservableCollection<WorkShopNode>();
            Name = name;
            NodeType = NodeType.FACTORY;
            WorkShopNodes.CollectionChanged += WorkShopNodes_CollectionChanged;
        }

        /// <summary>
        /// Gets or sets the work shop nodes.
        /// </summary>
        /// <value>The work shop nodes.</value>
        public ObservableCollection<WorkShopNode> WorkShopNodes { get => _workShopNodes; set => SetProperty(ref _workShopNodes, value); }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        public CompositeCollection ChildNodes
        {
            get
            {
                return new CompositeCollection()
                    {
                        new CollectionContainer() { Collection = WorkShopNodes }
                    };
            }
        }

        /// <summary>
        /// Adds the child.
        /// </summary>
        /// <param name="components">The components.</param>
        internal void AddChild(List<IBProjectComponent> components)
        {
            var workShopComponents = components
                .Where(x => x.IBComponenetType.ComponentTypeID == 3 && x.ParentID == this.Id).ToList();
            foreach (IBProjectComponent c in workShopComponents)
            {
                var ws = new WorkShopNode(c.NodeID, c.ComponentName, this);

                ws.AddChild(components);
                WorkShopNodes.Add(ws);
            }
        }

        /// <summary>
        /// Deletes this instance.
        /// </summary>
        public void Delete()
        {
            (ParentNode as InstalledBase)?.Factories.Remove(this);
        }
    }

    /// <summary>
    /// extension class for adding workshop for the factory
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class FactoryNodeExt
    {
        /// <summary>
        /// importing the workshop
        /// </summary>
        /// <param name="factory">The factory.</param>
        /// <param name="ibComponenets">The ib componenets.</param>
        public static void ImportWorkShop(this FactoryNode factory, List<IBImportModel> ibComponenets)
        {
            var rows = ibComponenets.Where(x => x.Factory == factory.Name);
            var workShops = rows.Select(x => x.Workshop).Distinct();

            foreach (var workShop in workShops)
            {
                var workShopNode = new WorkShopNode(GlobalFiled.GenerateRandomId(), workShop, factory);
                var ibComponents = ibComponenets.Where(i =>
                    string.Compare(i.Workshop, workShop, StringComparison.OrdinalIgnoreCase) == 0).ToList();
                factory.WorkShopNodes.Add(workShopNode);
                //Import should be done to attached node only, Node ID is mandatory for filtering
                workShopNode.ImportLine(ibComponents);
                workShopNode.ImportMachine(ibComponents);
            }
        }

        /// <summary>
        /// Gets all nodes.
        /// </summary>
        /// <param name="factory">The factory.</param>
        /// <returns>List&lt;Node&gt;.</returns>
        public static List<Node> getAllNodes(this FactoryNode factory)
        {
            List<Node> nodes = new List<Node>();

            foreach (var n in factory.WorkShopNodes)
            {
                nodes.Add(n);
                nodes.AddRange(n.getAllNodes());
            }

            return nodes;
        }
    }
}