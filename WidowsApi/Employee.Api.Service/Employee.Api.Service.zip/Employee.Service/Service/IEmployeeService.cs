﻿namespace Employee.Service.Service
{
    public interface IEmployeeService
    {
        void LoadApiData();
        // string GetEmployee();
    }
}