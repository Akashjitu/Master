﻿using SchneiderElectric.BrandIdentity.Controls;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace M2C.Desktop.Modules.ProjectPlan
{

    public class NumericTextBox : TextBox
    {
        //Example
         //<local:NumericTextBox Width = "300" Text="{Binding MyBinding, Mode=TwoWay, UpdateSourceTrigger=LostFocus,   NotifyOnValidationError=True, ValidatesOnDataErrors=True, ValidatesOnExceptions=True, ConverterCulture='en-US', StringFormat='F2'}" IsDecimalAllowed="True"
         //              MaxLength="20" Scale="2" IsEnabled="false"  />

        #region Properties

        /// <summary>
        /// Gets or sets the character to be used as decimal separator
        /// </summary>
        public string DecimalSeparator { get; set; }

        /// <summary>
        /// Gets or sets the mask to apply to the textbox
        /// </summary>
        public Boolean IsDecimalAllowed
        {
            get { return (Boolean)GetValue(IsDecimalAllowedProperty); }
            set { SetValue(IsDecimalAllowedProperty, value); }
        }

        /// <summary>
        /// Dependency property to store the decimal is allowed to be entered in the textbox
        /// </summary>
        public static readonly DependencyProperty IsDecimalAllowedProperty =
            DependencyProperty.Register("IsDecimalAllowed", typeof(Boolean), typeof(NumericTextBox), new PropertyMetadata(false));


        /// <summary>
        /// Gets or sets the mask to apply to the textbox
        /// </summary>
        public int Scale
        {
            get { return (int)GetValue(ScaleProperty); }
            set { SetValue(ScaleProperty, value); }
        }

        /// <summary>
        /// Dependency property to store the decimal is allowed to be entered in the textbox
        /// </summary>
        public static readonly DependencyProperty ScaleProperty =
            DependencyProperty.Register("Scale", typeof(int), typeof(NumericTextBox), new PropertyMetadata(0));

        #endregion

        /// <summary>
        /// Static Constructor
        /// </summary>
        static NumericTextBox()
        {
            
           // FrameworkElement.DefaultStyleKeyProperty.OverrideMetadata(typeof(NumericTextBox), (PropertyMetadata)new FrameworkPropertyMetadata((object)typeof(NumericTextBox)));
        }

        /// <summary>
        /// To check the character enetered
        /// </summary>
        protected override void OnPreviewTextInput(TextCompositionEventArgs e)
        {
            e.Handled = !AreAllValidNumericChars(e.Text);
            if (!e.Handled)
            {
                e.Handled = !MaxLengthReached(e);
            }
            base.OnPreviewTextInput(e);
        }
        protected override void OnGotFocus(RoutedEventArgs e)
        {
            BorderBrush = new SolidColorBrush(Colors.LightGreen);
            base.OnGotFocus(e);
        }

        //protected override void OnMouseEnter(MouseEventArgs e)
        //{
        //    BorderBrush = new SolidColorBrush(Colors.LightGreen);
        //    base.OnMouseEnter(e);
        //}

        protected override void OnGotMouseCapture(MouseEventArgs e)
        {
            BorderBrush = new SolidColorBrush(Colors.LightGreen);
           // base.OnGotMouseCapture(e);
        }

        /// <summary>
        ///To check if numbers entered are all valid numeric numbers
        /// </summary>
        bool AreAllValidNumericChars(string str)
        {
            if (string.IsNullOrEmpty(DecimalSeparator))
                DecimalSeparator = ".";

            bool ret = true;
            if (str == System.Globalization.NumberFormatInfo.CurrentInfo.NegativeSign |
                str == System.Globalization.NumberFormatInfo.CurrentInfo.PositiveSign)
                return ret;
            if (IsDecimalAllowed && str == DecimalSeparator)
                return ret;

            int l = str.Length;
            for (int i = 0; i < l; i++)
            {
                char ch = str[i];
                ret &= Char.IsDigit(ch);
            }

            return ret;
        }

        /// <summary>
        /// This method was added to prevent arithmetic overflows while saving in db on decimal part.
        /// </summary>
        bool MaxLengthReached(TextCompositionEventArgs e)
        {
            TextBox textBox = (TextBox)e.OriginalSource;
            int precision = textBox.MaxLength - Scale - 2;

            string textToValidate = textBox.Text.Insert(textBox.CaretIndex, e.Text).Replace("-", "");
            string[] numericValues = textToValidate.Split(Convert.ToChar(DecimalSeparator));

            if ((numericValues.Length <= 2) && (numericValues[0].Length <= precision) && ((numericValues.Length == 1) || (numericValues[1].Length <= Scale)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
