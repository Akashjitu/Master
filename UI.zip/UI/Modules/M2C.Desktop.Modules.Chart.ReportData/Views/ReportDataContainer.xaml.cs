﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReportDataContainer.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.Charts.ReportData.Views
{
    /// <summary>
    /// Interaction logic for ChartContainer.xaml
    /// </summary>
    public partial class ReportDataContainer : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportDataContainer" /> class.
        /// </summary>
        public ReportDataContainer()
        {
            InitializeComponent();
        }
    }
}