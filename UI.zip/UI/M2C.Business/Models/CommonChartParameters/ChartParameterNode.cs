﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ChartParameterNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using Prism.Mvvm;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace M2C.Business.Models.CommonChartParameters
{
    /// <summary>
    /// Class ChartParameterNode.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ChartParameterNode : BindableBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChartParameterNode"/> class.
        /// </summary>
        public ChartParameterNode()
        {
            ChartParameterChiledNodes= new ObservableCollection<ChartParameterNode>();
        }
        /// <summary>
        /// The node header
        /// </summary>
        private string _nodeHeader;
        /// <summary>
        /// The nodes
        /// </summary>
        private List<INode> _nodes;
        /// <summary>
        /// The node type
        /// </summary>
        private NodeType _nodeType;

        /// <summary>
        /// Gets or sets the node Count.
        /// </summary>
        private ObservableCollection<ChartParameterNode> _chartParameterNodes;

        /// <summary>
        /// Gets or sets the node Count.
        /// </summary>
        private int _nodeCount;

        /// <summary>
        /// Gets or sets the node header.
        /// </summary>
        /// <value>The node header.</value>
        public string NodeHeader { get => _nodeHeader; set => SetProperty(ref _nodeHeader, value); }

        /// <summary>
        /// Gets or sets the node Count.
        /// </summary>
        /// <value>The node header.</value>
        public int NodeCount { get => _nodeCount; set => SetProperty(ref _nodeCount, value); }

        /// <summary>
        /// Gets or sets the nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public List<INode> Nodes { get => _nodes; set => SetProperty(ref _nodes, value); }

        /// <summary>
        /// Gets or sets the type of the node.
        /// </summary>
        /// <value>The type of the node.</value>
        public NodeType NodeType { get => _nodeType; set => SetProperty(ref _nodeType, value); }

        /// <summary>
        /// Gets or sets the chart parameter chiled nodes.
        /// </summary>
        /// <value>The chart parameter chiled nodes.</value>
        public ObservableCollection<ChartParameterNode> ChartParameterChiledNodes { get => _chartParameterNodes; set => SetProperty(ref _chartParameterNodes, value); }
    }
}