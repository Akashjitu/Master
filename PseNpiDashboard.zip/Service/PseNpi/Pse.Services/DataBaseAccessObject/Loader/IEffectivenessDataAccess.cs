﻿using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IEffectivenessDataAccess
    {
        List<Data.Models.Effectiveness> LoadPppPartInfo(Data.Models.Effectiveness ttiPartAlignment);

        List<Data.Models.Effectiveness> LoadEffectivenesByDate(Data.Models.Effectiveness effectiveness);

        List<Data.Models.Effectiveness> LoadEffectivenesById(Data.Models.Effectiveness effectiveness);

        List<Data.Models.Effectiveness> LoadEffectivenesByPart(Data.Models.Effectiveness effectiveness);

        int AddEffectiveness(Effectiveness eft);

        int UpdateEffectiveness(Effectiveness eft);
    }
}