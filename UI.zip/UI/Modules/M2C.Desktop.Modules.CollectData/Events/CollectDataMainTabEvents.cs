﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CollectDataMainTabEvents.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Events;

namespace M2C.Desktop.Modules.CollectData.Events
{
    /// <summary>
    /// Tab switching event Installedbase/Technical resource
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{System.Int32}" />
    public class CollectDataMainTabSelectedEvent : PubSubEvent<int>
    {
    }
}