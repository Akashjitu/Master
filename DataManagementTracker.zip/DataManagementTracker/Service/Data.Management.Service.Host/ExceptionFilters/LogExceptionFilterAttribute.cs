﻿using Hts.Logger;
using System.Net;
using System.Net.Http;
using System.Web.Http.Filters;

namespace Data.Management.Service.Host.ExceptionFilters
{
    public class LogExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext context)
        {
            if (context == null || context.Exception == null)
                return;
            LogWriter.LogWrite(context.Exception, LogType.Error);

            context.Response = new HttpResponseMessage(HttpStatusCode.InternalServerError);
        }
    }
}