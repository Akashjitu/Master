﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectContextModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using Newtonsoft.Json;
using Prism.Mvvm;
using System;
using System.Collections.Generic;

namespace M2C.Business.Models.Project
{
    /// <summary>
    /// ProjectContextModel main model for Project
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ProjectContextModel : BindableBase
    {
        /// <summary>
        /// The customer
        /// </summary>
        private CustomerModel _customer;

        /// <summary>
        /// The Installed base project components
        /// </summary>
        private InstalledBase _installedBase;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectContextModel" /> class.
        /// </summary>
        public ProjectContextModel()
        {
            _inventory = new List<Inventory>();
            _customer = new CustomerModel();
        }

        /// <summary>
        /// The project identifier
        /// </summary>
        private int? _projectId;

        /// <summary>
        /// Gets or sets the project identifier.
        /// </summary>
        /// <value>The project identifier.</value>
        [JsonIgnore]
        public int? ProjectId { get => _projectId; set => SetProperty(ref _projectId, value); }

        /// <summary>
        /// Gets or sets the customer.
        /// </summary>
        /// <value>The customer.</value>
        public CustomerModel Customer { get => _customer; set => SetProperty(ref _customer, value); }

        /// <summary>
        /// The contacts
        /// </summary>
        private List<ContactModel> _contacts = new List<ContactModel>();

        /// <summary>
        /// Gets or sets the contacts.
        /// </summary>
        /// <value>The contacts.</value>
        public List<ContactModel> Contacts { get => this._contacts; set => SetProperty(ref _contacts, value); }

        /// <summary>
        /// Gets or sets the ib project components.
        /// </summary>
        /// <value>The ib project components.</value>
        public InstalledBase InstalledBase
        {
            get => _installedBase; set => _installedBase = value;
        }

        /// <summary>
        /// Gets or sets the technical resources.
        /// </summary>
        /// <value>The technical resources.</value>
        public TRNode TechnicalResources { get => _technicalResources; set => SetProperty(ref _technicalResources, value); }

        /// <summary>
        /// Gets or sets the created date.
        /// </summary>
        /// <value>The created date.</value>
        public DateTime? CreatedDate
        {
            get => createdDate; set => SetProperty(ref createdDate, value);
        }

        /// <summary>
        /// The created date
        /// </summary>
        private DateTime? createdDate;

        /// <summary>
        /// Gets or sets the modifiedd date.
        /// </summary>
        /// <value>The modifiedd date.</value>
        public DateTime? ModifieddDate
        {
            get => _modifiedDate; set => SetProperty(ref _modifiedDate, value);
        }

        /// <summary>
        /// The modified date
        /// </summary>
        private DateTime? _modifiedDate;

        /// <summary>
        /// The technical resources
        /// </summary>
        private TRNode _technicalResources;

        /// <summary>
        /// The inventory
        /// </summary>
        private List<Inventory> _inventory;

        private int version;

        /// <summary>
        /// Gets or sets the inventory.
        /// </summary>
        /// <value>The inventory.</value>
        ///
        [JsonIgnore]
        public List<Inventory> Inventory { get => _inventory; set => SetProperty(ref _inventory, value); }

        /// <summary>
        /// Gets or sets the criticity.
        /// </summary>
        /// <value>The criticity.</value>
        public string Criticity { get; set; }

        /// <summary>
        /// Gets or sets the criticities.
        /// </summary>
        /// <value>The criticities.</value>
        public CriticalityModel Criticities { get; set; }

        /// <summary>
        /// Gets or sets the project reference identifier.
        /// </summary>
        /// <value>The project reference identifier.</value>
        public string ProjectReferenceId { get; set; }

        /// <summary>
        /// Gets or sets the last synchronize date.
        /// </summary>
        /// <value>The last synchronize date.</value>
        public DateTime? LastSyncDate { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public int Version { get => version; set => version = value; }

        [JsonIgnore]
        public bool isOpenedFromFile { get; set; }
    }
}