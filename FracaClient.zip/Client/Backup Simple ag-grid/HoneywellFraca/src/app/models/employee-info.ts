export interface EmployeeInfo {
DisplayName: string;
Department: string;
FirstName: string;
MiddleName: string;
LastName: string;
LoginName: string;
LoginNameWithDomain: string;
StreetAddress: string;
City: string;
State: string;
PostalCode: string;
Country: string;
HomePhone: string;
Extension: string;
Mobile: string;
Fax: string;
EmailAddress: string;
Title: string;
Company: string;
Manager: string;
ManagerName: string;

}