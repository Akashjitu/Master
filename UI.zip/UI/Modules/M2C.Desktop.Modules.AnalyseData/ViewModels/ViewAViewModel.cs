﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.AnalyseData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ViewAViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;

namespace M2C.Desktop.Modules.AnalyseData.ViewModels
{
    /// <summary>
    /// Class ViewAViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ViewAViewModel : BindableBase
    {
        /// <summary>
        /// The message
        /// </summary>
        private string _message;
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message
        {
            get => _message;
            set => SetProperty(ref _message, value);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ViewAViewModel" /> class.
        /// </summary>
        public ViewAViewModel()
        {
            Message = "View A from your Prism Module";
        }
    }
}
