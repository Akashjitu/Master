﻿using Oracle.Data.Access;
using Pse.Data.Models;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class PliDataAccess : IPliDataAccess
    {
        public List<Pli> LoadByDate(Pli pli)
        {
            using (var dao = new DataAccessObject<Pli>())
            {
                var data = dao.LoadByInput(pli, "PK_F_PLI.SP_LOAD_F_PLI_BY_MM_YY");
                var returndata = new List<Pli>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Pli> LoadById(Pli pli)
        {
            using (var dao = new DataAccessObject<Pli>())
            {
                var data = dao.LoadByInput(pli, "PK_F_PLI.SP_LOAD_BY_ID");
                var returndata = new List<Pli>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Pli> LoadByKeyCode(Pli pli)
        {
            using (var dao = new DataAccessObject<Pli>())
            {
                var data = dao.LoadByInput(pli, "PK_F_PLI.SP_LOAD_PLI_BY_KEYCODE");
                var returndata = new List<Pli>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Pli> LoadPli()
        {
            using (var dao = new DataAccessObject<Pli>())
            {
                var data = dao.Load("PK_F_PLI.SP_LOAD_PLI");
                var returndata = new List<Pli>();
                returndata.AddRange(data);
                return returndata;
            }
        }
    }
}