﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SyncHistorySeed.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using Microsoft.EntityFrameworkCore;
using System;

namespace DataRepository.Seeds
{
    /// <summary>
    /// SyncHistory
    /// </summary>
    internal class SyncHistorySeed
    {
        /// <summary>
        /// Seeds the specified model builder.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public void Seed(ModelBuilder modelBuilder)
        {
            var version = 0;
            var syncDateSample = DateTime.Parse("2020-03-25");

            modelBuilder.Entity<SyncHistory>().HasData
                (
                   new SyncHistory() { ID = 1, SyncDate = syncDateSample, Status = 3, RetryCount = 0, Version = version, SyncId = Guid.NewGuid().ToString() }
                );
        }
    }
}