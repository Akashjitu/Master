﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-15-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="IProjectSyncService.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace RestClientServices.Contracts
{
    /// <summary>
    /// Project sync service M2C
    /// </summary>
    /// <seealso cref="RestClientServices.Contracts.IRestClientService" />
    public interface IProjectSyncService : IRestClientService
    {
        /// <summary>
        /// Gets the last synchronize date.
        /// </summary>
        /// <returns>System.String.</returns>
        string GetLastSyncDate();

        /// <summary>
        /// Posts the project date.
        /// </summary>
        /// <param name="JsonData">The json data.</param>
        /// <param name="projectReferenceId">The project reference identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool PostProjectDate(string JsonData,string projectReferenceId);

        /// <summary>
        /// Puts the project date.
        /// </summary>
        /// <param name="JsonData">The json data.</param>
        /// <param name="projectReferenceId">The project reference identifier.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool PutProjectDate(string JsonData,string projectReferenceId);
    }
}