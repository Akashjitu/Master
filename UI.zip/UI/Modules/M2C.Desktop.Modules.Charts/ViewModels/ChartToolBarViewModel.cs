﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ChartToolBarViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.Charts.Constants;
using M2C.Desktop.Modules.Charts.Events;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Data;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;

namespace M2C.Desktop.Modules.Charts.ViewModels
{
    /// <summary>
    /// Interaction logic for ChartToolBar
    /// </summary>
    /// <summary>
    /// Class ChartToolBarViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <summary>
    /// Class ChartToolBarViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ChartToolBarViewModel : BindableBase
    {
        #region Class Field

        /// <summary>
        /// The define indicator
        /// </summary>
        /// <summary>
        /// The define indicator
        /// </summary>
        private Dictionary<string, List<string>> _defineIndicator;
        /// <summary>
        /// The chart mappings
        /// </summary>
        /// <summary>
        /// The chart mappings
        /// </summary>
        private ObservableCollection<string> _chartMappings;
        /// <summary>
        /// The select inventory type
        /// </summary>
        /// <summary>
        /// The select inventory type
        /// </summary>
        private string _selectInventoryType;
        /// <summary>
        /// The select chart mapping
        /// </summary>
        /// <summary>
        /// The select chart mapping
        /// </summary>
        private string _selectChartMapping;
        /// <summary>
        /// The selected installed based node
        /// </summary>
        private INode _selectedInstalledBasedNode;
        /// <summary>
        /// The selected tr node
        /// </summary>
        private INode _selectedTrNode;
        /// <summary>
        /// The years
        /// </summary>
        private List<int> _years;
        /// <summary>
        /// The chart parameter
        /// </summary>
        private ChartParameter _chartParameter;
        /// <summary>
        /// The event aggregator
        /// </summary>
        private IEventAggregator _eventAggregator;
        /// <summary>
        /// The chart parameter nodes
        /// </summary>
        private ObservableCollection<ChartParameterNode> _chartParameterNodes;
        /// <summary>
        /// The is year enable
        /// </summary>
        private bool _isYearEnable;
        /// <summary>
        /// The is tree enable
        /// </summary>
        private bool _isTreeEnable;
        /// <summary>
        /// The x axis count
        /// </summary>
        private ObservableCollection<string> _xAxisCount;

        #endregion Class Field

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether this instance is tree enable.
        /// </summary>
        /// <value><c>true</c> if this instance is tree enable; otherwise, <c>false</c>.</value>
        public bool IsTreeEnable
        {
            get => _isTreeEnable;
            set => SetProperty(ref _isTreeEnable, value);
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is year enable.
        /// </summary>
        /// <value><c>true</c> if this instance is year enable; otherwise, <c>false</c>.</value>
        public bool IsYearEnable
        {
            get => _isYearEnable;
            set => SetProperty(ref _isYearEnable, value);
        }

        /// <summary>
        /// Provide Collection of DefineIndicator
        /// </summary>
        /// <value>The define indicator.</value>
        public Dictionary<string, List<string>> DefineIndicator
        {
            get => _defineIndicator;
            set => SetProperty(ref _defineIndicator, value);
        }

        /// <summary>
        /// Get Set Collection of Chart Mappings
        /// </summary>
        /// <value>The chart mappings.</value>
        public ObservableCollection<string> ChartMappings
        {
            get => _chartMappings;
            set => SetProperty(ref _chartMappings, value);
        }

        /// <summary>
        /// Collection of Years
        /// </summary>
        /// <value>The years.</value>
        public List<int> Years
        {
            get => _years;
            set => SetProperty(ref _years, value);
        }

        /// <summary>
        /// Gets or sets the x axis count.
        /// </summary>
        /// <value>The x axis count.</value>
        public ObservableCollection<string> XAxisCount
        {
            get => _xAxisCount;
            set => SetProperty(ref _xAxisCount, value);
        }

        /// <summary>
        /// Gets or sets the chart parameter nodes.
        /// </summary>
        /// <value>The chart parameter nodes.</value>
        public ObservableCollection<ChartParameterNode> ChartParameterNodes
        {
            get => _chartParameterNodes;
            set => SetProperty(ref _chartParameterNodes, value);
        }

        /// <summary>
        /// Gets or sets the chart parameter.
        /// </summary>
        /// <value>The chart parameter.</value>
        public ChartParameter ChartParameter
        {
            get => _chartParameter;
            set => SetProperty(ref _chartParameter, value);
        }

        /// <summary>
        /// Get Set Select Inventory From Combo Type
        /// </summary>
        /// <value>The type of the select inventory.</value>
        public string SelectInventoryType
        {
            get => _selectInventoryType;
            set => SetProperty(ref _selectInventoryType, value, OnInventoryTypeChanged);
        }

        /// <summary>
        /// Get Set Select Inventory From Combo Type
        /// </summary>
        /// <value>The select chart mapping.</value>
        public string SelectChartMapping { get => _selectChartMapping; set => SetProperty(ref _selectChartMapping, value, OnMappingTypeChanged); }


        #endregion Properties

        #region Command

        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>The selected item.</value>
        public DelegateCommand<object> SelectedItem { get; set; }

        /// <summary>
        /// Gets or sets the show result command.
        /// </summary>
        /// <value>The show result command.</value>
        public DelegateCommand ShowResultCommand { get; set; }

        #endregion Command

        /// <summary>
        /// Initializes a new instance of the <see cref="ChartToolBarViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="sharedContextService"></param>
        public ChartToolBarViewModel(IEventAggregator eventAggregator , ISharedContextService sharedContextService)
        {
            var projectModel = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
            _selectedInstalledBasedNode = projectModel.InstalledBase;
            _selectedTrNode = projectModel.TechnicalResources;
            
            XAxisCount = new ObservableCollection<string>();
            ShowResultCommand = new DelegateCommand(OnShowResult);
            ChartParameter = new ChartParameter();
            eventAggregator.GetEvent<IBTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            eventAggregator.GetEvent<TRTreeViewChangeEvent>().Subscribe(OnNodeSelectionChanged);
            SelectedItem = new DelegateCommand<object>(OnTreeSelectionChanged);
            ChartParameterNodes = new ObservableCollection<ChartParameterNode>();
            //  TreeHeaderItems = new ObservableCollection<string>();
            ChartMappings = new ObservableCollection<string>();
            _eventAggregator = eventAggregator;
            Years = new List<int>();
            var dt = DateTime.Now.AddYears(-3);

            for (var yearIndex = 0; yearIndex < 13; yearIndex++)
            {
                Years.Add(dt.AddYears(yearIndex).Year);
            }

            DefineIndicator = new Dictionary<string, List<string>>()
            {
                {
                    "Installed Base", new List<string>()
                    {
                        "Mapping",
                        "Configuration  Mapping",
                        "Obsolescence Mapping",
                        "Obsolescence",
                        "Machine Criticality"
                    }
                },
                {
                    "Technical Resources", new List<string>()
                    {
                        "Mapping",
                        "Obsolescence",
                        "Obsolescence Mapping",
                    }
                }
            };
            ChartMappings.Clear();
            ChartMappings.AddRange(DefineIndicator["Installed Base"]);
        }

        /// <summary>
        /// Called when [show result].
        /// </summary>
        private void OnShowResult()
        {
            ChartParameter.SelectedNode = _selectedInstalledBasedNode;
            if (SelectInventoryType == "Technical Resources")
                ChartParameter.SelectedNode = _selectedTrNode;

            if ((ChartParameter.SelectChartMapping == "Mapping" || 
                 ChartParameter.SelectChartMapping == "Obsolescence Mapping" ||
                 ChartParameter.SelectChartMapping == "Configuration  Mapping") && ChartParameter.SelectedParameterNode == null)
            {
                MessageBox.Show(ChartConstant.MessageSelectXAxisType, ChartConstant.Information, MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            _eventAggregator.GetEvent<ChartParameterEvent>().Publish(ChartParameter);
        }

        /// <summary>
        /// On Selection Value Change
        /// </summary>
        private void OnInventoryTypeChanged()
        {
            if (!string.IsNullOrEmpty(SelectInventoryType) && DefineIndicator.ContainsKey(SelectInventoryType))
            {
                ChartMappings.Clear();
                ChartMappings.AddRange(DefineIndicator[SelectInventoryType]);
                SetTreeNode();
                SelectChartMapping = ChartMappings.Count > 0 ? ChartMappings[0] : string.Empty;
            }

            ChartParameter.SelectInventoryType = SelectInventoryType;
        }

        /// <summary>
        /// On Mapping Type Change
        /// </summary>
        private void OnMappingTypeChanged()
        {
            IsYearEnable = false;
            IsTreeEnable = false;
            ChartParameter.SelectChartMapping = SelectChartMapping;
            XAxisCount.Clear();
            SetTreeNode();
            switch (ChartParameter.SelectChartMapping)
            {
                case "Mapping":
                    IsTreeEnable = !IsYearEnable;
                    break;

                case "Obsolescence":
                    IsYearEnable = !IsTreeEnable;
                    ChartParameter.SelectedParameterNode = null;
                    break;

                case "Machine Criticality":
                    ChartParameter.SelectedParameterNode = null;
                    break;
                case "Obsolescence Mapping":
                    IsTreeEnable = !IsYearEnable;
                    IsYearEnable = true; // added functionality in Obsolescence mapping , User can select Year
                    break;
                case "Configuration  Mapping":
                    IsTreeEnable = !IsYearEnable;
                    break;
            }
        }

        /// <summary>
        /// Event Handler when Node Selection Change
        /// </summary>
        /// <param name="node">The node.</param>
        private void OnNodeSelectionChanged(INode node)
        {
            if (node == null)
                return;
            if (node.ParentNodeAndNodeType.ContainsKey(NodeType.INSTALLEDBASE))
                _selectedInstalledBasedNode = node.ParentNodeAndNodeType[NodeType.INSTALLEDBASE];
            if (node.ParentNodeAndNodeType.ContainsKey(NodeType.TECHNICALRESOURCE))
                _selectedTrNode = node.ParentNodeAndNodeType[NodeType.TECHNICALRESOURCE];
            SetTreeNode();
        }

        /// <summary>
        /// Sets the tree node.
        /// </summary>
        private void SetTreeNode()
        {
            ChartParameter.SelectedParameterNode = null;
            if (SelectInventoryType == "Technical Resources")
                SetTrTree();
            else
                SetInstalledBasedTree();

            RefreshCollection();
        }

        /// <summary>
        /// On selection of Tree node
        /// </summary>
        /// <param name="eventArg">The event argument.</param>
        private void OnTreeSelectionChanged(object eventArg)
        {
            var e = eventArg as RoutedPropertyChangedEventArgs<object>;
            if (e == null)
                return;
            if (e.NewValue is ChartParameterNode param)
            {
                ChartParameter.SelectedParameterNode = param;
                XAxisBarCount(ChartParameter.SelectedParameterNode.NodeCount);
            }
            e.Handled = true;
        }

        /// <summary>
        /// xes the axis bar count.
        /// </summary>
        /// <param name="selectedXAxisTreeNode">The selected x axis tree node.</param>
        private void XAxisBarCount(int selectedXAxisTreeNode)
        {
            XAxisCount.Clear();
            XAxisCount.Add("All");
            for (var i = 1; i <= selectedXAxisTreeNode; i++)
                XAxisCount.Add(i.ToString());
            ChartParameter.SelectedElementNumber = "All";
        }

        /// <summary>
        /// Create Tree node for Installed Base
        /// </summary>
        private void SetInstalledBasedTree()
        {
            ChartParameter.AllParameterNodes.Clear();
            ChartParameterNodes.Clear();
            if (_selectedInstalledBasedNode == null)
                return;

            var machines = new List<MachineNode>();
            if (!(_selectedInstalledBasedNode is InstalledBase installedBaseNode)) return;

            var factories = installedBaseNode.Factories.Cast<INode>().ToList();
            var rootFactory = new ChartParameterNode()
            {
                NodeType = NodeType.FACTORY,
                NodeHeader = $"Factory ({factories.Select(i => i.Name).Distinct().Count()})",
                NodeCount = factories.Select(i => i.Name).Distinct().Count(),
                Nodes = factories
            };
            var childFactory = factories.Select(factory => new ChartParameterNode
            {
                NodeType = NodeType.FACTORY,
                NodeHeader = factory.Name,
                Nodes = new List<INode>() { factory }
            });
            rootFactory.ChartParameterChiledNodes.AddRange(childFactory);
            ChartParameterNodes.Add(rootFactory);

            var workshops = installedBaseNode.Factories.SelectMany(i => i.WorkShopNodes).ToList();
            var rootWorkShop = new ChartParameterNode()
            {
                NodeType = NodeType.WORKSHOP,
                NodeHeader = $"Workshop ({workshops.Select(i => i.Name).Distinct().Count()})",
                NodeCount = workshops.Select(i => i.Name).Distinct().Count(),
                Nodes = workshops.Cast<INode>().ToList()
            };
          var childWorkShop = workshops.Select(workshop => new ChartParameterNode
          {
              NodeType = NodeType.WORKSHOP,
              NodeHeader = workshop.Name,
              Nodes = new List<INode>() { workshop }
          });
            rootWorkShop.ChartParameterChiledNodes.AddRange(childWorkShop);
            ChartParameterNodes.Add(rootWorkShop);

            var line = workshops.SelectMany(i => i.LineNodes).ToList();
            var rootLine = new ChartParameterNode()
            {
                NodeType = NodeType.LINE, NodeHeader = $"Lines ({line.Select(i => i.Name).Distinct().Count()})",
                NodeCount = line.Select(i => i.Name).Distinct().Count(),
                Nodes = line.Cast<INode>().ToList()
            };
          var childLine = line.Select(lineNode => new ChartParameterNode
          {
              NodeType = NodeType.LINE,
              NodeHeader = lineNode.Name,
              Nodes = new List<INode>() { lineNode }
          });
            rootLine.ChartParameterChiledNodes.AddRange(childLine);
            ChartParameterNodes.Add(rootLine);

            var workshopsMachine = workshops.SelectMany(i => i.MachineNodes).ToList();
            var lineMachine = line.SelectMany(i => i.MachineNodes).ToList();
            var filterLineMachine = lineMachine.Where(i => workshopsMachine.All(k => k.Id != i.Id)).ToList();
            machines.AddRange(filterLineMachine);
            machines.AddRange(workshopsMachine);
            var rootMachine = new ChartParameterNode()
            {
                NodeType = NodeType.MACHINE,
                NodeHeader = $"Machine ({machines.Select(i => i.Name).Distinct().Count()})",
                NodeCount = machines.Select(i => i.Name).Distinct().Count(),
                Nodes = machines.Cast<INode>().ToList()
            };
            var childMachine = machines.Select(machineNode => new ChartParameterNode
            {
                NodeType = NodeType.MACHINE,
                NodeHeader = machineNode.Name,
                Nodes = new List<INode>() { machineNode }
            });
            rootMachine.ChartParameterChiledNodes.AddRange(childMachine);
            ChartParameterNodes.Add(rootMachine);

            var config = machines.SelectMany(i => i.ConfigNodes).ToList();
            ChartParameterNodes.Add(new ChartParameterNode()
            {
                NodeType = NodeType.OPEN_CONFIG,
                NodeHeader = $"Configuration ({config.Select(i => i.Name).Distinct().Count()})",
                NodeCount = config.Select(i => i.Name).Distinct().Count(),
                Nodes = config.Cast<INode>().ToList()
            });

            ChartParameter.AllParameterNodes.AddRange(ChartParameterNodes.Distinct());
        }

        /// <summary>
        /// Create Tree node for Technical Resource
        /// </summary>
        private void SetTrTree()
        {
            ChartParameter.AllParameterNodes.Clear();
            ChartParameterNodes.Clear();
            if (_selectedTrNode == null)
                return;


            if (!(_selectedTrNode is TRNode trNode)) return;

            var maintenanceNodes = trNode.MaintenanceNodes.ToList();
            var rootMaintenance = new ChartParameterNode()
            {
                NodeType = NodeType.MAINTENANCEZONE,
                NodeHeader = $"Maintenance ({maintenanceNodes.Count()})",
                NodeCount = maintenanceNodes.Count(),
                Nodes = maintenanceNodes.Cast<INode>().ToList()
            };
            var childFactory = maintenanceNodes.Select(maintenanceNode => new ChartParameterNode
            {
                NodeType = NodeType.MAINTENANCEZONE,
                NodeHeader = maintenanceNode.Name,
                Nodes = new List<INode>() { maintenanceNode }
            });
            rootMaintenance.ChartParameterChiledNodes.AddRange(childFactory);
            ChartParameterNodes.Add(rootMaintenance);

            var stock = maintenanceNodes.SelectMany(i => i.StockNodes).ToList();
            ChartParameterNodes.Add(new ChartParameterNode()
            {
                NodeType = NodeType.STOCK, NodeHeader = $"Stock ({stock.Count()})",
                Nodes = stock.Cast<INode>().ToList()
            });

            ChartParameter.AllParameterNodes.AddRange(ChartParameterNodes.Distinct());
        }

        /// <summary>
        /// Refreshes the collection.
        /// </summary>
        private void RefreshCollection()
        {

            CollectionViewSource.GetDefaultView(ChartParameterNodes).Refresh();
            CollectionViewSource.GetDefaultView(XAxisCount).Refresh();
            CollectionViewSource.GetDefaultView(ChartMappings).Refresh();
            //     CollectionViewSource.GetDefaultView(TreeHeaderItems).Refresh();
            CollectionViewSource.GetDefaultView(ChartParameterNodes).Refresh();
        }
    }
}