import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Store } from '@ngrx/store';

import { saveAs } from 'file-saver';

import { NgxSpinnerService } from 'ngx-spinner';
import {environment } from '../../environments/environment'
import * as OtlScoreCardAction from './../store/otlScoreCard/otlScoreCardAction';
import { IAppState } from '../store/otlScoreCard/otlScoreCardReducer';
@Injectable({
  providedIn: 'root'
})
export class OtlScoreCardService {

  headers: any;
  url = environment.apiBaseUrl;
  fileBaseUrl = environment.fileBaseUrl;

  constructor(private http: HttpClient, private store: Store<IAppState>, private spinner: NgxSpinnerService) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
     'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
     withCredentials: 'true',
  });
   }


   reportDownload(date) {
    console.log(date);
   
    this.http.get(this.fileBaseUrl+'OtlScoreCard?date=' + date , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'OtlScoreCard' + date + '.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }

  getAllOtlScoreCard() {
    this.spinner.show();
    this.http.get<any>(this.url+'OtlScoreCard')
    .subscribe(res => {
      this.spinner.hide()
      this.store.dispatch(new OtlScoreCardAction.LoadOtlScoreCard(res)
      )}, err => {
            this.spinner.hide();
          });
  }


  
  loadPliByFilter(criteria) {
    this.spinner.show();
    console.log('Load By  criteria ' + criteria)
    return this.http.post(this.url + 'OtlScoreCard/loadbycriteria', criteria, { headers: this.headers })
    .subscribe(res => {
      this.spinner.hide()
      this.store.dispatch(new OtlScoreCardAction.LoadOtlScoreCard(res)
      )}, err => {
            this.spinner.hide();
          });
  }


  reportDownloadByFilter(data) {
    this.http.post(this.fileBaseUrl+'OtlScoreCardfilterreport', data , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'OtlScoreCard.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }
  
  reportDownloadAll() {
    this.http.get(this.fileBaseUrl+'OtlScoreCardreport' , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'PliSummary.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }

}
