//using PSENPI.App_Start;
using Autofac;
using Autofac.Integration.WebApi;
using Data.Management.Services.DataBaseAccessObject;
using DataManagement.Data.Models;
using Data.Management.Services.Manager;
using Data.Management.Services;
using System.Linq;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace Data.Management.Host
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var config = GlobalConfiguration.Configuration;
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            // IOCConfig.RegisterComponents();
            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            var assemblyType = typeof(DataManagementTrack).GetTypeInfo();
            builder.RegisterAssemblyTypes(assemblyType.Assembly)
            .Where(t => t.Name.EndsWith("Service"))
            .AsImplementedInterfaces()
            .InstancePerRequest();
            config.EnableCors(new EnableCorsAttribute("*", "*", "*"));
            config.EnableCors();
            builder.RegisterWebApiFilterProvider(config);
            builder.RegisterType<DataManagementServices>().As<IDataManagementServices>().InstancePerRequest();
            builder.RegisterType<DataManagementManage>().As<IDataManagementManage>().InstancePerRequest();
            builder.RegisterType<DataManagementDbAccess>().As<IDataManagementDbAccess>().InstancePerRequest();

            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }
    }
}