//using Oracle.Data.Access;

//namespace Pse.Data.Models
//{
//    public class Otl
//    {
//        [Columns("KeyCode")]
//        public string KeyCode { get; set; }

//        [Columns("Accolade_Program_Name")]
//        public string Accolade_Program_Name { get; set; }

//        [Columns("HMR_Index")]
//        public string HMR_Index { get; set; }

//        [Columns("MS_Name")]
//        public string MS_Name { get; set; }

//        [Columns("MS_Category")]
//        public string MS_Category { get; set; }

//        [Columns("BaseLine_Date")]
//        public string BaseLine_Date { get; set; }

//        [Columns("Forecast_Date")]
//        public string Forecast_Date { get; set; }

//        [Columns("Actual_Finish")]
//        public string Actual_Finish { get; set; }

//        [Columns("OTL_TTI")]
//        public string OTL_TTI { get; set; }

//        [Columns("Status_Assessment")]
//        public string Status_Assessment { get; set; }

//        [Columns("Delay_in_days")]
//        public string Delay_in_days { get; set; }

//        [Columns("RCCA")]
//        public string RCCA { get; set; }

//        [Columns("MS_Responsible_Person")]
//        public string MS_Responsible_Person { get; set; }

//        [Columns("Accolade_Product_SBU")]
//        public string Accolade_Product_SBU { get; set; }

//        [Columns("Accolade_GBE")]
//        public string Accolade_GBE { get; set; }

//        [Columns("PAC")]
//        public string PAC { get; set; }

//        [Columns("Tier2_Owning")]
//        public string Tier2_Owning { get; set; }

//        [Columns("Tier3_Performing")]
//        public string Tier3_Performing { get; set; }

//        [Columns("Tier4_Performing")]
//        public string Tier4_Performing { get; set; }

//        [Columns("Accolade_PM_Focal")]
//        public string Accolade_PM_Focal { get; set; }

//        [Columns("Accolade_PP_c_Focal")]
//        public string Accolade_PP_c_Focal { get; set; }

//        [Columns("Accolade_Eng_Tech_Lead")]
//        public string Accolade_Eng_Tech_Lead { get; set; }

//        [Columns("_Accolade_IPDS_Phase_EP3")]
//        public string Accolade_IPDS_Phase_EP3 { get; set; }

//        [Columns("MS_Last_Updated_AZ_Time")]
//        public string MS_Last_Updated_AZ_Time { get; set; }

//        [Columns("HMR_ProjCode")]
//        public string HMR_ProjCode { get; set; }
//    }
//}