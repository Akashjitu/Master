﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IPositionQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.Common;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IPositionQueries
    /// </summary>
    public interface IPositionQueries
    {
        /// <summary>
        /// Loads the positions.
        /// </summary>
        /// <returns>List&lt;Position&gt;.</returns>
        List<Position> LoadPositions();
    }
}