﻿using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.IO;

namespace Schneider.M2C.OpenExcel.Parser.Tests
{
    [TestClass]
    public class ExcelParserTest : TestBase
    {
        private IExcelParser excelParser;

        [TestInitialize]
        public void TestIniTialize()
        {
            excelParser = new ExcelParser();
        }

        [TestMethod]
        public void GeModelsFromExcelTest()
        {
            var excelData = excelParser.GeModelsFromExcel<IBImportModel>(@"Mock_Data\Book1.xlsx", "Data", 1, 2);
            excelData.Should().NotBeEmpty();
        }

        [TestMethod]
        public void GeModelFromExcelTest()
        {
            var excelData = excelParser.GeModelsFromExcel<IBImportModel>(@"Mock_Data\Book1.xlsx", "Data", 1, 2, (int i) => { });
            excelData.Should().NotBeEmpty();
        }

        [TestMethod]
        public void GetDataTableFromExcelTest()
        {
            var excelData = excelParser.GetDataTableFromExcel(@"Mock_Data\Book1.xlsx", "Data", 1, 2);
            excelData.Should().NotBeNull();
        }

        [TestMethod]
        public void GetDataTableFromExcelStreamTest()
        {
            using (FileStream fileStream = new FileStream(@"Mock_Data\Book1.xlsx", FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                var excelData = excelParser.GetDataTableFromExcel(fileStream, "Data", 1, 2);
                excelData.Should().NotBeNull();
            }
        }

        [TestMethod]
        public void GeModelsFromExcelStreamTest()
        {
            using (FileStream fileStream = new FileStream(@"Mock_Data\Book1.xlsx", FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                var excelData = excelParser.GeModelsFromExcel<IBImportModel>(fileStream, "Data", 1, 2);
                excelData.Should().NotBeNull();
            }
        }

        [TestMethod]
        public void GetDataTableFromExcelNegativeTest()
        {
            Action act = () => excelParser.GetDataTableFromExcel(@"Mock_Data\Book2.xlsx", "Data", 1, 2);
            act.Should().Throw<FileNotFoundException>();

            Action acts = () => excelParser.GetDataTableFromExcel(@"Mock_Data\Book2.xlsx", "", 1, 2);
            acts.Should().Throw<FileNotFoundException>();
        }

        [TestMethod]
        public void GetModelFromExcelTest()
        {
            var columnLst = new List<string>() { "A", "B", "C", "D", "E", "F", "G", "H", "I" };
            var excelData = excelParser.GetModelFromExcel<TRImportModel>(@"Mock_Data\Book1.xlsx", "Data", columnLst);
            excelData.Should().NotBeNull();
        }
    }
}