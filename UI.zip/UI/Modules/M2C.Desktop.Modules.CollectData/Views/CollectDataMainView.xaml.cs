﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CollectDataMainView.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for CollectDataMainView.xaml
    /// </summary>
    public partial class CollectDataMainTab : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CollectDataMainTab" /> class.
        /// </summary>
        public CollectDataMainTab()
        {
            InitializeComponent();
        }
    }
}