﻿using Pse.Data.Models;
using Pse.Npi.Host.Logs;
using Pse.Npi.Host.Providers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Mail;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class FeedbackController : ApiController
    {
        ActiveDirectoryHelper.ActiveDirectoryHelper activDir = new ActiveDirectoryHelper.ActiveDirectoryHelper();
        [HttpPost]
        public HttpResponseMessage AddFeedBack(Feedback feedback)
        {

            try
            {

                var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);

                var emp = activDir.GetUsersByLoginName(eid);
                if(emp== null || emp.Count ==0)
                    return Request.CreateResponse(HttpStatusCode.InternalServerError, "Employee ID not Found.", JsonMediaTypeFormatter.DefaultMediaType);

                string htmlBody = "Hi,<br /> </br>" +
                    "One (Customer Approval Feedback)Request raised  by " + "<strong>" + emp[0].DisplayName + "</strong>" + "<br/>" + feedback.FeedbackBody +
                "</br><br/>" + "Regards,<br/><h4>Customer Approval Tracker Feedback</h4>";

                //string htmlBody = feedback.FeedbackBody;
                MailMessage Mail = new MailMessage();
                Mail.IsBodyHtml = true;

                //if (!string.IsNullOrEmpty(fileName))
                //{
                //    System.Net.Mail.Attachment attachment;
                //    attachment = new System.Net.Mail.Attachment(fileName);
                //    Mail.Attachments.Add(attachment);
                //}


                Mail.From = new MailAddress("PseDashboard@Honeywell.com");

                Mail.Subject = "Pse DashBoard Feedback";



                var mailTo = ConfigurationManager.AppSettings["FEEDBACK_MAIL_TO"] ?? "Anupam.Sinha@Honeywell.com";
                var mailCC = ConfigurationManager.AppSettings["FEEDBACK_MAIL_CC"] ?? "akash.kumar3@honeywell.com";


                Mail.CC.Add(mailCC);
                Mail.To.Add(mailTo);


                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(
                htmlBody,
                null, "text/html");
                Mail.AlternateViews.Add(htmlView);
                Mail.AlternateViews.Add(htmlView);
                SmtpClient client = new SmtpClient();
                client.Port = 25;
                client.Host = "smtp.honeywell.com";
                client.Send(Mail);
                Mail.Dispose();
                return Request.CreateResponse(HttpStatusCode.OK, "Mail Send", JsonMediaTypeFormatter.DefaultMediaType);


            }
            catch (Exception ex)
            {
                LogWriter.LogWrite(" LoadAllDataManagements eid ----------- " + ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Error Sending  mail :- " + ex.Message, JsonMediaTypeFormatter.DefaultMediaType);
            }
        }


    }
}
