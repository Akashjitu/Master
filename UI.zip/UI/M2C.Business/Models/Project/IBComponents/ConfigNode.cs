﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ConfigNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using Prism.Ioc;
using Prism.Unity;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Class ConfigNode.
    /// Implements the <see cref="M2C.Business.Models.Project.IBComponents.Node" />
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.Node" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ConfigNode : Node, ICloneable, IDelete
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigNode" /> class.
        /// </summary>
        public ConfigNode()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigNode" /> class.
        /// </summary>
        /// <param name="type">The type.</param>
        public ConfigNode(NodeType type)
        {
            this.NodeType = type;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="type">The type.</param>
        public ConfigNode(string name, NodeType type)
        {
            this.Name = name;
            this.NodeType = type;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigNode" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="type">The type.</param>
        /// <param name="parentNode">The parent node.</param>
        public ConfigNode(int id, string name, NodeType type, INode parentNode)
        {
            Id = id;
            ParentNode = parentNode;
            this.Name = name;
            this.NodeType = type;
        }

        /// <summary>
        /// Creates a new object that is a copy of the current instance.
        /// </summary>
        /// <returns>A new object that is a copy of this instance.</returns>
        public object Clone()
        {
            var cloneNode = MemberwiseClone() as ConfigNode;
            if (cloneNode != null)
            {
                var customerDocument = new ObservableCollection<CustomerDocument>();
                foreach (var doc in CustomerDocuments)
                    customerDocument.Add(new CustomerDocument() { Name = doc.Name, FilePath = doc.FilePath });

                cloneNode.CopyOfNodeInventories = GetCopyOfNodeInventories();
                cloneNode.ParentNode = null;
                cloneNode.CustomerDocuments = customerDocument;
                cloneNode.Id = null;
                return cloneNode;
            }
            return cloneNode;
        }

        /// <summary>
        /// Deletes this instance.
        /// </summary>
        public void Delete()
        {
            (this.ParentNode as MachineNode)?.ConfigNodes.Remove(this);
        }
    }

    /// <summary>
    /// extension class for Config node for adding the inventory for config nodes
    /// </summary>
    public static class ConfigExt
    {
        /// <summary>
        /// importing function for inventory
        /// </summary>
        /// <param name="config">The configuration.</param>
        /// <param name="IBComponenets">The ib componenets.</param>
        public static void ImportInventory(this ConfigNode config, List<IBImportModel> IBComponenets)
        {
            if (Application.Current != null)
            {
                IContainerProvider containProvider = (Application.Current as PrismApplication)?.Container;
                var _inventoryMapper = containProvider.Resolve<IInventoryMapper>();

                var IBComponenetsrow = IBComponenets.Where(x => x.ConfigurationName == config.Name).ToList();

                var inventory = _inventoryMapper.Map(IBComponenetsrow, new List<INode>() { config });
                foreach (var invnt in inventory)
                {
                    config.MasterInventories.Add(invnt);
                }
            }
        }
    }
}