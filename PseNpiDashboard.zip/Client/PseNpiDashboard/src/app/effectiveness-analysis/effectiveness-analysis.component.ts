import { Component, OnInit } from '@angular/core';
import { MessageService } from "primeng/components/common/messageservice";
import { HttpClient, HttpHeaders } from "@angular/common/http";
@Component({
  selector: 'app-effectiveness-analysis',
  templateUrl: './effectiveness-analysis.component.html',
  styleUrls: ['./effectiveness-analysis.component.sass']
})
export class EffectivenessAnalysisComponent implements OnInit {
  data: any;
  constructor(private messageService: MessageService) 
  //constructor() 
  {

      this.data = {
          labels: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11','12', '13', '14', '15', '16', '17', '18', '19', '20'],
          datasets: [
              {
                  label: '2017',
                  data: [4, 2, 8, 0, 1, 3, 5],
                  fill: false,
                  borderColor: 'green'
              },
              {
                  label: '2018',
                  data: [1, 3, 1, 8, 0, 3, 9],
                  fill: false,
                  borderColor: 'orange'
              },
              {
                  label: '2019',
                  data: [6, 8, 10, 6, 4, 0, 7],
                  fill: false,
                  borderColor: 'blue'
              }
          ]
      }
  }

  selectData(event) {
      this.messageService.add({severity: 'info', summary: 'Data Selected', 'detail': this.data.datasets[event.element._datasetIndex].data[event.element._index]});
  }

  ngOnInit() {
  }

}
