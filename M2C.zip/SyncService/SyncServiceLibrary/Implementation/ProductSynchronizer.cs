﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProductSynchronizer.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using AppConfiguration;
using DataRepository.DBContracts;
using DomainModels.IbCatalogModels;
using RestClientServices.Contracts;
using Schneider.M2C.OpenExcel.Parser.Model;
using SyncServiceLibrary.Contracts;
using SyncServiceLibrary.Mapper;
using SyncServiceLibrary.Model;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SyncServiceLibrary.Implementation
{
    /// <summary>
    /// Class ProductSynchronizer.
    /// Implements the <see cref="SyncServiceLibrary.Contracts.IProductSynchronizer" />
    /// </summary>
    /// <seealso cref="SyncServiceLibrary.Contracts.IProductSynchronizer" />
    public class ProductSynchronizer : IProductSynchronizer
    {
        /// <summary>
        /// The synchronize service queries
        /// </summary>
        private readonly ISyncServiceQueries syncServiceQueries;

        /// <summary>
        /// The application configuration
        /// </summary>
        private IAppConfigurations appConfig;

        /// <summary>
        /// The rest services factory
        /// </summary>
        private IRestServicesFactory restServicesFactory;

        /// <summary>
        /// The product query
        /// </summary>
        private readonly IProductQueries productQuery;

        /// <summary>
        /// The synchronize service mapper
        /// </summary>
        private readonly ISyncServiceDataMapper syncServiceMapper;

        /// <summary>
        /// The product synchronize
        /// </summary>
        private readonly IProductSyncService ProductSync;

        /// <summary>
        /// The brand query
        /// </summary>
        private readonly IBrandQueries brandQuery;
        /// <summary>
        /// The device type query
        /// </summary>
        private readonly IDeviceTypeQueries deviceTypeQuery;
        /// <summary>
        /// The range query
        /// </summary>
        private readonly IRangeQueries rangeQuery;
        /// <summary>
        /// The sub range query
        /// </summary>
        private readonly ISubRangeQueries subRangeQuery;

        /// <summary>
        /// Gets the retry count.
        /// </summary>
        /// <value>The retry count.</value>
        private int RetryCount
        {
            get
            {
                int.TryParse(appConfig.RetryCount, out int i);
                return i;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductSynchronizer" /> class.
        /// </summary>
        /// <param name="syncServiceQueries">The synchronize service queries.</param>
        /// <param name="appConfiguration">The application configuration.</param>
        /// <param name="restServiceFactory">The rest service factory.</param>
        /// <param name="productQueries">The product queries.</param>
        /// <param name="syncServiceMapper">The synchronize service mapper.</param>
        /// <param name="brandQueries">The brand queries.</param>
        /// <param name="deviceTypeQueries">The device type queries.</param>
        /// <param name="rangeQueries">The range queries.</param>
        /// <param name="subRangeQueries">The sub range queries.</param>
        public ProductSynchronizer(ISyncServiceQueries syncServiceQueries,
            IAppConfigurations appConfiguration,
            IRestServicesFactory restServiceFactory,
            IProductQueries productQueries,
            ISyncServiceDataMapper syncServiceMapper,
            IBrandQueries brandQueries,
            IDeviceTypeQueries deviceTypeQueries,
            IRangeQueries rangeQueries,
            ISubRangeQueries subRangeQueries)
        {
            this.syncServiceQueries = syncServiceQueries;
            this.appConfig = appConfiguration;
            this.restServicesFactory = restServiceFactory;
            this.productQuery = productQueries;
            this.syncServiceMapper = syncServiceMapper;
            this.brandQuery = brandQueries;
            deviceTypeQuery = deviceTypeQueries;
            rangeQuery = rangeQueries;
            subRangeQuery = subRangeQueries;

            ProductSync = this.restServicesFactory.GetRestClientService<IProductSyncService>(RestServiceTypes.PRODUCT_SYNC_SERVICE);
        }

        /// <summary>
        /// Synchronizes to local.
        /// </summary>
        /// <param name="EventCallback">The event callback.</param>
        public void SyncToLocal(Action<SyncResultModel> EventCallback)
        {
            try
            {
                int attempt = 0;
                SyncHistory SyncHistory = null;
                SyncResultModel syncResult = new SyncResultModel();
                do
                {
                    try
                    {
                        syncResult.Status = SyncStatus.IN_PROGRESS;
                        syncResult.Message = "Checking product updates";
                        EventCallback(syncResult);
                        ProductSyncModel[] products = GetProductFromServer();
                        if (products != null && products.Length > 0)
                        {
                            SyncHistory = syncServiceQueries.SaveSyncHistory(new SyncHistory()
                            {
                                SyncId = Guid.NewGuid().ToString(),
                                RetryCount = attempt,
                                Status = (int)SyncStatus.IN_PROGRESS,
                                SyncDate = DateTime.Now
                            });

                            syncResult.Status = SyncStatus.IN_PROGRESS;
                            syncResult.Message = "Products Sync started";
                            EventCallback(syncResult);
                        }
                        else
                        {
                            syncResult.Status = SyncStatus.SUCCESS;
                            syncResult.Message = "Products are up-to date";
                            EventCallback(syncResult);
                            Thread.Sleep(2000);
                            break;
                        }

                        OneIbCatalog[] catlog = products.Select(x => x.ibCatalog).ToArray();
                        SyncProductData(catlog);

                        if (SyncHistory != null)
                        {
                            SyncHistory.Status = (int)SyncStatus.SUCCESS;
                            syncServiceQueries.UpdateSyncHistory(SyncHistory);

                            syncResult.Status = SyncStatus.SUCCESS;
                            syncResult.Message = "Products Sync success";
                            EventCallback(syncResult);

                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        attempt++;
                        if (SyncHistory != null)
                        {
                            SyncHistory.Status = (int)SyncStatus.FAILED;
                            syncServiceQueries.UpdateSyncHistory(SyncHistory);
                        }
                        if (attempt <= RetryCount)
                        {
                            syncResult.Status = SyncStatus.IN_PROGRESS;
                            syncResult.Message = "Products Sync started";
                        }
                        else
                        {
                            syncResult.Status = SyncStatus.FAILED;
                            syncResult.Message = "Products Sync failed";
                        }
                        Task.Delay(500).Wait();

                        EventCallback(syncResult);
                    }
                }
                while (attempt <= RetryCount);
            }
            catch (Exception Ex)
            {
                EventCallback(new SyncResultModel()
                {
                    Status = SyncStatus.FAILED,
                    Message = Ex.Message
                });
            }
        }

        /// <summary>
        /// Synchronizes the product data.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        private void SyncProductData(OneIbCatalog[] oneIbCatalogs)
        {
            if (oneIbCatalogs == null) return;

            brandQuery.SaveBrands(syncServiceMapper.BrandMap(oneIbCatalogs));
            deviceTypeQuery.SaveDeviceTypes(syncServiceMapper.DeviceTypeMap(oneIbCatalogs));
            rangeQuery.SaveRanges(syncServiceMapper.RangeMap(oneIbCatalogs));

            var ranges = rangeQuery.LoadRanges();
            var subrange = syncServiceMapper.SubRangeMap(oneIbCatalogs.ToList(), ranges);
            var products = syncServiceMapper.ProductMap(oneIbCatalogs.ToList(), brandQuery.LoadBrands(), deviceTypeQuery.LoadDeviceTypes(), ranges);

            subRangeQuery.SaveSubRanges(subrange);
            productQuery.SaveProducts(products);
        }

        /// <summary>
        /// Gets the product from server.
        /// </summary>
        /// <returns>ProductSyncModel[].</returns>
        private ProductSyncModel[] GetProductFromServer()
        {
            DateTime? lastSyncDate = GetLastSyncedDate();

            if (lastSyncDate != null)
            {
                return ProductSync.getProductUpdateByDate<ProductSyncModel[]>(lastSyncDate?.ToString(@"o"));
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Gets the last synced date from DB
        /// </summary>
        /// <returns>System.Nullable&lt;DateTime&gt;.</returns>
        private DateTime? GetLastSyncedDate()
        {
            return syncServiceQueries.GetLastSyncDate();
        }
    }
}