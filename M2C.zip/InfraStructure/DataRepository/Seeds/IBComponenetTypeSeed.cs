﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-09-2020
// ***********************************************************************
// <copyright file="IBComponenetTypeSeed.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using Microsoft.EntityFrameworkCore;

namespace DataRepository.Seeds
{
    /// <summary>
    /// Class IBComponenetTypeSeed.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    internal class IBComponenetTypeSeed
    {
        /// <summary>
        /// Seeds the specified model builder.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public void Seed(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IBComponenetType>().HasData(
                new IBComponenetType
                {
                    ComponentTypeID = 1,
                    Name = "Install Base"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 2,
                    Name = "Factory"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 3,
                    Name = "Workshop"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 4,
                    Name = "Line"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 5,
                    Name = "Machine"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 6,
                    Name = "PLC Config"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 7,
                    Name = "Motion & Drive Config"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 8,
                    Name = "Scada HMI Config"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 9,
                    Name = "Open Configuration"
                }
                ,
                new IBComponenetType
                {
                    ComponentTypeID = 10,
                    Name = "Technical Resource"
                }
                ,
                new IBComponenetType
                {
                    ComponentTypeID = 11,
                    Name = "Maintenance Zone"
                }
                ,
                new IBComponenetType
                {
                    ComponentTypeID = 12,
                    Name = "Stock"
                },
                new IBComponenetType
                {
                    ComponentTypeID = 13,
                    Name = "Competencies"
                }
            );
        }
    }
}