﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="AppResource.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows;

namespace M2C.Desktop.Core.Resources
{
    /// <summary>
    /// Class AppResource.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class AppResource
    {
        /// <summary>
        /// Gets the resource string.
        /// </summary>
        /// <param name="xKey">The x key.</param>
        /// <returns>System.String.</returns>
        public static string GetResourceString(string xKey)
        {
            return (string)Application.Current.FindResource(xKey);
        }
    }
}