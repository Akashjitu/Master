﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReportExportTools.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows;
using System.Windows.Controls;

namespace M2C.Desktop.Modules.Charts.ReportData.Views
{
    /// <summary>
    /// Interaction logic for ReportExportTools.xaml
    /// </summary>
    public partial class ReportExportTools : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportExportTools" /> class.
        /// </summary>
        public ReportExportTools()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the OnClick event of the BtnShowResult control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void BtnShowResult_OnClick(object sender, RoutedEventArgs e)
        {
            
            ContextMenu cm = FindName("cmButton") as ContextMenu;
            cm.IsOpen = false;
            cm.PlacementTarget = sender as Button;
            cm.IsOpen = true;
        }
    }
}
