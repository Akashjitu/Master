import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-details',
  templateUrl: './common-details.component.html',
  styleUrls: ['./common-details.component.css']
})
export class CommonDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
