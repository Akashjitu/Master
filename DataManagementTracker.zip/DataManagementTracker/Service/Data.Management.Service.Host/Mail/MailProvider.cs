﻿using System;
using System.Net.Mail;

namespace Data.Management.Service.Host.Mail
{
    public class MailProvider : IMailProvider
    {
        public void SendMail(string byName, string byMailId, string dataManagerMailId, string cmMailId)
        {
            try
            {
                string htmlBody = "Hi,<br /> </br>" +
                    "One (Customer Approval Tracker)Request raised  by " + "<strong>" + byName + "</strong>" +
                    "</br><br/>" + "Regards,<br/><h4>Customer Approval Tracker Automation</h4>";
                MailMessage Mail = new MailMessage();
                Mail.IsBodyHtml = true;

                //if (!string.IsNullOrEmpty(fileName))
                //{
                //    System.Net.Mail.Attachment attachment;
                //    attachment = new System.Net.Mail.Attachment(fileName);
                //    Mail.Attachments.Add(attachment);
                //}

                Mail.From = new MailAddress("Customer_Approval_Tracker@Honeywell.com");

                Mail.Subject = "Customer Approval Tracker Automation";

                if (!string.IsNullOrEmpty(byMailId))
                    Mail.CC.Add(byMailId);
                if (!string.IsNullOrEmpty(dataManagerMailId))
                    Mail.To.Add(dataManagerMailId);
                if (!string.IsNullOrEmpty(cmMailId))
                    Mail.To.Add(cmMailId);

                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(
                htmlBody,
                null, "text/html");
                Mail.AlternateViews.Add(htmlView);
                Mail.AlternateViews.Add(htmlView);
                SmtpClient client = new SmtpClient();
                client.Port = 25;
                client.Host = "smtp.honeywell.com";
                client.Send(Mail);
                Mail.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}