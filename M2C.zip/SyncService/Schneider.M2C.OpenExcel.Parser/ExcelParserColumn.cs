﻿// ***********************************************************************
// Assembly         : Schneider.M2C.OpenExcel.Parser
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ExcelParserColumn.cs" company="Schneider.M2C.OpenExcel.Parser">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;

namespace Schneider.M2C.OpenExcel.Parser
{
    /// <summary>
    /// Class ExcelParserColumn.
    /// Implements the <see cref="System.Attribute" />
    /// </summary>
    /// <seealso cref="System.Attribute" />
    public class ExcelParserColumn : Attribute
    {
        /// <summary>
        /// The excel column
        /// </summary>
        /// <value>The excel column.</value>
        //public string ExcelColumn;

        public string ExcelColumn { get; set; }

        /// <summary>
        /// Set the Excel Columns Name
        /// </summary>
        /// <param name="excelcolumn">Excel File Column Name</param>
        public ExcelParserColumn(string excelcolumn)
        {
            ExcelColumn = excelcolumn;
        }
    }
}