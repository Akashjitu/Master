﻿
namespace Fraca.DataBaseAccessObject.Constants
{
    public class DataAccessConstant
    {
        public const string FRACA_ID_FROMAT = "FRACA_ID_FROMAT";
        public const string CONNECTION_STRING = "connectionString";
        public const string SP_ADD_FRACA = "PKG_FRACA.SP_ADD_FRACA";
        public const string SP_LOAD_By_PART = "PKG_FRACA.SP_LOAD_By_PART";
        public const string SP_LOAD_By_Filter = "PKG_FRACA.SP_LOAD_BY_FILTER";
        public const string SP_LOAD_By_ID = "PKG_FRACA.SP_LOAD_BY_ID";
        public const string SP_LOAD_By_DATE = "PKG_FRACA.SP_LOAD_BY_DATE";
        public const string SP_Delete_FRACA = "PKG_FRACA.SP_DELETE_FRACA";
        public const string SP_UPDATE_FRACA = "PKG_FRACA.SP_UPDATE_FRACA";
        public const string SP_LOAD_ALL_FRACA = "PKG_FRACA.SP_LOAD_ALL_FRACA";


    }
}
