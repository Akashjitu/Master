﻿using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.Models;

namespace M2C.Desktop.Modules.Charts.ElementProvides
{
    public class BarElementProvider : IBarElementProvider
    {
        private readonly IConfigMappingElementProvider _configMappingElementProvider;
        private readonly IMappingElementProvider _mappingElementProvider;
        private readonly IObsolescenceElementProvider _obsolescenceElementProvider;
        private readonly IObsolescenceMappingElementProvider _obsolescenceMappingElementProvider;
        private readonly ICriticalityElementProvider _criticalityElementProvider;

        public BarElementProvider(IConfigMappingElementProvider configMappingElementProvider,
            IMappingElementProvider mappingElementProvider,
            IObsolescenceElementProvider obsolescenceElementProvider,
            IObsolescenceMappingElementProvider obsolescenceMappingElementProvider, ICriticalityElementProvider criticalityElementProvider)
        {
            _configMappingElementProvider = configMappingElementProvider;
            _mappingElementProvider = mappingElementProvider;
            _obsolescenceElementProvider = obsolescenceElementProvider;
            _obsolescenceMappingElementProvider = obsolescenceMappingElementProvider;
            _criticalityElementProvider = criticalityElementProvider;
        }

        /// <summary>
        /// Get Configuration Mapping Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetConfigurationMappingElements(ChartParameter chartParameter, NodeType type = NodeType.OPEN_CONFIG)
        {
            return _configMappingElementProvider.GetConfigurationMappingElements(chartParameter, type);
        }

        /// <summary>
        /// Get Mapping Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetMappingBarElements(ChartParameter chartParameter,
            NodeType type = NodeType.OPEN_CONFIG)
        {
            return _mappingElementProvider.GetMappingBarElements(chartParameter, type);
        }

        /// <summary>
        /// Get Obsolescence Chart Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetObsolescenceChartElements(ChartParameter chartParameter,
            NodeType type = NodeType.OPEN_CONFIG)
        {
            return _obsolescenceElementProvider.GetObsolescenceChartElements(chartParameter, type);
        }

        /// <summary>
        /// Get Obsolescence Chart Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        /// <param name="type">The type.</param>
        public ChartBarElements GetbsolescenceMapping(ChartParameter chartParameter,
            NodeType type = NodeType.OPEN_CONFIG)
        {
            return _obsolescenceMappingElementProvider.GetObsolescenceMapping(chartParameter, type);
        }

        /// <summary>
        /// Get Criticality Bar Elements.
        /// </summary>
        /// <param name="chartParameter"></param>
        public ChartBarElements GetCriticalityBarElements(ChartParameter chartParameter)
        {
            return _criticalityElementProvider.GetCriticalityBarElements(chartParameter);
        }
    }
}