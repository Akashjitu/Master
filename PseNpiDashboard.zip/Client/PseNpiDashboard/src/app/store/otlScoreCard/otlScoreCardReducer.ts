

import { Action } from '@ngrx/store';
import * as OtlScoreCardAction from './otlScoreCardAction';
import { OtlScoreCard } from 'src/app/model/otlScoreCard';



export interface IAppState {
    readonly compliance: OtlScoreCard[];
}


export function otlScoreCardReducer(state: OtlScoreCard[] = [], action: OtlScoreCardAction.Actions) {

    switch (action.type) {

        case OtlScoreCardAction.ADD_OTL_SCORE_CARD: {
            return [...state, action.payload]

        }

        case OtlScoreCardAction.LOAD_OTL_SCORE_CARD: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case OtlScoreCardAction.UPDATE_OTL_SCORE_CARD: {
            const tti = (action.payload as OtlScoreCard);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            //return Object.assign([], state);
            return state.slice();
        }



        default:
            return state;
    }
}