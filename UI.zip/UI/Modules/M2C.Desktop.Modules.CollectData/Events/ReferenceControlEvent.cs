﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ReferenceControlEvent.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using Prism.Events;

namespace M2C.Desktop.Modules.CollectData.Events
{
    /// <summary>
    /// Event class act as a middle man between parent child view-models
    /// Parent Subscribe -&gt; Child Publish
    /// </summary>
    /// <seealso cref="Prism.Events.PubSubEvent{M2C.Business.Models.ProductModel}" />
    public class ReferenceControlEvent : PubSubEvent<ProductModel>
    {
    }
}