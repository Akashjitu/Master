﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="LoadingWindow.xaml.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Windows;

namespace M2C.Desktop.App.Views
{
    /// <summary>
    /// Interaction logic for LoadingWindow.xaml
    /// </summary>
    public partial class LoadingWindow : Window
    {
        /// <summary>
        /// The parent
        /// </summary>
        private readonly Window parent;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoadingWindow" /> class.
        /// </summary>
        public LoadingWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LoadingWindow" /> class.
        /// </summary>
        /// <param name="parent">The parent.</param>
        public LoadingWindow(Window parent)
        {
            InitializeComponent();
            parent.StateChanged += Parent_StateChanged;
            parent.SizeChanged += Parent_SizeChanged;
            this.Closed += LoadingWindow_Closed;
            this.parent = parent;
        }

        /// <summary>
        /// Handles the Closed event of the LoadingWindow control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void LoadingWindow_Closed(object sender, EventArgs e)
        {
            parent.StateChanged -= Parent_StateChanged;
            parent.SizeChanged -= Parent_SizeChanged;
        }

        /// <summary>
        /// Handles the SizeChanged event of the Parent control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="SizeChangedEventArgs" /> instance containing the event data.</param>
        private void Parent_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            CalculateLocation(sender as Window);
        }

        /// <summary>
        /// Handles the StateChanged event of the Parent control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void Parent_StateChanged(object sender, EventArgs e)
        {
            CalculateLocation(sender as Window);
        }

        /// <summary>
        /// Calculates the location.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void CalculateLocation(Window obj)
        {
            try
            {
                var state = obj.WindowState;
                var height = obj.Height;
                var width = obj.Width;
                var top = obj.Top;
                var left = obj.Left;
                var IsActive = obj.IsActive;
                this.Dispatcher.Invoke(() =>
                {
                    this.Topmost = IsActive;
                    if (state == WindowState.Minimized)
                    {
                        this.WindowState = state;
                    }
                    else
                    {
                        this.WindowState = WindowState.Normal;
                        this.Left = left + ((width / 2) - this.Width) + 20;
                        this.Top = top + ((height / 2));
                    }
                });
            }
            catch(Exception ex)
            {
                var data = ex.ToString();
            }
        }
    }
}