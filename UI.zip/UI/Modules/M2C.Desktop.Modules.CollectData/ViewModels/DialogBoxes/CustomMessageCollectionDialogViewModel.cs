﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-25-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CustomMessageCollectionDialogViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.ViewModels.DialogBoxes
{
    /// <summary>
    /// Provide Collection of Message to View
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    public class CustomMessageCollectionDialogViewModel : BindableBase, IDialogAware
    {
        /// <summary>
        /// The messages
        /// </summary>
        private List<string> _messages;
        /// <summary>
        /// The message label
        /// </summary>
        private string _messageLabel;
        /// <summary>
        /// The title
        /// </summary>
        private string _title = CollectionConstant.M2C;
        /// <summary>
        /// The is cancel visible
        /// </summary>
        private Visibility _isCancelVisible;

        /// <summary>
        /// get Set Message Label
        /// </summary>
        /// <value>The message label.</value>
        public string MessageLabel
        {
            get => _messageLabel;
            set => SetProperty(ref _messageLabel, value);
        }

        /// <summary>
        /// Gets or sets the is cancel visible.
        /// </summary>
        /// <value>The is cancel visible.</value>
        public Visibility IsCancelVisible
        {
            get => _isCancelVisible;
            set => SetProperty(ref _isCancelVisible, value);
        }
        /// <summary>
        /// Collection of message
        /// </summary>
        /// <value>The messages.</value>
        public List<string> Messages
        {
            get => _messages;
            set => SetProperty(ref _messages, value);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomMessageCollectionDialogViewModel" /> class.
        /// </summary>
        public CustomMessageCollectionDialogViewModel()
        {
            CloseDialogCommand = new DelegateCommand<string>(OnClose);
            IsCancelVisible = Visibility.Hidden;
        }

        /// <summary>
        /// Event of Close Dialog Box
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }

        /// <summary>
        /// Close Dialog box
        /// </summary>
        /// <param name="commandParam">The command parameter.</param>
        private void OnClose(string commandParam)
        {
            var result = (commandParam == CollectionConstant.Cancel)
                ? new DialogResult(ButtonResult.Cancel)
                : new DialogResult(ButtonResult.OK);
            RequestClose?.Invoke(result);
        }

        #region IDialogAware Function

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
        }

        /// <summary>
        /// Called when the dialog is opened.
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            if (parameters.TryGetValue(CollectionConstant.MessageLabel, out string messageLabel))
                MessageLabel = messageLabel;
            if (parameters.TryGetValue(CollectionConstant.MessageCollection, out List<string> messages))
            {
                Messages = messages;
                if(Messages.Count==0)
                {
                    Messages.Add("No Items found");
                }
            }
            else
            {
               
               
            }
            if (parameters.TryGetValue(CollectionConstant.Message, out string message))
                Messages = new List<string> { message };
            if (parameters.TryGetValue(CollectionConstant.Title, out string title))
                _title = title;
            if (parameters.TryGetValue(CollectionConstant.IsCancelVisible, out bool isCancelVisible))
                IsCancelVisible = isCancelVisible ? Visibility.Visible : Visibility.Hidden;
        }

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => _title;

        /// <summary>
        /// Occurs when [request close].
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        #endregion IDialogAware Function
    }
}