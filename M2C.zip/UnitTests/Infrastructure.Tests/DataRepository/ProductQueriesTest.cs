﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Range = DomainModels.IbCatalogModels.Range;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class ProductQueriesTest : TestBase
    {
        private IQueryable<Product> productList;
        private Mock<DbSet<Product>> productMock;

        private IQueryable<Brand> brandList;
        private Mock<DbSet<Brand>> brandMock;

        private IQueryable<DeviceType> deviceTypeList;
        private Mock<DbSet<DeviceType>> deviceTypeMock;

        private IQueryable<Range> rangeList;
        private Mock<DbSet<Range>> rangeeMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            ProductEntry productentryObj = new ProductEntry() { Id = 1, ProductId = 1 };
            List<ProductEntry> productentry = new List<ProductEntry>() { productentryObj };

            Product prodObj = new Product() { Id = 1, Brand = new Brand() { Id = 1 }, Range = new DomainModels.IbCatalogModels.Range() { Id = 1 }, ProductEntries = productentry, Identifier = "ID1", RangeId = 1, DeviceTypeId = 1, BrandId = 1 };
            List<Product> product = new List<Product>() { prodObj };
            productList = product.AsQueryable();
            productMock = MockRepo.Create<DbSet<Product>>();
            productMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(productList.Provider);
            productMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(productList.Expression);
            productMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(productList.ElementType);
            productMock.As<IQueryable<Product>>().Setup(m => m.GetEnumerator()).Returns(productList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.Products).Returns(productMock.Object);

            List<Brand> brand = new List<Brand>() { new Brand() { Id = 1 } };
            brandList = brand.AsQueryable();
            brandMock = MockRepo.Create<DbSet<Brand>>();
            brandMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(brandList.Provider);
            brandMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(brandList.Expression);
            brandMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(brandList.ElementType);
            brandMock.As<IQueryable<Brand>>().Setup(m => m.GetEnumerator()).Returns(brandList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.Brands).Returns(brandMock.Object);


            List<DeviceType> device = new List<DeviceType>() { new DeviceType() { Id = 1, ConfigType = "1" } };
            deviceTypeList = device.AsQueryable();
            deviceTypeMock = MockRepo.Create<DbSet<DeviceType>>();
            deviceTypeMock.As<IQueryable<DeviceType>>().Setup(m => m.Provider).Returns(deviceTypeList.Provider);
            deviceTypeMock.As<IQueryable<DeviceType>>().Setup(m => m.Expression).Returns(deviceTypeList.Expression);
            deviceTypeMock.As<IQueryable<DeviceType>>().Setup(m => m.ElementType).Returns(deviceTypeList.ElementType);
            deviceTypeMock.As<IQueryable<DeviceType>>().Setup(m => m.GetEnumerator()).Returns(deviceTypeList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.DeviceTypes).Returns(deviceTypeMock.Object);


            List<Range> range = new List<Range>() { new Range() { Id = 1 } };
            rangeList = range.AsQueryable();
            rangeeMock = MockRepo.Create<DbSet<Range>>();
            rangeeMock.As<IQueryable<Range>>().Setup(m => m.Provider).Returns(rangeList.Provider);
            rangeeMock.As<IQueryable<Range>>().Setup(m => m.Expression).Returns(rangeList.Expression);
            rangeeMock.As<IQueryable<Range>>().Setup(m => m.ElementType).Returns(rangeList.ElementType);
            rangeeMock.As<IQueryable<Range>>().Setup(m => m.GetEnumerator()).Returns(rangeList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.Ranges).Returns(rangeeMock.Object);



            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void ProductQueriesConstructorTest()
        {
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            product.Should().NotBeNull();
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void ProductQueriesSaveProductTest()
        {
            Product prodObject = new Product() { Id = 1, Identifier = "ID1", RangeId = 1, DeviceTypeId = 1, BrandId = 1 };

            List<Product> productLists = new List<Product>() { prodObject };
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            Action action = () => product.SaveProducts(null);
            action.Should().NotThrow();
            action = () => product.SaveProducts(productLists);
            action.Should().NotThrow();
            prodObject.Id = 0;
            prodObject.Identifier = "ID2";
            action = () => product.SaveProducts(productLists);
            action.Should().NotThrow();

            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void ProductQueriesLoadProductsTest()
        {
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            List<Product> productRes = product.LoadProducts();
            productRes.Should().HaveCount(1);
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void ProductQueriesGetProductsByDeviceIdAndRangeIdTest()
        {
            int rangeID = 1;
            int deviceId = 1;
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            List<Product> productRes = product.GetProductsByDeviceIdAndRangeId(rangeID, deviceId);
            productRes.Should().HaveCount(1);
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void ProductQueriesGetProductByIdsTest()
        {
            int brandId = 1;
            int rangeID = 1;
            int deviceId = 1;
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            List<Product> productRes = product.GetProductByIds(brandId, rangeID, deviceId);
            productRes.Should().HaveCount(1);
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void LoadProductsByProductTest()
        {
            Product products;

            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            products = null;
            List<Product> productRes = product.GetProductsByIdOrIdentifier(products);
            productRes.Should().BeNull();
            products = new Product() { Id = 1 };
            productRes = product.GetProductsByIdOrIdentifier(products);
            productRes.Should().HaveCount(1);
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void LoadProductsByIDTest()
        {
            string id = null;

            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            List<Product> productRes = product.GetProductsStartWithIdentifier(id);
            productRes.Should().BeEmpty();
            id = "ID1";
            productRes = product.GetProductsStartWithIdentifier(id);
            productRes.Should().HaveCount(1);
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void GetProductsByIdentifierTest()
        {
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            Product productRes = product.GetProductsByIdentifier("ID1");
            productRes.Should().NotBeNull();
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void GetProductsByIdentifierNegativeTest()
        {
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            Product productRes = product.GetProductsByIdentifier("ID2");
            productRes.Should().BeNull();

            productRes = product.GetProductsByIdentifier(null);
            productRes.Should().BeNull();
            ((IDisposable)product).Dispose();
        }


        [TestMethod]
        public void getProductsTest()
        {
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            List<Product> productRes = product.GetProducts("ID1");
            productRes.Should().HaveCount(1);

            productRes = product.GetProducts(null);
            productRes.Should().HaveCount(0);
            ((IDisposable)product).Dispose();
        }

        [TestMethod]
        public void GetProductsByCountTest()
        {
            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            List<Product> productRes = product.GetProductsByCount();
            productRes.Should().NotBeNull();
            ((IDisposable)product).Dispose();
        }


        [TestMethod]
        public void GetProductsStartWithIdentifierTest()
        {

            IProductQueries product = new ProductQueries(IDbContextFactoryMock.Object);
            List<Product> productRes = product.GetProductsStartWithIdentifier("1", "1");
            productRes.Should().NotBeNull();
            productRes = product.GetProductsStartWithIdentifier("1", "2");
            productRes.Should().NotBeNull();
            productRes = product.GetProductsStartWithIdentifier(null, "2");
            productRes.Should().NotBeNull();
            ((IDisposable)product).Dispose();

        }
    }
}