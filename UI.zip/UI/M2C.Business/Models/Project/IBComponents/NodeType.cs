﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="NodeType.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Text;

namespace M2C.Business.Models.Project.IBComponents
{
    /// <summary>
    /// Type of node
    /// </summary>
    public enum NodeType
    {
        /// <summary>
        /// The none
        /// </summary>
        NONE = 0,
        /// <summary>
        /// The installedbase
        /// </summary>
        INSTALLEDBASE,
        /// <summary>
        /// The factory
        /// </summary>
        FACTORY,
        /// <summary>
        /// The workshop
        /// </summary>
        WORKSHOP,
        /// <summary>
        /// The line
        /// </summary>
        LINE,
        /// <summary>
        /// The machine
        /// </summary>
        MACHINE,
        /// <summary>
        /// The PLC configuration
        /// </summary>
        PLC_CONFIG,
        /// <summary>
        /// The md configuration
        /// </summary>
        MD_CONFIG,
        /// <summary>
        /// The shmi configuration
        /// </summary>
        SHMI_CONFIG,
        /// <summary>
        /// The open configuration
        /// </summary>
        OPEN_CONFIG,

        /// <summary>
        /// The Technical Resource
        /// </summary>
        TECHNICALRESOURCE,
        /// <summary>
        /// The Maintenance Zone
        /// </summary>
        MAINTENANCEZONE,

        /// <summary>
        /// Stock
        /// </summary>
        STOCK,

        /// <summary>
        /// The competencies
        /// </summary>
        COMPETENCIES
    }
}
