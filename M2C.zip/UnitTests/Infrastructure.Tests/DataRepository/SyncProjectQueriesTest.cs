﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogModels;
using DomainModels.ProjectModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class SyncProjectQueriesTest : TestBase
    {
        private IQueryable<Project> projectList;
        private Mock<DbSet<Project>> projectMock;

        [TestInitialize]
        public void TestIniTialize()
        {


            List<Project> project = new List<Project>() { new Project() { ProjectID = 1, LastSyncDate = Convert.ToDateTime("2020-04-15 10:00:54.1355708"), ModifiedOn = Convert.ToDateTime("2020-04-15 10:00:54.1355708") } };
            projectList = project.AsQueryable();
            projectMock = MockRepo.Create<DbSet<Project>>();
            projectMock.As<IQueryable<Project>>().Setup(m => m.Provider).Returns(projectList.Provider);
            projectMock.As<IQueryable<Project>>().Setup(m => m.Expression).Returns(projectList.Expression);
            projectMock.As<IQueryable<Project>>().Setup(m => m.ElementType).Returns(projectList.ElementType);
            projectMock.As<IQueryable<Project>>().Setup(m => m.GetEnumerator()).Returns(projectList.GetEnumerator());
            IProjectDbContextMock.Setup(x => x.Projects).Returns(projectMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProjectDbContext>()).Returns(IProjectDbContextMock.Object);

        }

        [TestMethod]
        public void SyncProjectQueriesConstructorTest()
        {
            ISyncProjectQueries syncProjectObj = new SyncProjectQueries(IDbContextFactoryMock.Object);
            syncProjectObj.Should().NotBeNull();

        }
        [TestMethod]
        public void GetAllProjectsToSyncTest()
        {
            ISyncProjectQueries syncProject = new SyncProjectQueries(IDbContextFactoryMock.Object);
            List<Project> projects = syncProject.GetAllProjectsToSync();
            projects.Should().NotBeNull();
        }
        [TestMethod]
        public void UpdateLastSyncByTest()
        {
            ISyncProjectQueries syncProject = new SyncProjectQueries(IDbContextFactoryMock.Object);
            bool result = syncProject.UpdateLastSyncBy(1, "1");
            result.Should().BeTrue();
        }
    }
}
