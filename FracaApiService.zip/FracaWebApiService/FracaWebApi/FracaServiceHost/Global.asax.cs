﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Autofac.Integration.WebApi;
using System.Reflection;
using Fraca.Data.Models;
using Fraca.Service.Service;
using Fraca.Service.Manager;
using Fraca.Service.ServiceConsumer;
using Fraca.Service.DataBaseAccessObject.Loader;
using Fraca.Service.DataBaseAccessObject.Saver;
using Fraca.Service.Reporting;
using Autofac;
//using Swashbuckle.Application;
using System.Web.Http.Cors;
using Fraca.Service.Validator;

namespace FracaServiceHost
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            var config = GlobalConfiguration.Configuration;
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);


            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());


            var assemblyType = typeof(FracaInfo).GetTypeInfo();

            builder.RegisterAssemblyTypes(assemblyType.Assembly)
            .Where(t => t.Name.EndsWith("Service"))
            .AsImplementedInterfaces()
            .InstancePerRequest();


            //config.EnableSwagger(c => c.SingleApiVersion("v2", "Fraca Service Web"))
            //  .EnableSwaggerUi();


            config.EnableCors(new EnableCorsAttribute("*", "*", "*") {  SupportsCredentials = true  });
            config.EnableCors();

            builder.RegisterWebApiFilterProvider(config);
            builder.RegisterType<FracaService>().As<IFracaService>().InstancePerRequest();
            builder.RegisterType<FracaServiceManage>().As<IFracaServiceManage>().InstancePerRequest();
            builder.RegisterType<EmployeeServcie>().As<IEmployeeServcie>().InstancePerRequest();
            builder.RegisterType<SeviceDataSave>().As<ISeviceDataSave>().InstancePerRequest();
            builder.RegisterType<ServiceDataLoader>().As<IServiceDataLoader>().InstancePerRequest();
            builder.RegisterType<PdfReportMapper>().As<IPdfReportMapper>().InstancePerRequest();

            builder.RegisterType<UserValidator>().As<IUserValidator>().InstancePerRequest();
            
            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }
    }
}
