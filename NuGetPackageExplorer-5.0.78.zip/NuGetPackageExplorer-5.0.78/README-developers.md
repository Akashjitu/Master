How to change version number:
===

1. Change version in `version.json`.

How to publish on Chocolatey
===

Update: This is handled on VSTS Release Management


