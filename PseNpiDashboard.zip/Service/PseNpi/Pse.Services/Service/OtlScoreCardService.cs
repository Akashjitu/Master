﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pse.Data.Models;
using Pse.Services.Manager;

namespace Pse.Services.Service
{
    public class OtlScoreCardService : IOtlScoreCardService
    {
        IOtlScoreCardManager _manager;

       public OtlScoreCardService(IOtlScoreCardManager manager)
        {
            _manager = manager;
        }
        public OtlScoreCard AddOtlScoreCard(OtlScoreCard otlScoreCard)
        {
            return _manager.AddOtlScoreCard(otlScoreCard);
        }

        public List<OtlScoreCard> LoadAllOtlScoreCards()
        {
            return _manager.LoadAllOtlScoreCards();
        }

        public List<OtlScoreCard> LoadLatestOtlScoreCard(string keycode)
        {
            return _manager.LoadLatestOtlScoreCard(keycode);
        }

        public List<OtlScoreCard> LoadOtlScoreCardByBaseLineDate(DateTime baselineDate)
        {
            return _manager.LoadOtlScoreCardByBaseLineDate(baselineDate);
        }

        public List<OtlScoreCard> LoadOtlScoreCardById(int Id)
        {
            return _manager.LoadOtlScoreCardById(Id);
        }

        public List<OtlScoreCard> LoadOtlScoreCardByKeyCode(string keycode)
        {
            return _manager.LoadOtlScoreCardByKeyCode(keycode);
        }

        public List<OtlScoreCard> LoadScoreCardByCreationDate(DateTime creationDate)
        {
            return _manager.LoadScoreCardByCreationDate(creationDate);
        }

        public OtlScoreCard UpdateOtlScoreCard(OtlScoreCard otlScoreCard)
        {
            return _manager.UpdateOtlScoreCard(otlScoreCard);
        }
    }
}
