﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Xml;

namespace User.Digital.Sign
{
    public static class EncryptionDigitalSignature
    {
        #region ReadOnly Fields

        private static readonly string SignatureID = "idPackageSignature";

        private static readonly string RtOfficeDocument =
           "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";

        private static readonly string ManifestHashAlgorithm = "http://www.w3.org/2000/09/xmldsig#sha1";
        private static readonly string OfficeObjectID = "idOfficeObject";

        private static readonly string xml =
            "<SignatureProperties xmlns=\"http://www.w3.org/2000/09/xmldsig#\">\n  <SignatureProperty Id=\"idOfficeV1Details\" Target=\"#{0}\">\n    <SignatureInfoV1 xmlns=\"http://schemas.microsoft.com/office/2006/digsig\">\n      <ManifestHashAlgorithm>{1}</ManifestHashAlgorithm>\n    </SignatureInfoV1>\n  </SignatureProperty>\n</SignatureProperties>";

        private static string _certificateTitle = string.Empty;
        private static string _certificateMessage = string.Empty;

        #endregion ReadOnly Fields

        public static void SignOfficeFile(string filepath, string certificateTitle = "", string certificateMessage = "")
        {
            _certificateTitle = certificateTitle;
            _certificateMessage = certificateMessage;
            try
            {
                var ms = new MemoryStream();
                using (var source = new FileStream(filepath, FileMode.Open, FileAccess.Read))
                {
                    source.Seek(0, SeekOrigin.Begin);
                    source.CopyTo(ms);
                }

                SignOfficeFile(ms, _certificateTitle, _certificateMessage);

                // write the resulting file top the file system
                using (FileStream fs = new FileStream(filepath, FileMode.Create))
                {
                    ms.Seek(0, SeekOrigin.Begin);
                    ms.CopyTo(fs);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static X509Certificate2 GetCertificate()
        {
            var certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            certStore.Open(OpenFlags.ReadWrite);
            var currentUserCertificate = certStore.Certificates.Find(X509FindType.FindByIssuerName, Environment.UserName, true);
            certStore.Close();
            return currentUserCertificate.Count == 0 ? null : currentUserCertificate[0];

           
            //var certData = currentUserCertificate.Export(X509ContentType.Pfx, "MyPassword");
            //File.WriteAllBytes(@"C:\MyCert.pfx", certData);

            //var certs = X509Certificate2UI.SelectFromCollection(currentUserCertificate, _certificateTitle, _certificateMessage,
            //    X509SelectionFlag.SingleSelection);

            //return certs.Count > 0 ? certs[0] : null;

            //////////
            //X509Certificate2 cert = new X509Certificate2("a.pfx", "password", X509KeyStorageFlags.PersistKeySet);
            //X509Store store = new X509Store(StoreName.My);
            //store.Open(OpenFlags.ReadWrite);
            //store.Add(cert);

            ////or

            //X509Certificate2 cert = new X509Certificate2("a.pfx", "password", X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet);
            //X509Store store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            //store.Open(OpenFlags.ReadWrite);
            //store.Add(xCertificate);
        }

        public static void SignOfficeFile(MemoryStream outputStream, string certificateTitle = "",
            string certificateMessage = "")
        {
            _certificateTitle = certificateTitle;
            _certificateMessage = certificateMessage;
            var partsToSign = new List<Uri>();
            var relationshipsToSign = new List<PackageRelationshipSelector>();
            try
            {
                var certificate = GetCertificate();

                /* var package = WordprocessingDocument.Open(outputStream, true).Package*/
                using (var package = Package.Open(outputStream, FileMode.Open, FileAccess.ReadWrite))
                {
                    foreach (var relationship in package.GetRelationshipsByType(RtOfficeDocument))
                        AddSignableItems(relationship, partsToSign, relationshipsToSign);

                    var packageDigitalSignatureManager = new PackageDigitalSignatureManager(package)
                    {
                        CertificateOption = CertificateEmbeddingOption.InSignaturePart
                    };

                    var signatureId = SignatureID;
                    var manifestHashAlgorithm = ManifestHashAlgorithm;
                    var officeObject = CreateOfficeObject(signatureId, manifestHashAlgorithm);
                    var officeObjectReference = new Reference("#" + OfficeObjectID);
                    packageDigitalSignatureManager.Sign(partsToSign, certificate, relationshipsToSign, signatureId,
                        new[] { officeObject }, new[] { officeObjectReference });
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void AddSignableItems(PackageRelationship relationship, ICollection<Uri> partsToSign, ICollection<PackageRelationshipSelector> relationshipsToSign)
        {
            var selector =
                new PackageRelationshipSelector(relationship.SourceUri, PackageRelationshipSelectorType.Id, relationship.Id);
            relationshipsToSign.Add(selector);

            if (relationship.TargetMode != TargetMode.Internal) return;

            var packagePart = relationship.Package.GetPart(PackUriHelper.ResolvePartUri(relationship.SourceUri, relationship.TargetUri));

            if (partsToSign.Contains(packagePart.Uri)) return;
            partsToSign.Add(packagePart.Uri);

            foreach (var childRelationship in packagePart.GetRelationships())
                AddSignableItems(childRelationship, partsToSign, relationshipsToSign);
        }

        private static DataObject CreateOfficeObject(string signatureId, string manifestHashAlgorithm)
        {
            var document = new XmlDocument();
            document.LoadXml(string.Format(xml, signatureId, manifestHashAlgorithm));

            var officeObject = new DataObject();
            // do not change the order of the following two lines
            officeObject.LoadXml(document.DocumentElement); // resets ID
            officeObject.Id = OfficeObjectID; // required ID, do not change
            return officeObject;
        }
    }
}