﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProjectLogic.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.Project;
using System;
using System.Collections.Generic;
using System.Text;

namespace M2C.Business.Contracts
{
    /// <summary>
    /// Interface IProjectLogic
    /// </summary>
    public interface IProjectLogic
    {
        /// <summary>
        /// Saves the specified project model.
        /// </summary>
        /// <param name="projectModel">The project model.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool Save(ref ProjectContextModel projectModel);
        /// <summary>
        /// Gets the project.
        /// </summary>
        /// <param name="ProjectID">The project identifier.</param>
        /// <returns>ProjectContextModel.</returns>
        ProjectContextModel GetProject(int ProjectID);
        /// <summary>
        /// Gets all project ids.
        /// </summary>
        /// <returns>List&lt;System.Int32&gt;.</returns>
        List<ProjectContextModel> GetAllProjects();

        /// <summary>
        /// Reads the project.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <returns>ProjectContextModel.</returns>
        ProjectContextModel ReadProject(string filePath);

        /// <summary>
        /// Get Projects With Customers
        /// </summary>
        /// <returns>List&lt;ProjectContextModel&gt;.</returns>
        List<ProjectContextModel> GetProjectsWithCustomers();


        /// <summary>
        /// Gets or sets the update inventory callback.
        /// </summary>
        /// <value>
        /// The update inventory callback.
        /// </value>
        Predicate<IReadOnlyCollection<string>> UpdateInventoryCallback { get; set; }


        /// <summary>
        /// Checks the project is updated.
        /// </summary>
        /// <param name="projectModel">The project model.</param>
        /// <returns></returns>
        bool CheckProjectIsUpdated(ProjectContextModel projectModel);

        /// <summary>
        /// Gets the synchronize history latest version.
        /// </summary>
        /// <returns></returns>
        int getSyncHistoryLatestVersion();
    }
}
