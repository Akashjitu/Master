﻿using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace M2C.Business.Mappers
{
    [TestClass]
    public class SubRangeModelMapperTest
    {
        private SubRangeModelMapper subRangeModelMapper;

        [TestInitialize]
        public void Setup()
        {
            subRangeModelMapper = new SubRangeModelMapper();
        }

        [TestMethod]
        public void ShouldReturnBrandModel()
        {
            var subRanges = subRangeModelMapper.Map(MockProvider.GetSubRange());
            Assert.IsNotNull(subRanges);
            Assert.IsTrue(subRanges.Count > 0);
        }
    }
}