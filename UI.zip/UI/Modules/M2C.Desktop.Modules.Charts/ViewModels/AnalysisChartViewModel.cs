﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="AnalysisChartViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models.CommonChartParameters;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Modules.Charts.ElementProvides;
using M2C.Desktop.Modules.Charts.Events;
using M2C.Desktop.Modules.Charts.Models;
using Prism.Events;
using Prism.Mvvm;

namespace M2C.Desktop.Modules.Charts.ViewModels
{
    /// <summary>
    /// Class AnalysisChartViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class AnalysisChartViewModel : BindableBase
    {
        /// <summary>
        /// The header label
        /// </summary>
        private string _headerLabel;

        /// <summary>
        /// The x axes label
        /// </summary>
        private string _xAxesLabel;

        /// <summary>
        /// The obsolescence charts height
        /// </summary>
        private int _obsolescenceChartsHeight;

        /// <summary>
        /// The mapping chart height
        /// </summary>
        private int _mappingChartHeight;

        /// <summary>
        /// The y axes label
        /// </summary>
        private string _yAxesLabel;

        private readonly IBarElementProvider _elementProvider;
        private ChartBarElements _chartBarElements;
        private int _configMappingChartHeight;

        /// <summary>
        /// Provide Collection of Element
        /// </summary>
        public ChartBarElements ChartBarElements { get => _chartBarElements; set => SetProperty(ref _chartBarElements, value); }

        /// <summary>
        /// Gets or sets the x axes label.
        /// </summary>
        /// <value>The x axes label.</value>
        public string XAxesLabel { get => _xAxesLabel; set => SetProperty(ref _xAxesLabel, value); }

        /// <summary>
        /// Gets or sets the y axes label.
        /// </summary>
        /// <value>The y axes label.</value>
        public string YAxesLabel { get => _yAxesLabel; set => SetProperty(ref _yAxesLabel, value); }

        /// <summary>
        /// Gets or sets the header label.
        /// </summary>
        /// <value>The header label.</value>
        public string HeaderLabel { get => _headerLabel; set => SetProperty(ref _headerLabel, value); }

        /// <summary>
        /// Gets or sets the height of the mapping chart.
        /// </summary>
        /// <value>The height of the mapping chart.</value>
        public int MappingChartHeight { get => _mappingChartHeight; set => SetProperty(ref _mappingChartHeight, value); }

        /// <summary>
        /// Gets or sets the height of the Config Mapping Chart.
        /// </summary>
        /// <value>The height of the mapping chart.</value>
        public int ConfigMappingChartHeight { get => _configMappingChartHeight; set => SetProperty(ref _configMappingChartHeight, value); }

        /// <summary>
        /// Gets or sets the height of the obsolescence charts.
        /// </summary>
        /// <value>The height of the obsolescence charts.</value>
        public int ObsolescenceChartsHeight { get => _obsolescenceChartsHeight; set => SetProperty(ref _obsolescenceChartsHeight, value); }

        /// <summary>
        /// Initializes a new instance of the <see cref="AnalysisChartViewModel" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="elementProvider"></param>
        public AnalysisChartViewModel(IEventAggregator eventAggregator, IBarElementProvider elementProvider)
        {
            _elementProvider = elementProvider;
            MappingChartHeight = 900;
            ConfigMappingChartHeight = 0;
            ChartBarElements = new ChartBarElements();
            eventAggregator.GetEvent<ChartParameterEvent>().Subscribe(OnShowChartByChartParameter);
            HeaderLabel = "Perimeter: Installed base";
            YAxesLabel = "Quantity";
        }

        /// <summary>
        /// Called when [show chart by chart parameter].
        /// </summary>
        /// <param name="chartParameter">The chart parameter.</param>
        private void OnShowChartByChartParameter(ChartParameter chartParameter)
        {
            YAxesLabel = "Quantity";
            MappingChartHeight = 900;
            ConfigMappingChartHeight = 0;
            ObsolescenceChartsHeight = 0;
            switch (chartParameter.SelectInventoryType)
            {
                case "Installed Base":
                    CreateInstalledBasedElements(chartParameter);
                    break;

                case "Technical Resources":
                    CreateTechnicalResourceElement(chartParameter);
                    break;
            }

            HeaderLabel = $"{chartParameter.SelectChartMapping} by {chartParameter.SelectInventoryType}";
            if (chartParameter.SelectedParameterNode != null)
                HeaderLabel = $"{chartParameter.SelectChartMapping} {chartParameter.SelectInventoryType} by {chartParameter.SelectedParameterNode.NodeType.ToString()}";
        }

        /// <summary>
        /// Create Technical Resource Element
        /// </summary>
        /// <param name="chartParameter"></param>
        private void CreateTechnicalResourceElement(ChartParameter chartParameter)
        {
            MappingChartHeight = 0;
            ObsolescenceChartsHeight = 0;
            ConfigMappingChartHeight = 0;
            switch (chartParameter.SelectChartMapping)
            {
                case "Mapping":
                    ChartBarElements = _elementProvider.GetMappingBarElements(chartParameter, NodeType.STOCK);
                    MappingChartHeight = 900;
                    XAxesLabel = chartParameter.SelectedParameterNode.NodeType.ToString();
                    break;

                case "Obsolescence":
                    ChartBarElements = _elementProvider.GetObsolescenceChartElements(chartParameter, NodeType.STOCK);
                    XAxesLabel = "Stock";
                    //YAxesLabel = "No. of Reference";
                    ObsolescenceChartsHeight = 900;

                    break;

                case "Obsolescence Mapping":
                    ChartBarElements = _elementProvider.GetbsolescenceMapping(chartParameter, NodeType.STOCK);
                    ObsolescenceChartsHeight = 900;
                    XAxesLabel = chartParameter.SelectedParameterNode.NodeType.ToString();
                    break;

                case "Configuration  Mapping":
                    ChartBarElements = _elementProvider.GetConfigurationMappingElements(chartParameter, NodeType.STOCK);
                    ConfigMappingChartHeight = 900;
                    XAxesLabel = chartParameter.SelectedParameterNode.NodeType == NodeType.OPEN_CONFIG
                        ? "STOCK"
                        : $"{chartParameter.SelectedParameterNode.NodeType}";
                    break;
            }
        }

        /// <summary>
        /// Create Installed Based Elements
        /// </summary>
        /// <param name="chartParameter"></param>
        private void CreateInstalledBasedElements(ChartParameter chartParameter)
        {
            MappingChartHeight = 0;
            ObsolescenceChartsHeight = 0;
            ConfigMappingChartHeight = 0;
            switch (chartParameter.SelectChartMapping)
            {
                case "Mapping":
                    ChartBarElements = _elementProvider.GetMappingBarElements(chartParameter);
                    MappingChartHeight = 900;
                    XAxesLabel = chartParameter.SelectedParameterNode.NodeType == NodeType.OPEN_CONFIG
                        ? "CONFIGURATION"
                        : $"{chartParameter.SelectedParameterNode.NodeType}";
                    break;

                case "Obsolescence":
                    ChartBarElements = _elementProvider.GetObsolescenceChartElements(chartParameter);
                    XAxesLabel = "Configuration";
                    //YAxesLabel = "No. of Reference";
                    ObsolescenceChartsHeight = 900;
                    break;

                case "Machine Criticality":
                    ChartBarElements = _elementProvider.GetCriticalityBarElements(chartParameter);
                    ChartBarElements.ChartElements = ChartBarElements.CriticalitiesChartElements;
                    YAxesLabel = "Process Criticality";
                    XAxesLabel = "Machine (4 = Very Critical, 3 = Critical, 2 = Somewhat Critical, 1 = Not Critical)";
                    MappingChartHeight = 900;
                    break;

                case "Obsolescence Mapping":
                    ChartBarElements = _elementProvider.GetbsolescenceMapping(chartParameter);
                    ObsolescenceChartsHeight = 900;
                    XAxesLabel = chartParameter.SelectedParameterNode.NodeType == NodeType.OPEN_CONFIG
                        ? "CONFIGURATION"
                        : $"{chartParameter.SelectedParameterNode.NodeType}";
                    break;

                case "Configuration  Mapping":
                    ChartBarElements = _elementProvider.GetConfigurationMappingElements(chartParameter);
                    ConfigMappingChartHeight = 900;
                    XAxesLabel = chartParameter.SelectedParameterNode.NodeType == NodeType.OPEN_CONFIG
                        ? "CONFIGURATION"
                        : $"{chartParameter.SelectedParameterNode.NodeType}";
                    break;
            }
        }
    }
}