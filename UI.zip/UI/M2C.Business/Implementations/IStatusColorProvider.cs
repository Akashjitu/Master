﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IStatusColorProvider.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Business.Implementations
{
    /// <summary>
    /// Interface IStatusColorProvider
    /// </summary>
    public interface IStatusColorProvider
    {

        /// <summary>
        /// Get Color based year
        /// </summary>
        /// <param name="fromDate">For Which Year you want to color</param>
        /// <param name="dosa">year of dosa</param>
        /// <param name="dos">year of dos</param>
        /// <param name="eos">year of eos</param>
        /// <returns>Name of the color</returns>
        string GetYearColor(int fromDate, int? dosa, int? dos, int? eos);
    }
}