﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="TRSideBarTree.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Modules.CollectData.Events;
using M2C.Desktop.Modules.CollectData.ViewModels;
using Prism.Events;
using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using M2C.Desktop.Core.GlobalEvents;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for TRSideBarTreeview
    /// </summary>
    public partial class TRSideBarTree : UserControl
    {
        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator eventAggregator;

        /// <summary>
        /// Initializes a new instance of the <see cref="TRSideBarTree" /> class.
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        public TRSideBarTree(IEventAggregator eventAggregator)
        {
            InitializeComponent();
            this.eventAggregator = eventAggregator;
            eventAggregator.GetEvent<ProjectResetEvent>().Subscribe(ResetTree, ThreadOption.UIThread);
            this.eventAggregator.GetEvent<CollectDataMainTabSelectedEvent>().Subscribe(mainTabChangeEvent, ThreadOption.UIThread, false, x => x == 1);
        }

        /// <summary>
        /// Reset Tree
        /// </summary>
        /// <param name="obj">if set to <c>true</c> [object].</param>
        private void ResetTree(bool obj)
        {
            TR_TreeView.ItemsSource = null;
            DataContext = null;
        }
        /// <summary>
        /// Handles the Opened event of the ContextMenu control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.RoutedEventArgs" /> instance containing the event data.</param>
        private void ContextMenu_Opened(object sender, System.Windows.RoutedEventArgs e)
        {
            ContextMenu menu = sender as ContextMenu;

            if (menu != null) menu.DataContext = this.DataContext;
        }

        /// <summary>
        /// Handles the PreviewMouseRightButtonDown event of the MainTreeView control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Input.MouseButtonEventArgs" /> instance containing the event data.</param>
        private void MainTreeView_PreviewMouseRightButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                TreeViewItem treeViewItem = VisualUpwardSearch(e.OriginalSource as DependencyObject);

                if (treeViewItem != null)
                {
                    treeViewItem.Focus();
                    e.Handled = true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Visuals the upward search.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>TreeViewItem.</returns>
        private static TreeViewItem VisualUpwardSearch(DependencyObject source)
        {
            while (source != null && !(source is TreeViewItem))
                source = VisualTreeHelper.GetParent(source);

            return source as TreeViewItem;
        }

        /// <summary>
        /// Handles the SubmenuOpened event of the MenuItem control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void MenuItem_SubmenuOpened(object sender, RoutedEventArgs e)
        {
            TRTreeRest();
        }

        /// <summary>
        /// Mains the tab change event.
        /// </summary>
        /// <param name="index">The index.</param>
        private void mainTabChangeEvent(int index)
        {
            TRTreeRest();
            var viewModel = (TRSideBarTreeViewModel)DataContext;
            viewModel?.RootNodeCommand.Execute();
        }

        /// <summary>
        /// Trs the tree rest.
        /// </summary>
        private void TRTreeRest()
        {
            try
            {
                TreeViewItem tvi = TR_TreeView.ItemContainerGenerator.ContainerFromIndex(0) as TreeViewItem;

                if (tvi != null)
                {
                    tvi.IsSelected = true;
                    tvi.IsSelected = false;
                }
            }
            catch (NullReferenceException ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// Handles the IsVisibleChanged event of the TextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private void TextBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox != null && textBox.IsVisible)
            {
                textBox.Focus();
                textBox.CaretIndex = textBox.Text.Length;
                textBox.CaptureMouse();
                textBox.IsMouseCapturedChanged += TextBox_IsMouseCapturedChanged;
            }
        }

        /// <summary>
        /// Handles the IsMouseCapturedChanged event of the TextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private void TextBox_IsMouseCapturedChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            Point p = Mouse.GetPosition(textBox);
            Debug.WriteLine($"TextBox_IsMouseCapturedChanged : {p.X} {p.Y}");
            if (textBox != null && (textBox.IsVisible && !textBox.IsMouseCaptured && (p.Y < 0 || p.Y > 20)))
            {
                var viewModel = (TRSideBarTreeViewModel)DataContext;
                viewModel?.NodeRenameCommand.Execute();
                textBox.IsMouseCapturedChanged -= TextBox_IsMouseCapturedChanged;
                textBox.ReleaseMouseCapture();
                TRTreeRest();
            }
            else
            {
                textBox?.CaptureMouse();
            }
        }
    }
}