import { Component, OnInit } from '@angular/core';
import { AngularEditorConfig } from '@kolkov/angular-editor';

@Component({
  selector: 'app-program-overview',
  templateUrl: './program-overview.component.html',
  styleUrls: ['./program-overview.component.css']
})
export class ProgramOverviewComponent implements OnInit {
  programScopeValue:any;
  performanceValue: any;
  notesValues:any;
  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '35rem',
    minHeight: '5rem',
    placeholder: 'Enter text here...',
    translate: 'no',
    uploadUrl: 'v1/images', // if needed,
    fonts:[  { class: 'arial', name: 'Arial' },
    { class: 'times-new-roman', name: 'Times New Roman' },
    {name : "Comic Sans MS", class: "comic-sans-ms"},
    {name : "Courier New", class: "courier-new"},
    {name : "Georgia", class: "georgia"},
    {name : "Verdana", class: "verdana"},
    {name : "Impact", class: "impact"},
  ],



    // customClasses: [ // optional
    //   {
    //     name: "quote",
    //     class: "quote",
    //   },
    //   {
    //     name: 'redText',
    //     class: 'redText'
    //   },
    //   {
    //     name: "titleText",
    //     class: "titleText",
    //     tag: "h1",
    //   },
    // ],
    showToolbar:true,
    enableToolbar:true
  };


  constructor() { }

  ngOnInit() {
  }

}
