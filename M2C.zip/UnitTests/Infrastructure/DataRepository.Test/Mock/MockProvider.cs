﻿using DomainModels.Common;
using DomainModels.IbCatalogModels;
using System;
using System.Collections.Generic;

namespace M2C.Business.Test.Mock
{
    public class MockProvider
    {
        public static List<Position> GetPositions()
        {
            return new List<Position>
            {
                new Position {Id = 1, Name = "Project Manager"},
                new Position {Id = 2, Name = "Project Engineer"},
                new Position {Id = 3, Name = "Commercial Manager"}
            };
        }

        public static List<Country> GetCountries()
        {
            return new List<Country>
            {
                new Country {Id = 3, Name = "United Kingdom", Code = "GB", Region = "WESTERN EUROPE"},
                new Country {Id = 1, Name = "United States", Code = "US", Region = "NORTHERN AMERICA"},
                new Country {Id = 2, Name = "France", Code = "FR", Region = "WESTERN EUROPE"},
                new Country {Id = 4, Name = "India", Code = "IN", Region = "ASIA (EX. NEAR EAST)"},

                new Country {Id = 211, Name = "Afghanistan", Code = "AF", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 68, Name = "Albania", Code = "AL", Region = "EASTERN EUROPE"},
                new Country {Id = 210, Name = "Algeria", Code = "DZ", Region = "NORTHERN AFRICA"},
                new Country {Id = 92, Name = "American Samoa", Code = "AS", Region = "OCEANIA"},
                new Country {Id = 5, Name = "Andorra", Code = "AD", Region = "WESTERN EUROPE"},
                new Country {Id = 6, Name = "Angola", Code = "AO", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 7, Name = "Anguilla", Code = "AI", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 8, Name = "Antigua & Barbuda", Code = "AG", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 9, Name = "Argentina", Code = "AR", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 10, Name = "Armenia", Code = "AM", Region = "C.W. OF IND. STATES"},
                new Country {Id = 11, Name = "Aruba", Code = "AW", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 12, Name = "Australia", Code = "AU", Region = "OCEANIA"},
                new Country {Id = 13, Name = "Austria", Code = "AT", Region = "WESTERN EUROPE"},
                new Country {Id = 14, Name = "Azerbaijan", Code = "AZ", Region = "C.W. OF IND. STATES"},
                new Country {Id = 15, Name = "Bahamas", Code = "BS", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 16, Name = "Bahrain", Code = "BH", Region = "NEAR EAST"},
                new Country {Id = 17, Name = "Bangladesh", Code = "BD", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 18, Name = "Barbados", Code = "BB", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 19, Name = "Belarus", Code = "BY", Region = "C.W. OF IND. STATES"},
                new Country {Id = 20, Name = "Belgium", Code = "BE", Region = "WESTERN EUROPE"},
                new Country {Id = 21, Name = "Belize", Code = "BZ", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 22, Name = "Benin", Code = "BJ", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 23, Name = "Bermuda", Code = "BM", Region = "NORTHERN AMERICA"},
                new Country {Id = 24, Name = "Bhutan", Code = "BT", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 25, Name = "Bolivia", Code = "BO", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 26, Name = "Bosnia & Herzegovina", Code = "BA", Region = "EASTERN EUROPE"},
                new Country {Id = 27, Name = "Botswana", Code = "BW", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 28, Name = "Brazil", Code = "BR", Region = "LATIN AMER. & CARIB"},
                new Country
                {
                    Id = 29, Name = "British Indian Ocean Territory", Code = "IO", Region = "LATIN AMER. & CARIB"
                },
                new Country {Id = 30, Name = "Brunei Darussalam", Code = "BN", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 31, Name = "Bulgaria", Code = "BG", Region = "EASTERN EUROPE"},
                new Country {Id = 32, Name = "Burkina Faso", Code = "BF", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 33, Name = "Burundi", Code = "BI", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 34, Name = "Cambodia", Code = "KH", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 35, Name = "Cameroon", Code = "CM", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 36, Name = "Canada", Code = "CA", Region = "NORTHERN AMERICA"},
                new Country {Id = 37, Name = "Cape Verde", Code = "CV", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 38, Name = "Cayman Islands", Code = "KY", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 39, Name = "Central African Republic", Code = "CF", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 40, Name = "Chad", Code = "TD", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 41, Name = "Chile", Code = "CL", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 42, Name = "China", Code = "CN", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 43, Name = "Colombia", Code = "CO", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 44, Name = "Comoros", Code = "KM", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 45, Name = "Congo Dem. Rep.", Code = "CG", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 46, Name = "Congo Repub.", Code = "CD", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 47, Name = "Cook Islands", Code = "CK", Region = "OCEANIA"},
                new Country {Id = 48, Name = "Costa Rica", Code = "CR", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 49, Name = "Cote d'Ivoire", Code = "CI", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 50, Name = "Croatia", Code = "HR", Region = "EASTERN EUROPE"},
                new Country {Id = 51, Name = "Cuba", Code = "CU", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 52, Name = "Cyprus", Code = "CY", Region = "NEAR EAST"},
                new Country {Id = 53, Name = "Czech Republic", Code = "CZ", Region = "EASTERN EUROPE"},
                new Country {Id = 54, Name = "Denmark", Code = "DK", Region = "WESTERN EUROPE"},
                new Country {Id = 55, Name = "Djibouti", Code = "DJ", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 56, Name = "Dominica", Code = "DM", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 57, Name = "Dominican Republic", Code = "DO", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 58, Name = "Ecuador", Code = "EC", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 59, Name = "Egypt", Code = "EG", Region = "NORTHERN AFRICA"},
                new Country {Id = 60, Name = "El Salvador", Code = "SV", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 61, Name = "Equatorial Guinea", Code = "GQ", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 62, Name = "Eritrea", Code = "ER", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 63, Name = "Estonia", Code = "EE", Region = "BALTICS"},
                new Country {Id = 64, Name = "Ethiopia", Code = "ET", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 65, Name = "Faroe Islands", Code = "FO", Region = "WESTERN EUROPE"},
                new Country {Id = 66, Name = "Fiji", Code = "FJ", Region = "OCEANIA"},
                new Country {Id = 67, Name = "Finland", Code = "FI", Region = "WESTERN EUROPE"},

                new Country {Id = 69, Name = "French Guiana", Code = "GF", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 70, Name = "French Polynesia", Code = "PF", Region = "OCEANIA"},
                new Country {Id = 71, Name = "Gabon", Code = "GA", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 72, Name = "Gambia", Code = "GM", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 73, Name = "Georgia", Code = "GE", Region = "C.W. OF IND. STATES"},
                new Country {Id = 74, Name = "Germany", Code = "DE", Region = "WESTERN EUROPE"},
                new Country {Id = 75, Name = "Ghana", Code = "GH", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 76, Name = "Gibraltar", Code = "GI", Region = "WESTERN EUROPE"},
                new Country {Id = 77, Name = "Greece", Code = "GR", Region = "WESTERN EUROPE"},
                new Country {Id = 78, Name = "Greenland", Code = "GL", Region = "NORTHERN AMERICA"},
                new Country {Id = 79, Name = "Grenada", Code = "GD", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 80, Name = "Guadeloupe", Code = "GP", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 81, Name = "Guam", Code = "GU", Region = "OCEANIA"},
                new Country {Id = 82, Name = "Guatemala", Code = "GT", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 83, Name = "Guernsey", Code = "GG", Region = "WESTERN EUROPE"},
                new Country {Id = 84, Name = "Guinea", Code = "GN", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 85, Name = "Guinea-Bissau", Code = "GW", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 86, Name = "Guyana", Code = "GY", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 87, Name = "Haiti", Code = "HT", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 88, Name = "Honduras", Code = "HN", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 89, Name = "Hong Kong", Code = "HK", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 90, Name = "Hungary", Code = "HU", Region = "EASTERN EUROPE"},
                new Country {Id = 91, Name = "Iceland", Code = "IS", Region = "WESTERN EUROPE"},

                new Country {Id = 93, Name = "Indonesia", Code = "ID", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 94, Name = "Iran", Code = "IR", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 95, Name = "Iraq", Code = "IQ", Region = "NEAR EAST"},
                new Country {Id = 96, Name = "Ireland", Code = "IE", Region = "WESTERN EUROPE"},
                new Country {Id = 97, Name = "Isle of Man", Code = "IM", Region = "WESTERN EUROPE"},
                new Country {Id = 98, Name = "Israel", Code = "IL", Region = "NEAR EAST"},
                new Country {Id = 99, Name = "Italy", Code = "IT", Region = "WESTERN EUROPE"},
                new Country {Id = 100, Name = "Jamaica", Code = "JM", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 101, Name = "Japan", Code = "JP", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 102, Name = "Jersey", Code = "JE", Region = "WESTERN EUROPE"},
                new Country {Id = 103, Name = "Jordan", Code = "JO", Region = "NEAR EAST"},
                new Country {Id = 104, Name = "Kazakhstan", Code = "KZ", Region = "C.W. OF IND. STATES"},
                new Country {Id = 105, Name = "Kenya", Code = "KE", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 106, Name = "Kiribati", Code = "KI", Region = "OCEANIA"},
                new Country {Id = 107, Name = "Korea North", Code = "KP", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 108, Name = "Korea  South", Code = "KR", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 109, Name = "Kuwait", Code = "KW", Region = "NEAR EAST"},
                new Country {Id = 110, Name = "Kyrgyzstan", Code = "KG", Region = "C.W. OF IND. STATES"},
                new Country {Id = 111, Name = "Laos", Code = "LA", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 112, Name = "Latvia", Code = "LV", Region = "BALTICS"},
                new Country {Id = 113, Name = "Lebanon", Code = "LB", Region = "NEAR EAST"},
                new Country {Id = 114, Name = "Lesotho", Code = "LS", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 115, Name = "Liberia", Code = "LR", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 116, Name = "Libya", Code = "LY", Region = "NORTHERN AFRICA"},
                new Country {Id = 117, Name = "Liechtenstein ", Code = "LI", Region = "WESTERN EUROPE"},
                new Country {Id = 118, Name = "Lithuania", Code = "LT", Region = "BALTICS"},
                new Country {Id = 119, Name = "Luxembourg", Code = "LU", Region = "WESTERN EUROPE"},
                new Country {Id = 120, Name = "Macau", Code = "MO", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 121, Name = "Macedonia", Code = "MK", Region = "EASTERN EUROPE"},
                new Country {Id = 122, Name = "Madagascar", Code = "MG", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 123, Name = "Malawi", Code = "MW", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 124, Name = "Malaysia", Code = "MY", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 125, Name = "Maldives", Code = "MV", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 126, Name = "Mali", Code = "ML", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 127, Name = "Malta", Code = "MT", Region = "WESTERN EUROPE"},
                new Country {Id = 128, Name = "Marshall Islands", Code = "MH", Region = "OCEANIA"},
                new Country {Id = 129, Name = "Martinique", Code = "MQ", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 130, Name = "Mauritania", Code = "MR", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 131, Name = "Mauritius", Code = "MU", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 132, Name = "Mayotte", Code = "YT", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 133, Name = "Mexico", Code = "MX", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 134, Name = "Micronesia Fed. St.", Code = "FM", Region = "OCEANIA"},
                new Country {Id = 135, Name = "Moldova", Code = "MD", Region = "C.W. OF IND. STATES"},
                new Country {Id = 136, Name = "Monaco", Code = "MC", Region = "WESTERN EUROPE"},
                new Country {Id = 137, Name = "Mongolia", Code = "MN", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 138, Name = "Montserrat", Code = "MS", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 139, Name = "Morocco", Code = "MA", Region = "NORTHERN AFRICA"},
                new Country {Id = 140, Name = "Mozambique", Code = "MZ", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 141, Name = "Myanmar", Code = "MM", Region = "OCEANIA"},
                new Country {Id = 142, Name = "Namibia", Code = "NA", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 143, Name = "Nauru", Code = "NR", Region = "OCEANIA"},
                new Country {Id = 144, Name = "Nepal", Code = "NP", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 145, Name = "Netherlands", Code = "NL", Region = "WESTERN EUROPE"},
                new Country {Id = 146, Name = "Netherlands Antilles", Code = "AN", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 147, Name = "New Caledonia", Code = "NC", Region = "OCEANIA"},
                new Country {Id = 148, Name = "New Zealand", Code = "NZ", Region = "OCEANIA"},
                new Country {Id = 149, Name = "Nicaragua", Code = "NI", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 150, Name = "Niger", Code = "NE", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 151, Name = "Nigeria", Code = "NG", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 152, Name = "Norway", Code = "NO", Region = "WESTERN EUROPE"},
                new Country {Id = 153, Name = "Oman", Code = "OM", Region = "NEAR EAST"},
                new Country {Id = 154, Name = "Pakistan", Code = "PK", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 155, Name = "Palau", Code = "PW", Region = "OCEANIA"},
                new Country {Id = 156, Name = "Panama", Code = "PA", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 157, Name = "Papua New Guinea", Code = "PG", Region = "OCEANIA"},
                new Country {Id = 158, Name = "Paraguay", Code = "PY", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 159, Name = "Peru", Code = "PE", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 160, Name = "Philippines", Code = "PH", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 161, Name = "Poland", Code = "PL", Region = "EASTERN EUROPE"},
                new Country {Id = 162, Name = "Portugal", Code = "PT", Region = "WESTERN EUROPE"},
                new Country {Id = 163, Name = "Puerto Rico", Code = "PR", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 164, Name = "Qatar", Code = "QA", Region = "NEAR EAST"},
                new Country {Id = 165, Name = "Reunion", Code = "RE", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 166, Name = "Romania", Code = "RO", Region = "EASTERN EUROPE"},
                new Country {Id = 167, Name = "Russia", Code = "RU", Region = "C.W. OF IND. STATES"},
                new Country {Id = 168, Name = "Rwanda", Code = "RW", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 169, Name = "Saint Helena", Code = "SH", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 170, Name = "Saint Kitts & Nevis", Code = "KN", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 171, Name = "Saint Lucia", Code = "LC", Region = "LATIN AMER. & CARIB"},
                new Country
                {
                    Id = 172, Name = "Saint Vincent and the Grenadines", Code = "VC", Region = "LATIN AMER. & CARIB"
                },
                new Country {Id = 173, Name = "Samoa", Code = "WS", Region = "OCEANIA"},
                new Country {Id = 174, Name = "San Marino", Code = "SM", Region = "WESTERN EUROPE"},
                new Country {Id = 175, Name = "Sao Tome & Principe", Code = "ST", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 176, Name = "Saudi Arabia", Code = "SA", Region = "NEAR EAST"},
                new Country {Id = 177, Name = "Senegal", Code = "SN", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 178, Name = "Serbia", Code = "CS", Region = "EASTERN EUROPE"},
                new Country {Id = 179, Name = "Seychelles", Code = "SC", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 180, Name = "Sierra Leone", Code = "SL", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 181, Name = "Singapore", Code = "SG", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 182, Name = "Slovakia", Code = "SK", Region = "EASTERN EUROPE"},
                new Country {Id = 183, Name = "Slovenia", Code = "SI", Region = "EASTERN EUROPE"},
                new Country {Id = 184, Name = "Solomon Islands", Code = "SB", Region = "OCEANIA"},
                new Country {Id = 185, Name = "Somalia", Code = "SO", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 186, Name = "South Africa", Code = "ZA", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 187, Name = "Spain", Code = "ES", Region = "WESTERN EUROPE"},
                new Country {Id = 188, Name = "Sri Lanka", Code = "LK", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 189, Name = "Sudan", Code = "SD", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 190, Name = "Suriname", Code = "SR", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 191, Name = "Swaziland", Code = "SZ", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 192, Name = "Sweden", Code = "SE", Region = "WESTERN EUROPE"},
                new Country {Id = 193, Name = "Switzerland", Code = "CH", Region = "WESTERN EUROPE"},
                new Country {Id = 194, Name = "Syria", Code = "SY", Region = "NEAR EAST"},
                new Country {Id = 195, Name = "Taiwan", Code = "TW", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 196, Name = "Tajikistan", Code = "TJ", Region = "C.W. OF IND. STATES"},
                new Country {Id = 197, Name = "Tanzania", Code = "TZ", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 198, Name = "Thailand", Code = "TH", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 199, Name = "Togo", Code = "TG", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 200, Name = "Tonga", Code = "TO", Region = "OCEANIA"},
                new Country {Id = 201, Name = "Trinidad & Tobago", Code = "TT", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 202, Name = "Tunisia", Code = "TN", Region = "NORTHERN AFRICA"},
                new Country {Id = 203, Name = "Turkey", Code = "TR", Region = "NEAR EAST"},
                new Country {Id = 204, Name = "Turkmenistan", Code = "TM", Region = "C.W. OF IND. STATES"},
                new Country {Id = 205, Name = "Turks & Caicos Is", Code = "TC", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 206, Name = "Tuvalu", Code = "TV", Region = "OCEANIA"},
                new Country {Id = 207, Name = "Uganda", Code = "UG", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 208, Name = "Ukraine", Code = "UA", Region = "C.W. OF IND. STATES"},
                new Country {Id = 209, Name = "United Arab Emirates", Code = "AE", Region = "NEAR EAST"},

                new Country {Id = 212, Name = "Uruguay", Code = "UY", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 213, Name = "Uzbekistan", Code = "UZ", Region = "C.W. OF IND. STATES"},
                new Country {Id = 214, Name = "Vanuatu", Code = "VU", Region = "OCEANIA"},
                new Country {Id = 215, Name = "Venezuela", Code = "VE", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 216, Name = "Vietnam", Code = "VN", Region = "ASIA (EX. NEAR EAST)"},
                new Country {Id = 217, Name = "Virgin Islands", Code = "VI", Region = "LATIN AMER. & CARIB"},
                new Country {Id = 218, Name = "Wallis and Futuna", Code = "WF", Region = "OCEANIA"},
                new Country {Id = 219, Name = "Western Sahara", Code = "EH", Region = "NORTHERN AFRICA"},
                new Country {Id = 220, Name = "Yemen", Code = "YE", Region = "NEAR EAST"},
                new Country {Id = 221, Name = "Zambia", Code = "ZM", Region = "SUB-SAHARAN AFRICA"},
                new Country {Id = 222, Name = "Zimbabwe", Code = "ZW", Region = "SUB-SAHARAN AFRICA"}
            };
        }

        public static List<Brand> GetBrands()
        {
            return new List<Brand>
            {
                new Brand { Id = 1, Name = "Schneider",CreatedDate = DateTime.Today},
                new Brand { Id = 2, Name = "Schneider",CreatedDate = DateTime.Today},
                new Brand { Id = 3, Name = "Schneider",CreatedDate = DateTime.Today},
                new Brand { Id = 4, Name = "Schneider",CreatedDate = DateTime.Today},
                new Brand { Id = 5, Name = "Schneider",CreatedDate = DateTime.Today},
                new Brand { Id = 6, Name = "Schneider",CreatedDate = DateTime.Today},
                new Brand { Id = 9, Name = "Schneider",CreatedDate = DateTime.Today}
            };
        }

        public static List<DeviceType> GetDeviceTypes()
        {
            return new List<DeviceType>
            {
                new DeviceType { Id = 1, Type = "DeviceTypeLegacy1",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription1"},
                new DeviceType { Id = 2, Type = "DeviceTypeLegacy2",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription2"},
                new DeviceType { Id = 3, Type = "DeviceTypeLegacy3",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription3"},
                new DeviceType { Id = 4, Type = "DeviceTypeLegacy4",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription5"},
                new DeviceType { Id = 5, Type = "DeviceTypeLegacy5",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription4"},
                new DeviceType { Id = 6, Type = "DeviceTypeLegacy6",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription6"},
                new DeviceType { Id = 9, Type = "DeviceTypeLegacy7",CreatedDate = DateTime.Today,OpsTypeDescription = "OpsTypeDescription7"}
            };
        }

        public static List<Product> GetProducts()
        {
            return new List<Product>
            {
                new Product { Id = 1, CreatedDate = DateTime.Today, RangeId=1, Serviceable= "Serviceable1", BrandId=1, Configuration="Configuration1", DeviceTypeId =1  },
                new Product { Id = 2, CreatedDate = DateTime.Today, RangeId=2, Serviceable= "Serviceable1", BrandId=2, Configuration="Configuration2", DeviceTypeId =2  },
                new Product { Id = 3, CreatedDate = DateTime.Today, RangeId=1, Serviceable= "Serviceable1", BrandId=1, Configuration="Configuration3", DeviceTypeId =1  },
                new Product { Id = 4, CreatedDate = DateTime.Today, RangeId=3, Serviceable= "Serviceable1", BrandId=2, Configuration="Configuration4", DeviceTypeId =2  },
                new Product { Id =5, CreatedDate = DateTime.Today, RangeId=4, Serviceable= "Serviceable1", BrandId=1, Configuration="Configuration5", DeviceTypeId =1  },
            };
        }

        public static List<Range> GetRanges()
        {
            return new List<Range>
            {
                new Range { Id = 1, Name = "Range1", CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode1" },
                new Range { Id = 2, Name = "Range2",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode2"},
                new Range { Id = 3, Name = "Range3",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode3"},
                new Range { Id = 4, Name = "Range4",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode4"},
                new Range { Id = 5, Name = "Range5",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode5"},
                new Range { Id = 6, Name = "Range6",CreatedDate =DateTime.Today, OpsDescription ="SdhSubRangeCode6"},
                new Range { Id = 9, Name = "Range10",CreatedDate =DateTime.Today,OpsDescription="SdhSubRangeCode7"}
            };
        }

        public static Profile GetProfile()
        {
            return new Profile
            {
                Country = GetCountries()[0],
                CountryId = GetCountries()[0].Id,
                Id = 1,
                Created = DateTime.Today,
                Updated = DateTime.Today.AddDays(1),
                FirstName = "TestName",
                LastName = "TestLast",
                Email = "test@se.com",
                Fax = "+9188888888",
                MobileNumber = "+91999999000",
                Position = GetPositions()[0],
                PositionId = GetPositions()[0].Id,
                PostalCode = "123456",
                Region = GetCountries()[0].Region,
                Street = "Main Street",
                Telephone = "+9188888888",
                Town = "MainTown"
            };
        }

        public static List<SubRange> GetSubRange()
        {
            return new List<SubRange>
            {
                new SubRange{RangeId = 1,  CreatedDate= DateTime.Today, Id = 1, Name= "SdhSubRangeCode5", SdhDescription ="SdhSubRangeDescription1", UpdatedDate= DateTime.Now},
                new SubRange{RangeId = 2,  CreatedDate= DateTime.Today, Id = 1, Name= "SdhSubRangeCode2", SdhDescription ="SdhSubRangeDescription2",  UpdatedDate= DateTime.Now},
                new SubRange{RangeId = 3,  CreatedDate= DateTime.Today, Id = 1, Name= "SdhSubRangeCode1", SdhDescription ="SdhSubRangeDescription3",  UpdatedDate= DateTime.Now},
                new SubRange{RangeId = 4,  CreatedDate= DateTime.Today, Id = 1, Name= "SdhSubRangeCode4", SdhDescription ="SdhSubRangeDescription4",  UpdatedDate= DateTime.Now},
            };
        }
    }
}