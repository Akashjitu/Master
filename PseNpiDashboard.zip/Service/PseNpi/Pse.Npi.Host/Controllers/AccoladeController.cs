﻿using Pse.Data.Models;
using Pse.Services.Service;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class AccoladeController : ApiController
    {
        ISpeService _service;
        public AccoladeController(ISpeService service)
        {
            _service = service;

        }

        [HttpGet]
        public HttpResponseMessage Get()
        {
            List<TtiPartAlignment> ttiPartAlignments = null;
            for (int i = 0; i < 2; i++)
            {
                ttiPartAlignments = _service.LoadTtiByDate(new TtiPartAlignment() { InfoCreatedDate = DateTime.Today.AddMonths(-i) });
                if (ttiPartAlignments != null && ttiPartAlignments.Count > 0)
                    break;
            }
            //int k = 1;
            //var tti =
            //tti.ForEach(i => i.Id = k++);
          return  Request.CreateResponse(HttpStatusCode.OK, ttiPartAlignments, JsonMediaTypeFormatter.DefaultMediaType);
        }
        
    }
}
