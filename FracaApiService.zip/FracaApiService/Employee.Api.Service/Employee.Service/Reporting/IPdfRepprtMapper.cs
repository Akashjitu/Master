﻿using Fraca.Data.Models;


namespace Fraca.Service.Reporting
{
   public interface IPdfReportMapper
    {
        byte[] GetMappedReport(FracaInfo fracainfo);
       
    }
}
