﻿using System;
using System.Collections.Generic;
using Oracle.Data.Access;
using Pse.Data.Models;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public class ServiceDataLoader : IServiceDataLoader
    {
        public List<Data.Models.Compliance> LoadCompliance()
        {
            using (var dao = new DataAccessObject<Data.Models.Compliance>())
            {
                var data = dao.Load("PK_PSE_COMPLIANCE.SP_LOAD_COMPLIANCE");
                var returndata = new List<Data.Models.Compliance>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<TtiPartAlignment> LoadTti()
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
              var data = dao.Load("PK_PSE_TTI.SP_LOAD_TTI");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            } 
        }

        public List<TtiPartAlignment> LoadTtiByParameter(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_TTI.SP_LOAD_TTI_BY_KC_AND_DATE");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            }
        }
        

        public List<TtiPartAlignment> LoadTtiByDate(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_TTI.SP_LOAD_TTI_BY_MO_YY");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            }
        }


        public List<TtiPartAlignment> LoadTtiById(TtiPartAlignment ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<TtiPartAlignment>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_TTI.SP_LOAD_TTI_BY_ID");
                var returndata = new List<TtiPartAlignment>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Data.Models.Effectiveness> LoadPppPartInfo(Data.Models.Effectiveness ttiPartAlignment)
        {
            using (var dao = new DataAccessObject<Data.Models.Effectiveness>())
            {
                var data = dao.LoadByInput(ttiPartAlignment, "PK_PSE_PPP_PART.SP_LOAD_PPP_PART_INFO");
                var returndata = new List<Data.Models.Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Data.Models.Effectiveness> LoadEffectivenesByDate(Data.Models.Effectiveness effectiveness)
        {
            using (var dao = new DataAccessObject<Data.Models.Effectiveness>())
            {
                var data = dao.LoadByInput(effectiveness, "PK_PSE_EFFECTIVENESS.SP_LOAD_EFFECTIV_BY_MO_YY");
                var returndata = new List<Data.Models.Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<Data.Models.Effectiveness> LoadEffectivenesById(Data.Models.Effectiveness effectiveness)
        {
            using (var dao = new DataAccessObject<Data.Models.Effectiveness>())
            {
                var data = dao.LoadByInput(effectiveness, "PK_PSE_EFFECTIVENESS.SP_LOAD_EFFECTIV_BY_ID");
                var returndata = new List<Data.Models.Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }


        public List<Data.Models.Effectiveness> LoadEffectivenesByPart(Data.Models.Effectiveness effectiveness)
        {
            using (var dao = new DataAccessObject<Data.Models.Effectiveness>())
            {
                var data = dao.LoadByInput(effectiveness, "PK_PSE_EFFECTIVENESS.SP_LOAD_EFFECTIV_BY_PART");
                var returndata = new List<Data.Models.Effectiveness>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<EffectivenessAnalysisDataAccess> LoadEffectivenessAnalysisByPart(EffectivenessAnalysisDataAccess effectivenessAnalysis)
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysisDataAccess>())
            {
                var data = dao.LoadByInput(effectivenessAnalysis, "PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EFFECT_ANSIS_BY_PART");
                var returndata = new List<EffectivenessAnalysisDataAccess>();
                returndata.AddRange(data);
                return returndata;
            }
        }


        public List<EffectivenessAnalysisDataAccess> LoadEffectivenessAnalysisById(EffectivenessAnalysisDataAccess effectivenessAnalysis)
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysisDataAccess>())
            {
                var data = dao.LoadByInput(effectivenessAnalysis, "PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EFFECT_ANSIS_BY_ID");
                var returndata = new List<EffectivenessAnalysisDataAccess>();
                returndata.AddRange(data);
                return returndata;
            }
        }


        public List<EffectivenessAnalysisDataAccess> LoadEffectivenessAnalysisByCreationDate(EffectivenessAnalysisDataAccess effectivenessAnalysis)
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysisDataAccess>())
            {
                var data = dao.LoadByInput(effectivenessAnalysis, "PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EF_ANSIS_BY_MO_YY");
                var returndata = new List<EffectivenessAnalysisDataAccess>();
                returndata.AddRange(data);
                return returndata;
            }
        }

        public List<EffectivenessAnalysisDataAccess> LoadEffectivenesAnalysis()
        {
            using (var dao = new DataAccessObject<EffectivenessAnalysisDataAccess>())
            {
                var data = dao.Load("PK_PSE_EFFECTIVENESS_ANALYSIS.SP_LOAD_EFFECT_ANSIS");
                var returndata = new List<EffectivenessAnalysisDataAccess>();
                returndata.AddRange(data);
                return returndata;
            }
        }

    }



}


