

import { Action } from '@ngrx/store';
import * as OtlDispositionAction from './otlDispositionAction';

import { OtlDisposition } from '../../model/OtlDisposition';



export interface IAppState {
    readonly compliance: OtlDisposition[];
}


export function otlDispositioneReducer(state: OtlDisposition[] = [], action: OtlDispositionAction.Actions) {

    switch (action.type) {

        case OtlDispositionAction.ADD_OTL_DISPOSITION: {
            return [...state, action.payload]

        }

        case OtlDispositionAction.LOAD_OTL_DISPOSITION: {
            state = action.payload;
          //  console.log("user Name :" + action.type)
           // console.log("after : "+JSON.stringify(state));
            return state;
        }

        case OtlDispositionAction.UPDATE_OTL_DISPOSITION: {
            const tti = (action.payload as OtlDisposition);
            const todo = state.find(t => t.id === tti.id);

            if (todo != undefined || todo != null) {

                let index = state.indexOf(todo);

                let sliceArray = state.splice(index, 1, todo);
            }
            //return Object.assign([], state);
            return state.slice();
        }



        default:
            return state;
    }
}