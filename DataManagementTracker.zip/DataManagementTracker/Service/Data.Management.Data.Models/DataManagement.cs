﻿using Data.Management.Data.Models.Enum;
using Oracle.Data.Access;
using System;

namespace DataManagement.Data.Models
{
    public class DataManagementTrack
    {
        private string _Requestor;
        private string _Site;
        private string _DocumentPartNumber;
        private string _Revision;
        private string _DocumentTitle;
        private string _Ecn;
        private string _CustomerName;
        private string _ProgramNames;
        private string _Priority;
        private string _DataManager;
        private string _Cm;
        private string _RequestorComments;
        private string _DocumentType;
        private string _EndItemPartNumber;
        private string _CategoryOfChange;
        private string _ScnNumber;
        private string _CmComments;
        private string _SdrlNumber;
        private string _SdrlTitle;
        private string _Nomenclature;
        private string _CustomerReferenceNumber;
        private string _HoneywellTransmittalLetter;
        private string _HonStatus;
        private string _DispositionStatus;
        private string _CustomerStatus;
        private string _ApProgram;
        private string _BcaPrimaryReviewerEngineer;
        private string _BcaPa;
        private string _DmComments;
        private string _HoneywellComments;
        private string _ExportDisclosure;
        private string _CreatedBy;
        private string _UpdatedBy;
        private string _IsActive;

        [Columns("p_ID")]
        public int Id { get; set; }

        [Columns("P_REQUESTOR")]
        public string Requestor { get { return _Requestor; } set { _Requestor = value ?? string.Empty; } }

        [Columns("P_REQUESTRECEIVEDDATE")]
        public DateTime RequestReceivedDate { get; set; }

        [Columns("P_SITE")]
        public string Site { get { return _Site; } set { _Site = value ?? string.Empty; } }

        [Columns("P_SITE_ID")]
        public int SiteId { get; set; }

        [Columns("P_DOCUMENT_PART_NUMBER")]
        public string DocumentPartNumber { get { return _DocumentPartNumber; } set { _DocumentPartNumber = value ?? string.Empty; } }

        [Columns("P_REVISION")]
        public string Revision { get { return _Revision; } set { _Revision = value ?? string.Empty; } }

        [Columns("P_DOCUMENT_TITLE")]
        public string DocumentTitle { get { return _DocumentTitle; } set { _DocumentTitle = value ?? string.Empty; } }

        [Columns("P_ECN")]
        public string Ecn { get { return _Ecn; } set { _Ecn = value ?? string.Empty; } }

        [Columns("P_CUSTOMER_NAME")]
        public string CustomerName { get { return _CustomerName; } set { _CustomerName = value ?? string.Empty; } }

        [Columns("P_CUSTOMER_ID")]
        public int CustomerId { get; set; }

        [Columns("P_PROGRAM_NAMES")]
        public string ProgramNames { get { return _ProgramNames; } set { _ProgramNames = value ?? string.Empty; } }

        [Columns("P_PROGRAM_ID")]
        public int Programid { get; set; }

        [Columns("P_PRIORITY")]
        public string Priority { get { return _Priority; } set { _Priority = value ?? string.Empty; } }

        [Columns("P_DATA_MANAGER")]
        public string DataManager { get { return _DataManager; } set { _DataManager = value ?? string.Empty; } }

        [Columns("P_CM")]
        public string Cm { get { return _Cm; } set { _Cm = value ?? string.Empty; } }

        [Columns("P_REQUESTOR_COMMENTS")]
        public string RequestorComments { get { return _RequestorComments; } set { _RequestorComments = value ?? string.Empty; } }

        [Columns("P_DOCUMENT_TYPE")]
        public string DocumentType { get { return _DocumentType; } set { _DocumentType = value ?? string.Empty; } }

        [Columns("P_END_ITEM_PART_NUMBER")]
        public string EndItemPartNumber { get { return _EndItemPartNumber; } set { _EndItemPartNumber = value ?? string.Empty; } }

        [Columns("P_CATEGORY_OF_CHANGE")]
        public string CategoryOfChange { get { return _CategoryOfChange; } set { _CategoryOfChange = value ?? string.Empty; } }

        [Columns("P_SCN_NUMBER")]
        public string ScnNumber { get { return _ScnNumber; } set { _ScnNumber = value ?? string.Empty; } }

        [Columns("P_CM_COMMENTS")]
        public string CmComments { get { return _CmComments; } set { _CmComments = value ?? string.Empty; } }

        [Columns("P_SDRL_NUMBER")]
        public string SdrlNumber { get { return _SdrlNumber; } set { _SdrlNumber = value ?? string.Empty; } }

        [Columns("P_SDRL_TITLE")]
        public string SdrlTitle { get { return _SdrlTitle; } set { _SdrlTitle = value ?? string.Empty; } }

        [Columns("P_NOMENCLATURE")]
        public string Nomenclature { get { return _Nomenclature; } set { _Nomenclature = value ?? string.Empty; } }

        [Columns("P_CUSTOMER_REFERENCE_NUMBER")]
        public string CustomerReferenceNumber { get { return _CustomerReferenceNumber; } set { _CustomerReferenceNumber = value ?? string.Empty; } }

        [Columns("P_HONEYWELL_TRANSMITTAL_LETTER")]
        public string HoneywellTransmittalLetter { get { return _HoneywellTransmittalLetter; } set { _HoneywellTransmittalLetter = value ?? string.Empty; } }

        [Columns("P_DM_DATE_SENT_TO_CUSTOMER")]
        public DateTime? DmDateSentToCustomer { get; set; }

        [Columns("P_HON_STATUS")]
        public string HonStatus { get { return _HonStatus; } set { _HonStatus = value ?? string.Empty; } }

        [Columns("P_REQUIRED_DISPOSITION_DATE")]
        public DateTime? RequiredDispositionDate { get; set; }

        [Columns("P_DISPOSITION_STATUS")]
        public string DispositionStatus { get { return _DispositionStatus; } set { _DispositionStatus = value ?? string.Empty; } }

        [Columns("P_CUSTOMER_STATUS")]
        public string CustomerStatus { get { return _CustomerStatus; } set { _CustomerStatus = value ?? string.Empty; } }

        [Columns("P_AP_PROGRAM")]
        public string ApProgram { get { return _ApProgram; } set { _ApProgram = value ?? string.Empty; } }

        [Columns("P_IMPACTED_PO_DATE")]
        public DateTime? ImpactedPoDate { get; set; }

        [Columns("P_BCA_PRIMARY_REVIEWER")]
        public string BcaPrimaryReviewerEngineer { get { return _BcaPrimaryReviewerEngineer; } set { _BcaPrimaryReviewerEngineer = value ?? string.Empty; } }

        [Columns("P_BCA_PA")]
        public string BcaPa { get { return _BcaPa; } set { _BcaPa = value ?? string.Empty; } }

        [Columns("P_DM_COMMENTS")]
        public string DmComments { get { return _DmComments; } set { _DmComments = value ?? string.Empty; } }

        [Columns("P_HONEYWELL_COMMENTS")]
        public string HoneywellComments { get { return _HoneywellComments; } set { _HoneywellComments = value ?? string.Empty; } }

        [Columns("P_EXPORT_DISCLOSURE")]
        public string ExportDisclosure { get { return _ExportDisclosure; } set { _ExportDisclosure = value ?? string.Empty; } }

        [Columns("P_CREATED_BY")]
        public string CreatedBy { get { return _CreatedBy; } set { _CreatedBy = value ?? string.Empty; } }

        [Columns("P_CREATED_DATE")]
        public DateTime? CreatedDate { get; set; }

        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get { return _UpdatedBy; } set { _UpdatedBy = value ?? string.Empty; } }

        [Columns("P_UPDATED_DATE")]
        public DateTime? UpdatedDate { get; set; }

        [Columns("P_IS_ACTIVE")]
        public string IsActive { get; set; }

        public AccessUIType AccessUIType { get; set; }

        [Columns("P_REQUESTOR_ID")]
        public string RequestorId { get; set; }
    }
}