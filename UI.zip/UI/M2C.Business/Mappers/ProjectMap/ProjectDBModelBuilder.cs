﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProjectDBModelBuilder.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DomainModels;
using DomainModels.Common;
using DomainModels.ProjectModels;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Business.Models.Project.TRComponents;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace M2C.Business.Mappers.ProjectMap
{
    /// <summary>
    /// Class ProjectDbModelBuilder.
    /// Implements the <see cref="M2C.Business.Mappers.ProjectMap.IProjectDbModelBuilder" />
    /// </summary>
    /// <seealso cref="M2C.Business.Mappers.ProjectMap.IProjectDbModelBuilder" />
    public class ProjectDbModelBuilder : IProjectDbModelBuilder
    {
        /// <summary>
        /// The source model
        /// </summary>
        private ProjectContextModel _sourceModel;

        /// <summary>
        /// The project database context
        /// </summary>
        private IProjectDbContext _projectDbContext;

        /// <summary>
        /// The target model
        /// </summary>
        private Project _targetProject;

        /// <summary>
        /// The inventory mapper
        /// </summary>
        private readonly IInventoryMapper _inventoryMapper;
        /// <summary>
        /// The project queries
        /// </summary>
        private IProjectQueries _projectQueries;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectDbModelBuilder" /> class.
        /// </summary>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        /// <param name="projectQueries">The project queries.</param>
        public ProjectDbModelBuilder(IInventoryMapper inventoryMapper, IProjectQueries projectQueries)
        {
            _inventoryMapper = inventoryMapper;
            _projectQueries = projectQueries;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectDbModelBuilder" /> class.
        /// </summary>
        /// <param name="projectModel">The project model.</param>
        /// <param name="projectDbContext">The project database context.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        /// <param name="projectQueries">The project queries.</param>
        public ProjectDbModelBuilder(ProjectContextModel projectModel, IProjectDbContext projectDbContext, IInventoryMapper inventoryMapper, IProjectQueries projectQueries)
        {
            _sourceModel = projectModel;
            _projectDbContext = projectDbContext;
            _inventoryMapper = inventoryMapper;
            if (_sourceModel.ProjectId != null)
            {
                _targetProject = projectQueries.GetProject(_sourceModel.ProjectId ?? 0);
            }
        }

        /// <summary>
        /// Builds the project.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildProject()
        {
            if (_targetProject == null)
            {
                _targetProject = new Project { ProjectID = _sourceModel.ProjectId ?? 0 };
                _projectDbContext.Projects.Add(_targetProject);
            }
            else
                _projectDbContext.Projects.Update(_targetProject);

            _targetProject.Version = _sourceModel.Version;

            FillChangeTrack(_targetProject);

            return this;
        }

        /// <summary>
        /// Builds the customer.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildCustomer()
        {
            if (_targetProject.Customer == null)
            {
                _targetProject.Customer = new Customer();
                _projectDbContext.Customers.Add(_targetProject.Customer);
            }
            else
                _projectDbContext.Customers.Update(_targetProject.Customer);

            _targetProject.Customer.BfoId = _sourceModel.Customer.BfoIdValue ?? 0;
            _targetProject.Customer.City = _sourceModel.Customer.City;
            _targetProject.Customer.Comment = _sourceModel.Customer.Comment;
            _targetProject.Customer.CompanyName = _sourceModel.Customer.CompanyName;
            _targetProject.Customer.CountryId = _sourceModel?.Customer?.Country?.Id ?? 1;
            _targetProject.Customer.ProjectName = _sourceModel.Customer.ProjectName;
            _targetProject.Customer.Region = _sourceModel.Customer.Region;
            _targetProject.Customer.PostalCode = _sourceModel.Customer.PostalCode;
            _targetProject.Customer.Street = _sourceModel.Customer.Street;

            FillChangeTrack(_targetProject.Customer);

            return this;
        }

        /// <summary>
        /// Builds the contact.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildContact()
        {
            if (_targetProject.Contacts == null)
            {
                _targetProject.Contacts = new List<Contact>();
            }

            var deletedContacts = _targetProject.Contacts.Where(x => !_sourceModel.Contacts.Select(y => y.Id).Contains(x.ContactID));
            if (deletedContacts.Any())
            {
                _projectDbContext.Contacts.RemoveRange(deletedContacts);
            }

            foreach (var contactModel in _sourceModel.Contacts)
            {
                Contact contact;
                if (contactModel.Id == 0)
                {
                    contact = new Contact();
                    FillContact(ref contact, contactModel);
                    _targetProject.Contacts.Add(contact);
                    _projectDbContext.Contacts.Add(contact);
                }
                else
                {
                    contact = _targetProject.Contacts.FirstOrDefault(x => x.ContactID == contactModel.Id);
                    if (contact != null)
                    {
                        FillContact(ref contact, contactModel);
                        _projectDbContext.Contacts.Update(contact);
                    }
                }
            }

            return this;
        }

        /// <summary>
        /// Fills the contact.
        /// </summary>
        /// <param name="dbContact">The database contact.</param>
        /// <param name="contactModel">The contact model.</param>
        private void FillContact(ref Contact dbContact, ContactModel contactModel)
        {
            dbContact.City = contactModel.Town;
            dbContact.ContactType = _projectDbContext.ContactTypes.Find((int)contactModel.ContactType);
            dbContact.CountryId = contactModel.Country?.Id ?? 1;
            dbContact.Email = contactModel.Email;
            dbContact.Fax = contactModel.Fax;
            dbContact.FirstName = contactModel.FirstName;
            dbContact.IsLinked = contactModel.IsLinked;
            dbContact.LastName = contactModel.LastName;
            dbContact.Mobile = contactModel.MobileNumber;
            dbContact.PositionId = contactModel.Position?.Id ?? 1;
            dbContact.Street = contactModel.Street;
            dbContact.Telephone = contactModel.Telephone;
            dbContact.Project = _targetProject;
            dbContact.PostalCode = contactModel.PostalCode;
            dbContact.Region = contactModel.Region;

            FillChangeTrack(dbContact);
        }

        /// <summary>
        /// Builds the Ib components.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildIbComponents()
        {
            if (_sourceModel.InstalledBase == null)
                return this;

            var listNodes = _sourceModel.InstalledBase.GetAllNodes();

            if (!listNodes.Any())
                return this;

            var ibProjectComponents = _projectDbContext.IBProjectComponents.Where(x => x.Project.ProjectID == _targetProject.ProjectID).ToArray();
            var operationModes = _projectDbContext.OperationModes.Where(x => x.Project.ProjectID == _targetProject.ProjectID).ToArray();
            var criticalities = _projectDbContext.Criticalities.Where(x => x.Project.ProjectID == _targetProject.ProjectID).ToArray();
            if (ibProjectComponents.Any())
            {
                if (operationModes.Any())
                {
                    _projectDbContext.OperationModes.RemoveRange(operationModes);
                    _projectDbContext.SaveChanges();
                }

                if (criticalities.Any())
                {
                    _projectDbContext.Criticalities.RemoveRange(criticalities);
                    _projectDbContext.SaveChanges();
                }

                _projectDbContext.IBProjectComponents.RemoveRange(ibProjectComponents);

                _projectDbContext.SaveChanges();
            }

            _targetProject.IBProjectComponents = new List<IBProjectComponent>();

            var ibComponentTypes = _projectDbContext.IBComponenetTypes.ToList();
            foreach (var n in listNodes)
            {
                var ibProjectComponent = new IBProjectComponent
                {
                    Project = _targetProject,
                    ComponentName = n.Name,
                    IBComponenetType = ibComponentTypes.FirstOrDefault(t => t.ComponentTypeID == (int)n.NodeType),
                    Metadata = new Metadata() { Key = $"{_targetProject?.Customer?.ProjectName}_{n.Name}" },
                    NodeID = n.Id ?? -1
                };

                if (n.ParentNode is null)
                    ibProjectComponent.ParentID = 0;
                else
                    ibProjectComponent.ParentID = n.ParentNode.Id ?? -1;

                _targetProject?.IBProjectComponents.Add(ibProjectComponent);
            }

            return this;
        }

        /// <summary>
        /// Builds the Ib components.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildTrComponents()
        {
            if (_sourceModel.TechnicalResources == null)
                return this;

            var listNodes = _sourceModel.TechnicalResources.GetAllNodes();

            if (!listNodes.Any())
                return this;

            if (_targetProject.IBProjectComponents == null)
                _targetProject.IBProjectComponents = new List<IBProjectComponent>();

            var ibComponentTypes = _projectDbContext.IBComponenetTypes.ToList();
            foreach (var n in listNodes)
            {
                if (string.IsNullOrEmpty(n.Name))
                    continue;
                var ibProjectComponent = new IBProjectComponent
                {
                    Project = _targetProject,
                    ComponentName = n.Name,
                    IBComponenetType = ibComponentTypes.FirstOrDefault(t => t.ComponentTypeID == (int)n.NodeType),
                    Metadata = new Metadata() { Key = $"{_targetProject?.Customer?.ProjectName}_{n.Name}" },
                    NodeID = n.Id ?? -1,
                    IsTRNode = true,
                };

                if (n.ParentNode is null)
                    ibProjectComponent.ParentID = 0;
                else
                    ibProjectComponent.ParentID = n.ParentNode.Id ?? -1;

                _targetProject?.IBProjectComponents.Add(ibProjectComponent);
            }

            return this;
        }

        /// <summary>
        /// Gets the project.
        /// </summary>
        /// <returns>Project.</returns>
        public Project GetProject()
        {
            return _targetProject;
        }

        /// <summary>
        /// Fills the change track.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="param">The parameter.</param>
        /// <returns>T.</returns>
        private static void FillChangeTrack<T>(T param) where T : ChangeTrack
        {
            param.ModifiedBy = param.CreatedBy = "User";
            if (param.CreatedOn == DateTime.MinValue)
                param.CreatedOn = DateTime.Now;
            param.ModifiedOn = DateTime.Now;
        }

        /// <summary>
        /// builds the operation mode
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildOperationMode()
        {
            if (_targetProject.OperationModes == null)
                _targetProject.OperationModes = new List<OperationMode>();

            if (_sourceModel.InstalledBase == null)
                return this;

            var nodes = _sourceModel.InstalledBase.GetAllNodes();
            var machineNodeInfo = nodes.Where(i => i.NodeType == NodeType.MACHINE).ToList();

            if (!machineNodeInfo.Any())
                return this;

            foreach (var item in machineNodeInfo)
            {
                if (item.MasterInventories.Any())
                {
                    var operationModes = new OperationMode();
                    var operationMode = (IOperationMode)item;
                    if (operationMode.OperationParams == null) continue;

                    operationModes.HourlyProduction = operationMode.OperationParams.HourlyProduction;
                    operationModes.OperatingMode = operationMode.OperationParams.OperatingMode;
                    operationModes.StartupDate = operationMode.OperationParams.StartDate.ToString();
                    operationModes.EndOfLife = operationMode.OperationParams.EndDate.ToString();
                    operationModes.Age = operationMode.OperationParams.Age;
                    operationModes.Comments = operationMode.OperationParams.Comments;

                    operationModes.IBProjectComponent = _targetProject.IBProjectComponents.First(x => x.NodeID == item.Id);
                    operationModes.NodeID = item.Id ?? -1;
                    operationModes.Project = _targetProject;

                    _targetProject.OperationModes.Add(operationModes);
                }
            }

            return this;
        }

        /// <summary>
        /// builds the ProjectInventories
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildProjectInventories()
        {
            var installBasedNode = _sourceModel.InstalledBase;
            var technicalResourcesNode = _sourceModel.TechnicalResources;

            if (_targetProject.ProjectInventories == null)
                _targetProject.ProjectInventories = new List<ProjectInventory>();
            var projectInventories = new List<ProjectInventory>();
            RemoveProjectInventories(_targetProject.ProjectInventories);

            if (technicalResourcesNode != null && technicalResourcesNode.MasterInventories.Count > 0)
            {
                projectInventories.AddRange(_inventoryMapper.Map(technicalResourcesNode.MasterInventories));
            }

            if (installBasedNode != null && installBasedNode.MasterInventories.Count > 0)
            {
                projectInventories.AddRange(_inventoryMapper.Map(installBasedNode.MasterInventories));
            }

            foreach (var inventory in projectInventories)
                _targetProject.ProjectInventories.Add(inventory);

            return this;
        }

        /// <summary>
        /// Removes the project inventories.
        /// </summary>
        /// <param name="dbProjectInventories">The database project inventories.</param>
        private void RemoveProjectInventories(ICollection<ProjectInventory> dbProjectInventories)
        {
            var projectInventories = new List<ProjectInventory>();
            projectInventories.AddRange(dbProjectInventories);
            projectInventories.ForEach(i => dbProjectInventories.Remove(i));
        }

        /// <summary>
        /// builds the Inventory Comments
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildInventoryComments()
        {
            if (_targetProject.InventoryComments == null)
                _targetProject.InventoryComments = new List<InventoryComments>();

            if (_sourceModel.InstalledBase == null)
                return this;
            var nodes = new List<Node>();

            var installBasedNode = _sourceModel.InstalledBase.GetAllNodes();
            var technicalResourcesNode = _sourceModel.TechnicalResources.GetAllNodes();

            nodes.AddRange(installBasedNode);
            nodes.AddRange(technicalResourcesNode);
            RemoveProjectInventoryComments(_targetProject.InventoryComments);
            foreach (var node in nodes)
            {
                if (string.IsNullOrEmpty(node.Comment) && (node.CustomerDocuments == null || node.CustomerDocuments.Count == 0))
                    continue;
                var inventoryComments = new InventoryComments
                {
                    CustomerDocuments = JsonConvert.SerializeObject(node.CustomerDocuments),
                    Comments = node.Comment,
                    NodeId = node.Id ?? -1,
                    Project = _targetProject,
                    NodeType = (int)node.NodeType,
                };
                _targetProject.InventoryComments.Add(inventoryComments);
            }

            return this;
        }

        /// <summary>
        /// Removes the project inventory comments.
        /// </summary>
        /// <param name="dbInventoryComentses">The database inventory comentses.</param>
        private void RemoveProjectInventoryComments(ICollection<InventoryComments> dbInventoryComentses)
        {
            var inventoryComments = new List<InventoryComments>();
            inventoryComments.AddRange(dbInventoryComentses);
            inventoryComments.ForEach(i => dbInventoryComentses.Remove(i));
        }

        /// <summary>
        /// Build the criticality
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        public ProjectDbModelBuilder BuildCriticality()
        {
            if (_targetProject.Criticalities == null)
                _targetProject.Criticalities = new List<Criticality>();

            if (_sourceModel.InstalledBase == null)
                return this;

            var nodes = _sourceModel.InstalledBase.GetAllNodes();
            var machineNodeInfo = nodes.Where(i => i.NodeType == NodeType.MACHINE).ToList();

            if (!machineNodeInfo.Any())
                return this;

            foreach (var item in machineNodeInfo)
            {
                if (item.MasterInventories.Any())
                {
                    var criticality = new Criticality();
                    MachineNode machineNode = (MachineNode)item;
                    if (machineNode.CriticalityParameters == null) continue;

                    criticality.QualityIssue = machineNode.CriticalityParameters.QualityIssue;
                    criticality.SafetyIssue = machineNode.CriticalityParameters.SafetyIssue;
                    criticality.LeadTimeIssue = machineNode.CriticalityParameters.LeadTimeIssue;
                    criticality.CostsIssue = machineNode.CriticalityParameters.CostsIssue;
                    criticality.CriticalityValue = machineNode.CriticalityParameters.SelectedValue;
                    criticality.Comments = machineNode.CriticalityParameters.Comments;

                    criticality.IBProjectComponent = _targetProject.IBProjectComponents.First(x => x.NodeID == item.Id);
                    criticality.NodeID = item.Id ?? -1;
                    criticality.Project = _targetProject;

                    _targetProject.Criticalities.Add(criticality);
                }
            }

            return this;
        }

        /// <summary>
        /// Gets the project.
        /// </summary>
        /// <param name="projectContextModel">The project context model.</param>
        /// <param name="projectDbContext">The project database context.</param>
        /// <returns>Project.</returns>
        public Project GetProject(ProjectContextModel projectContextModel, IProjectDbContext projectDbContext)
        {
            _projectDbContext = projectDbContext;
            _sourceModel = projectContextModel;
            _targetProject = null;
            if (_sourceModel.ProjectId != null)
                _targetProject = _projectQueries.GetProject(_sourceModel.ProjectId ?? 0);

            BuildProject();
            BuildCustomer();
            BuildContact();
            BuildIbComponents();
            BuildTrComponents();
            BuildOperationMode();
            BuildProjectInventories();
            BuildInventoryComments();
            BuildCriticality();
            return _targetProject;
        }
    }
}