﻿using Oracle.Data.Access;

namespace Data.Management.Data.Models
{
    public class Site
    {
        [Columns("P_SITE_ID")]
        public int ID { get; set; }

        [Columns("P_SITE_NAME")]
        public string Name { get; set; }

        [Columns("P_CODE")]
        public string Code { get; set; }
    }
}