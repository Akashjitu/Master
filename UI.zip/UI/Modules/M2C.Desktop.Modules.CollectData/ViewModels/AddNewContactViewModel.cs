﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="AddNewContactViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************

using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class AddNewContactViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    public class AddNewContactViewModel : BindableBase, IDialogAware
    {
        /// <summary>
        /// The model
        /// </summary>
        private ContactModel _model;
        /// <summary>
        /// The countries
        /// </summary>
        private ObservableCollection<CountryModel> _countries;
        /// <summary>
        /// The positions
        /// </summary>
        private ObservableCollection<PositionModel> _positions;
        /// <summary>
        /// The command type
        /// </summary>
        private string commandType;
        /// <summary>
        /// The project logic
        /// </summary>
        private readonly IProjectLogic _projectLogic;

        /// <summary>
        /// Gets the business utilities.
        /// </summary>
        /// <value>The business utilities.</value>
        public IBusinessUtilities BusinessUtilities { get; }
        /// <summary>
        /// Gets or sets the close dialog command.
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }
        /// <summary>
        /// Gets or sets the cancel command.
        /// </summary>
        /// <value>The cancel command.</value>
        public DelegateCommand<string> CancelCommand { get; set; }
        /// <summary>
        /// Gets or sets the reset dialog command.
        /// </summary>
        /// <value>The reset dialog command.</value>
        public DelegateCommand ResetDialogCommand { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AddNewContactViewModel" /> class.
        /// </summary>
        /// <param name="businessUtilities">The business utilities.</param>
        /// <param name="projectLogic">The project logic.</param>
        public AddNewContactViewModel(IBusinessUtilities businessUtilities, IProjectLogic projectLogic)
        {
            BusinessUtilities = businessUtilities;
            this._projectLogic = projectLogic;
            _model = new ContactModel();
            _countries = new ObservableCollection<CountryModel>(BusinessUtilities.getCountries());
            _positions = new ObservableCollection<PositionModel>(BusinessUtilities.getPositions());

            CloseDialogCommand = new DelegateCommand<string>(OnSaveAction, CanSave).
                ObservesProperty(() => Model.FirstName).
                 ObservesProperty(() => Model.LastName).
                  ObservesProperty(() => Model.Email);

            CancelCommand = new DelegateCommand<string>(OnSaveAction);

            ResetDialogCommand = new DelegateCommand(onResetAction);
        }

        /// <summary>
        /// Gets or sets the model.
        /// </summary>
        /// <value>The model.</value>
        public ContactModel Model { get => _model; set => SetProperty(ref _model, value); }

        /// <summary>
        /// Gets or sets the reset state model.
        /// </summary>
        /// <value>The reset state model.</value>
        public ContactModel ResetStateModel { get; set; } = new ContactModel();

        /// <summary>
        /// Gets or sets the countries.
        /// </summary>
        /// <value>The countries.</value>
        public ObservableCollection<CountryModel> Countries
        {
            get => _countries;
            set => _countries = value;
        }

        /// <summary>
        /// Gets or sets the positions.
        /// </summary>
        /// <value>The positions.</value>
        public ObservableCollection<PositionModel> Positions
        {
            get => _positions;
            set => _positions = value;
        }

        /// <summary>
        /// Type of Action(Add/Update) command passed from Parent Window
        /// </summary>
        /// <value>The type of the command.</value>
        public string CommandType { get => commandType; set => SetProperty(ref commandType, value); }

        /// <summary>
        /// CloseDialogCommand
        /// </summary>
        /// <param name="CommandParam">The command parameter.</param>
        /// <returns><c>true</c> if this instance can save the specified command parameter; otherwise, <c>false</c>.</returns>
        private bool CanSave(string CommandParam)
        {
            return !string.IsNullOrWhiteSpace(Model.FirstName) && !string.IsNullOrWhiteSpace(Model.LastName) && !string.IsNullOrWhiteSpace(Model.Email);
        }

        /// <summary>
        /// CloseDialogCommand
        /// </summary>
        /// <param name="CommandParam">The command parameter.</param>
        private void OnSaveAction(string CommandParam)
        {
            IDialogParameters contactParam = new DialogParameters();
            contactParam.Add("Command", CommandType);
            if (CommandParam.ToUpper() == "SAVE")
            {
                contactParam.Add("data", _model);

                RaiseRequestClose(new DialogResult(ButtonResult.OK,
                   contactParam));
            }
            else if (CommandParam.ToUpper() == "UPDATE")
            {
                contactParam.Add("data", _model);

                RaiseRequestClose(new DialogResult(ButtonResult.OK,
                   contactParam));
            }
            else
            {
                RaiseRequestClose(new DialogResult(ButtonResult.Cancel));
            }
        }

        /// <summary>
        /// Ons the reset action.
        /// </summary>
        private void onResetAction()
        {
            if (MessageBox.Show("Do you want to reset values?", "Reset", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Model = ContactModel.Clone(ResetStateModel);
            }
        }

        #region IDialogAware Implementation

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => "Contact";

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
        }

        /// <summary>
        /// Called when the dialog is opened.
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            CommandType = parameters.GetValue<string>("Command");
            if (CommandType == "Save")
            {
                Model = new ContactModel() { ContactType = parameters.GetValue<ContactType>("Data") };
            }
            else if (CommandType == "Update")
            {
                Model = parameters.GetValue<ContactModel>("Data");

                //Linking Object ref back to observable collection
                if (Model.Country != null)
                {
                    Model.Country = this.Countries.FirstOrDefault(x => x.Id == Model.Country.Id);
                }
                if (Model.Position != null)
                {
                    Model.Position = this.Positions.FirstOrDefault(x => x.Id == Model.Position.Id);
                }
            }

            ResetStateModel = ContactModel.Clone(Model);
        }

        #endregion IDialogAware Implementation
    }
}