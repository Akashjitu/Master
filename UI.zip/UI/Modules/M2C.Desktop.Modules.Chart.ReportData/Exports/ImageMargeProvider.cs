﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2C.Desktop.Modules.Charts.ReportData.Exports
{
    public class ImageMargeProvider
    {
        public static System.Drawing.Bitmap CombineBitmap(string[] files)
        {
            //read all images into memory
            List<System.Drawing.Bitmap> images = new List<System.Drawing.Bitmap>();
            System.Drawing.Bitmap finalImage = null;

            try
            {
                int width = 0;
                int height = 0;

                foreach (string image in files)
                {
                    //create a Bitmap from the file and add it to the list
                    System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(image);

                    //update the size of the final bitmap
                    width += bitmap.Width;
                    height = bitmap.Height > height ? bitmap.Height : height;

                    images.Add(bitmap);
                }

                //create a bitmap to hold the combined image
                finalImage = new System.Drawing.Bitmap(width, height);

                //get a graphics object from the image so we can draw on it
                using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(finalImage))
                {
                    //set background color
                    g.Clear(System.Drawing.Color.Black);

                    //go through each image and draw it on the final image
                    int offset = 0;
                    foreach (System.Drawing.Bitmap image in images)
                    {
                        g.DrawImage(image,
                            new System.Drawing.Rectangle(offset, 0, image.Width, image.Height));
                        offset += image.Width;
                    }
                }

                return finalImage;
            }
            catch (Exception ex)
            {
                if (finalImage != null)
                    finalImage.Dispose();

                throw ex;
            }
            finally
            {
                //clean up memory
                foreach (System.Drawing.Bitmap image in images)
                {
                    image.Dispose();
                }
            }
        }

        public static Image Marge(List<Image> imagess)
        {//read all images into memory
            List<System.Drawing.Bitmap> images = new List<System.Drawing.Bitmap>();
            System.Drawing.Bitmap finalImage = null;

            try
            {
                int width = 0;
                int height = 0;


                foreach (var image in imagess)
                {
                    System.Drawing.Bitmap bitmap = (Bitmap)image;
                    height += bitmap.Height;
                    width = bitmap.Width > width ? bitmap.Width : width;
                    images.Add(bitmap);
                }
                //create a bitmap to hold the combined image
                finalImage = new System.Drawing.Bitmap(width, height);


                //get a graphics object from the image so we can draw on it
                using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(finalImage))
                {
                    //set background color
                    g.Clear(System.Drawing.Color.Black);

                    //go through each image and draw it on the final image
                    int offset = 0;
                    foreach (System.Drawing.Bitmap image in images)
                    {
                        g.DrawImage(image,
                            new System.Drawing.Rectangle(0, offset, image.Width, image.Height));
                        offset += image.Height;
                    }
                }

                return finalImage;
            }
            catch (Exception ex)
            {
                if (finalImage != null)
                    finalImage.Dispose();

                throw ex;
            }
            finally
            {
                //clean up memory
                foreach (System.Drawing.Bitmap image in images)
                {
                    image.Dispose();
                }
            }

        }


        //public Image Marge(List<Image> images)
        //{
        //    Image finalImage=null;

        //    foreach (var image in images)
        //    {
        //        if (finalImage == null)
        //        {
        //            using (Bitmap bitmap = new Bitmap(image.Width, image.Height))
        //            {
        //                using (Graphics g = Graphics.FromImage(bitmap))
        //                {
        //                    g.CompositingMode = CompositingMode.SourceCopy;
        //                    g.DrawImageUnscaled(image, 0, 0);
        //                    finalImage = bitmap;
        //                }
        //            }
        //        }
        //        else
        //        {
        //            using (Bitmap bitmap = new Bitmap(image.Width, image.Height + finalImage.Height))

        //            using (Graphics g = Graphics.FromImage(bitmap))
        //            {
        //                g.CompositingMode = CompositingMode.SourceCopy;
        //                g.DrawImageUnscaled(image, 0, 0);
        //                g.DrawImageUnscaled(finalImage, 0, image.Height);
        //                finalImage = bitmap;
        //            }
        //        }
        //    }

        //    return finalImage;


        //    using (Image image1 = System.Drawing.Image.FromFile("filename1"))
        //    using (Image image2 = System.Drawing.Image.FromFile("filename2"))

        //    using (Bitmap b = new Bitmap(image2.Width, image2.Height + image1.Height))

        //    using (Graphics g = Graphics.FromImage(b))
        //    {
        //        g.CompositingMode = CompositingMode.SourceCopy;
        //        g.DrawImageUnscaled(image2, 0, 0);
        //        g.DrawImageUnscaled(image1, 0, image2.Height);

        //        b.Save(context.Response.OutputStream, ImageFormat.Png);
        //    }
        //}
    }
}
