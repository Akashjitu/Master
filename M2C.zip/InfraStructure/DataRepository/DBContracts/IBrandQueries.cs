﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IBrandQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IBrandQueries
    /// </summary>
    public interface IBrandQueries
    {
        /// <summary>
        /// Saves the brands.
        /// </summary>
        /// <param name="brands">The brands.</param>
        void SaveBrands(List<Brand> brands);

        /// <summary>
        /// Loads the brands.
        /// </summary>
        /// <param name="brand">The brand.</param>
        /// <returns>List&lt;Brand&gt;.</returns>
        List<Brand> LoadBrands(Brand brand);

        /// <summary>
        /// Loads the brands.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="isSe">Check Se Brand </param>
        /// <returns>List&lt;Brand&gt;.</returns>
        List<Brand> LoadBrands(string name, bool isSe= true);

        /// <summary>
        /// Loads the brands.
        /// </summary>
        /// <returns>List&lt;Brand&gt;.</returns>
        List<Brand> LoadBrands();
    }
}