﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Management.Data.Models
{
  public  class Feedback
    {
        public string FeedbackBody { get; set; }
    }
}
