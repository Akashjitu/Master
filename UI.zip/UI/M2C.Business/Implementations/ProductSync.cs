﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="ProductSync.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository;
using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.ProjectModels;
using M2C.Business.Contracts;
using M2C.Business.Helpers;
using M2C.Business.Mappers;
using M2C.Business.Mappers.ProjectMap;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser;
using Schneider.M2C.OpenExcel.Parser.Model;
using SyncServiceLibrary.Contracts;
using SyncServiceLibrary.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class ProductSync.
    /// </summary>
    public class ProductSync : IProductSync
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProductSync" /> class.
        /// </summary>
        /// <param name="productSynchronizer">The product synchronizer.</param>
        /// <param name="projectSynchronizer">The project synchronizer.</param>
        /// <param name="syncProjectQueries">The synchronize project queries.</param>
        /// <param name="projectMapper">The project mapper.</param>
        /// <param name="projectLogic">The project logic.</param>
        /// <exception cref="ArgumentNullException">syncProjectQueries</exception>
        public ProductSync(IProductSynchronizer productSynchronizer,
            IProjectSynchronizer projectSynchronizer,
            ISyncProjectQueries syncProjectQueries,
            IProjectMapper projectMapper,
            IProjectLogic projectLogic)
        {
            this.productSynchronizer = productSynchronizer;
            this.projectSynchronizer = projectSynchronizer;
            this.syncProjectQueries = syncProjectQueries;
            this.projectMapper = projectMapper;
            this.projectLogic = projectLogic;
        }

        /// <summary>
        /// The product queries
        /// </summary>
        private readonly IProductQueries _productQueries = new ProductQueries(new ApplicationDbContextFactory());

        /// <summary>
        /// The product synchronizer
        /// </summary>
        private readonly IProductSynchronizer productSynchronizer;

        /// <summary>
        /// The project synchronizer
        /// </summary>
        private readonly IProjectSynchronizer projectSynchronizer;

        /// <summary>
        /// The synchronize project queries
        /// </summary>
        private readonly ISyncProjectQueries syncProjectQueries;

        /// <summary>
        /// The project mapper
        /// </summary>
        private readonly IProjectMapper projectMapper;

        /// <summary>
        /// The project logic
        /// </summary>
        private readonly IProjectLogic projectLogic;

        /// <summary>
        /// Synchronizes the product.
        /// </summary>
        /// <param name="action">The action.</param>
        public void SyncProduct(Action<SyncProcessModel> action)
        {
            productSynchronizer.SyncToLocal((SyncResultModel result) =>
            {
                action(new SyncProcessModel(result));
            });

            action(new SyncProcessModel() { Status = ProcessStatus.COMPLETED });
        }

        /// <summary>
        /// Synchronizes the projects.
        /// </summary>
        /// <param name="action">The action.</param>
        /// <exception cref="NotImplementedException"></exception>
        public void SyncProjects(Action<SyncProcessModel> action)
        {
            List<ProjectContextModel> Projects = GetProjectsToSync();
            int i = 0;
            foreach (ProjectContextModel prj in Projects)
            {
                i++;
                var FullProjectData = projectLogic.GetProject(prj.ProjectId ?? 0);

                action(new SyncProcessModel()
                {
                    Status = ProcessStatus.IN_PROGRESS,
                    Message = $"Syncing Project {i}/{Projects.Count}"
                });
                string jsonData = JsonConvert.SerializeObject(FullProjectData, Formatting.Indented,
                                  new JsonSerializerSettings { ContractResolver = new DynamicContractResolver("MasterInventories") });

                projectSynchronizer.SyncToServer(jsonData, FullProjectData.ProjectReferenceId,
                    FullProjectData.ProjectId ?? 0, (SyncResultModel result) =>
                    {
                        action(new SyncProcessModel(result));
                    });
            }

            action(new SyncProcessModel() { Status = ProcessStatus.COMPLETED });
        }

        /// <summary>
        /// Synchronizes the product data asynchronous.
        /// </summary>
        public void SyncProductDataAsync(string FilePath)
        {
            if (_productQueries.GetProductsByCount().Count <= 1)
            {
              SyncProductData(FilePath);
            }
        }

        /// <summary>
        /// Synchronizes the product data.
        /// </summary>
        private void SyncProductData(string filepath)
        {
            IExcelParser excelParser = new ExcelParser();
            
            try
            {
                var tsk = Task.Factory.StartNew(() =>
                {
                    return excelParser.GeModelsFromExcel<OneIbCatalog>($"{filepath}", "One IB Catalog",
                        5, 6, i => { });
                });

               var oneIbCatalogs = GetFilterOneIbCatalogs(tsk.Result);

                if (oneIbCatalogs == null) return;
                var filterOneIbCatalogs = oneIbCatalogs.ToArray();

                using (ProductQueries app = new ProductQueries(new ApplicationDbContextFactory()))
                {
                    IBrandQueries brandQueries = app;
                    IDeviceTypeQueries deviceTypeQueries = app;
                    IRangeQueries rangeQueries = app;
                    ISubRangeQueries subRangeQueries = app;
                    IProductQueries productQueries = app;
                    var t = Task.Factory.StartNew(() =>
                    {
                        brandQueries.SaveBrands(new BrandModelMapper().Map(filterOneIbCatalogs));
                        deviceTypeQueries.SaveDeviceTypes(new DeviceTypeModelMapper().Map(filterOneIbCatalogs));
                        rangeQueries.SaveRanges(new RangeModelMapper().Map(filterOneIbCatalogs));
                    });
                    t.Wait();
                    var t2 = Task.Factory.StartNew(() =>
                    {
                        var ranges = rangeQueries.LoadRanges();
                        var subrange = new SubRangeModelMapper().Map(oneIbCatalogs, ranges);
                        var products = new ProductModelMapper().Map(oneIbCatalogs, brandQueries.LoadBrands(),
                            deviceTypeQueries.LoadDeviceTypes(), ranges);

                        subRangeQueries.SaveSubRanges(subrange);
                        productQueries.SaveProducts(products);
                    });
                    t2.Wait();
                }
            }
            catch (Exception ex)
            {
                var data = ex.ToString();
            }
        }

        /// <summary>
        /// Gets the filter one ib catalogs.
        /// </summary>
        /// <param name="oneIbCatalogs">The one ib catalogs.</param>
        /// <returns>List&lt;OneIbCatalog&gt;.</returns>
        private List<OneIbCatalog> GetFilterOneIbCatalogs(List<OneIbCatalog> oneIbCatalogs)
        {
            if (oneIbCatalogs == null)
                return null;

            List<OneIbCatalog> filterBu;
            using (var app = new ProductQueries(new ApplicationDbContextFactory()))
            {
                IFilterIbCatalogBuQueries fbuQry = app;
                IFilterIbCatalogProductCategoryQueries fbcQry = app;
                IFilterIbCatalogStatusIpCreationQueries fbStatQry = app;
                var bu = fbuQry.FilterIbCatalogBu().Select(i => i.Name).ToList();
                var ipCreations = fbStatQry.FilterIbCatalogStatusIpCreations().Select(i => i.Name).ToList();
                var productCategories = fbcQry.FilterIbCatalogProductCategories().Select(i => i.Name).ToList();

                filterBu = oneIbCatalogs.Where(i => !string.IsNullOrEmpty(i.Bu) && bu.Contains(i.Bu.ToUpper())).ToList();
                filterBu = filterBu.Where(i => !string.IsNullOrEmpty(i.ProductIdentifierCategory) && productCategories.Contains(i.ProductIdentifierCategory.ToUpper())).ToList();
                filterBu = filterBu.Where(i => !string.IsNullOrEmpty(i.StatusRelevantForIpCreation) && ipCreations.Contains(i.StatusRelevantForIpCreation.ToUpper())).ToList();
            }
            return filterBu;
        }

        /// <summary>
        /// Gets the projects to synchronize.
        /// </summary>
        /// <returns>List&lt;ProjectContextModel&gt;.</returns>
        public List<ProjectContextModel> GetProjectsToSync()
        {
            List<Project> projects = syncProjectQueries.GetAllProjectsToSync();
            List<ProjectContextModel> projectContextModels = new List<ProjectContextModel>();
            for (int i = 0; i < projects.Count; i++)
            {
                Project dbModel = projects[i];
                ProjectContextModel contextModel = new ProjectContextModel();
                ProjectBusinessModelBuilder businessModelBuilder = new ProjectBusinessModelBuilder(ref dbModel, ref contextModel, null, null, new ProductQueries(new ApplicationDbContextFactory()));
                projectMapper.CreateProjectsOnlyBusinessModel(businessModelBuilder);

                projectContextModels.Add(businessModelBuilder.GetProject());
            }

            return projectContextModels;
        }
    }
}