﻿using System.Collections.Generic;

namespace Data.Management.Data.Models
{
    public class Reference
    {
        public List<Site> Sites { get; set; }

        public List<Customer> Customers { get; set; }

        public List<Program> Programs { get; set; }

        public EmployeeInfo Access { get; set; }
    }
}