﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-14-2020
// ***********************************************************************
// <copyright file="WindowClosingBehavior.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.App.ViewModels;
using M2C.Desktop.Core.ContextServices;
using Prism.Commands;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;

namespace M2C.Desktop.App.Behaviors
{
    /// <summary>
    /// WindowClosing Behavior
    /// Here on close save dialog is handled
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class WindowClosingBehavior
    {
        /// <summary>
        /// The window close command
        /// </summary>
        public static readonly ICommand WindowCloseCommand = new DelegateCommand<Window>(win => win.Close());

        /// <summary>
        /// Gets or sets the shared context object.
        /// </summary>
        /// <value>The shared context object.</value>
        private static ISharedContextService SharedContextObj { get; set; }

        /// <summary>
        /// Gets the shared context.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <returns>ISharedContextService.</returns>
        public static ISharedContextService GetSharedContext(DependencyObject obj)
        {
            return (ISharedContextService)obj.GetValue(SharedContext);
        }

        /// <summary>
        /// Sets the shared context.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="value">The value.</param>
        public static void SetSharedContext(DependencyObject obj, ISharedContextService value)
        {
            obj.SetValue(SharedContext, value);
        }

        /// <summary>
        /// The shared context
        /// </summary>
        public static readonly DependencyProperty SharedContext =
            DependencyProperty.RegisterAttached("SharedContext", typeof(ISharedContextService),
            typeof(WindowClosingBehavior),
            new UIPropertyMetadata(null, new PropertyChangedCallback(OnValueChange)));

        /// <summary>
        /// Called when [value change].
        /// </summary>
        /// <param name="d">The d.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnValueChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (!(d is Window))
            {
                return;
            }
            var window = d as Window;
            SharedContextObj = (ISharedContextService)e.NewValue;
            if (!SharedContextObj.IsSavePending)
            {
                window.Closing += Window_Closing;
            }
            else
            {
                window.Closing -= Window_Closing;
            }
        }

        /// <summary>
        /// Confirm exit
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="CancelEventArgs" /> instance containing the event data.</param>
        private static void Window_Closing(object sender, CancelEventArgs e)
        {
            e.Cancel = !ShowExitDialog(sender as Window);
        }

        /// <summary>
        /// Shows the exit dialog.
        /// </summary>
        /// <param name="window">The window.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private static bool ShowExitDialog(Window window)
        {
            if (SharedContextObj.IsSavePending)
            {
                MessageBoxResult result = MessageBox.Show(window, "Do you want to save the project before exit?",
                    "Application Exit",
                    MessageBoxButton.YesNoCancel, MessageBoxImage.Asterisk, MessageBoxResult.Yes);
                if (result == MessageBoxResult.Yes)
                {
                    MainWindowViewModel vm = window.DataContext as MainWindowViewModel;
                    vm?.GlobalMenuComands.SaveCommand.Execute("");
                }
                // added Cancel button . If User want to cancel operation.
                if (result == MessageBoxResult.Cancel)
                {
                    return false;
                }
                return true;
            }
            else
            {
                return true;
            }
        }
    }
}