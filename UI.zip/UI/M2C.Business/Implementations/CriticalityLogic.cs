﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="CriticalityLogic.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Models;
using System;
using System.Collections.Generic;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class CriticalityLogic.
    /// Implements the <see cref="M2C.Business.Contracts.ICriticalityLogic" />
    /// </summary>
    /// <seealso cref="M2C.Business.Contracts.ICriticalityLogic" />
    public class CriticalityLogic : ICriticalityLogic
    {
        /// <summary>
        /// Function to calculate  the criticality
        /// </summary>
        /// <param name="safety">The safety.</param>
        /// <param name="quality">The quality.</param>
        /// <param name="leadTime">The lead time.</param>
        /// <param name="costsIssue">The costs issue.</param>
        /// <returns>CriticalityValue.</returns>
        public CriticalityValue CalculateCriticality(int safety, string quality, string leadTime, string costsIssue)
        {
            double roundedValue;
            double qualityValue = GetTheParametrValue(quality);
            double leadTimeValue = GetTheParametrValue(leadTime);
            double costsIssueTime = GetTheParametrValue(costsIssue);

            double averageValue = (qualityValue + leadTimeValue + costsIssueTime) / 3;
            if (Math.Abs(averageValue - 2.5) < 0.0001)
                roundedValue = 2;
            else
                roundedValue = Math.Round(averageValue);

            switch (roundedValue)
            {
                case (int)CriticalityValue.Critical:
                    return CriticalityValue.Critical;

                case (int)CriticalityValue.Not_Critical:
                    return CriticalityValue.Not_Critical;

                case (int)CriticalityValue.Somewhat_Critical:
                    return CriticalityValue.Somewhat_Critical;

                case (int)CriticalityValue.Very_Critical:
                    return CriticalityValue.Very_Critical;
            }
            return CriticalityValue.Not_Critical;
        }

        /// <summary>
        /// function to check the value for each parameter
        /// </summary>
        /// <param name="quality">The quality.</param>
        /// <returns>System.Double.</returns>
        private static double GetTheParametrValue(string quality)
        {
            double qualityValue = 0.0;
            switch (quality)
            {
                case CriticalitystringValues.LOW_IMPACT:
                    qualityValue = QualityParametrValue.Low_Impact;
                    break;

                case CriticalitystringValues.AVERAGE_IMPACT:
                    qualityValue = QualityParametrValue.Average_Impact;
                    break;

                case CriticalitystringValues.HIGH_IMPACT:
                    qualityValue = QualityParametrValue.High_ImpactT;
                    break;

                case CriticalitystringValues.VERY_HIGH_IMPACT:
                    qualityValue = QualityParametrValue.Very_high_Impact;
                    break;
            }

            return qualityValue;
        }

        /// <summary>
        /// To get the parameters
        /// </summary>
        /// <returns>List&lt;System.String&gt;.</returns>

        public List<string> GetCriticalityParameters()
        {
            return new List<string>()
                                      { CriticalitystringValues.LOW_IMPACT,
                                        CriticalitystringValues.AVERAGE_IMPACT,
                                         CriticalitystringValues.HIGH_IMPACT,
                                         CriticalitystringValues.VERY_HIGH_IMPACT
                                      };
        }
    }
}