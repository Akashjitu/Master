﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SyncHistory.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DomainModels.IbCatalogModels
{
    /// <summary>
    /// Class SyncHistory.
    /// </summary>
    public class SyncHistory
    {
        // <summary>
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the synchronize date.
        /// </summary>
        /// <value>The synchronize date.</value>
        public DateTime SyncDate { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>The status.</value>
        public int Status { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the retry count.
        /// </summary>
        /// <value>The retry count.</value>
        public int RetryCount { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>The version.</value>
        public double Version { get; set; }

        // <summary>
        /// <summary>
        /// Gets or sets the synchronize identifier.
        /// </summary>
        /// <value>The synchronize identifier.</value>
        [Key]
        public string SyncId { get; set; }

        
    }
}
