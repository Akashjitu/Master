﻿using M2C.Business.Contracts;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.Navigation.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using Prism.Services.Dialogs;

namespace M2C.UI.Tests.NavigationModule
{
    [TestClass]
    public class MainRibbonBarViewModelTest : TestBase
    {
        private Mock<IGlobalMenuComands> mockGlobalMenuComands;
        private Mock<IDialogService> mockDialogService;
        private Mock<IEventAggregator> mockEventAggregator;
        private Mock<IRegionManager> mockIRegionManager;
        private Mock<IFileOpenDialogue> mockIFileOpenDialogue;
        private Mock<IProjectLogic> mockIProjectLogic;
        private Mock<ISharedContextService> mockISharedContextService;
        private Mock<IMyProfileLogic> mockIMyProfileLogic;
        private Mock<ITemplateDownloadLogic> mockITemplateDownloadLogic;
        private Mock<IProductSync> mockIProductSync;

        [TestInitialize]
        public void TestIniTialize()
        {
            mockGlobalMenuComands = MockRepo.Create<IGlobalMenuComands>();
            mockGlobalMenuComands.SetupGet(x => x.NewProjectCommand).Returns(new CompositeCommand());
            mockGlobalMenuComands.SetupGet(x => x.SaveCommand).Returns(new CompositeCommand());
            mockGlobalMenuComands.SetupGet(x => x.ExportProjectCommand).Returns(new CompositeCommand());
            mockDialogService = MockRepo.Create<IDialogService>();
            mockEventAggregator = MockRepo.Create<IEventAggregator>();
            mockIRegionManager = MockRepo.Create<IRegionManager>();
            mockIFileOpenDialogue = MockRepo.Create<IFileOpenDialogue>();
            mockIProjectLogic = MockRepo.Create<IProjectLogic>();
            mockISharedContextService = MockRepo.Create<ISharedContextService>();
            mockIMyProfileLogic = MockRepo.Create<IMyProfileLogic>();
            mockITemplateDownloadLogic = MockRepo.Create<ITemplateDownloadLogic>();
            mockIProductSync = MockRepo.Create<IProductSync>();
        }

        [TestMethod]
        public void MainRibbonBarViewModelObjectTest()
        {
            mockEventAggregator.Setup(t => t.GetEvent<ProjectChangeEvent>()).Returns(new ProjectChangeEvent());
            MainRibbonBarViewModel vm = new MainRibbonBarViewModel(mockGlobalMenuComands.Object,
                                    mockDialogService.Object, mockEventAggregator.Object,
                                    mockIRegionManager.Object, mockIFileOpenDialogue.Object, mockIProjectLogic.Object, mockISharedContextService.Object,
                                    mockIMyProfileLogic.Object, mockITemplateDownloadLogic.Object, mockIProductSync.Object);
            if (vm.GlobalMenuComands != null)
                Assert.IsTrue(true, "MainWindowViewModel Created");
        }
    }
}