﻿// ***********************************************************************
// Assembly         : M2CRenewalApplication
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="AppSplashScreen.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using SchneiderElectric.BrandIdentity.Windows;
using System;
using System.Timers;
using System.Windows.Threading;

namespace M2C.Desktop.App.Core.Splash
{
    /// <summary>
    /// M2C splash Screen component
    /// </summary>
    internal class AppSplashScreen
    {
        /// <summary>
        /// The automatic close enabled
        /// </summary>
        private bool _autoCloseEnabled = true;
        /// <summary>
        /// The splash screen
        /// </summary>
        private readonly SchneiderElectric.BrandIdentity.Windows.SplashScreen _splashScreen = null;
        /// <summary>
        /// The UI dispacter
        /// </summary>
        private Dispatcher _uiDispacter = null;

        /// <summary>
        /// Property for Updating progress of process
        /// </summary>
        /// <value>The progress information.</value>
        public ProgressInfo ProgressInfo { get; set; } = new ProgressInfo();

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="screen">The screen.</param>
        public AppSplashScreen(SchneiderElectric.BrandIdentity.Windows.SplashScreen screen)
        {
            _splashScreen = screen;
        }

        /// <summary>
        /// Show M2C splash Screen
        /// </summary>
        /// <param name="autoClose">if set to <c>true</c> [automatic close].</param>
        public void Show(bool autoClose)
        {
            _autoCloseEnabled = autoClose;

            if (_autoCloseEnabled)
            {
                _splashScreen.Show();
            }
            else
            {
                _splashScreen.ProgressInfo = ProgressInfo;
                _splashScreen.Show();
            }
        }

        /// <summary>
        /// Close M2C splash Screen
        /// </summary>
        /// <param name="timeSpan">The time span.</param>
        public void Close(TimeSpan timeSpan)
        {
            _uiDispacter = Dispatcher.CurrentDispatcher;

            if (timeSpan != TimeSpan.Zero) { getTimer(timeSpan.TotalMilliseconds).Start(); } else { _splashScreen.Close(false); }
        }

        /// <summary>
        /// Gets the timer.
        /// </summary>
        /// <param name="interval">The interval.</param>
        /// <returns>System.Timers.Timer.</returns>
        private System.Timers.Timer getTimer(double interval)
        {
            Timer timer = new System.Timers.Timer(interval);
            timer.Elapsed += Timer_Elapsed;
            timer.AutoReset = false;
            return timer;
        }

        /// <summary>
        /// Handles the Elapsed event of the Timer control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ElapsedEventArgs" /> instance containing the event data.</param>
        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _uiDispacter?.Invoke(() => { _splashScreen.Close(false); });
        }
    }
}