﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="UIConstants.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace M2C.Desktop.Core.Constants
{
    /// <summary>
    /// UI Layer Constants
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class UIConstants
    {
        /// <summary>
        /// The projectcontext
        /// </summary>
        public const string PROJECTCONTEXT = "ProjectContext";

        /// <summary>
        /// The factory
        /// </summary>
        public const string FACTORY = "Factory";

        /// <summary>
        /// The workshop
        /// </summary>
        public const string WORKSHOP = "Workshop";

        /// <summary>
        /// The line
        /// </summary>
        public const string LINE = "Line";

        /// <summary>
        /// The machine
        /// </summary>
        public const string MACHINE = "Machine";

        /// <summary>
        /// The PLC configuration
        /// </summary>
        public const string PLC_CONFIGURATION = "PLC Configuration";

        /// <summary>
        /// The motion drive configuration
        /// </summary>
        public const string MOTION_DRIVE_CONFIGURATION = "Motion & Drive Configuration";

        /// <summary>
        /// The scada hmi configuration
        /// </summary>
        public const string SCADA_HMI_CONFIGURATION = "Scada HMI Configuration";

        /// <summary>
        /// The open configuration
        /// </summary>
        public const string OPEN_CONFIGURATION = "Open Configuration";

        /// <summary>
        /// The maintenance zone
        /// </summary>
        public const string MAINTENANCE_ZONE = "Maintenance zone";

        /// <summary>
        /// The addmaintenancezone
        /// </summary>
        public const string ADDMAINTENANCEZONE = "Add Maintenance zone";

        /// <summary>
        /// The cap maintenancezone
        /// </summary>
        public const string CAP_MAINTENANCEZONE = "MAINTENANCEZONE";

        /// <summary>
        /// The stock
        /// </summary>
        public const string STOCK = "Stock";

        /// <summary>
        /// The competencies
        /// </summary>
        public const string COMPETENCIES = "Competencies";

        /// <summary>
        /// The add stock
        /// </summary>
        public const string ADD_STOCK = "Add Stock";

        /// <summary>
        /// The add competencies
        /// </summary>
        public const string ADD_COMPETENCIES = "Add Competencies";

        /// <summary>
        /// The error
        /// </summary>
        public const string ERROR = "ERROR";

        /// <summary>
        /// The disposableregionbehavior
        /// </summary>
        public const string DISPOSABLEREGIONBEHAVIOR = "DisposableRegionBehavior";

        /// <summary>
        /// cancel message for Save project
        /// </summary>
        public const string SaveCancelMessage = "Do you want to cancel project creation?";
        /// <summary>
        /// cancel message for Edit project
        /// </summary>
        public const string EditCancelMessage = "Do you want to cancel?";

        /// <summary>
        /// The project property header
        /// </summary>
        public const string ProjectPropertyHeader = "Project Properties";
        /// <summary>
        /// The project create header
        /// </summary>
        public const string ProjectCreateHeader= "Project Creation";

        /// <summary>
        /// The accesstoken
        /// </summary>
        public const string ACCESSTOKEN = "Accesstoken";
        /// <summary>
        /// The m2 c login
        /// </summary>
        public const string M2C_LOGIN = "M2C Login";
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>The code.</value>
        public static string CODE { get; set; } = "code";
        /// <summary>
        /// Gets or sets the idmserror.
        /// </summary>
        /// <value>The idmserror.</value>
        public static string IDMSERROR { get; set; } = "error";
    }
}