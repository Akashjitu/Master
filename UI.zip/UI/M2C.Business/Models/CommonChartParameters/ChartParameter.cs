﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ChartParameter.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;
using System.Collections.ObjectModel;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using Prism.Mvvm;

namespace M2C.Business.Models.CommonChartParameters
{
    /// <summary>
    /// Class ChartParameter.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ChartParameter : BindableBase
    {
        /// <summary>
        /// The select inventory type
        /// </summary>
        private string _selectInventoryType;
        /// <summary>
        /// The selected year
        /// </summary>
        private int _selectedYear;
        /// <summary>
        /// The select chart mapping
        /// </summary>
        private string _selectChartMapping;
        /// <summary>
        /// The selected element number
        /// </summary>
        private string _selectedElementNumber;
        /// <summary>
        /// The selected node
        /// </summary>
        private INode _selectedNode;
        /// <summary>
        /// The selected parameter node
        /// </summary>
        private ChartParameterNode _selectedParameterNode;
        /// <summary>
        /// The chart parameter nodes
        /// </summary>
        private ObservableCollection<ChartParameterNode> _chartParameterNodes;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChartParameter" /> class.
        /// </summary>
        public ChartParameter()
        {
            AllParameterNodes= new ObservableCollection<ChartParameterNode>();
           // AllNodesByType = new Dictionary<NodeType, List<INode>>();
        }

        /// <summary>
        /// Get Set Select Inventory From Combo Type
        /// </summary>
        /// <value>The type of the select inventory.</value>
        public string SelectInventoryType { get => _selectInventoryType; set => SetProperty(ref _selectInventoryType, value); }

        /// <summary>
        /// Current Selected Year
        /// </summary>
        /// <value>The selected year.</value>
        public int SelectedYear { get => _selectedYear; set => SetProperty(ref _selectedYear, value); }

        /// <summary>
        /// Get Set Select Inventory From Combo Type
        /// </summary>
        /// <value>The select chart mapping.</value>
        public string SelectChartMapping { get => _selectChartMapping; set => SetProperty(ref _selectChartMapping, value); }

        /// <summary>
        /// Selected Tree node Header
        /// </summary>
        /// <value>The selected parameter node.</value>
        public ChartParameterNode SelectedParameterNode { get => _selectedParameterNode; set => SetProperty(ref _selectedParameterNode, value); }


        /// <summary>
        /// Selected Tree node Header
        /// </summary>
        /// <value>The selected element number.</value>
        public string SelectedElementNumber { get => _selectedElementNumber; set => SetProperty(ref _selectedElementNumber, value); }

        /// <summary>
        /// Selected  Node
        /// </summary>
        /// <value>The selected node.</value>
        public INode SelectedNode { get => _selectedNode; set => SetProperty(ref _selectedNode, value); }


        /// <summary>
        /// Collection of all Chart Parameter Nodes
        /// </summary>
        /// <value>All parameter nodes.</value>
        public ObservableCollection<ChartParameterNode> AllParameterNodes
        {
            get => _chartParameterNodes;
            set => SetProperty(ref _chartParameterNodes, value);
        }
    }
}