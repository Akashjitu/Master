﻿using M2C.Business.Models;
using M2C.Business.Models.Project.IBComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.ObjectModel;

namespace M2C.Business.Test.Models.Project.IBComponents
{
    [TestClass]
    public class NodeTest
    {
        private Node _node;

        [TestInitialize]
        public void Setup()
        {
            _node = new Node { MasterInventories = new ObservableCollection<Inventory>() };
        }

        [TestMethod]
        [DataRow(NodeType.FACTORY, "FACTORY1")]
        [DataRow(NodeType.WORKSHOP, "WORKSHOP1")]
        [DataRow(NodeType.MACHINE, "MACHINE1")]
        [DataRow(NodeType.LINE, "LINE1")]
        [DataRow(NodeType.PLC_CONFIG, "PLC_CONFIG1")]
        [DataRow(NodeType.MD_CONFIG, "MD_CONFIG1")]
        [DataRow(NodeType.OPEN_CONFIG, "OPEN_CONFIG1")]
        [DataRow(NodeType.SHMI_CONFIG, "SHMI_CONFIG1")]
        [DataRow(NodeType.NONE, null)]
        public void ShouldReturnInventoriesBasedOnTheNodeType(NodeType nodeType, string name)
        {
            _node.NodeType = nodeType;
            _node.Name = name;

            var result = _node.Inventories;
            Assert.IsNotNull(result);
            //Assert.IsTrue(result.Any()i=>i.)
        }
    }
}