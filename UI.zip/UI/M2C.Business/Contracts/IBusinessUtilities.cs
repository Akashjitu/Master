﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IBusinessUtilities.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using System.Collections.Generic;

namespace M2C.Business.Contracts
{
    /// <summary>
    /// Interface IBusinessUtilities
    /// </summary>
    public interface IBusinessUtilities
    {
        /// <summary>
        /// Gets the countries.
        /// </summary>
        /// <returns>List&lt;CountryModel&gt;.</returns>
        List<CountryModel> getCountries();
        /// <summary>
        /// Gets the positions.
        /// </summary>
        /// <returns>List&lt;PositionModel&gt;.</returns>
        List<PositionModel> getPositions();
    }
}