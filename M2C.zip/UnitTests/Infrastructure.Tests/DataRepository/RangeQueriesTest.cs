﻿using DataRepository.DBContracts;
using DataRepository.Queries;
using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Range = DomainModels.IbCatalogModels.Range;

namespace Infrastructure.Tests.DataRepository
{
    [TestClass]
    public class RangeQueriesTest : TestBase
    {
        private IQueryable<Range> rangeList;
        private Mock<DbSet<Range>> rangeMock;

        private IQueryable<Product> productList;
        private Mock<DbSet<Product>> productMock;

        [TestInitialize]
        public void TestIniTialize()
        {
            Range rangeObj = new Range() { Id = 1, Name = "Range1" };
            List<Range> range = new List<Range>() { rangeObj };
            rangeList = range.AsQueryable();

            Product prodObj = new Product() { Id = 1, Brand = new Brand(), Range = new DomainModels.IbCatalogModels.Range(), BrandId = 1, DeviceTypeId = 1 };
            List<Product> product = new List<Product>() { prodObj };
            productList = product.AsQueryable();

            IDbContextFactoryMock = MockRepo.Create<IDbContextFactory>();
            IProductDbContextMock = MockRepo.Create<IProductDbContext>();
            rangeMock = MockRepo.Create<DbSet<Range>>();
            rangeMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(rangeList.Provider);
            rangeMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(rangeList.Expression);
            rangeMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(rangeList.ElementType);
            rangeMock.As<IQueryable<Range>>().Setup(m => m.GetEnumerator()).Returns(rangeList.GetEnumerator());
            IProductDbContextMock.Setup(x => x.Ranges).Returns(rangeMock.Object);

            productMock = MockRepo.Create<DbSet<Product>>();
            productMock.As<IQueryable<Brand>>().Setup(m => m.Provider).Returns(productList.Provider);
            productMock.As<IQueryable<Brand>>().Setup(m => m.Expression).Returns(productList.Expression);
            productMock.As<IQueryable<Brand>>().Setup(m => m.ElementType).Returns(productList.ElementType);
            productMock.As<IQueryable<Product>>().Setup(m => m.GetEnumerator()).Returns(productList.GetEnumerator());//added
            IProductDbContextMock.Setup(x => x.Products).Returns(productMock.Object);

            IDbContextFactoryMock.Setup(t => t.Create<IProductDbContext>()).Returns(IProductDbContextMock.Object);
        }

        [TestMethod]
        public void RangeQueriesConstructorTest()
        {
            IRangeQueries range = new ProductQueries(IDbContextFactoryMock.Object);
            range.Should().NotBeNull();
            ((IDisposable)range).Dispose();
        }

        [TestMethod]
        public void RangeQueriesSaveRangesTest()
        {
            Range rangeObject = new Range() { Id = 1, Name = "Range1" };
            List<Range> rangeLists = new List<Range>() { rangeObject };
            IRangeQueries range = new ProductQueries(IDbContextFactoryMock.Object);

            Action action = () => range.SaveRanges(null);
            action.Should().NotThrow();
            action = () => range.SaveRanges(rangeLists);
            action.Should().NotThrow();
            rangeObject.Id = 0;
            rangeObject.Name = "Range2";
            action = () => range.SaveRanges(rangeLists);
            action.Should().NotThrow();

            ((IDisposable)range).Dispose();
        }

        [TestMethod]
        public void RangeQueriesLoadRangesTest()
        {
            IRangeQueries range = new ProductQueries(IDbContextFactoryMock.Object);
            List<Range> rangeRes = range.LoadRanges();
            rangeRes.Should().HaveCount(1);
            ((IDisposable)range).Dispose();
        }

        [TestMethod]
        public void RangeQueriesLoadRangesByRangeTest()
        {
            Range ranges = new Range() { Id = 1, Name = "Range1" };

            IRangeQueries range = new ProductQueries(IDbContextFactoryMock.Object);
            List<Range> rangeRes = range.LoadRanges(null);
            rangeRes.Should().BeNull();
            rangeRes = range.LoadRanges(ranges);
            rangeRes.Should().HaveCount(1);

            ((IDisposable)range).Dispose();
        }

        [TestMethod]
        public void RangeQueriesGetRangeByBrandTest()
        {
            int brandId = 1;
            IRangeQueries range = new ProductQueries(IDbContextFactoryMock.Object);

            List<Range> rangeRes = range.GetRangeByBrand(brandId);
            rangeRes.Should().HaveCount(1);
            ((IDisposable)range).Dispose();
        }

        [TestMethod]
        public void RangeQueriesGetRangeByBrandAndDeviceTypeIdsTest()
        {
            int brandId = 1;
            int deviceTypeId = 1;
            IRangeQueries range = new ProductQueries(IDbContextFactoryMock.Object);
            List<Range> rangeRes = range.GetRangeByBrandAndDeviceTypeIds(brandId, deviceTypeId);
            rangeRes.Should().HaveCount(1);
            ((IDisposable)range).Dispose();
        }

        [TestMethod]
        public void RangeQueriesGetRangeByDeviceIdTest()
        {
            int deviceId = 1;
            IRangeQueries range = new ProductQueries(IDbContextFactoryMock.Object);
            List<Range> rangeRes = range.GetRangeByDeviceId(deviceId);
            rangeRes.Should().HaveCount(1);
            ((IDisposable)range).Dispose();
        }
    }
}