﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ContactModel.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.ModelValidators;
using Newtonsoft.Json;
using Prism.Mvvm;
using System;

namespace M2C.Business.Models.Project
{
    /// <summary>
    /// Class ContactModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class ContactModel : BindableBase
    {
        /// <summary>
        /// Clones the specified source.
        /// </summary>
        /// <param name="source">The source.</param>
        /// <returns>ContactModel.</returns>
        public static ContactModel Clone(ContactModel source)
        {
            return new ContactModel();
        }

        /// <summary>
        /// The first name
        /// </summary>
        private string firstName;
        /// <summary>
        /// The last name
        /// </summary>
        private string lastName;
        /// <summary>
        /// The email
        /// </summary>
        private string email;
        /// <summary>
        /// The street
        /// </summary>
        private string street;
        /// <summary>
        /// The town
        /// </summary>
        private string town;
        /// <summary>
        /// The postal code
        /// </summary>
        private string postalCode;
        /// <summary>
        /// The region
        /// </summary>
        private string region;
        /// <summary>
        /// The telephone
        /// </summary>
        private string telephone;
        /// <summary>
        /// The mobile number
        /// </summary>
        private string mobileNumber;
        /// <summary>
        /// The fax
        /// </summary>
        private string fax;
        /// <summary>
        /// The country
        /// </summary>
        private CountryModel country;
        /// <summary>
        /// The position
        /// </summary>
        private PositionModel position;

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        [JsonIgnore]
        public int Id { get; set; }
        /// <summary>
        /// Gets or sets the project identifier.
        /// </summary>
        /// <value>The project identifier.</value>
        [JsonIgnore]
        public int ProjectId { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is linked.
        /// </summary>
        /// <value><c>true</c> if this instance is linked; otherwise, <c>false</c>.</value>
        public bool IsLinked { get; set; }

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>The first name.</value>
        public string FirstName { get => firstName; set => SetProperty(ref firstName, value); }
        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>The last name.</value>
        public string LastName { get => lastName; set => SetProperty(ref lastName, value); }

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>The email.</value>
        /// <exception cref="ApplicationException">Invalid Email format</exception>
        public string Email
        {
            get => email; set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidEmail(value))
                {
                    SetProperty(ref email, null);
                    throw new ApplicationException("Invalid Email format");
                }
                SetProperty(ref email, value);
            }
        }

        /// <summary>
        /// Gets or sets the street.
        /// </summary>
        /// <value>The street.</value>
        public string Street { get => street; set => SetProperty(ref street, value); }

        /// <summary>
        /// Gets or sets the town.
        /// </summary>
        /// <value>The town.</value>
        public string Town { get => town; set => SetProperty(ref town, value); }

        /// <summary>
        /// Gets or sets the postal code.
        /// </summary>
        /// <value>The postal code.</value>
        /// <exception cref="ApplicationException">Invalid postal code format</exception>
        public string PostalCode
        {
            get => postalCode; set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsvalidZipCode(value))
                {
                    SetProperty(ref postalCode, value);
                    throw new ApplicationException("Invalid postal code format");
                }
                SetProperty(ref postalCode, value);
            }
        }

        /// <summary>
        /// Gets or sets the region.
        /// </summary>
        /// <value>The region.</value>
        public string Region { get => region; set => SetProperty(ref region, value); }

        /// <summary>
        /// Gets or sets the telephone.
        /// </summary>
        /// <value>The telephone.</value>
        /// <exception cref="ApplicationException">Invalid TelePhone format</exception>
        public string Telephone
        {
            get => telephone; set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidPhone(value))
                {
                    SetProperty(ref telephone, null);
                    throw new ApplicationException("Invalid TelePhone format");
                }
                SetProperty(ref telephone, value);
            }
        }

        /// <summary>
        /// Gets or sets the mobile number.
        /// </summary>
        /// <value>The mobile number.</value>
        /// <exception cref="ApplicationException">Invalid MobilePhone format</exception>
        public string MobileNumber
        {
            get => mobileNumber; set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidPhone(value))
                {
                    SetProperty(ref mobileNumber, null);
                    throw new ApplicationException("Invalid MobilePhone format");
                }
                SetProperty(ref mobileNumber, value);
            }
        }

        /// <summary>
        /// Gets or sets the fax.
        /// </summary>
        /// <value>The fax.</value>
        /// <exception cref="ApplicationException">Invalid fax format</exception>
        public string Fax
        {
            get => fax; set
            {
                if (!string.IsNullOrEmpty(value) && !FormatValidators.IsValidFax(value))
                {
                    SetProperty(ref fax, null);
                    throw new ApplicationException("Invalid fax format");
                }
                SetProperty(ref fax, value);
            }
        }

        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>The country.</value>
        public CountryModel Country
        {
            get => country;
            set => SetProperty(ref country, value);
        }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>The position.</value>
        public PositionModel Position
        {
            get => position; set => SetProperty(ref position, value);
        }

        /// <summary>
        /// The contact type
        /// </summary>
        private ContactType contactType = ContactType.CUSTOMER;
        /// <summary>
        /// Gets or sets the type of the contact.
        /// </summary>
        /// <value>The type of the contact.</value>
        public ContactType ContactType { get => contactType; set => SetProperty(ref contactType, value); }

        /// <summary>
        /// Gets or sets the created.
        /// </summary>
        /// <value>The created.</value>
        public DateTime Created { get; set; }
        /// <summary>
        /// Gets or sets the updated.
        /// </summary>
        /// <value>The updated.</value>
        public DateTime Updated { get; set; }

        /// <summary>
        /// Determines whether this instance is empty.
        /// </summary>
        /// <returns><c>true</c> if this instance is empty; otherwise, <c>false</c>.</returns>
        public bool IsEmpty()
        {
            return string.IsNullOrEmpty(this.FirstName);
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is default contact.
        /// </summary>
        /// <value><c>true</c> if this instance is default contact; otherwise, <c>false</c>.</value>
        public bool IsDefaultContact { get; set; }
    }
}