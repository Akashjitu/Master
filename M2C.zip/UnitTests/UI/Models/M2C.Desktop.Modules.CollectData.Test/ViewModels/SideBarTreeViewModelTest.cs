﻿using M2C.Business.Contracts;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.ViewModels;

//sing M2C.UI.Tests;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Prism.Commands;
using Prism.Events;
using Prism.Services.Dialogs;
using System;
using M2C.Business.Mappers;
using M2C.Business.Models.Project;
using M2C.Desktop.Core.Constants;
using NSubstitute;

namespace M2C.Desktop.Modules.CollectData.Test.ViewModels
{
    [TestClass]
    public class SideBarTreeViewModelTest : TestBase
    {
        private Mock<IGlobalIBComponentsCommand> mockGlobalIBCommand;
        private Mock<IDialogService> mockDialogService;
        private Mock<IEventAggregator> mockEventAggregator;
        private Mock<IExcelImport> mockExcelImport;
        private Mock<IExcelExport> mockExcelExport;
        private Mock<ISharedContextService> mocksharedContextService;
        private SideBarTreeViewModel sideBarTreeViewModelObj;
        private Mock<IInventoryMapper> _inventoryMapper;
        protected Mock<IDialogService> dialogServiceMock = new Mock<IDialogService>();
        private Mock<IFileOpenDialogue> mockFileOpenDialogue = new Mock<IFileOpenDialogue>();

        [TestInitialize]
        public void TestIniTialize()
        {
            _inventoryMapper =  MockRepo.Create<IInventoryMapper>();
            mockGlobalIBCommand = MockRepo.Create<IGlobalIBComponentsCommand>();
            mockGlobalIBCommand.SetupGet(x => x.AddNodeCommand).Returns(new CompositeCommand());
            mockGlobalIBCommand.SetupGet(x => x.ImportIBComponenetCommand).Returns(new CompositeCommand());
            mockGlobalIBCommand.SetupGet(x => x.ExportIBComponenetCommand).Returns(new CompositeCommand());
            mockDialogService = MockRepo.Create<IDialogService>();
            mockEventAggregator = MockRepo.Create<IEventAggregator>();
            mockExcelImport = MockRepo.Create<IExcelImport>();
            mockExcelExport = MockRepo.Create<IExcelExport>();
            mocksharedContextService = MockRepo.Create<ISharedContextService>();
            mocksharedContextService.Setup(x => x.Get<ProjectContextModel>(It.IsAny<string>())).Returns(new ProjectContextModel());
            mockFileOpenDialogue = MockRepo.Create<IFileOpenDialogue>();
        }

        [TestMethod]
        public void SideBarTreeViewModelObjectTest()
        {
            mockEventAggregator.Setup(t => t.GetEvent<ProjectChangeEvent>()).Returns(new ProjectChangeEvent());
            sideBarTreeViewModelObj = new SideBarTreeViewModel(mockGlobalIBCommand.Object, mocksharedContextService.Object, mockEventAggregator.Object, mockExcelImport.Object, mockFileOpenDialogue.Object, mockExcelExport.Object, _inventoryMapper.Object);
            if (sideBarTreeViewModelObj.ComponentsCommand != null)
                Assert.IsTrue(true, "SideBarTreeViewModel Created");
        }

        [TestMethod]
        public void OnImportIbComponenetTest()
        {
            mockEventAggregator.Setup(t => t.GetEvent<ProjectChangeEvent>()).Returns(new ProjectChangeEvent());
            sideBarTreeViewModelObj = new SideBarTreeViewModel(mockGlobalIBCommand.Object, mocksharedContextService.Object, mockEventAggregator.Object, mockExcelImport.Object, mockFileOpenDialogue.Object, mockExcelExport.Object, _inventoryMapper.Object);
            mockFileOpenDialogue.Setup(x => x.ShowDialog()).Returns(true);
            mockFileOpenDialogue.Setup(x => x.FileName).Returns(@"MOCK\LIstMachine.xlsx");
            mockExcelImport.Setup(x => x.IBComponentImport(@"MOCK\LIstMachine.xlsx", new InstalledBase()));
            Assert.IsNotNull(sideBarTreeViewModelObj.ComponentsCommand.ImportIBComponenetCommand);
            sideBarTreeViewModelObj.OnImportIbComponenet();
        }

        [TestMethod]
        [Ignore]
        public void onImportIbComponenetNegativeTest()
        {
            sideBarTreeViewModelObj = new SideBarTreeViewModel(mockGlobalIBCommand.Object, mocksharedContextService.Object, mockEventAggregator.Object, mockExcelImport.Object, mockFileOpenDialogue.Object, mockExcelExport.Object, _inventoryMapper.Object);
            mockFileOpenDialogue.Setup(x => x.ShowDialog()).Returns(true);
            mockFileOpenDialogue.Setup(x => x.FileName).Returns(@"MOCK\Invalid.xlsx");
            mockExcelImport.Setup(x => x.IBComponentImport(@"MOCK\Invalid.xlsx", new InstalledBase())).Throws<ApplicationException>();
            Assert.IsNotNull(sideBarTreeViewModelObj.ComponentsCommand.ImportIBComponenetCommand);
            sideBarTreeViewModelObj.OnImportIbComponenet();
        }
    }
}