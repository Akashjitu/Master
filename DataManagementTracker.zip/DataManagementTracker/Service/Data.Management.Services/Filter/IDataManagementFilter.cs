﻿using DataManagement.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Management.Services.Filter
{
    public interface IDataManagementFilter
    {
        List<DataManagementTrack> FilterAccess(string eid, List<DataManagementTrack> dataManagementTrack);
    }
}
