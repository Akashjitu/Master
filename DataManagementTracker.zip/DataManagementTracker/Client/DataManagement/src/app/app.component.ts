import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataManagementService } from './services/data-management.service';
import { ReferenceService } from './services/referenceService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'PseNpiDashboard';
  constructor(private router: Router,private service: DataManagementService,   public referenceService: ReferenceService,) { }

  ngOnInit() {
  //  this.service.getAlDataManagement();
  this.referenceService.getAllReference();
  this.service.getAlDataManagement();
    this.router.navigate(['home']);
    console.log('Clicked ' + JSON.stringify(event));
  

  }
  onNavigate(event){
 console.log('onNavigate event' + event);
  }
}
