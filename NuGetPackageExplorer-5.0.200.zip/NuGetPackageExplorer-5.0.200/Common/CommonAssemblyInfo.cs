using System.Resources;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US")]
