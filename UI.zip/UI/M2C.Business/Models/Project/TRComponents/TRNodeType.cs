﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 01-21-2020
// ***********************************************************************
// <copyright file="TRNodeType.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Business.Models.Project.TRComponents
{
    /// <summary>
    /// Technical resource node type
    /// </summary>
    public enum TRNodeType
    {
        /// <summary>
        /// The none
        /// </summary>
        NONE = 0,
        /// <summary>
        /// The technicalresource
        /// </summary>
        TECHNICALRESOURCE,
        /// <summary>
        /// The maintenancezone
        /// </summary>
        MAINTENANCEZONE,
        /// <summary>
        /// The stock
        /// </summary>
        STOCK,
        /// <summary>
        /// The competencies
        /// </summary>
        COMPETENCIES
    }
}