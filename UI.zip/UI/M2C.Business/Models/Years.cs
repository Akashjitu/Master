﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-28-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Years.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;

namespace M2C.Business.Models
{

    /// <summary>
    /// class to manage year
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Years : BindableBase
    {
        /// <summary>
        /// The year
        /// </summary>
        private string _year;
        /// <summary>
        /// The year1
        /// </summary>
        private string _year1;
        /// <summary>
        /// The year2
        /// </summary>
        private string _year2;
        /// <summary>
        /// The year3
        /// </summary>
        private string _year3;
        /// <summary>
        /// The year4
        /// </summary>
        private string _year4;

        /// <summary>
        /// Gets or sets the year.
        /// </summary>
        /// <value>The year.</value>
        public string Year
        {
            get => _year;
            set => SetProperty(ref _year, value);
        }
        /// <summary>
        /// Gets or sets the year1.
        /// </summary>
        /// <value>The year1.</value>
        public string Year1
        {
            get => _year1;
            set => SetProperty(ref _year1, value);
        }
        /// <summary>
        /// Gets or sets the year2.
        /// </summary>
        /// <value>The year2.</value>
        public string Year2
        {
            get => _year2;
            set => SetProperty(ref _year2, value);
        }
        /// <summary>
        /// Gets or sets the year3.
        /// </summary>
        /// <value>The year3.</value>
        public string Year3
        {
            get => _year3;
            set => SetProperty(ref _year3, value);
        }
        /// <summary>
        /// Gets or sets the year4.
        /// </summary>
        /// <value>The year4.</value>
        public string Year4
        {
            get => _year4; set => SetProperty(ref _year4, value);
        }
    }
}