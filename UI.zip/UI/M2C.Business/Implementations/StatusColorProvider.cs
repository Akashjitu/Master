﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-08-2020
// ***********************************************************************
// <copyright file="StatusColorProvider.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Business.Implementations
{
    /// <summary>
    /// Class StatusColorProvider.
    /// Implements the <see cref="M2C.Business.Implementations.IStatusColorProvider" />
    /// </summary>
    /// <seealso cref="M2C.Business.Implementations.IStatusColorProvider" />
    public class StatusColorProvider : IStatusColorProvider
    {

        /// <summary>
        /// Get Color based year
        /// </summary>
        /// <param name="fromDate">For Which Year you want to color</param>
        /// <param name="dosa">year of dosa</param>
        /// <param name="dos">year of dos</param>
        /// <param name="eos">year of eos</param>
        /// <returns>Name of the color</returns>
        public string GetYearColor(int fromDate, int? dosa, int? dos, int? eos)
        {
            //Current year is before(End of production or Phase out +1)– Active(Green) 2022 should be green
            //Current year is after End of production or Phase out but before End of commercialization + 1) – Available Phase
            //Current year is after End of commercialization but before End of services + 1) – Service Phase
            //Current year is after End of services+1 – Limited Phase

            if (dos == null && eos == null && dosa == null)
            {
                return "#FF3DCD58";//Green
            }
            if (dosa == null || fromDate > dosa)
            {
                if (dos == null || fromDate > dos)
                {
                    if (eos == null || fromDate > eos)
                    {
                        return "#FFDC0A0A";//Red
                    }
                    return "#FFFFD100"; //Yellow
                }
                return "#FFFFD100"; //Yellow
            }
            return "#FF3DCD58";//Green
        }
    }
}