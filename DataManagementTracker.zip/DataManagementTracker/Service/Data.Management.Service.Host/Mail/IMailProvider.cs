﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Management.Service.Host.Mail
{
  public  interface IMailProvider
    {
        void SendMail(string byName, string byMailId, string dataManagerMailId, string cmMailId);
    }
}
