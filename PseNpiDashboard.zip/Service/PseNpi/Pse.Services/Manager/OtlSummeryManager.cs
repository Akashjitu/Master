﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pse.Data.Models;
using Pse.Services.DataBaseAccessObject.Loader;

namespace Pse.Services.Manager
{
    public class OtlSummeryManager : IOtlSummeryManager

    {
        private readonly IOtlSummeryDataAccess _otlSummeryDataAccess;
        public OtlSummeryManager(IOtlSummeryDataAccess otlSummeryDataAccess)
        {
            _otlSummeryDataAccess = otlSummeryDataAccess;

        }
        public OtlSummery AddOtlSummery(OtlSummery otlSummery)
        {
            return _otlSummeryDataAccess.AddOtlSummery(otlSummery);
        }

        public List<OtlSummery> LoadAllOtlSummery()
        {
            return _otlSummeryDataAccess.LoadAllOtlSummery();
        }

        public List<OtlSummery> LoadOtlSummeryByBaseLine(DateTime baseLine)
        {
            return _otlSummeryDataAccess.LoadOtlSummeryByBaseLine(baseLine);
        }

        public List<OtlSummery> LoadOtlSummeryByCreatedDate(DateTime created)
        {
            return _otlSummeryDataAccess.LoadOtlSummeryByCreatedDate(created);
        }

        public List<OtlSummery> LoadOtlSummeryByID(int id)
        {
            return _otlSummeryDataAccess.LoadOtlSummeryByID(id);
        }

        public List<OtlSummery> LoadOtlSummeryByKeyCode(string keycode)
        {
            return _otlSummeryDataAccess.LoadOtlSummeryByKeyCode(keycode);

        }

        public OtlSummery UpdateOtlSummery(OtlSummery otlSummery)
        {
            return _otlSummeryDataAccess.UpdateOtlSummery(otlSummery);
        }
    }
}
