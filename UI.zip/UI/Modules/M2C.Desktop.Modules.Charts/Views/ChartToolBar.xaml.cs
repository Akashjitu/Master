﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ChartToolBar.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace M2C.Desktop.Modules.Charts.Views
{
    /// <summary>
    /// Interaction logic for ChartToolBarView.xaml
    /// </summary>
    public partial class ChartToolBar : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChartToolBar" /> class.
        /// </summary>
        public ChartToolBar()
        {
            InitializeComponent();
        }
    }
}
