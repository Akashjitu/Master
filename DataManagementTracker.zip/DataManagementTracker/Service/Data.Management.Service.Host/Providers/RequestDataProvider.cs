﻿using Hts.Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Data.Management.Service.Host.Providers
{
    public class RequestDataProvider
    {

        public static string GetValue(System.Web.HttpContext current, TypeOfData type)
        {
            
            switch (type)
            {
                case TypeOfData.UserName:
                    var aray = current.User.Identity.Name.Split('\\');
                    LogWriter.LogWrite(" GetValue----------- " + current.User.Identity.Name, LogType.Information);
                    if (aray.Length > 1)
                        return aray[1];
                    if (aray.Length == 1)
                        return aray[0];
                    break;
                default:
                    return string.Empty;
            }
            return string.Empty;
        }
    }
    public enum TypeOfData
    {
        UserName
    }

}
