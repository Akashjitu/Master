import { Component, OnInit  } from '@angular/core';
import { Form } from '@angular/forms';
import { NgRedux, select}  from '@angular-redux/store'; 
import {IAppSate,  rootReducer ,INITIAL_STATE} from '../store' 
import {TOGGLE_TODO,ADD_TODO,REMOVE_TODO} from  '../action'
import {ITodo} from '../todo';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  @select() todos; 
  @select() lastUpdate; 

  public _model: ITodo = {
    id: 0,
    description: "",
    isCompleted: false,
    priority: "low",
    responsible: ""
  };
  public get model(): ITodo {
    return this._model;
  }
  public set model(value: ITodo) {
    this._model = value;
  }

  constructor(private  ngRedux: NgRedux<IAppSate>) { }

  ngOnInit() {
  }

  onSubmit(){

    this.ngRedux.dispatch({type: ADD_TODO, todo: this.model});
  }
  toggleTodo(todo){
    this.ngRedux.dispatch({type: TOGGLE_TODO, id: todo.id});
  }

  removeTodd(todo){
    this.ngRedux.dispatch({type: REMOVE_TODO, id: todo.id});
  }

}
