﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="AddInventoryDialog.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Regions;
using System.Windows.Controls;

namespace M2C.Desktop.Modules.CollectData.Views
{
    /// <summary>
    /// Interaction logic for AddInventoryDialog
    /// </summary>
    public partial class AddInventoryDialog : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AddInventoryDialog" /> class.
        /// </summary>
        /// <param name="regionManager">The region manager.</param>
        public AddInventoryDialog(IRegionManager regionManager)
        {
            InitializeComponent();
            RegionManager.SetRegionManager(this, regionManager);
        }
    }
}