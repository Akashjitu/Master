﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 01-21-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="MaintenanceNode.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using M2C.Business.Contracts;
using M2C.Business.Models.Project.IBComponents;
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Data;
using M2C.Business.GlobalFields;

namespace M2C.Business.Models.Project.TRComponents
{
    /// <summary>
    /// MaintenanceNode tree node
    /// </summary>
    /// <seealso cref="M2C.Business.Models.Project.TRComponents.TRBaseNode" />
    /// <seealso cref="M2C.Business.Models.Project.IBComponents.IChildNode" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class MaintenanceNode : Node, IChildNode, IDelete
    {
        /// <summary>
        /// The stock nodes
        /// </summary>
        private ObservableCollection<StockNode> _stockNodes;

        /// <summary>
        /// The competencies nodes
        /// </summary>
        private ObservableCollection<CompetenciesNode> _competenciesNodes;

        /// <summary>
        /// Initializes a new instance of the <see cref="MaintenanceNode" /> class.
        /// </summary>
        public MaintenanceNode()
        {
            this.NodeType = NodeType.MAINTENANCEZONE;
            _stockNodes = new ObservableCollection<StockNode>();
            _competenciesNodes = new ObservableCollection<CompetenciesNode>();

            StockNodes.CollectionChanged += StockNodes_CollectionChanged;
            CompetenciesNodes.CollectionChanged += StockNodes_CollectionChanged;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MaintenanceNode" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public MaintenanceNode(string name)
        {
            this.NodeType = NodeType.MAINTENANCEZONE;
            this.Name = name;
            _stockNodes = new ObservableCollection<StockNode>();
            _competenciesNodes = new ObservableCollection<CompetenciesNode>();

            StockNodes.CollectionChanged += StockNodes_CollectionChanged;
            CompetenciesNodes.CollectionChanged += StockNodes_CollectionChanged;
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="MaintenanceNode" /> class.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="name">The name.</param>
        /// <param name="parentNode">The parent node.</param>
        public MaintenanceNode(int id, string name, INode parentNode)
        {
            Id = id;
            ParentNode = parentNode;
            this.NodeType = NodeType.MAINTENANCEZONE;
            this.Name = name;
            _stockNodes = new ObservableCollection<StockNode>();
            _competenciesNodes = new ObservableCollection<CompetenciesNode>();

            StockNodes.CollectionChanged += StockNodes_CollectionChanged;
            CompetenciesNodes.CollectionChanged += StockNodes_CollectionChanged;
        }

        /// <summary>
        /// Handles the CollectionChanged event of the StockNodes control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Collections.Specialized.NotifyCollectionChangedEventArgs" /> instance containing the event data.</param>
        private void StockNodes_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems?.Count > 0)
                (e.NewItems[0] as Node)?.SetParentNode(this);
        }

        /// <summary>
        /// Deletes this instance.
        /// </summary>
        public void Delete()
        {
            (this.ParentNode as TRNode)?.MaintenanceNodes.Remove(this);
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The child nodes.</value>
        [JsonIgnore]
        public CompositeCollection ChildNodes
        {
            get
            {
                return new CompositeCollection()
                    {
                        new CollectionContainer() { Collection = StockNodes },
                         new CollectionContainer() { Collection = CompetenciesNodes }
                    };
            }
        }

        /// <summary>
        /// Adds the child.
        /// </summary>
        /// <param name="components">The components.</param>
        public void AddChild(IEnumerable<IBProjectComponent> components)
        {
            foreach (var c in components
                .Where(x => x.IBComponenetType.ComponentTypeID == (int)NodeType.STOCK && x.ParentID == this.Id).ToList())
            {
                StockNodes.Add(new StockNode(c.NodeID, c.ComponentName, this));
            }

        }

        /// <summary>
        /// Gets or sets the stock nodes.
        /// </summary>
        /// <value>The stock nodes.</value>
        public ObservableCollection<StockNode> StockNodes { get => _stockNodes; set => SetProperty(ref _stockNodes, value); }

        /// <summary>
        /// Gets or sets the competencies nodes.
        /// </summary>
        /// <value>The competencies nodes.</value>
        public ObservableCollection<CompetenciesNode> CompetenciesNodes { get => _competenciesNodes; set => SetProperty(ref _competenciesNodes, value); }
    }

    /// <summary>
    /// extension class for importing stock node for the maintenance node
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class MaintenanceNodeExt
    {
        /// <summary>
        /// Imports the stock.
        /// </summary>
        /// <param name="maintenanceNode">The maintenance node.</param>
        /// <param name="trComponents">The tr components.</param>
        public static void ImportStock(this MaintenanceNode maintenanceNode, List<TRImportModel> trComponents)
        {
            var stockList = trComponents.Select(x => x.Configuration).Distinct();
            foreach (var name in stockList)
            {
                var stockObj = new StockNode(GlobalFiled.GenerateRandomId(), name, maintenanceNode);
                //var stockObj = new StockNode(item)
                //{ ParentNode = maintenanceNode};
                ////Import should be done to attached node only, Node ID is mandatory for filtering
                maintenanceNode.StockNodes.Add(stockObj);

                stockObj.ImportInventory(trComponents.ToList());
            }
        }

        /// <summary>
        /// Gets all Child nodes.
        /// </summary>
        /// <param name="maintenanceNode">The maintenance node.</param>
        /// <returns>List&lt;Node&gt;.</returns>
        public static List<Node> GetAllNodes(this MaintenanceNode maintenanceNode)
        {
           return maintenanceNode.StockNodes.Cast<Node>().ToList();
        }
    }
}