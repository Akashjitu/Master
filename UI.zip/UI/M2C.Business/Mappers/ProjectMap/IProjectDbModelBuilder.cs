﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProjectDbModelBuilder.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;
using DomainModels;
using DomainModels.ProjectModels;
using M2C.Business.Models.Project;

namespace M2C.Business.Mappers.ProjectMap
{
    /// <summary>
    /// Interface IProjectDbModelBuilder
    /// </summary>
    public interface IProjectDbModelBuilder
    {
        /// <summary>
        /// Builds the project.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        ProjectDbModelBuilder BuildProject();

        /// <summary>
        /// Builds the customer.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        ProjectDbModelBuilder BuildCustomer();

        /// <summary>
        /// Builds the contact.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        ProjectDbModelBuilder BuildContact();

        /// <summary>
        /// Builds the Ib components.
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        ProjectDbModelBuilder BuildIbComponents();

        /// <summary>
        /// Gets the project.
        /// </summary>
        /// <returns>Project.</returns>
        Project GetProject();

        /// <summary>
        /// builds the operation mode
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        ProjectDbModelBuilder BuildOperationMode();

        /// <summary>
        /// builds the ProjectInventories
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        ProjectDbModelBuilder BuildProjectInventories();

        /// <summary>
        /// builds the Inventory Comments
        /// </summary>
        /// <returns>ProjectDbModelBuilder.</returns>
        ProjectDbModelBuilder BuildInventoryComments();


        /// <summary>
        /// Get the fills project
        /// </summary>
        /// <param name="projectContextModel">The project context model.</param>
        /// <param name="projectDbContext">The project database context.</param>
        /// <returns>Project.</returns>
        Project GetProject(ProjectContextModel projectContextModel, IProjectDbContext projectDbContext);
    }
}