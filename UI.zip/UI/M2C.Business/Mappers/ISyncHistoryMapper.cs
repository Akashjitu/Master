﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ISyncHistoryMapper.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogModels;
using SyncServiceLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M2C.Business.Mappers
{
    /// <summary>
    /// Interface ISyncHistoryMapper
    /// </summary>
    public interface ISyncHistoryMapper
    {
        /// <summary>
        /// Maps the specified attempt.
        /// </summary>
        /// <param name="attempt">The attempt.</param>
        /// <param name="status">The status.</param>
        /// <param name="version">The version.</param>
        /// <returns>SyncHistory.</returns>
        SyncHistory Map(int attempt, int status,int version);
    }
}
