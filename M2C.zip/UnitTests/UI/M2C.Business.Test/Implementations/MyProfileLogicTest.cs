﻿using DataRepository.DBContracts;
using DomainModels.Common;
using M2C.Business.Models;
using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace M2C.Business.Implementations
{
    [TestClass]
    public class MyProfileLogicTest
    {
        private MyProfileLogic myProfileLogic;
        private IProfileQueries dataAccessObejct;

        [TestInitialize]
        public void Setup()
        {
            dataAccessObejct = Substitute.For<IProfileQueries>();
            myProfileLogic = new MyProfileLogic(dataAccessObejct);
            dataAccessObejct.GetProfile().Returns(MockProvider.GetProfile());
            dataAccessObejct.RemoveProfile(Arg.Any<int>()).Returns(true);
            dataAccessObejct.SaveProfile(Arg.Any<Profile>());
        }

        [TestMethod]
        public void ShouldRemoveProfileBasedOnId()
        {
            var isDeleted = myProfileLogic.DeleteProfile(1);
            Assert.IsTrue(isDeleted);
        }

        [TestMethod]
        public void ShouldReturnProfile()
        {
            var profile = myProfileLogic.GetProfile();
            Assert.IsNotNull(profile);
        }

        [TestMethod]
        public void ShouldSaveProfile()
        {
            var IsSaved = myProfileLogic.SaveProfile(new ProfileModel());
            Assert.IsTrue(IsSaved);
        }
    }
}