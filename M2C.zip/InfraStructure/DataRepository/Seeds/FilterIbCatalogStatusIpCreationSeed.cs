﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="FilterIbCatalogStatusIpCreationSeed.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.IbCatalogFilter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace DataRepository.Seeds
{
    /// <summary>
    /// Class FilterIbCatalogStatusIpCreationSeed.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    internal class FilterIbCatalogStatusIpCreationSeed
    {
        /// <summary>
        /// Seeds the specified model builder.
        /// </summary>
        /// <param name="modelBuilder">The model builder.</param>
        public void Seed(ModelBuilder modelBuilder)
        {
            var recurrentTime = DateTime.Today;
            var filterIbCatalogStatusIpCreations = new List<FilterIbCatalogStatusIpCreation>
            {
                new FilterIbCatalogStatusIpCreation {Name = "YES", Id = 1, CreatedDate = recurrentTime},
            };
            modelBuilder.Entity<FilterIbCatalogStatusIpCreation>().HasData(filterIbCatalogStatusIpCreations);
        }
    }
}