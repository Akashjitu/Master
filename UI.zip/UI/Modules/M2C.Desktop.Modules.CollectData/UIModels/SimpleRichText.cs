﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 02-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="SimpleRichText.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Threading;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Class SimpleRichText.
    /// Implements the <see cref="System.Windows.Controls.RichTextBox" />
    /// </summary>
    /// <seealso cref="System.Windows.Controls.RichTextBox" />
    public class SimpleRichText : RichTextBox
    {
        /// <summary>
        /// The text has loaded
        /// </summary>
        private bool _textHasLoaded;
        /// <summary>
        /// The is invoke pending
        /// </summary>
        private bool _isInvokePending;

        /// <summary>
        /// Initializes a new instance of the <see cref="SimpleRichText" /> class.
        /// </summary>
        public SimpleRichText()
        {
            Loaded += RichTextBox_Loaded;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SimpleRichText" /> class.
        /// </summary>
        /// <param name="document">A <see cref="T:System.Windows.Documents.FlowDocument" /> to be added as the initial contents of the new <see cref="T:System.Windows.Controls.RichTextBox" />.</param>
        public SimpleRichText(FlowDocument document)
            : base(document) { }

        /// <summary>
        /// The text property
        /// </summary>
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(SimpleRichText),
                new FrameworkPropertyMetadata(string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    OnTextPropertyChanged));

        /// <summary>
        /// Gets or sets the text.
        /// </summary>
        /// <value>The text.</value>
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        /// <summary>
        /// Handles the <see cref="E:TextPropertyChanged" /> event.
        /// </summary>
        /// <param name="dependencyObject">The dependency object.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private static void OnTextPropertyChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var richTextBox = (SimpleRichText)dependencyObject;

            if ((richTextBox._textHasLoaded) && (richTextBox._isInvokePending || !richTextBox._textHasLoaded)) return;

            SetText(richTextBox.Document, (string)e.NewValue);
            richTextBox._textHasLoaded = true;
        }

        /// <summary>
        /// Handles the Loaded event of the RichTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        private void RichTextBox_Loaded(object sender, RoutedEventArgs e)
        {
            var binding = BindingOperations.GetBinding(this, TextProperty);
            DataContextChanged += RichTextBox_DataContextChanged;
            if (binding == null) return;

            if (binding.UpdateSourceTrigger == UpdateSourceTrigger.Default || binding.UpdateSourceTrigger == UpdateSourceTrigger.LostFocus)
                PreviewLostKeyboardFocus += (sourceObject, eventArgs) => UpdateText();
            else
                TextChanged += (sourceObject, eventArgs) => InvokeUpdateText();
        }

        /// <summary>
        /// Updates the text.
        /// </summary>
        private void UpdateText()
        {
            if (!_textHasLoaded && string.IsNullOrEmpty(Text))
                _textHasLoaded = true;

            if (_textHasLoaded)
                this.SetValue(TextProperty, GetText(Document));
            //Text = TextFormatter.GetText(Document);

            _isInvokePending = false;
        }

        /// <summary>
        /// Invokes the update text.
        /// </summary>
        private void InvokeUpdateText()
        {
            if (_isInvokePending) return;

            Dispatcher?.BeginInvoke(DispatcherPriority.Background, new Action(UpdateText));
            _isInvokePending = true;
        }

        /// <summary>
        /// Handles the DataContextChanged event of the RichTextBox control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs" /> instance containing the event data.</param>
        private void RichTextBox_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue != null)
                _textHasLoaded = false;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <returns>System.String.</returns>
        private static string GetText(FlowDocument document)
        {
            if (document.Blocks.Count == 0)
                return string.Empty;

            var textRange = new TextRange(document.ContentStart, document.ContentEnd);
            using (var ms = new MemoryStream())
            {
                textRange.Save(ms, DataFormats.Rtf);
                return Encoding.Default.GetString(ms.ToArray()); ;
            }
        }

        /// <summary>
        /// Sets the text.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="text">The text.</param>
        private static void SetText(FlowDocument document, string text)
        {
            if (string.IsNullOrEmpty(text))
                text = @"{\rtf1\ansi}";

            var textRange = new TextRange(document.ContentStart, document.ContentEnd);

            using (var ms = new MemoryStream(Encoding.ASCII.GetBytes(text)))
            {
                textRange.Load(ms, DataFormats.Rtf);
            }
        }
    }
}