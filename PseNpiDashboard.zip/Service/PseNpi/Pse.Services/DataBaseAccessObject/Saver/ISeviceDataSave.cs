﻿using System.Collections.Generic;
using Pse.Data.Models;

namespace Spea.Service.DataBaseAccessObject.Saver
{
    public interface ISeviceDataSave
    {
        int UpdateCompliance(Compliance compliance);
        int DeleteCompliance(Compliance compliance);
        int AddCompliance(Compliance compliance);

       int AddTTiInfo(TtiPartAlignment ttiPartAlignment);
       int UpdateTTiInfo(TtiPartAlignment ttiPartAlignment);
       int AddEffectiveness(Effectiveness eft);
       int UpdateEffectiveness(Effectiveness eft);

    }
}
