﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ProductSyncModel.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Newtonsoft.Json;
using Schneider.M2C.OpenExcel.Parser.Model;
using System;

namespace SyncServiceLibrary.Model
{
    /// <summary>
    /// ProductSyncModel json model for API response
    /// </summary>
    public class ProductSyncModel
    {
        /// <summary>
        /// Gets or sets the event identifier.
        /// </summary>
        /// <value>The event identifier.</value>
        public string eventId { get; set; }

        /// <summary>
        /// Gets or sets the event date UTC.
        /// </summary>
        /// <value>The event date UTC.</value>
        public DateTime eventDateUtc { get; set; }

        /// <summary>
        /// Gets or sets the type of the event.
        /// </summary>
        /// <value>The type of the event.</value>
        public string eventType { get; set; }

        /// <summary>
        /// Gets or sets the name of the table.
        /// </summary>
        /// <value>The name of the table.</value>
        public string tableName { get; set; }

        /// <summary>
        /// Gets or sets the record identifier.
        /// </summary>
        /// <value>The record identifier.</value>
        public string recordId { get; set; }

        /// <summary>
        /// Gets or sets the event data details.
        /// </summary>
        /// <value>The event data details.</value>
        public string eventDataDetails { get; set; }

        /// <summary>
        /// Gets or sets the version number.
        /// </summary>
        /// <value>The version number.</value>
        public string versionNumber { get; set; }

        /// <summary>
        /// Gets the ib catalog from eventDataDetails
        /// derived property
        /// </summary>
        /// <value>The ib catalog.</value>
        [JsonIgnore]
        public OneIbCatalog ibCatalog
        {
            get
            {
                if (!string.IsNullOrEmpty(eventDataDetails))
                {
                    OneIbCatalog data = JsonConvert.DeserializeObject<OneIbCatalog>(eventDataDetails);
                    data.Version = Convert.ToInt32(this.versionNumber);
                    return data;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}