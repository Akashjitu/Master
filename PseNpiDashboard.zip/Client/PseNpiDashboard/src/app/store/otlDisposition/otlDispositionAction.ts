
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';

import { OtlDisposition } from '../../model/OtlDisposition';
export const ADD_OTL_DISPOSITION = 'ADD_OTL_DISPOSITION';
export const LOAD_OTL_DISPOSITION = 'LOAD_OTL_DISPOSITION';
export const REMOVE_OTL_DISPOSITION = 'REMOVE_OTL_DISPOSITION';
export const UPDATE_OTL_DISPOSITION: string = 'UPDATE_OTL_DISPOSITION';



export class LoadOtlDisposition implements Action {
    readonly type = LOAD_OTL_DISPOSITION;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddOtlDisposition implements Action {
    readonly type = ADD_OTL_DISPOSITION;

    constructor(public payload: OtlDisposition) { }
}

export class UpdateOtlDisposition implements Action {
    readonly type = UPDATE_OTL_DISPOSITION;

    constructor(public payload: OtlDisposition) { }
}

export class RemoveOtlDisposition implements Action {
    readonly type = REMOVE_OTL_DISPOSITION;

    constructor(public payload: number) { }
}


export type Actions = AddOtlDisposition | RemoveOtlDisposition | LoadOtlDisposition;
