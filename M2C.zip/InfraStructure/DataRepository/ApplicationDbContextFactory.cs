﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="ApplicationDbContextFactory.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DataRepository.DBContracts;

namespace DataRepository
{
    /// <summary>
    /// Class ApplicationDbContextFactory.
    /// Implements the <see cref="DataRepository.DBContracts.IDbContextFactory" />
    /// </summary>
    /// <seealso cref="DataRepository.DBContracts.IDbContextFactory" />
    public class ApplicationDbContextFactory : IDbContextFactory
    {
        /// <summary>
        /// Creates this instance.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>T.</returns>
        public T Create<T>()
        {
            if (typeof(T).Name == "IProductDbContext")
            {
                IProductDbContext DbContext = new ProductDbContext();
                return (T)(DbContext as object);
            }
            else if (typeof(T).Name == "IProjectDbContext")
            {
                IProjectDbContext DbContext = new ProjectDbContext();
                return (T)(DbContext as object);
            }
            else
            {
                return (T)(null as object);
            }
        }
    }
}