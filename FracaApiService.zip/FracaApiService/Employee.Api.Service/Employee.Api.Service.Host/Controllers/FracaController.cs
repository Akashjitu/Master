﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using Fraca.Service.Service;
using System.Net.Http.Formatting;
using Fraca.Data.Models;
using Fraca.Api.Service.Host.Authorizes;

namespace Fraca.Api.Service.Host.Controllers
{
     //[Authorize]
     //[Authentication]
    public class FracaController : ApiController
    {
        private readonly IFracaService _FracaService;

        public FracaController(IFracaService FracaService)
        {
            _FracaService = FracaService;
        }

        [HttpGet]
        public HttpResponseMessage GetAllFraca()
        {
            // var s = User.Identity;
            // var s = RequestContext.Principal;
         var d=   System.Web.HttpContext.Current.User.Identity.Name.Split('\\')[1];
            var fracaData =   _FracaService.GetAllFracaData();
            var res = Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);
            return res;
        }


        [HttpPost]
        public HttpResponseMessage AddNewFraca(FracaInfo fracaInfo)
        {
            var fracaData = _FracaService.AddNewFraca(fracaInfo);
            var res = Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);
            return res;
        }

        [HttpPut]
        public HttpResponseMessage UpdateFraca(string fracaNo, FracaInfo fracaInfo)
        {
            var fracaData = _FracaService.UpdateFraca(fracaNo, fracaInfo);
            var res = Request.CreateResponse(HttpStatusCode.OK, fracaData, JsonMediaTypeFormatter.DefaultMediaType);
            return res;
        }



        [HttpDelete]
        public HttpResponseMessage DeleteFraca(string fracaNo)
        {
            _FracaService.DeleteFraca(fracaNo);
            var res = Request.CreateResponse(HttpStatusCode.OK,  JsonMediaTypeFormatter.DefaultMediaType);
            return res;
        }
    }
}