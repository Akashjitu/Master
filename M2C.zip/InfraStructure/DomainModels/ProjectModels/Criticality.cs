﻿// ***********************************************************************
// Assembly         : DomainModels
// Author           : SESA56024
// Created          : 03-12-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Criticality.cs" company="DomainModels">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DomainModels
{
    /// <summary>
    /// class criticality
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Criticality
    {

        /// <summary>
        /// Gets or sets the operation mode identifier
        /// </summary>
        /// <value>The criticality identifier.</value>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CriticalityID { get; set; }

        /// <summary>
        /// Gets or sets the SafetyIssue parameter
        /// </summary>
        /// <value>The safety issue.</value>
        public string SafetyIssue { get; set; }

        /// <summary>
        /// Gets or Sets the QualityIssue
        /// </summary>
        /// <value>The quality issue.</value>
        public string QualityIssue { get; set; }

        /// <summary>
        /// Gets or sets the LeadTimeIssue
        /// </summary>
        /// <value>The lead time issue.</value>
        public string LeadTimeIssue { get; set; }

        /// <summary>
        /// Gets or sets the CostsIssue
        /// </summary>
        /// <value>The costs issue.</value>
        public string CostsIssue { get; set; }

        /// <summary>
        /// gets or sets the CriticalityValue
        /// </summary>
        /// <value>The criticality value.</value>
        public string CriticalityValue { get; set; }

        /// <summary>
        /// Gets or Sets the Comments
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        [ForeignKey("IBProjectComponentId")]
        public int NodeID { get; set; }

        /// <summary>
        /// Gets or sets the ib project component.
        /// </summary>
        /// <value>The ib project component.</value>
        public virtual IBProjectComponent IBProjectComponent { get; set; }

        /// <summary>
        /// Gets or sets the  project Id.
        /// </summary>
        /// <value>The project.</value>
        [ForeignKey("ProjectID")]
        public Project Project { get; set; }
    }
}
