﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-15-2020
// ***********************************************************************
// <copyright file="IRestServiceRequest.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;

namespace RestClientServices.Contracts
{
    /// <summary>
    /// Interface IRestServiceRequest
    /// </summary>
    public interface IRestServiceRequest
    {
        /// <summary>
        /// Gets or sets the resource path.
        /// </summary>
        /// <value>The resource path.</value>
        string ResourcePath { get; set; }

        /// <summary>
        /// Gets or sets the path parameters.
        /// </summary>
        /// <value>The path parameters.</value>
        Dictionary<string, object> PathParams { get; set; }

        /// <summary>
        /// Gets or sets the queryparams.
        /// </summary>
        /// <value>The queryparams.</value>
        Dictionary<string, object> Queryparams { get; set; }

        /// <summary>
        /// Gets or sets the header parameters.
        /// </summary>
        /// <value>The header parameters.</value>
        Dictionary<string, object> HeaderParams { get; set; }

        /// <summary>
        /// Gets or sets the type of the request.
        /// </summary>
        /// <value>The type of the request.</value>
        RequestTypes RequestType { get; set; }

        /// <summary>
        /// Gets or sets the body parameter.
        /// </summary>
        /// <value>The body parameter.</value>
        object BodyParam { get; set; }
    }
}