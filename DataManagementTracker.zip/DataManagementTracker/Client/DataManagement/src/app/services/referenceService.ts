import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { NgxSpinnerService } from 'ngx-spinner';
import { IAppState } from '../store/reference/referenceReducer';
import * as ReferenceAction from '../store/reference/referenceAction';
import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root'
  })

export class ReferenceService {

    headers: any;

    url = environment.apiBaseUrl;
    fileBaseUrl = environment.fileBaseUrl;
  
    constructor(private http: HttpClient, private store: Store<IAppState>, private spinner: NgxSpinnerService) {
      this.headers = new HttpHeaders({
        Accept: 'application/json',
        'zumo-api-version': '2.0.0',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': 'true',
       'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
       withCredentials: 'true',
    });
     }
  
 
    getAllReference() {
      this.spinner.show();
      this.http.get<any>(this.url+'DataManagementReference')
      .subscribe(res => {
        this.spinner.hide()
        this.store.dispatch(new ReferenceAction.LoadReference(res)
        )}, err => {
              this.spinner.hide();
            });
    }
  
  
    
   
  }
  