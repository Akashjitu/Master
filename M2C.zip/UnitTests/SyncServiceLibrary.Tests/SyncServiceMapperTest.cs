﻿using DomainModels.IbCatalogModels;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Schneider.M2C.OpenExcel.Parser.Model;
using SyncServiceLibrary.Mapper;
using System.Collections.Generic;

namespace SyncServiceLibrary.Tests
{
    /// <summary>
    /// Test class for SyncServiceMapper
    /// </summary>
    [TestClass]
    public class SyncServiceMapperTest
    {
        [TestInitialize]
        public void TestInitialize()
        {
        }

        /// <summary>
        /// BrandMap Test
        /// </summary>
        [TestMethod]
        public void BrandMapTest()
        {
            OneIbCatalog[] ibCatalog = new OneIbCatalog[1] { new OneIbCatalog() { BrandLegacy = "brand" } };

            SyncServiceDataMapper mapper = new SyncServiceDataMapper();
            var brandRes = mapper.BrandMap(ibCatalog);
            brandRes.Should().NotBeNull();
        }

        /// <summary>
        /// DeviceType Test
        /// </summary>
        [TestMethod]
        public void DeviceTypeTest()
        {
            OneIbCatalog[] ibCatalog = new OneIbCatalog[1] { new OneIbCatalog() { DeviceTypeLegacy = "PLC", OpsDeviceTypeDescription = "DeviceTypeDescription" } };
            SyncServiceDataMapper mapper = new SyncServiceDataMapper();
            var type = mapper.DeviceTypeMap(ibCatalog);
            type.Should().NotBeNull();
        }

        /// <summary>
        /// SubRangeMap Test
        /// </summary>
        [TestMethod]
        public void SubRangeMapTest()
        {
            List<OneIbCatalog> ibCatalog = new List<OneIbCatalog>() { new OneIbCatalog() { RangeLegacy = "PLC", SdhSubRangeDescription = "SdhSubRangeDescription", SdhSubRangeCode = "SdhSubRangeCode" } };

            List<Range> ranges = new List<Range>() { new Range() { Name = "Range" } };
            SyncServiceDataMapper mapper = new SyncServiceDataMapper();
            var type = mapper.SubRangeMap(ibCatalog, ranges);
            type.Should().NotBeNull();
        }

        /// <summary>
        /// RangeMap Test
        /// </summary>
        [TestMethod]
        public void RangeMapTest()
        {
            OneIbCatalog[] ibCatalog = new OneIbCatalog[1] { new OneIbCatalog() { RangeLegacy = "RangeLegacy", OpsRangeDescription = "OpsRangeDescription" } };
            SyncServiceDataMapper mapper = new SyncServiceDataMapper();
            var type = mapper.RangeMap(ibCatalog);
            type.Should().NotBeNull();
        }

        /// <summary>
        /// ProductMap Test
        /// </summary>
        [TestMethod]
        public void ProductMapTest()
        {
            List<Brand> brands = new List<Brand>() { new Brand() { Name = "Brand1" } };
            List<DeviceType> deviceTypes = new List<DeviceType>() { new DeviceType() { Type = "DeviceType1" } };
            List<Range> ranges = new List<Range>() { new Range() { Name = "Range1" } };

            List<OneIbCatalog> ibCatalog = new List<OneIbCatalog>() { new OneIbCatalog() { ProductIdentifier = "P1", BrandLegacy = "BrandLegacy", RangeLegacy = "RangeLegacy", DeviceTypeLegacy = "DeviceTypeLegacy" } };
            SyncServiceDataMapper mapper = new SyncServiceDataMapper();
            var product = mapper.ProductMap(ibCatalog, brands, deviceTypes, ranges);
            product.Should().NotBeNull();
        }

        /// <summary>
        /// SyncHistoryMap Test
        /// </summary>
        [TestMethod]
        public void SyncHistoryMapTest()
        {
            SyncServiceDataMapper mapper = new SyncServiceDataMapper();
            var syncHistory = mapper.SyncHistoryMap(1, 1);
            syncHistory.Should().NotBeNull();
        }
    }
}