
import { Injectable } from '@angular/core';
import { Action } from '@ngrx/store';

import { Compliance } from 'src/app/model/compliance';
export const ADD_COMPLIANCE = 'ADD_COMPLIANCE';
export const LOAD_COMPLIANCE = 'LOAD_COMPLIANCE';
export const REMOVE_COMPLIANCE = 'REMOVE_COMPLIANCE';
export const UPDATE_COMPLIANCE: string = 'UPDATE_COMPLIANCE';



export class LoadCompliance implements Action {
    readonly type = LOAD_COMPLIANCE;

    constructor(public payload: any) {
        //console.log("payload " + payload);
       // console.log('payload1  :'+ JSON.stringify(payload));
    }
}

export class AddCompliance implements Action {
    readonly type = ADD_COMPLIANCE;

    constructor(public payload: Compliance) { }
}

export class UpdateCompliance implements Action {
    readonly type = UPDATE_COMPLIANCE;

    constructor(public payload: Compliance) { }
}

export class RemoveCompliance implements Action {
    readonly type = REMOVE_COMPLIANCE;

    constructor(public payload: number) { }
}


export type Actions = AddCompliance | RemoveCompliance | LoadCompliance;
