import { Component, OnInit, TemplateRef } from '@angular/core';
import { OtlScoreCardColumns } from './otlScoreCardColumns';
import { HttpClient } from '@angular/common/http';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Store } from '@ngrx/store';
import { OtlScoreCardService } from '../services/otl-ScoreCard.Service';
import { IAppState } from '../store/otlScoreCard/otlScoreCardReducer';

@Component({
  selector: 'app-otl-score-info-card',
  templateUrl: './otl-score-card.component.html',
  styleUrls: ['./otl-score-card.component.sass']
})
export class OtlScoreCardInfoComponent implements OnInit {

  modalRef: BsModalRef;
  gridApi;
  gridColumnApi;
  isExportFilter = false;
  columnDefs;
  defaultColDef;
  rowData: any;
  searchText;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  theme = 'ag-theme-balham';
  pliModel = {
    partNumber:'',
    keyCode:'',
    otlBaselineDate: ''
  }


  ngOnInit() {
  }
  constructor(private http: HttpClient, private service: OtlScoreCardService, public store: Store<IAppState>, private modalService: BsModalService, ) {
    this.initColumns();

    this.defaultColDef = {
      resizable: true,
      sortable: true,
      enableFilter: true,
      //width: 100,
      //editable: true,
      filter: true
    };
    service.getAllOtlScoreCard();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.autoSizeAll();
    this.store.select('otlScoreCardReducer').subscribe(data => {
      this.rowData = data;
    });
    this.initColumnsList();
  }

  initColumns() {
    this.columnDefs = OtlScoreCardColumns.columns;
  }

  autoSizeAll() {
    var allColumnIds = [];
    this.gridColumnApi.getAllColumns().forEach(function (column) {
      allColumnIds.push(column.colId);
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }

  export() {
    if (this.isExportFilter == false) {
      this.service.reportDownloadAll();
    } else {
      this.service.reportDownloadByFilter(this.pliModel);
    }

  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }

  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(this.searchText);
  }
  onItemSelect(item: any) {
   
    this.gridColumnApi.setColumnsVisible([item], true);

  }
  onDeSelect(item: any) {
    
    this.gridColumnApi.setColumnsVisible([item], false);

  }
  onSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], true);
    }
  }

  onDeSelectAll(items: any) {
    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      this.gridColumnApi.setColumnsVisible([allColumns[index].colId], false);
    }
  }
  initColumnsList() {
    var allColumnIds = [];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'colId',
      textField: 'headerName',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.gridColumnApi.getAllColumns().forEach(function (column) {
      
      allColumnIds.push({ colId: column.colId, headerName: column.colId });

    });
    this.selectedItems = [
      { colId: 'keyCode', headerName: 'keyCode' },
      { colId: 'productionSite', headerName: 'productionSite' }
    ];

    let allColumns = this.gridColumnApi.getAllColumns();
    for (var index in allColumns) {
      if (allColumns[index].visible === true) {
        this.selectedItems.push({ colId: allColumns[index].colId, headerName: allColumns[index].colId })
      }

    }
    this.dropdownList = allColumnIds;

  }

  showTemplate(template: TemplateRef<any>) {
      this.modalRef = this.modalService.show(template);
  }

  onFilterSubmit() {
    this.service.loadPliByFilter(this.pliModel);
    this.modalRef.hide();
  }

  onExportChange(value) {
    this.isExportFilter = value;
  }

  clearFilters() {

    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }
}
