﻿using Fraca.Service.Manager;
using Fraca.Data.Models;
using System;

namespace Fraca.Service.Service
{
    public class FracaService : IFracaService
    {
        private readonly IFracaServiceManage _FracaServiceManage;

        public FracaService(IFracaServiceManage FracaServiceManage)
        {
            _FracaServiceManage = FracaServiceManage;
        }

        public FracaInfo AddNewFraca(FracaInfo fracainfo)
        {
            return _FracaServiceManage.AddNewFraca(fracainfo);
        }

        public void DeleteFraca(string Fracaid)
        {
            _FracaServiceManage.DeleteFraca(Fracaid);
        }

        public FracaData GetAllFracaData()
        {
            return _FracaServiceManage.GetAllFracaData();
        }

        public FracaData GetFracaByDate(FracaCriteria criteria)
        {
          return  _FracaServiceManage.GetFracaByDate(criteria);
        }

        public FracaData GetFracaByFilter(FracaCriteria criteria)
        {
          return  _FracaServiceManage.GetFracaByFilter(criteria);
        }

        public FracaData GetFracaById(string Fracaid)
        {
            return _FracaServiceManage.GetFracaById( Fracaid);
        }

        public byte[] GetFracaPdfReport(string fracaId)
        {
            return _FracaServiceManage.GetFracaPdfReport(fracaId);
        }

        public FracaInfo UpdateFraca(string Fracaid, FracaInfo fracaInfo)
        {
          return   _FracaServiceManage.UpdateFraca(Fracaid, fracaInfo);
        }
    }
}