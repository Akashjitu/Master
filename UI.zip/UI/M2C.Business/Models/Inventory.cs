﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-22-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="Inventory.cs" company="M2C.Business">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using Prism.Mvvm;

namespace M2C.Business.Models
{
    /// <summary>
    /// Class Inventory.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Inventory : BindableBase
    {
        /// <summary>
        /// The sub range identifier
        /// </summary>
        internal int SubRangeId;

        /// <summary>
        /// The is selected
        /// </summary>
        private bool _isSelected;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is selected.
        /// </summary>
        /// <value><c>true</c> if this instance is selected; otherwise, <c>false</c>.</value>
        public bool IsSelected
        {
            get => _isSelected;
            set => SetProperty(ref _isSelected, value);
        }

        /// <summary>
        /// Gets or sets the MaintenanceZone for Stock.
        /// </summary>
        /// <value>The factory.</value>
        public string MaintenanceZone { get; set; }

        /// <summary>
        /// Gets or sets the MaintenanceZone Id for Stock.
        /// </summary>
        /// <value>The maintenance zone identifier.</value>
        public int MaintenanceZoneId { get; set; }

        /// <summary>
        /// Gets or sets the factory Id.
        /// </summary>
        /// <value>The factory identifier.</value>
        public int FactoryId { get; set; }

        /// <summary>
        /// Gets or sets the factory.
        /// </summary>
        /// <value>The factory.</value>
        public string Factory { get; set; }

        /// <summary>
        /// Gets or sets the workshop Id.
        /// </summary>
        /// <value>The workshop identifier.</value>
        public int WorkshopId { get; set; }

        /// <summary>
        /// Gets or sets the workshop.
        /// </summary>
        /// <value>The workshop.</value>
        public string Workshop { get; set; }

        /// <summary>
        /// Gets or sets the Line Id.
        /// </summary>
        /// <value>The line identifier.</value>
        public int LineId { get; set; }

        /// <summary>
        /// Gets or sets the line.
        /// </summary>
        /// <value>The line.</value>
        public string Line { get; set; }

        /// <summary>
        /// Gets or sets the Machine Id.
        /// </summary>
        /// <value>The machine identifier.</value>
        public int MachineId { get; set; }

        /// <summary>
        /// Gets or sets the machine.
        /// </summary>
        /// <value>The machine.</value>
        public string Machine { get; set; }

        /// <summary>
        /// Gets or sets the Configuration Id.
        /// </summary>
        /// <value>The configuration identifier.</value>
        public int ConfigurationId { get; set; }

        /// <summary>
        /// Gets or sets the configuration.
        /// </summary>
        /// <value>The configuration.</value>
        public string Configuration { get; set; }

        /// <summary>
        /// Gets or sets the type of the device.
        /// </summary>
        /// <value>The type of the device.</value>
        public string DeviceType { get; set; }

        /// <summary>
        /// Gets or sets the range.
        /// </summary>
        /// <value>The range.</value>
        public string Range { get; set; }

        /// <summary>
        /// Gets or sets the sub range.
        /// </summary>
        /// <value>The sub range.</value>
        public string SubRange { get; set; }

        /// <summary>
        /// Gets or sets the reference.
        /// </summary>
        /// <value>The reference.</value>
        public string Reference
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the quantity.
        /// </summary>
        /// <value>The quantity.</value>
        public int Quantity { get; set; }

        /// <summary>
        /// Gets or sets the pv number.
        /// </summary>
        /// <value>The pv number.</value>
        public string PvNumber { get; set; }

        /// <summary>
        /// Gets or sets the sv number.
        /// </summary>
        /// <value>The sv number.</value>
        public string SvNumber { get; set; }

        /// <summary>
        /// Gets or sets the unit price.
        /// </summary>
        /// <value>The unit price.</value>
        public string UnitPrice
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the strategic.
        /// </summary>
        /// <value>The strategic.</value>
        public string Strategic { get; set; }

        /// <summary>
        /// Gets or sets the brand.
        /// </summary>
        /// <value>The brand.</value>
        public string Brand { get; set; }

        /// <summary>
        /// Gets or sets the year.
        /// </summary>
        /// <value>The year.</value>
        public string Year
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year1.
        /// </summary>
        /// <value>The year1.</value>
        public string Year1
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year2.
        /// </summary>
        /// <value>The year2.</value>
        public string Year2
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year3.
        /// </summary>
        /// <value>The year3.</value>
        public string Year3
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the year4.
        /// </summary>
        /// <value>The year4.</value>
        public string Year4
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the dosa.
        /// </summary>
        /// <value>The dosa.</value>
        public string Dosa
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the do s.
        /// </summary>
        /// <value>The do s.</value>
        public string DoS
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the eo s.
        /// </summary>
        /// <value>The eo s.</value>
        public string EoS
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the comment.
        /// </summary>
        /// <value>The comment.</value>
        public string Comment { get; set; }

        /// <summary>
        /// Gets the brand identifier.
        /// </summary>
        /// <value>The brand identifier.</value>
        public int BrandId { get; internal set; }

        /// <summary>
        /// Gets the range identifier.
        /// </summary>
        /// <value>The range identifier.</value>
        public int RangeId { get; internal set; }

        /// <summary>
        /// Gets the device type identifier.
        /// </summary>
        /// <value>The device type identifier.</value>
        public int DeviceTypeId { get; internal set; }
        private string _criticality;

        /// <summary>
        /// Get the criticality
        /// </summary>
        /// <value>The criticality.</value>
        public string Criticality { get { return string.IsNullOrEmpty(_criticality) ? CriticalitystringValues.NotCritical : _criticality; } set { _criticality = value; } }

        /// <summary>
        /// Gets the Config type
        /// </summary>
        /// <value>The type of the configuration.</value>
        public string ConfigType { get; set; }

        /// <summary>
        /// Gets or sets the operation mode.
        /// </summary>
        /// <value>The operation mode.</value>
        public OperationModeModel OperationMode { get; set; }

        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>
        /// The version.
        /// </value>
        public int Version { get; set; }
    }
}