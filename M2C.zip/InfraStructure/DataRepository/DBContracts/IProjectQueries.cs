﻿// ***********************************************************************
// Assembly         : DataRepository
// Author           : SESA56024
// Created          : 02-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProjectQueries.cs" company="DataRepository">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using DomainModels.ProjectModels;
using System.Collections.Generic;

namespace DataRepository.DBContracts
{
    /// <summary>
    /// Interface IProjectQueries
    /// </summary>
    public interface IProjectQueries
    {
        /// <summary>
        /// Gets all projects.
        /// </summary>
        /// <returns>List&lt;Project&gt;.</returns>
        List<Project> GetAllProjects();

        /// <summary>
        /// Get Project by Id
        /// </summary>
        /// <param name="projectId">The project identifier.</param>
        /// <returns>Project.</returns>
        Project GetProject(int projectId);

        /// <summary>
        /// Projects only not mapping
        /// </summary>
        /// <returns>List&lt;Project&gt;.</returns>
        List<Project> GetOnlyProjects();
    }
}