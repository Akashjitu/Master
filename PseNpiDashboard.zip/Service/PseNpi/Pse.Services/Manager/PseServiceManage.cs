﻿using Pse.Data.Models;
using Pse.Services.DataBaseAccessObject.Loader;
using Pse.Services.Exports;
using Pse.Services.Mappers;
using Spea.Service.DataBaseAccessObject.Saver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Pse.Services.Manager
{
    public class SpeServiceManage : ISpeServiceManage
    {
        private readonly ITtiDataAccess _tti;
        private readonly IComplianceDataAccess _compliance;
        private readonly IEffectivenessDataAccess _effectiveness;
        private readonly IEffectivenessAnalysisDataAccess _effectivenessAnalysis;
        private readonly IOtlDispositionDataAccess _otlDisposition;
        private readonly ISimpleExport _export;
        private readonly IPliDataAccess _pli;
        private readonly IOtlAnalysisDataAccess _otlAnalysis;
        private readonly IEscapesDataAccess _escapesDataAccess;
        private readonly IEscapesMapper _escapesMapper;

        public SpeServiceManage(IServiceDataLoader loader, ISeviceDataSave saver,
          ITtiDataAccess tti,
          IComplianceDataAccess compliance,
          IEffectivenessDataAccess effectiveness,
          IEffectivenessAnalysisDataAccess effectivenessAnalysis,
          IOtlDispositionDataAccess otlDisposition,
            ISimpleExport export,
            IPliDataAccess pli,
             IOtlAnalysisDataAccess otlAnalysis,
             IEscapesDataAccess escapesDataAccess,
              IEscapesMapper escapesMapper
             )
        {
            _tti = tti;
            _compliance = compliance;
            _effectiveness = effectiveness;
            _effectivenessAnalysis = effectivenessAnalysis;
            _otlDisposition = otlDisposition;
            _export = export;
            _pli = pli;
            _otlAnalysis = otlAnalysis;
            _escapesDataAccess = escapesDataAccess;
            _escapesMapper = escapesMapper;
        }

        public int AddCompliance(Compliance compliance)
        {
            return _compliance.AddCompliance(compliance);
        }

        public int AddTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            return _tti.AddTTiInfo(ttiPartAlignment);
        }

        public int DeleteCompliance(Compliance compliance)
        {
            return _compliance.DeleteCompliance(compliance);
        }

        public List<Compliance> LoadCompliance()
        {
            return _compliance.LoadCompliance();
        }

        public List<TtiPartAlignment> LoadTti()
        {
            return _tti.LoadTti();
        }

        public List<TtiPartAlignment> LoadTtiByDate(TtiPartAlignment ttiPartAlignment)
        {
            var data = _tti.LoadTtiByDate(ttiPartAlignment);

            return data;
        }

        public List<TtiPartAlignment> LoadTtiByParameter(TtiPartAlignment ttiPartAlignment)
        {
            return _tti.LoadTtiByParameter(ttiPartAlignment);
        }

        public int SubmitCompliances(List<Compliance> compliances)
        {
            var dbCompliances = _compliance.LoadCompliance();

            var forUpdate = compliances.Where(i => dbCompliances.Any(k => k.id == i.id)).ToList();
            var forAdd = compliances.Where(i => !dbCompliances.Any(k => k.id == i.id)).ToList();

            int rowUpdatedCount = 0;
            if (forAdd != null && forAdd.Count > 0)
            {
                foreach (var compliance in forAdd)
                {
                    rowUpdatedCount += _compliance.AddCompliance(compliance);
                }
            }
            if (forUpdate != null && forUpdate.Count > 0)
            {
                foreach (var compliance in forUpdate)
                {
                    rowUpdatedCount += _compliance.UpdateCompliance(compliance);
                }
            }

            return rowUpdatedCount;
        }

        public int SubmitTTi(List<TtiPartAlignment> tti)
        {
            int returnvalue = 0;
            foreach (TtiPartAlignment ttiItem in tti)
            {
                //var value= _loader.LoadTtiByParameter(ttiItem);
                var value = _tti.LoadTtiById(ttiItem);
                if (value == null && value.Count == 0)
                    returnvalue += _tti.AddTTiInfo(ttiItem);
                else
                    returnvalue += _tti.UpdateTTiInfo(ttiItem);
            }
            return returnvalue;
        }

        public int UpdateCompliance(Compliance compliance)
        {
            return _compliance.UpdateCompliance(compliance);
        }

        public int UpdateTTiInfo(TtiPartAlignment ttiPartAlignment)
        {
            return _tti.UpdateTTiInfo(ttiPartAlignment);
        }

        public List<Effectiveness> LoadEffectivenesByDate(Effectiveness effectiveness)
        {
            return _effectiveness.LoadEffectivenesByDate(effectiveness);
        }

        public List<Effectiveness> LoadEffectivenesById(Effectiveness effectiveness)
        {
            return _effectiveness.LoadEffectivenesById(effectiveness);
        }

        public List<Effectiveness> LoadEffectivenesByPart(Effectiveness effectiveness)
        {
            return _effectiveness.LoadEffectivenesByPart(effectiveness);
        }

        public int SubmitEffectivenes(List<Effectiveness> effectiveness)
        {
            int returnValue = 0;
            foreach (var eft in effectiveness)
            {
                var lodadedEft = _effectiveness.LoadEffectivenesById(eft);

                if (lodadedEft == null || lodadedEft.Count == 0)
                {
                    returnValue += _effectiveness.AddEffectiveness(eft);
                }
                else
                    returnValue += _effectiveness.UpdateEffectiveness(eft);
            }
            return returnValue;
        }

        public List<Effectiveness> LoadPppPartInfo(Effectiveness effectiveness)
        {
            return _effectiveness.LoadPppPartInfo(effectiveness);
        }

        public List<EffectivenessAnalysis> LoadEffectivenesAnalysis()
        {
            return _effectivenessAnalysis.LoadEffectivenesAnalysis();
        }

        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisByCreationDate(EffectivenessAnalysis effectivenessAnalysis)
        {
            return _effectivenessAnalysis.LoadEffectivenessAnalysisByCreationDate(effectivenessAnalysis);
        }

        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisById(EffectivenessAnalysis effectivenessAnalysis)
        {
            return _effectivenessAnalysis.LoadEffectivenessAnalysisById(effectivenessAnalysis);
        }

        public List<EffectivenessAnalysis> LoadEffectivenessAnalysisByPart(EffectivenessAnalysis effectivenessAnalysis)
        {
            return _effectivenessAnalysis.LoadEffectivenessAnalysisByPart(effectivenessAnalysis);
        }

        public int SubmitOtlDisposition(List<OtlDispositionDetails> lstOTL)
        {
            int returncount = 0;
            foreach (var otl in lstOTL)
            {
                returncount = _otlDisposition.UpdateOtlDispositionByID(otl);
            }
            return returncount;
        }

        public List<OtlDispositionDetails> LoadOtlDispositionById(OtlDispositionDetails otlDisposition)
        {
            return _otlDisposition.LoadOtlDispositionById(otlDisposition);
        }

        public List<OtlDispositionDetails> LoadOtlDispositionByDate(OtlDispositionDetails otlDisposition)
        {
            return _otlDisposition.LoadOtlDispositionByDate(otlDisposition);
        }

        public List<OtlDispositionDetails> LoadOtlDispositionByKeyCode(OtlDispositionDetails otlDisposition)
        {
            return _otlDisposition.LoadOtlDispositionByKeyCode(otlDisposition);
        }

        public int UpdateOtlDispositionByID(OtlDispositionDetails otlDisposition)
        {
            return _otlDisposition.UpdateOtlDispositionByID(otlDisposition);
        }

        public byte[] ExportEffectivenesAnalysis(EffectivenessAnalysis effectivenessAnalysis)
        {
            var data = LoadEffectivenessAnalysisByCreationDate(effectivenessAnalysis);
            return _export.Export<EffectivenessAnalysis>(data, "Effectiveness_Analysis", 0);
        }

        public byte[] ExportOtlDisposition(OtlDispositionDetails otlDisposition)
        {
            var data = LoadOtlDispositionByDate(otlDisposition);
            return _export.Export<OtlDispositionDetails>(data, "OTL_Disposition", 0);
        }

        public byte[] ExportEffectivene(Effectiveness effectiveness)
        {
            var data = LoadEffectivenesByDate(effectiveness);
            return _export.Export<Effectiveness>(data, "Effectiveness", 0);
        }

        public byte[] ExportTti(TtiPartAlignment tti)
        {
            var data = LoadTtiByDate(tti);
            return _export.Export<TtiPartAlignment>(data, "TTIPartAlignment ", 10);
        }

        public byte[] ExportCompliance(Compliance compliance)
        {
            var data = LoadCompliance();
            return _export.Export<Compliance>(data, "Compliance ", 0);
        }

        public byte[] ExportPliByDate(Pli pli)
        {
            var plidata = LoadPliByDate(pli);
            return _export.Export<Pli>(plidata, "F_PLI", 0);
        }

        public byte[] ExportOtlAnalysisByDate(OtlAnalysis otlAnalysis)
        {
            var data = LoadOtlAnalysisByDate(otlAnalysis);
            return _export.Export<OtlAnalysis>(data, "OTL_Analysis", 0);
        }

        public List<Pli> LoadPli()
        {
            return _pli.LoadPli();
        }

        public List<Pli> LoadPliByDate(Pli pli)
        {
            return _pli.LoadByDate(pli);
        }

        public List<Pli> LoadPliById(Pli pli)
        {
            return _pli.LoadById(pli);
        }

        public List<Pli> LoadPliByKeyCode(Pli pli)
        {
            return _pli.LoadByKeyCode(pli);
        }

        public List<OtlAnalysis> LoadOtlAnalysis()
        {
            return _otlAnalysis.LoadOtlAnalysis();
        }

        public List<OtlAnalysis> LoadOtlAnalysisByDate(OtlAnalysis otl)
        {
            return _otlAnalysis.LoadOtlAnalysisByDate(otl);
        }

        public List<OtlAnalysis> LoadOtlAnalysisById(OtlAnalysis otl)
        {
            return _otlAnalysis.LoadOtlAnalysisById(otl);
        }

        public List<OtlAnalysis> LoadOtlAnalysisByKeyCode(OtlAnalysis otl)
        {
            return _otlAnalysis.LoadOtlAnalysisByKeyCode(otl);
        }

        public int SubmitOtlAnalysisById(List<OtlAnalysis> otls)
        {
            int returnValue = 0;
            foreach (var otl in otls)
            {
                var otldata = _otlAnalysis.LoadOtlAnalysisById(otl);
                if (otldata == null || otldata.Count == 0)
                    returnValue += _otlAnalysis.UpdateOtlAnalysisById(otl);
                else
                    returnValue += _otlAnalysis.AddOtlAnalysisById(otl);
            }
            return returnValue;
        }

        public EscapesManufacturedOtl EscapesManufacturedOtl(DateTime fromdate, int subtractMonth)
        {

            var toDate = fromdate.AddMonths(-(subtractMonth));
            var escapsData = _escapesDataAccess.LoadEscapesDataBtweenShipDate(toDate, fromdate);
            var escapesDictionary = _escapesMapper.GetMapDictionary(escapsData);
            return new EscapesManufacturedOtl { EscapesManufacturedAfterOtl = escapesDictionary };



            //var lastMonthYear = fromdate.AddMonths(-(subtractMonth));

            //Dictionary<int, int[]> dic = new Dictionary<int, int[]>();
            //Random random = new Random();
            //int dicIndex = 0;
            //if (fromdate > lastMonthYear)
            //{
            //    for (int i = 0; i < subtractMonth; i++)
            //    {
            //        var mnthyr = fromdate.AddMonths(-(i));
            //        if (!dic.ContainsKey(mnthyr.Year))
            //        {
            //            dicIndex = 0;
            //            dic.Add(mnthyr.Year, new int[subtractMonth]);
            //            dic[mnthyr.Year][dicIndex] = random.Next(1, 9);
            //            dicIndex++;
            //        }
            //        else
            //        {
            //            dic[mnthyr.Year][dicIndex] = random.Next(1, 9);
            //            dicIndex++;
            //        }
            //    }
            //}

            //return new EscapesManufacturedOtl { EscapesManufacturedAfterOtl = dic };
        }

        public byte[] ExportEscapesManufacturedOtl(DateTime fromdate, int subtractMonth)
        {
            var toDate = fromdate.AddMonths(-(subtractMonth));
            var escapsData = _escapesDataAccess.LoadEscapesDataBtweenShipDate(toDate, fromdate);
            var escapesTable = _escapesMapper.GetMapDataTable(escapsData);
            return _export.ExportChart(escapesTable, "PTL Escapes", "Escapes Manufactured After OTL", "Escapes", "Months After OTL", "MonthsSinceOTL", OfficeOpenXml.Drawing.Chart.eChartType.Line);
        }

        public byte[] ExportAllPli()
        {
            var plidata = LoadPli();
            return _export.Export<Pli>(plidata, "F_PLI", 0);
        }

        public byte[] ExportPliByFilter(Pli criteria)
        {
            var allData = LoadPli();

            if (!string.IsNullOrEmpty(criteria.SBU))
                allData = allData.Where(i => string.Compare(i.SBU, criteria.SBU, StringComparison.OrdinalIgnoreCase) == 0).ToList();

            if (!string.IsNullOrEmpty(criteria.GBE))
                allData = allData.Where(i => string.Compare(i.GBE, criteria.GBE, StringComparison.OrdinalIgnoreCase) == 0).ToList();


            if (!string.IsNullOrEmpty(criteria.IpdsPhase))
                allData = allData.Where(i => string.Compare(i.IpdsPhase, criteria.IpdsPhase, StringComparison.OrdinalIgnoreCase) == 0).ToList();


            if (!string.IsNullOrEmpty(criteria.PliRating))
                allData = allData.Where(i => string.Compare(i.PliRating, criteria.PliRating, StringComparison.OrdinalIgnoreCase) == 0).ToList();

            return _export.Export<Pli>(allData, "F_PLI", 0);
        }
    }
}