﻿using Fraca.Service.Service;
using Fraca.Service.ServiceConsumer;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Fraca.Api.Service.Host.Controllers
{
    public class EmployeeController : ApiController
    {

        private readonly IEmployeeServcie _employeeServcie;

        public EmployeeController(IEmployeeServcie employeeServcie)
        {
            _employeeServcie = employeeServcie;
        }


        [HttpGet]
        public HttpResponseMessage GetEmployeeName(string id)
        {
           var info = _employeeServcie.GetEmployeeInfo(id);

            if(info == null || info.Count ==0)
                return Request.CreateResponse(HttpStatusCode.NonAuthoritativeInformation, info[0], JsonMediaTypeFormatter.DefaultMediaType);

            var res = Request.CreateResponse(HttpStatusCode.OK, info[0], JsonMediaTypeFormatter.DefaultMediaType);
            
            return res;
        }
    }
}
