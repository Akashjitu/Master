﻿using Oracle.Data.Access.Constants;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;

namespace Oracle.Data.Access
{
    public class DataAccessObject<T> : IDisposable where T : class
    {
        public OracleConnection OracleDataBaseConnection { get { return _oracleConnection; } }

        private readonly OracleConnection _oracleConnection = null;

        public string ConnectionString { get { return _connectionString; } }
        private readonly string _connectionString = null;

        public DataAccessObject()
        {
           if(!ConfigurationManager.AppSettings.AllKeys.Contains(DataAccessConstant.CONNECTION_STRING))
            {
                throw new Exception("CONNECTION_STRING not found in your App or web Config, Please Add CONNECTION_STRING as a Key and Value is your Db connection string.");
            }

            _connectionString = ConfigurationManager.AppSettings[DataAccessConstant.CONNECTION_STRING].ToString();
            _oracleConnection = new OracleConnection(_connectionString);
            _oracleConnection.Open();
        }

        private Dictionary<string, string> _entityProperties;

        /// <summary>
        /// Load all data from table based on Package and Stored Procedure Name.
        /// </summary>
        /// <param name="storedProcedure">Provide Stored Procedure Name with packages name Like package.sp.</param>
        /// <returns>Load All data From database.</returns>
        public IList<T> Load(string storedProcedure)
        {
            try
            {
                var DbColumn = GetStoredProcedureInfo(storedProcedure).Values.Where(i => i.IN_OUT == "OUT").FirstOrDefault();

                _entityProperties = GetNameAndDbName();

                if (_entityProperties == null)
                    return null;

                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = storedProcedure;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(DbColumn.ARGUMENT_NAME, OracleDbType.RefCursor, ParameterDirection.Output).Value = null;
                    var dr = command.ExecuteReader();
                    var lstEntities = new List<T>();
                    while (dr.Read())
                    {
                        var entity = MapData(dr);

                        if (entity != null)
                            lstEntities.Add(entity);
                    }
                    return lstEntities;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Load all data from table based on Package and Stored Procedure Name.
        /// </summary>
        /// <param name="entity"> Provide Class object and set data in properties based on the Stored Procedure parameters.</param>
        /// <param name="storedProcedure">Provide Stored Procedure Name with packages name Like package.sp.</param>
        /// <returns>Load data bease on the Stored Procedure parameters. </returns>
        public IList<T> LoadByInput(T entity, string storedProcedure)
        {
            try
            {
                var dbColumnInfo = GetStoredProcedureInfo(storedProcedure);
                var entityColumnInfo = GetNameAndDbName();

                _entityProperties = GetNameAndDbName();

                if (_entityProperties == null)
                    return null;

                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = storedProcedure;
                    command.CommandType = CommandType.StoredProcedure;

                    foreach (var key in dbColumnInfo.Keys)
                    {
                        OracleDbType oracleDbType = GetOracleDbType(dbColumnInfo[key].DATA_TYPE);
                        ParameterDirection parameterDirection = GetParameterDirection(dbColumnInfo[key].IN_OUT);

                        var propertyName = entityColumnInfo.Where(i => 
                        string.Compare(i.Value, dbColumnInfo[key].ARGUMENT_NAME, StringComparison.OrdinalIgnoreCase) == 0)
                        .Select(i => i.Key).FirstOrDefault();

                        object propertyValue = string.Empty;
                        if (propertyName != null && dbColumnInfo[key].IN_OUT != "OUT")
                            propertyValue = entity.GetType().GetProperty(propertyName).GetValue(entity, null);



                        //if ((propertyValue == null || propertyValue == "") && dbColumnInfo[key].IN_OUT != "OUT")
                        //    throw new Exception(string.Format("Parameter name or Column name mismatch : {0}", dbColumnInfo[key].ARGUMENT_NAME));

                        if (dbColumnInfo[key].IN_OUT == "OUT")
                            command.Parameters.Add(dbColumnInfo[key].ARGUMENT_NAME, OracleDbType.RefCursor, ParameterDirection.Output).Value = null;
                        else
                            command.Parameters.Add(dbColumnInfo[key].ARGUMENT_NAME, oracleDbType, propertyValue, parameterDirection);
                    }

                    var dr = command.ExecuteReader();
                    var lstEntities = new List<T>();
                    while (dr.Read())
                    {
                        var mapEntity = MapData(dr);

                        if (entity != null)
                            lstEntities.Add(mapEntity);
                    }
                    return lstEntities;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public IList<T> LoaderByQuery(string query)
        {
            if (string.IsNullOrEmpty(query))
                throw new Exception("DataBase is Empty or Null");

            if (_oracleConnection.State == ConnectionState.Closed)
            {
                _oracleConnection.Open();
            }

            using (var command = _oracleConnection.CreateCommand())
            {
                command.CommandText = query.Trim();
                command.CommandType = CommandType.Text;
                var dr = command.ExecuteReader();
                var lstEntities = new List<T>();
                while (dr.Read())
                {
                    var mapEntity = MapData(dr);
                        lstEntities.Add(mapEntity);
                }
                return lstEntities;
            }
            
        }

        



        /// <summary>
        /// Insert Data into the table, help of  Stored Procedure.
        /// </summary>
        /// <param name="entity">Provide Class object and set data in properties based on the Stored Procedure parameters.</param>
        /// <param name="spFullName">Provide Stored Procedure Name with packages name Like package.sp.</param>
        /// <returns>return affected rows count.</returns>
        public int Post(T entity, string spFullName)
        {
            return Execute(entity, spFullName);
        }

        /// <summary>
        /// update Data to the table, help of  Stored Procedure.
        /// </summary>
        /// <param name="entity">Provide Class object and set data in properties based on the Stored Procedure parameters.</param>
        /// <param name="spFullName">Provide Stored Procedure Name with packages name Like package.sp.</param>
        /// <returns>return affected rows count.</returns>
        public int Put(T entity, string spFullName)
        {
            return Execute(entity, spFullName);
        }

        /// <summary>
        /// Delete Data From table, help of Stored Procedure.
        /// </summary>
        /// <param name="entity">Provide Class object and set data in properties based on the Stored Procedure parameters.</param>
        /// <param name="spFullName">Provide Stored Procedure Name with packages name Like package.sp.</param>
        /// <returns>return affected rows count.</returns>
        public int Delete(T entity, string spFullName)
        {
            return Execute(entity, spFullName);
        }


        /// <summary>
        /// Get Information about any Stored Procedure like Type of parameter, etc.
        /// </summary>
        /// <param name="fullName">Provide Stored Procedure Name with packages name Like package.sp.</param>
        /// <returns> Dictionary with StoredProcedureInfo</returns>
        public Dictionary<string, StoredProcedureInfo> GetStoredProcedureInfo(string fullName)
        {
            var arr = fullName.Split('.');
            string sqlcommand = string.Format(DataAccessConstant.SP_INFO, arr);
            try
            {
                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = sqlcommand;
                    command.CommandType = CommandType.Text;
                    var dr = command.ExecuteReader();
                    var dicEntities = new Dictionary<string, StoredProcedureInfo>();

                    while (dr.Read())
                    {
                        var info = new StoredProcedureInfo();

                        info.OWNER = dr["OWNER"].ToString();
                        info.OBJECT_NAME = dr["OBJECT_NAME"].ToString();
                        info.PACKAGE_NAME = dr["PACKAGE_NAME"].ToString();
                        info.OBJECT_ID = dr["OBJECT_ID"].ToString();
                        info.OVERLOAD = dr["OVERLOAD"].ToString();
                        info.SUBPROGRAM_ID = dr["SUBPROGRAM_ID"].ToString();
                        info.ARGUMENT_NAME = dr["ARGUMENT_NAME"].ToString();
                        info.POSITION = dr["POSITION"].ToString();
                        info.SEQUENCE = dr["SEQUENCE"].ToString();
                        info.DATA_LEVEL = dr["DATA_LEVEL"].ToString();
                        info.DATA_TYPE = dr["DATA_TYPE"].ToString();
                        info.DEFAULTED = dr["DEFAULTED"].ToString();
                        info.DEFAULT_VALUE = dr["DEFAULT_VALUE"].ToString();
                        info.DEFAULT_LENGTH = dr["DEFAULT_LENGTH"].ToString();
                        info.IN_OUT = dr["IN_OUT"].ToString();
                        info.DATA_LENGTH = dr["DATA_LENGTH"].ToString();
                        info.DATA_PRECISION = dr["DATA_PRECISION"].ToString();
                        info.DATA_SCALE = dr["DATA_SCALE"].ToString();
                        info.RADIX = dr["RADIX"].ToString();
                        info.CHARACTER_SET_NAME = dr["CHARACTER_SET_NAME"].ToString();
                        info.TYPE_OWNER = dr["TYPE_OWNER"].ToString();
                        info.TYPE_NAME = dr["TYPE_NAME"].ToString();
                        info.TYPE_SUBNAME = dr["TYPE_SUBNAME"].ToString();
                        info.TYPE_LINK = dr["TYPE_LINK"].ToString();
                        info.PLS_TYPE = dr["PLS_TYPE"].ToString();
                        info.CHAR_LENGTH = dr["CHAR_LENGTH"].ToString();
                        info.CHAR_USED = dr["CHAR_USED"].ToString();
                        info.ORIGIN_CON_ID = dr["ORIGIN_CON_ID"].ToString();

                        dicEntities.Add(info.ARGUMENT_NAME, info);
                    }
                    return dicEntities.Values.OrderBy(i => int.Parse(i.POSITION)).ToDictionary(i => i.ARGUMENT_NAME, k => k);
                    // return dicEntities;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private Dictionary<string, string> GetNameAndDbName()
        {
            var entityType = typeof(T);
            var properties = entityType.GetProperties();

            Dictionary<string, string> cloumn = new Dictionary<string, string>();

            foreach (var property in properties)
            {
                //var dd =  property.GetCustomAttributes(false)
                //                                          .ToDictionary(a => a.GetType().Name, a => a);

                var sColumns = property.GetCustomAttributes(false).Where(i => i is Columns).Select(i => (i as Columns)).ToList();

                if (sColumns == null)
                    return null;
                foreach (var col in sColumns)
                {
                    cloumn.Add(property.Name, col.DataBaseColumnName);
                }
            }
            return cloumn;
        }

        private T MapData(OracleDataReader datareader)
        {
            if (datareader == null)
                return default(T);
            var entity = (T)Activator.CreateInstance(typeof(T));

            var properties = entity.GetType().GetProperties();

            if (properties == null)
                return default(T);

            foreach (var entityProperty in _entityProperties)
            {
                var propertyInfo = properties.Where(i => (string.Compare(i.Name, entityProperty.Key, StringComparison.OrdinalIgnoreCase) == 0)).First();
                //   bool isFieldExists = datareader.GetSchemaTable().Columns.Contains(entityProperty.Value);
                bool isFieldExists = Enumerable.Range(0, datareader.FieldCount).Any(i => string.Compare(datareader.GetName(i), entityProperty.Value, StringComparison.OrdinalIgnoreCase) == 0);
                if (propertyInfo != null && isFieldExists)
                {
                    //  propertyInfo.SetValue(entity, Convert.ChangeType(datareader[entityProperty.Value].ToString(), propertyInfo.PropertyType), null);

                    var dbvalue = datareader[entityProperty.Value];
                    if (dbvalue  is DBNull)
                        continue;
                    var targetType = IsNullableType(propertyInfo.PropertyType) ? Nullable.GetUnderlyingType(propertyInfo.PropertyType) : propertyInfo.PropertyType;

                    propertyInfo.SetValue(entity, Convert.ChangeType(datareader[entityProperty.Value], targetType), null);
                }
            }
            return entity;
        }
        
        private ParameterDirection GetParameterDirection(string name)
        {
            switch (name)
            {
                case "IN":
                    return ParameterDirection.Input;

                case "OUT":
                    return ParameterDirection.Output;

                default:
                    ParameterDirection parameterDirection;
                    Enum.TryParse(name, out parameterDirection);
                    return parameterDirection;
            }
        }

        private OracleDbType GetOracleDbType(string datatype)
        {
            switch (datatype.ToLower())
            {
                case "varchar2":return OracleDbType.Varchar2;
                case "bfile": return OracleDbType.BFile;
                case "blob": return OracleDbType.Blob;
                case "byte": return OracleDbType.Byte;
                case "char": return OracleDbType.Char;
                case "clob": return OracleDbType.Clob;
                case "date": return OracleDbType.Date;
                case "decimal": return OracleDbType.Decimal;
                case "double": return OracleDbType.Double;
                case "long": return OracleDbType.Long;
                case "longraw": return OracleDbType.LongRaw;
                case "int16": return OracleDbType.Int16;
                case "int32": return OracleDbType.Int32;
                case "int64": return OracleDbType.Int64;
                case "intervalds": return OracleDbType.IntervalDS;
                case "intervalym": return OracleDbType.IntervalYM;
                case "nclob": return OracleDbType.NClob;
                case "nchar": return OracleDbType.NChar;
                case "nvarchar2": return OracleDbType.NVarchar2;
                case "raw": return OracleDbType.Raw;
                case "ref cursor": return OracleDbType.RefCursor;
                case "refcursor": return OracleDbType.RefCursor;
                case "single": return OracleDbType.Single;
                case "timestamp": return OracleDbType.TimeStamp;
                case "timestampltz": return OracleDbType.TimeStampLTZ;
                case "timestamptz": return OracleDbType.TimeStampTZ;
                case "xmltype": return OracleDbType.XmlType;
                case "binarydouble": return OracleDbType.BinaryDouble;
                case "binaryfloat": return OracleDbType.BinaryFloat;
                case "boolean": return OracleDbType.Boolean;
                case "number": return OracleDbType.Int32;
                case "bit": return OracleDbType.Boolean;
                default: return OracleDbType.Varchar2;
            }
        }

        private int Execute(T entity, string spFullName)
        {
            try
            {
                var dbColumnInfo = GetStoredProcedureInfo(spFullName);
                var entityColumnInfo = GetNameAndDbName();

                if (_oracleConnection.State == ConnectionState.Closed)
                {
                    _oracleConnection.Open();
                }
                using (var command = _oracleConnection.CreateCommand())
                {
                    command.CommandText = spFullName;
                    command.CommandType = CommandType.StoredProcedure;

                    foreach (var key in dbColumnInfo.Keys)
                    {
                        OracleDbType oracleDbType = GetOracleDbType(dbColumnInfo[key].DATA_TYPE);
                        //Enum.TryParse<OracleDbType>(dbColumnInfo[key].DATA_TYPE, out oracleDbType);

                        var propertyName = entityColumnInfo.Where(i => string.Compare(i.Value, dbColumnInfo[key].ARGUMENT_NAME,StringComparison.OrdinalIgnoreCase)==0).Select(i => i.Key).FirstOrDefault();
                        var values = entity.GetType().GetProperty(propertyName).GetValue(entity, null);

                        ParameterDirection parameterDirection = GetParameterDirection(dbColumnInfo[key].IN_OUT);

                        command.Parameters.Add(dbColumnInfo[key].ARGUMENT_NAME, oracleDbType, values, parameterDirection);
                    }
               

                    return command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        ~DataAccessObject()
        {
            Dispose();
        }

        /// <summary>
        ///  Releases all resources
        /// </summary>
        public void Dispose()
        {
            if (_oracleConnection != null)
            {
                _oracleConnection.Close();
                _oracleConnection.Dispose();
            }
        }

        private static bool IsNullableType(Type type)
        {
            return type.IsGenericType && type.GetGenericTypeDefinition().Equals(typeof(Nullable<>));
        }

    }
}