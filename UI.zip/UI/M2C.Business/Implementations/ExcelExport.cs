﻿// ***********************************************************************
// Assembly         : M2C.Business
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="ExcelExport.cs" company="M2C.Business">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using InputParserLibary.Contracts;
using InputParserLibary.DataModels;
using M2C.Business.Contracts;
using M2C.Business.Models;
using Schneider.M2C.OpenExcel.Parser;
using System;

//using OfficeOpenXml;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace M2C.Business.Implementations
{
    /// <summary>
    /// function for exporting to Excel
    /// </summary>
    public class ExcelExport : IExcelExport
    {
        /// <summary>
        /// The excel writer
        /// </summary>
        private IExcelWriter excelWriter;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExcelExport" /> class.
        /// </summary>
        /// <param name="_excelWriter">The excel writer.</param>
        public ExcelExport(IExcelWriter _excelWriter)
        {
            excelWriter = _excelWriter;
        }

        /// <summary>
        /// Export function for Installed Base
        /// </summary>
        /// <param name="inventories">The inventories.</param>
        /// <param name="FilePath">The file path.</param>
        /// <exception cref="Exception">Excel application stopped responding</exception>
        /// <exception cref="Exception"></exception>
        public void IBExcelExport(ObservableCollection<Inventory> inventories, string FilePath)
        {
            try
            {
                excelWriter.FilePath = FilePath;
                ExcelInitialization();

                List<ExcelDataColumn> headers = new List<ExcelDataColumn>() { new ExcelDataColumn() { HeaderName = ExcelParserConstants.FACTORY } ,
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.WORKSHOP },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.LINE },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.MACHINE },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.MACHINE_CRITICITY},
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.CONFIGURATION },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.CONFIGURATION_TYPE },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.REFERENCE },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.DESCRIPTION },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.PV },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.SV },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.QUANTTY },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.BRAND },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.COMMENT }};

                //Adding the Data
                List<ExcelDataRow> listDatRows = new List<ExcelDataRow>();

                foreach (var item in inventories)
                {
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Factory });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Workshop });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Line });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Machine });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Criticality ?? CriticalitystringValues.NotCritical });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Configuration });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.ConfigType });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Reference });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Name });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.PvNumber });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.SvNumber });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Quantity.ToString(), DataType = "INT" });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Brand });
                    listDatRows.Add(new ExcelDataRow() { CellData = item.Comment });
                }

                excelWriter.Write(headers, listDatRows);
            }
            catch (System.Runtime.InteropServices.COMException ex)
            {
                throw new Exception("Excel application stopped responding");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                excelWriter.Close();
            }
        }

        /// <summary>
        /// Excels the initialization.
        /// </summary>
        private void ExcelInitialization()
        {
            excelWriter.AddWorkBook();
            excelWriter.AddWorksheet("Data");
            excelWriter.SetWorkBook(1);
            excelWriter.SetActiveSheet(1);
        }

        /// <summary>
        /// Export function for Technical resource
        /// </summary>
        /// <param name="inventories">The inventories.</param>
        /// <param name="FilePath">The file path.</param>
        /// <exception cref="Exception">Excel application stopped responding</exception>
        /// <exception cref="Exception"></exception>
        public void TRExcelExport(ObservableCollection<Inventory> inventories, string FilePath)
        {
            try
            {
                excelWriter.FilePath = FilePath;
                ExcelInitialization();
                //Adding the Header
                List<ExcelDataColumn> headers = new List<ExcelDataColumn>() { new ExcelDataColumn() { HeaderName = ExcelParserConstants.MAINTENANCE_ZONE } ,
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.CONFIGURATION_NAME },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.REFERENCE },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.DESCRIPTION },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.PV },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.SV },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.QUANTTY },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.BRAND },
                                                                          new ExcelDataColumn() { HeaderName = ExcelParserConstants.COMMENT }};

                //Adding the Data
                List<ExcelDataRow> datas = new List<ExcelDataRow>();

                foreach (var item in inventories)
                {
                    datas.Add(new ExcelDataRow() { CellData = item.MaintenanceZone });
                    datas.Add(new ExcelDataRow() { CellData = item.Configuration });
                    datas.Add(new ExcelDataRow() { CellData = item.Reference });
                    datas.Add(new ExcelDataRow() { CellData = item.Name });
                    datas.Add(new ExcelDataRow() { CellData = item.PvNumber });
                    datas.Add(new ExcelDataRow() { CellData = item.SvNumber });
                    datas.Add(new ExcelDataRow() { CellData = item.Quantity.ToString(), DataType = "INT" });
                    datas.Add(new ExcelDataRow() { CellData = item.Brand });
                    datas.Add(new ExcelDataRow() { CellData = item.Comment });
                }

                excelWriter.Write(headers, datas);
            }
            catch (System.Runtime.InteropServices.COMException ex)
            {
                throw new Exception("Excel application stopped responding");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                excelWriter.Close();
            }
        }
    }
}