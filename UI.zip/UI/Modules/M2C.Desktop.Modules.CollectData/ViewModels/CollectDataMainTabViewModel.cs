﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="CollectDataMainTabViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Desktop.Modules.CollectData.Events;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class CollectDataMainTabViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class CollectDataMainTabViewModel : BindableBase
    {
        /// <summary>
        /// The tab selected
        /// </summary>
        private int _tabSelected = 0;
        /// <summary>
        /// The events
        /// </summary>
        private readonly IEventAggregator events;

        /// <summary>
        /// Gets or sets the tab selected.
        /// </summary>
        /// <value>The tab selected.</value>
        public int TabSelected
        {
            get => _tabSelected; set
            {
                _tabSelected = value;
                this.events.GetEvent<CollectDataMainTabSelectedEvent>().Publish(_tabSelected);
            }
        }
        /// <summary>
        /// Gets or sets the show add resource command.
        /// </summary>
        /// <value>The show add resource command.</value>
        public DelegateCommand ShowAddResourceCommand { get; set; }

        /// <summary>
        /// Gets the dialog service.
        /// </summary>
        /// <value>The dialog service.</value>
        public IDialogService DialogService { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="CollectDataMainTabViewModel" /> class.
        /// </summary>
        /// <param name="dialogService">The dialog service.</param>
        /// <param name="events">The events.</param>
        public CollectDataMainTabViewModel(IDialogService dialogService, IEventAggregator events)
        {
            ShowAddResourceCommand = new DelegateCommand(ShowAddResourceDialog);
            DialogService = dialogService;
            this.events = events;
        }





        /// <summary>
        /// Shows the add resource dialog.
        /// </summary>
        private void ShowAddResourceDialog()
        {
            DialogService.ShowDialog("AddInventoryDialog", null, null);
        }
    }
}