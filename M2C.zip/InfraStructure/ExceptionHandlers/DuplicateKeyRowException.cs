﻿// ***********************************************************************
// Assembly         : ExceptionHandlers
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="DuplicateKeyRowException.cs" company="ExceptionHandlers">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using Microsoft.Data.Sqlite;
using System;
using System.Data;

namespace ExceptionHandlers
{
    /// <summary>
    /// Class DuplicateKeyRowException.
    /// Implements the <see cref="System.Exception" />
    /// </summary>
    /// <seealso cref="System.Exception" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DuplicateKeyRowException : Exception
    {
        /// <summary>
        /// Gets the name of the table.
        /// </summary>
        /// <value>The name of the table.</value>
        public string TableName { get; }
        /// <summary>
        /// Gets the name of the index.
        /// </summary>
        /// <value>The name of the index.</value>
        public string IndexName { get; }
        /// <summary>
        /// Gets the key values.
        /// </summary>
        /// <value>The key values.</value>
        public string KeyValues { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DuplicateKeyRowException" /> class.
        /// </summary>
        /// <param name="e">The e.</param>
        /// <exception cref="ArgumentException">SqlException is not a duplicate key row exception</exception>
        public DuplicateKeyRowException(SqliteException e) : base(e.Message, e)
        {
            if (e.SqliteExtendedErrorCode != 2601)
                throw new ArgumentException("SqlException is not a duplicate key row exception", e);

            var regex = @"\ACannot insert duplicate key row in object \'(?<TableName>.+?)\' with unique index \'(?<IndexName>.+?)\'\. The duplicate key value is \((?<KeyValues>.+?)\)";
            var match = new System.Text.RegularExpressions.Regex(regex, System.Text.RegularExpressions.RegexOptions.Compiled).Match(e.Message);

            Data["TableName"] = TableName = match?.Groups["TableName"].Value;
            Data["IndexName"] = IndexName = match?.Groups["IndexName"].Value;
            Data["KeyValues"] = KeyValues = match?.Groups["KeyValues"].Value;
        }
    }
}
