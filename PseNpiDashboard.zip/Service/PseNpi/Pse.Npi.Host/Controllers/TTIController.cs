﻿using Pse.Data.Models;
using Pse.Services.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace Pse.Npi.Host.Controllers
{
    public class TTIController : ApiController
    {
        ISpeService _service;
        public TTIController(ISpeService service)
        {
            _service = service;

        }

        [HttpGet]
        public HttpResponseMessage Get(string infoCreatedDate, string filertType)
        {
            DateTime dt;
            if (!DateTime.TryParse(infoCreatedDate, out dt) || string.IsNullOrEmpty(filertType) )
                return Request.CreateResponse(HttpStatusCode.BadRequest, "Please Select Date", JsonMediaTypeFormatter.DefaultMediaType);

            List<TtiPartAlignment> ttiPartAlignments = null;

            switch (filertType)
            {
                case "OTL":

                    ttiPartAlignments = _service.LoadTti();
                    ttiPartAlignments = ttiPartAlignments.Where(i => i.OTL_Baseline_Date == dt.Year.ToString()).ToList();

                    break;
                case "PPM":
                 //   ttiPartAlignments = ttiPartAlignments.Where(i => i.PP == infoCreatedDate).ToList();
                    break;
                case "RTY":
                    break;
                case "BaseLine":
                    break;
                case "Created":
                      ttiPartAlignments  = _service.LoadTtiByDate(new TtiPartAlignment() { InfoCreatedDate = dt });
                    break;

                default:
                    break;
            }
          //    < li class="dropdown-item" (click)="onLoadFilterChange('BaseLine')">Load By BaseLine Year</li>
          //<li class="dropdown-item" (click)="onLoadFilterChange('')">Load By OTL</li>
          //<li class="dropdown-item" (click)="onLoadFilterChange('')">Load By PPM</li>
          //<li class="dropdown-item" (click)="onLoadFilterChange('')">Load By RTY</li>
          //<li class="divider"></li>
          //<li class="dropdown-item" (click)="onLoadFilterChange('Created')">Load By Created</li>
        
 

          //  var tti = _service.LoadTtiByDate(new TtiPartAlignment() { InfoCreatedDate = dt });
            
            return Request.CreateResponse(HttpStatusCode.OK, ttiPartAlignments, JsonMediaTypeFormatter.DefaultMediaType);
        }



        [HttpPost]
        public HttpResponseMessage SaveTti(TtiPartAlignment[] ttiPartAlignment)
        {
            var cp = _service.SubmitTti(ttiPartAlignment.ToList());


            return Request.CreateResponse(HttpStatusCode.OK, cp, JsonMediaTypeFormatter.DefaultMediaType);
        }

    }
}
