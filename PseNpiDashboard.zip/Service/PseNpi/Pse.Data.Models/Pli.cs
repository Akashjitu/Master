﻿using Oracle.Data.Access;
using Pse.Data.Models.Attributes;
using System;

namespace Pse.Data.Models
{
    public class Pli
    {
        private string _IrfHealth;
        private string _EseHealth;
        private string _CrfHealth;
        private string _PliRating;
        private string _ApqpHealth;
        private string _Rtyhealth;
        private string _UPC;
        private string _OtlHealth;

        [Columns("P_KEY_CODE")]
        public string KeyCode { get; set; }

        [Columns("P_PROGRAM_NAME")]
        public string ProgramName { get; set; }

        [Columns("P_PROGRAM_PM")]
        public string ProgramPM { get; set; }

        [Columns("P_SBU")]
        public string SBU { get; set; }

        [Columns("P_GBE")]
        public string GBE { get; set; }

        [Columns("P_IPDS_PHASE")]
        public string IpdsPhase { get; set; }

        [Columns("P_IRF_HEALTH")]
        public string IrfHealth
        {
            get { return _IrfHealth == null ? null : _IrfHealth.Trim('\''); }
            set { _IrfHealth = value; }
        }

        [Columns("P_CRF_HEALTH")]
        public string CrfHealth
        {
            get { return _CrfHealth == null ? null : _CrfHealth.Trim('\''); }
            set { _CrfHealth = value; }
        }

        [Columns("P_ESE_HEALTH")]
        public string EseHealth
        {
            get { return _EseHealth == null ? null : _EseHealth.Trim('\''); }
            set { _EseHealth = value; }
        }

        [Columns("P_RTY_HEALTH")]
        public string Rtyhealth
        {
            get { return _Rtyhealth == null ? null : _Rtyhealth.Trim('\''); }
            set { _Rtyhealth = value; }
        }

        [Columns("P_UPC")]
        public string UPC
        {
            get { return _UPC == null ? null : _UPC.Trim('\''); }
            set { _UPC = value; }
        }

        [Columns("P_APQP_HEALTH")]
        public string ApqpHealth
        {
            get { return _ApqpHealth == null ? null : _ApqpHealth.Trim('\''); }
            set { _ApqpHealth = value; }
        }

        [Columns("P_PLI_RATING")]
        public string PliRating
        {
            get { return _PliRating == null ? null : _PliRating.Trim('\''); }
            set { _PliRating = value; }
        }

        [Columns("P_OTL")]
        public string OtlHealth 
        {
            get { return _OtlHealth == null ? null : _OtlHealth.Trim('\''); }
            set { _OtlHealth = value; }
        }

        [Columns("P_OTL_COMMNETS")]
        public string OtlCommnets { get; set; }

        [ExportColumn(true)]
        [Columns("P_CREATED_DATE")]
        public DateTime CreatedDate { get; set; }

        [Columns("P_CREATED_BY")]
        public string CreatedBy { get; set; }

        [Columns("P_UPDATED_BY")]
        public string UpdatedBy { get; set; }

        [Columns("P_ACTIVE")]
        public string Active { get; set; }

        [ExportColumn(true)]
        [Columns("P_UPDATED_DATE")]
        public DateTime UpdatedDate { get; set; }

        [ExportColumn(true)]
        [Columns("P_ID")]
        public int Id { get; set; }


        [Columns("P_NO_OF_NEW_PARTS")]
        public string NoOfNewParts { get; set; }

        [Columns("P_NO_OF_NEW_PARTS_ON_CONTRACT")]
        public string NoOfNewPartsOnContract { get; set; }

        [Columns("P_ESE_NEW_VERSION")]
        public string EseNewVersion { get; set; }

        [Columns("P_IRF")]
        public string Irf { get; set; }

        [Columns("P_CRF")]
        public string Crf { get; set; }

        [Columns("P_ECE_ESCAPES")]
        public string EceEscapes { get; set; }

    }
}