import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { IAppState } from '../store/pliSummary/pliSummaryReducer';
import { saveAs } from 'file-saver';
import * as OtlSummaryAction from './../store/OtlSummery/otlSummaryAction';
import { NgxSpinnerService } from 'ngx-spinner';
import {environment } from '../../environments/environment'
@Injectable({
  providedIn: 'root'
})
export class OtlSummaryService {
 

  headers: any;
  url = environment.apiBaseUrl;
  fileBaseUrl = environment.fileBaseUrl;

  constructor(private http: HttpClient, private store: Store<IAppState>, private spinner: NgxSpinnerService) {
    this.headers = new HttpHeaders({
      Accept: 'application/json',
      'zumo-api-version': '2.0.0',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true',
     'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE, PUT',
     withCredentials: 'true',
  });
   }


   reportDownload(date) {
    console.log(date);
   
    this.http.get(this.fileBaseUrl+'OtlSummery?date=' + date , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'PliSummary' + date + '.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }

  getAllOtlSummary() {
    this.spinner.show();
    this.http.get<any>(this.url+'OtlSummery')
    .subscribe(res => {
      this.spinner.hide()
      this.store.dispatch(new OtlSummaryAction.LoadGridOtlSummary(res)
      )}, err => {
            this.spinner.hide();
          });
  }


  
  loadPliByFilter(criteria) {
    this.spinner.show();
    console.log('Load By  criteria ' + criteria)
    return this.http.post(this.url + 'OtlSummery/loadbycriteria', criteria, { headers: this.headers })
    .subscribe(res => {
      this.spinner.hide()
      this.store.dispatch(new OtlSummaryAction.LoadGridOtlSummary(res)
      )}, err => {
            this.spinner.hide();
          });
  }


  update(modifieditems) {
    this.spinner.show();
    console.log('updated   ' + JSON.stringify(modifieditems))
    return this.http.put(this.url + 'OtlSummery/'+ modifieditems.id, modifieditems, { headers: this.headers })
    .subscribe(res => {
      this.spinner.hide()
      this.store.dispatch(new OtlSummaryAction.UpdateGridOtlSummary(res)
      )}, err => {
            this.spinner.hide();
          });
  }


  reportDownloadByFilter(data) {
    this.http.post(this.fileBaseUrl+'plifilterreport', data , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'PliSummary.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }
  
  reportDownloadAll() {
    this.http.get(this.fileBaseUrl+'plisummaryreport' , {responseType: 'blob', headers: this.headers} )
   .subscribe(response => { saveAs(response, 'PliSummary.xlsx',
   { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })},
   err => {console.log(`ERROR: ${err}`),
   console.log('error', 'Whoops, Not able to connect with service. Please check PSE Service'); });
  }

}
