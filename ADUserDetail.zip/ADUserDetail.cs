﻿
using System.DirectoryServices;

namespace Honeywell.ActiveDirectory
{
    public class ADUserDetail: ADProfile
    {
        private string _firstName;
        private string _middleName;
        private string _lastName;
        private string _loginName;
        private string _loginNameWithDomain;
        private string _streetAddress;
        private string _city;
        private string _state;
        private string _postalCode;
        private string _country;
        private string _homePhone;
        private string _extension;
        private string _mobile;
        private string _fax;
        private string _emailAddress;
        private string _title;
        private string _company;
        private string _manager;
        private string _managerName;
        private string _department;
        private string _displayName;

        public string DisplayName
        {
            get
            {
                return this._displayName;
            }
        }

        public string Department
        {
            get
            {
                return this._department;
            }
        }

        public string FirstName
        {
            get
            {
                return this._firstName;
            }
        }

        public string MiddleName
        {
            get
            {
                return this._middleName;
            }
        }

        public string LastName
        {
            get
            {
                return this._lastName;
            }
        }

        public string LoginName
        {
            get
            {
                return this._loginName;
            }
        }

        public string LoginNameWithDomain
        {
            get
            {
                return this._loginNameWithDomain;
            }
        }

        public string StreetAddress
        {
            get
            {
                return this._streetAddress;
            }
        }

        public string City
        {
            get
            {
                return this._city;
            }
        }

        public string State
        {
            get
            {
                return this._state;
            }
        }

        public string PostalCode
        {
            get
            {
                return this._postalCode;
            }
        }

        public string Country
        {
            get
            {
                return this._country;
            }
        }

        public string HomePhone
        {
            get
            {
                return this._homePhone;
            }
        }

        public string Extension
        {
            get
            {
                return this._extension;
            }
        }

        public string Mobile
        {
            get
            {
                return this._mobile;
            }
        }

        public string Fax
        {
            get
            {
                return this._fax;
            }
        }

        public string EmailAddress
        {
            get
            {
                return this._emailAddress;
            }
        }

        public string Title
        {
            get
            {
                return this._title;
            }
        }

        public string Company
        {
            get
            {
                return this._company;
            }
        }

        public ADUserDetail Manager
        {
            get
            {
                if (!string.IsNullOrEmpty(this._managerName))
                    return new ActiveDirectoryHelper().GetUserByFullName(this._managerName);
                return (ADUserDetail)null;
            }
        }

        public string ManagerName
        {
            get
            {
                return this._managerName;
            }
        }

        private ADUserDetail(DirectoryEntry directoryUser)
        {
            string str = "";
            this._displayName = ADUserDetail.GetProperty(directoryUser, "displayName");
            this._firstName = ADUserDetail.GetProperty(directoryUser, "givenName");
            this._middleName = ADUserDetail.GetProperty(directoryUser, "initials");
            this._lastName = ADUserDetail.GetProperty(directoryUser, "sn");
            this._loginName = ADUserDetail.GetProperty(directoryUser, "sAMAccountName");
            ADUserDetail.GetProperty(directoryUser, "userPrincipalName");
            this._loginNameWithDomain = string.Format("{0}\\{1}", (object)str, (object)this._loginName);
            this._streetAddress = ADUserDetail.GetProperty(directoryUser, "streetAddress");
            this._city = ADUserDetail.GetProperty(directoryUser, "l");
            this._state = ADUserDetail.GetProperty(directoryUser, "st");
            this._postalCode = ADUserDetail.GetProperty(directoryUser, "postalCode");
            this._country = ADUserDetail.GetProperty(directoryUser, "co");
            this._company = ADUserDetail.GetProperty(directoryUser, "company");
            this._department = ADUserDetail.GetProperty(directoryUser, "department");
            this._homePhone = ADUserDetail.GetProperty(directoryUser, "homePhone");
            this._extension = ADUserDetail.GetProperty(directoryUser, "ipPhone");
            this._mobile = ADUserDetail.GetProperty(directoryUser, "mobile");
            this._fax = ADUserDetail.GetProperty(directoryUser, "facsimileTelephoneNumber");
            this._emailAddress = ADUserDetail.GetProperty(directoryUser, "mail");
            this._title = ADUserDetail.GetProperty(directoryUser, "title");
            this._manager = ADUserDetail.GetProperty(directoryUser, "manager");
            if (string.IsNullOrEmpty(this._manager))
                return;
            this._managerName = this._manager.Split(',')[0].Replace("CN=", "");
            EID = this._loginName;
            UserName = this._displayName;
        }

        private static string GetProperty(DirectoryEntry userDetail, string propertyName)
        {
            if (userDetail.Properties.Contains(propertyName))
                return userDetail.Properties[propertyName][0].ToString();
            return string.Empty;
        }

        public static ADUserDetail GetUser(DirectoryEntry directoryUser)
        {
            return new ADUserDetail(directoryUser);
        }
    }
}
