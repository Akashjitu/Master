﻿using System;
using Fraca.Data.Models;
using Microsoft.Reporting.WinForms;
using System.IO;
using System.Collections.Generic;
using System.Reflection;

namespace Fraca.Service.Reporting
{
    public class PdfReportMapper : IPdfReportMapper
    {
        

        public byte[] GetMappedReport(FracaInfo fracainfo)
        {
         
            LocalReport localReport = new LocalReport();
           
            ReportDataSource reportDataSource = new ReportDataSource("ReportingDataSet", new List<FracaInfo>() { fracainfo });
            localReport.DataSources.Clear();
            localReport.ReportPath = System.Web.Hosting.HostingEnvironment.MapPath("~/FracaReport.rdlc");// Server.MapPath("~/FracaReport.rdlc");
            localReport.DataSources.Add(reportDataSource);
            localReport.Refresh();
            
            string strReportType = "pdf";
            string strMimeType;
            string strEncoding;
            string strFileNameExtension;
            string strDeviceInfo = "";
            //<DeviceInfo>" +
            //                           "  <OmitDocumentMap>true</OmitDocumentMap>" +
            //                           "  <OmitFormulas>False</OmitFormulas>" +
            //                           "  <RemoveSpace>0.125in</RemoveSpace>" +
            //                           "<SimplePageHeaders>false</SimplePageHeaders>" +
            //                           "</DeviceInfo>";

            Warning[] arrStrWarnings;
            string[] arrStrStreams;
          
            byte[] bytes = localReport.Render(strReportType, strDeviceInfo, out strMimeType, out strEncoding, out strFileNameExtension, out arrStrStreams, out arrStrWarnings);
//
     

            return bytes;
        }



      

    }
}
