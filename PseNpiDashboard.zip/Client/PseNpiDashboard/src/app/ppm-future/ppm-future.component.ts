import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppm-future',
  templateUrl: './ppm-future.component.html',
  styleUrls: ['./ppm-future.component.sass']
})
export class PpmFutureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
