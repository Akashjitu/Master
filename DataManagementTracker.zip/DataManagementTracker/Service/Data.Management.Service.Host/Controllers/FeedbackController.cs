﻿using Data.Management.Data.Models;
using Data.Management.Service.Host.ExceptionFilters;
using Data.Management.Service.Host.Mail;
using Data.Management.Service.Host.Providers;
using Data.Management.Services.Service;
using DataManagement.Data.Models;
using Honeywell.ActiveDirectory;
using Hts.Logger;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Mail;
using System.Web.Http;

namespace Data.Management.Service.Host.Controllers
{
    [LogExceptionFilterAttribute]
    public class FeedbackController : ApiController
    {
        private readonly IMailProvider _mailService;
        private readonly IEmployeeService _employee;
        IActiveDirectoryHelper _activeDirectoryHelper;
        public FeedbackController( IMailProvider mailService, IEmployeeService employee, IActiveDirectoryHelper activeDirectoryHelper)
        {
         
            _mailService = mailService;
             _employee = employee; 
             _activeDirectoryHelper =activeDirectoryHelper;

    }
        [HttpPost]
        public HttpResponseMessage AddFeedBack(Feedback feedback)
        {

            try
            {

                var eid = RequestDataProvider.GetValue(System.Web.HttpContext.Current, TypeOfData.UserName);

                var emp = _employee.GetEmployeeInfo(eid);
                string htmlBody = "Hi,<br /> </br>" +
                    "One (Customer Approval Feedback)Request raised  by " + "<strong>" + emp.DisplayName + "</strong>" + "<br/>" + feedback.FeedbackBody+
                "</br><br/>" + "Regards,<br/><h4>Customer Approval Tracker Feedback</h4>";

                //string htmlBody = feedback.FeedbackBody;
                MailMessage Mail= new MailMessage();
                Mail.IsBodyHtml = true;

                //if (!string.IsNullOrEmpty(fileName))
                //{
                //    System.Net.Mail.Attachment attachment;
                //    attachment = new System.Net.Mail.Attachment(fileName);
                //    Mail.Attachments.Add(attachment);
                //}

              
                Mail.From = new MailAddress("Customer_Approval_Tracker@Honeywell.com");

                Mail.Subject = "Customer Approval Tracker Feedback";



                var mailTo = ConfigurationManager.AppSettings["FEEDBACK_MAIL_TO"]?? "Anupam.Sinha@Honeywell.com";
                var mailCC = ConfigurationManager.AppSettings["FEEDBACK_MAIL_CC"]?? "akash.kumar3@honeywell.com";
                      

                    Mail.CC.Add(mailCC);
                    Mail.To.Add(mailTo);


                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(
                htmlBody,
                null, "text/html");
                Mail.AlternateViews.Add(htmlView);
                Mail.AlternateViews.Add(htmlView);
                SmtpClient client = new SmtpClient();
                client.Port = 25;
                client.Host = "smtp.honeywell.com";
                client.Send(Mail);
                Mail.Dispose();
                return Request.CreateResponse(HttpStatusCode.OK, "Mail Send", JsonMediaTypeFormatter.DefaultMediaType);
            

            }
            catch (Exception ex)
            {
                LogWriter.LogWrite(" LoadAllDataManagements eid ----------- " + ex.Message, LogType.Error);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, "Error Sending  mail :- " + ex.Message, JsonMediaTypeFormatter.DefaultMediaType);
            }
        }

        private void SendMail(DataManagementTrack dataManagement)
        {
           

            var requestor = _activeDirectoryHelper.GetUsersByLoginName(dataManagement.Requestor);
            var dm = _activeDirectoryHelper.GetUsersByLoginName(dataManagement.DataManager);
            var cm = _activeDirectoryHelper.GetUsersByLoginName(dataManagement.Cm);

            if ((requestor != null && requestor.Count > 0) && (dm != null && dm.Count > 0) && (cm != null && cm.Count > 0))
                _mailService.SendMail("akash Kumar", "akash.kumar3@honeywell.com", "akash.kumar3@honeywell.com", "akash.kumar3@honeywell.com");
        }
    }
}
