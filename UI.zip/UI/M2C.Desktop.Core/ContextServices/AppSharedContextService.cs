﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Core
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="AppSharedContextService.cs" company="">
//     Copyright ©  2019
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Generic;

namespace M2C.Desktop.Core.ContextServices
{
    /// <summary>
    /// Shared service to maintain application context
    /// </summary>
    /// <seealso cref="M2C.Desktop.Core.ContextServices.ISharedContextService" />
    public class AppSharedContextService : ISharedContextService
    {
        /// <summary>
        /// The context data
        /// </summary>
        private readonly IDictionary<string, object> _contextData = new Dictionary<string, object>();


        /// <summary>
        /// Gets or sets a value indicating whether this instance is save pending.
        /// </summary>
        /// <value><c>true</c> if this instance is save pending; otherwise, <c>false</c>.</value>
        public bool IsSavePending { get; set; } = false;

        /// <summary>
        /// Adds the specified key.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">The key.</param>
        /// <param name="data">The data.</param>
        public void Add<T>(string key, T data) where T : class
        {
            _contextData.Add(key, data);
        }

        /// <summary>
        /// Gets the specified key.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">The key.</param>
        /// <returns>T.</returns>
        public T Get<T>(string key) where T : class
        {
            if (!_contextData.TryGetValue(key, out var value))
            {
                return null;
            }
            return (T)value;
        }

        /// <summary>
        /// Removes the specified key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Remove(string key)
        {
            return _contextData.Remove(key);
        }

        /// <summary>
        /// Updates the specified key.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key">The key.</param>
        /// <param name="data">The data.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Update<T>(string key, T data) where T : class
        {
            return _contextData.TryGetValue(key, out _);
        }
    }
}