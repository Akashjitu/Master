﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 03-05-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="OperationModeDialogueViewModel.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business;
using M2C.Business.Contracts;
using M2C.Business.Models;
using M2C.Desktop.Modules.CollectData.Constants;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// Class OperationModeDialogueViewModel.
    /// Implements the <see cref="Prism.Mvvm.BindableBase" />
    /// Implements the <see cref="Prism.Services.Dialogs.IDialogAware" />
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Services.Dialogs.IDialogAware" />
    internal class OperationModeDialogueViewModel : BindableBase, IDialogAware
    {
        /// <summary>
        /// The selected operation mode
        /// </summary>
        private string _selectedOperationMode;
        /// <summary>
        /// The selected hourly product
        /// </summary>
        private string _selectedHourlyProd;
        /// <summary>
        /// The comments
        /// </summary>
        private string _comments;
        /// <summary>
        /// The age
        /// </summary>
        private string _age;
        /// <summary>
        /// The selected start date
        /// </summary>
        private DateTime? _selectedStartDate;
        /// <summary>
        /// The start date
        /// </summary>
        private DateTime? _startDate;
        /// <summary>
        /// The end date
        /// </summary>
        private DateTime? _endDate;
        /// <summary>
        /// The operation mode logic
        /// </summary>
        private IOperationModeLogic operationModeLogic;
        /// <summary>
        /// Gets or sets the operating mode.
        /// </summary>
        /// <value>The operating mode.</value>
        public ObservableCollection<string> OperatingMode { get; set; } = new ObservableCollection<string>();
        /// <summary>
        /// Gets or sets the hourly production.
        /// </summary>
        /// <value>The hourly production.</value>
        public ObservableCollection<string> HourlyProduction { get; set; } = new ObservableCollection<string>();
        /// <summary>
        /// Gets or sets the close dialog command.
        /// </summary>
        /// <value>The close dialog command.</value>
        public DelegateCommand<string> CloseDialogCommand { get; set; }

        /// <summary>
        /// Gets or sets the selected operation mode.
        /// </summary>
        /// <value>The selected operation mode.</value>
        public string SelectedOperationMode
        {
            get => _selectedOperationMode;
            set => SetProperty(ref _selectedOperationMode, value);
        }

        /// <summary>
        /// Gets or sets the comments.
        /// </summary>
        /// <value>The comments.</value>
        public string Comments { get => _comments; set => SetProperty(ref _comments, value); }

        /// <summary>
        /// Gets or sets the age.
        /// </summary>
        /// <value>The age.</value>
        public string Age { get => _age; set => SetProperty(ref _age, value); }

        /// <summary>
        /// Gets or sets the selected hourly product.
        /// </summary>
        /// <value>The selected hourly product.</value>
        public string SelectedHourlyProd
        {
            get => _selectedHourlyProd;
            set => SetProperty(ref _selectedHourlyProd, value);
        }

        /// <summary>
        /// Gets or sets the selected start date.
        /// </summary>
        /// <value>The selected start date.</value>
        public DateTime? SelectedStartDate { get => _selectedStartDate; set => SetProperty(ref _selectedStartDate, value); }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>The start date.</value>
        public DateTime? StartDate { get => _startDate; set => SetProperty(ref _startDate, value); }
        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>The end date.</value>
        public DateTime? EndDate { get => _endDate; set => SetProperty(ref _endDate, value); }
        /// <summary>
        /// Gets or sets the on date change command.
        /// </summary>
        /// <value>The on date change command.</value>
        public DelegateCommand<string> OnDateChangeCommand { get; set; }
        /// <summary>
        /// Gets or sets the date change command.
        /// </summary>
        /// <value>The date change command.</value>
        public DelegateCommand DateChangeCommand { get; set; }
        /// <summary>
        /// OperationModeDialogueViewModel constructor
        /// </summary>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="_operationModeLogic">The operation mode logic.</param>
        public OperationModeDialogueViewModel(IEventAggregator eventAggregator, IOperationModeLogic _operationModeLogic)
        {
            operationModeLogic = _operationModeLogic;
            OnDateChangeCommand = new DelegateCommand<string>(OnDatechange);
            CloseDialogCommand = new DelegateCommand<string>(OnAddAction);
            DateChangeCommand = new DelegateCommand(OnSelectDate);
            HourlyProduction = operationModeLogic.GetHourlyProduction();
            OperatingMode = operationModeLogic.GetOperatingMode();
            SelectedStartDate = DateTime.Now;
            InitializeParameter();
        }
        /// <summary>
        /// initializing values
        /// </summary>
        private void InitializeParameter()
        {
            SelectedHourlyProd = BusinessConstants.HOURLY_PRODUCTION1;
            SelectedOperationMode = BusinessConstants.OPERATION_MODE1;

            StartDate = DateTime.Today;
            EndDate = DateTime.Today.AddDays(1);
            Age = "0";
        }
        /// <summary>
        /// datechange event handler
        /// </summary>
        /// <param name="obj">The object.</param>
        private void OnDatechange(string obj)
        {
            var today = DateTime.Now;
            var difference = (today.Subtract((DateTime)StartDate)).Days / 365;
            Age = difference.ToString();
        }
        /// <summary>
        /// Add parameters function
        /// </summary>
        /// <param name="commParam">The comm parameter.</param>
        private void OnAddAction(string commParam)
        {
            try
            {
                var parameters = new DialogParameters();
                if (string.Compare(commParam, CollectionConstant.Add, StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    OperationModeModel operationModes = new OperationModeModel() { OperatingMode = SelectedOperationMode, HourlyProduction = SelectedHourlyProd, Age = this.Age, Comments = this.Comments, StartDate = this.StartDate, EndDate = this.EndDate };
                    parameters.Add(CollectionConstant.Add, operationModes);
                    RequestClose?.Invoke(new DialogResult(ButtonResult.OK, parameters));
                }
                else
                    RaiseRequestClose(new DialogResult(ButtonResult.Cancel));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Raises the request close.
        /// </summary>
        /// <param name="dialogResult">The dialog result.</param>
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
        {
            RequestClose?.Invoke(dialogResult);
        }

        /// <summary>
        /// The title of the dialog that will show in the Window title bar.
        /// </summary>
        /// <value>The title.</value>
        public string Title => "Operation Modes and life cycle";

        /// <summary>
        /// Instructs the IDialogWindow to close the dialog.
        /// </summary>
        public event Action<IDialogResult> RequestClose;

        /// <summary>
        /// Determines if the dialog can be closed.
        /// </summary>
        /// <returns>True: close the dialog; False: the dialog will not close</returns>
        public bool CanCloseDialog()
        {
            return true;
        }

        /// <summary>
        /// Called when the dialog is closed.
        /// </summary>
        public void OnDialogClosed()
        {
            
        }
        /// <summary>
        /// dialoge box event handler
        /// </summary>
        /// <param name="parameters">The parameters passed to the dialog</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            //HourlyProduction = operationModeLogic.GetHourlyProduction();
            //OperatingMode = operationModeLogic.GetOperatingMode();

            if (parameters.TryGetValue("OperationMode", out ObservableCollection<OperationModeModel> operationParam))
            {
                foreach (var param in operationParam)
                {
                    if (param != null)
                    {
                        SelectedHourlyProd = param.HourlyProduction;
                        SelectedOperationMode = param.OperatingMode;
                        Age = param.Age;
                        StartDate = param.StartDate;
                        EndDate = param.EndDate;
                        Comments = param.Comments;
                    }
                }
            }
        }

        /// <summary>
        /// Called when [select date].
        /// </summary>
        private void OnSelectDate()
        {
           
        }
    }
}