﻿using Hts.Logger;
using Oracle.Data.Access;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Host
{
    public class Program
    {
        static void Main(string[] args)
        {

            LogWriter.LogWrite(new Exception("test"), LogType.Error);

            //using (DataAccessObject<FracaInfo> obj = new DataAccessObject<FracaInfo>())
            //{

            //          var list1 = obj.GetStoredProcedureInfo("PK_PSE.SP_ADD_COMPLIANCE");
            //    var list = obj.GetStoredProcedureInfo("PK_PSE.SP_UPDATE_COMPLIANCE");

            //    var list2 = obj.GetStoredProcedureInfo("PK_PSE.SP_ADD_COMPLIANCE");
            //    var list3 = obj.GetStoredProcedureInfo("PK_PSE.SP_UPDATE_COMPLIANCE");
            //    //var i = obj.Post("PKG_FRACA.SP_LOAD_ALL_FRACA");

            //}
            Console.ReadLine();
        }
    }

    public class MyClass
    {
        [Columns("test")]
        public string MyName { get; set; }
    }


    public class FracaInfo
    {
        [Columns("FRACANO")]
        public string FracaNo { get; set; }


        [Columns("PART_NO")]
        public string PartNo { get; set; }

        [Columns("OPENDATE")]
        public string OpenDate { get; set; }

        [Columns("CLOSEDATE")]
        public string CloseDate { get; set; }


        [Columns("FAILEDDATE")]
        public string FailedDate { get; set; }

        [Columns("PRODUCT")]
        public string Product { get; set; }

        [Columns("PROGRAM")]
        public string Program { get; set; }


        [Columns("CUSTOMER")]
        public string Customer { get; set; }

        [Columns("TESTENV")]
        public string TestEnv { get; set; }

        [Columns("ORIGINATOR")]
        public string Originator { get; set; }





        [Columns("RESPENG")]
        public string RespEng { get; set; }

        [Columns("SYSTEM")]
        public string System { get; set; }

        [Columns("ELECTRICAL")]
        public string Electrical { get; set; }

        [Columns("EMI")]
        public string Emi { get; set; }

        [Columns("CLOSEDBY")]
        public string ClosedBy { get; set; }


        [Columns("TESTDOC")]
        public string TestDoc { get; set; }


        [Columns("PARAGRAPH")]
        public string Paragraph { get; set; }


        [Columns("TESTTYPE")]
        public string TestType { get; set; }


        [Columns("FAILURECODE")]
        public string FailureCode { get; set; }

        [Columns("END_UNIT")]
        public string EndUnit { get; set; }



        [Columns("LEVEL1")]
        public string Level1 { get; set; }

        [Columns("LEVEL2")]
        public string Level2 { get; set; }


        [Columns("NOMENCLATURE")]
        public string Nomenclature { get; set; }



        [Columns("SERIAL_NO")]
        public string SerialNumber { get; set; }


        [Columns("DESIGNATOR")]
        public string Designator { get; set; }




        [Columns("INFLIGHT_SHUTDOWN")]
        public bool InflightShutdown { get; set; }


        [Columns("INFLIGHT_POWER_LOSS")]
        public bool InflightPowerLoss { get; set; }


        [Columns("CHARGEABILITY")]
        public bool Chargeability { get; set; }


        [Columns("SAFETY_AFFECTED")]
        public bool SafetyAffected { get; set; }

        [Columns("FAILURE_TO_START")]
        public bool FailureToStart { get; set; }


        [Columns("PROBLEM")]
        public string ProblemDescription { get; set; }
        

        [Columns("FINDING")]
        public string Finding { get; set; }


        [Columns("ANALYSIST")]
        public string Analysis { get; set; }


        [Columns("LAST_UPDATE_BY")]
        public string LAST_UPDATE_BY { get; set; }


        public string Status { get; set; }


        [Columns("LAST_UPDATE")]
        public DateTime LAST_UPDATE { get; set; }


    }

}
