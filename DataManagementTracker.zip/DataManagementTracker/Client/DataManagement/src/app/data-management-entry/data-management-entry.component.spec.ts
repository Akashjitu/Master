import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataManagementEntryComponent } from './data-management-entry.component';

describe('DataManagementEntryComponent', () => {
  let component: DataManagementEntryComponent;
  let fixture: ComponentFixture<DataManagementEntryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataManagementEntryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataManagementEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
