﻿using M2C.Desktop.Core.CommonValidations;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace M2C.Desktop.Core.Tests.CommonValidations
{
    [TestClass]
    public class InputValidatorTest
    {
        [TestInitialize]
        public void TestIniTialize()
        {
        }

        [TestMethod]
        public void AreAllValidNumericCharsTest()
        {
            string str = "Sample";
            bool result = InputValidator.AreAllValidNumericChars(str);
            Assert.AreEqual(result, false);
            str = "+";
            result = InputValidator.AreAllValidNumericChars(str);
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public void IsNumberTest()
        {
            string str = "sample";
            bool result = InputValidator.IsNumber(str);
            Assert.AreEqual(result, true);
            str = "sample123";
            result = InputValidator.IsNumber(str);
            Assert.AreEqual(result, true);
            str = "123";
            result = InputValidator.IsNumber(str);
            Assert.AreEqual(result, false);
        }
    }
}