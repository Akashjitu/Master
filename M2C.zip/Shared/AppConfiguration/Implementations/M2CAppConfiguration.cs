﻿// ***********************************************************************
// Assembly         : AppConfiguration
// Author           : SESA56024
// Created          : 03-18-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-20-2020
// ***********************************************************************
// <copyright file="M2CAppConfiguration.cs" company="AppConfiguration">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Collections.Specialized;
using System.Configuration;

namespace AppConfiguration
{
    /// <summary>
    /// M2C App Configuration
    /// </summary>
    /// <seealso cref="AppConfiguration.IAppConfigurations" />
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class M2CAppConfiguration : IAppConfigurations
    {
        /// <summary>
        /// The appsettings
        /// </summary>
        private NameValueCollection _appsettings;

        /// <summary>
        /// Initializes a new instance of the <see cref="M2CAppConfiguration" /> class.
        /// </summary>
        public M2CAppConfiguration()
        {
            _appsettings = ConfigurationManager.AppSettings;
        }

        /// <summary>
        /// Gets the install based columns.
        /// </summary>
        /// <value>The install based columns.</value>
        public string InstallBasedColumns { get => getSettingsByKey(AppConfigConstants.INSTALLBASEDCOLUMNS); }

        /// <summary>
        /// Gets the technical resource columns.
        /// </summary>
        /// <value>The technical resource columns.</value>
        public string TechnicalResourceColumns { get => getSettingsByKey(AppConfigConstants.TECHNICALRESOURCECOLUMNS); }

        /// <summary>
        /// Gets the customer document columns.
        /// </summary>
        /// <value>The customer document columns.</value>
        public string CustomerDocumentColumns { get => getSettingsByKey(AppConfigConstants.CUSTOMERDOCUMENTCOLUMNS); }

        /// <summary>
        /// Gets the synchronize service path.
        /// </summary>
        /// <value>The synchronize service path.</value>
        public string SyncServicePath => getSettingsByKey(AppConfigConstants.SYNCSERVICEURL);

        /// <summary>
        /// Gets the idms application.
        /// </summary>
        /// <value>The idms application.</value>
        public string IDMSApplication => getSettingsByKey(AppConfigConstants.IDMSAPPLICATION);

        /// <summary>
        /// Gets the authentication service path.
        /// </summary>
        /// <value>The authentication service path.</value>
        public string AuthServicePath => getSettingsByKey(AppConfigConstants.AUTHSERVICEURL);

        /// <summary>
        /// Gets the settings by key.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns>System.String.</returns>
        private string getSettingsByKey(string key)
        {
            return _appsettings[key] ?? "";
        }

        /// <summary>
        /// Gets the retry count.
        /// </summary>
        /// <value>The retry count.</value>
        public string RetryCount { get => getSettingsByKey(AppConfigConstants.RETRY_COUNT); }
    }
}