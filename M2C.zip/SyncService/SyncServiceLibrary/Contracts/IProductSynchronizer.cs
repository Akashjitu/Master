﻿// ***********************************************************************
// Assembly         : SyncServiceLibrary
// Author           : SESA56024
// Created          : 04-06-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IProductSynchronizer.cs" company="SyncServiceLibrary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using SyncServiceLibrary.Model;
using System;

namespace SyncServiceLibrary.Contracts
{
    /// <summary>
    /// This interface handles M2C product synchronization
    /// </summary>
    public interface IProductSynchronizer
    {
        /// <summary>
        /// Synchronizes to local.
        /// </summary>
        /// <param name="EventCallback">The event callback.</param>
        void SyncToLocal(Action<SyncResultModel> EventCallback);
    }
}