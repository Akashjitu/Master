﻿using M2C.Business.Test.Mock;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace M2C.Business.Mappers
{
    [TestClass]
    public class ProductModelMapperTest
    {
        private IProductModelMapper productModelMapper;

        [TestInitialize]
        public void Setup()
        {
            productModelMapper = new ProductModelMapper();
        }

        [TestMethod]
        public void ShouldReturnProductModel()
        {
            var productModels = productModelMapper.Map(MockProvider.GetProducts());
            Assert.IsNotNull(productModels);
            Assert.IsTrue(productModels.Count > 0);
        }
    }
}