﻿using Pse.Data.Models;
using System;
using System.Collections.Generic;

namespace Pse.Services.DataBaseAccessObject.Loader
{
    public interface IEscapesDataAccess
    {
        List<Escapes> LoadEscapesData();

        List<Escapes> LoadEscapesDataByDate(Escapes escapes);

        List<Escapes> LoadEscapesDataById(Escapes escapes);

        List<Escapes> LoadEscapesDataByPart(Escapes escapes);

        List<Escapes> LoadEscapesDataBtweenShipDate(DateTime toShipDate, DateTime fromShipDate);
    }
}