﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 03-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="FocusAction.cs" company="">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Models;
using M2C.Business.Models.Project;

namespace M2C.Desktop.Modules.CollectData.UIModels
{
    /// <summary>
    /// Class FocusAction.
    /// </summary>
    public class FocusAction
    {
        /// <summary>
        /// Gets or sets the action.
        /// </summary>
        /// <value>The action.</value>
        public string Action { get; set; }
        /// <summary>
        /// Gets or sets the inventory.
        /// </summary>
        /// <value>The inventory.</value>
        public Inventory Inventory { get; set; }

        /// <summary>
        /// Gets or sets the customer document.
        /// </summary>
        /// <value>The customer document.</value>
        public CustomerDocument CustomerDocument { get; set; }
    }
}