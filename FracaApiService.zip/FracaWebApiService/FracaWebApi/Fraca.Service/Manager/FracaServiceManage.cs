﻿
using System;
using Fraca.Service.DataBaseAccessObject.Saver;
using Fraca.Data.Models;
using Fraca.Service.ServiceConsumer;
using Fraca.Service.DataBaseAccessObject.Loader;
using Fraca.Service.Reporting;

namespace Fraca.Service.Manager
{
    public class FracaServiceManage : IFracaServiceManage
    {
        private readonly IEmployeeServcie _apiServiceConsumer;
        private readonly ISeviceDataSave _seviceDataSave;
        private readonly IServiceDataLoader _serviceloader;
        private readonly IPdfReportMapper _pdfReportMapper;

        public FracaServiceManage(IEmployeeServcie apiServiceConsumer, ISeviceDataSave seviceDataSave, IServiceDataLoader serviceDataLoader , IPdfReportMapper pdfReportMapper)
        {
            _apiServiceConsumer = apiServiceConsumer;
            _seviceDataSave = seviceDataSave;
            _serviceloader = serviceDataLoader;
            _pdfReportMapper = pdfReportMapper;
        }

        public FracaData GetAllFracaData()
        {
            var fracas = _serviceloader.GetAllFracaData();
            return fracas;
        }

        public FracaData GetFracaById(string Fracaid)
        {
            return _serviceloader.GetFracaById(Fracaid);
        }

        public FracaData GetFracaByDate(FracaCriteria criteria)
        {
            return _serviceloader.GetFracaByDate(criteria);
        }

        public FracaData GetFracaByFilter(FracaCriteria criteria)
        {
            if (criteria == null)
                return null;

            if (!string.IsNullOrEmpty(criteria.FracaNo) && !string.IsNullOrEmpty(criteria.PartNo))
                return _serviceloader.GetFracaByFilter(criteria);
            else if (!string.IsNullOrEmpty(criteria.FracaNo))
                return _serviceloader.GetFracaById(criteria.FracaNo.Trim());
            else if (!string.IsNullOrEmpty(criteria.PartNo))
                return _serviceloader.GetFracaByPartNo(criteria.PartNo.Trim());

            else if (string.IsNullOrEmpty(criteria.FracaNo) && string.IsNullOrEmpty(criteria.PartNo))
                return _serviceloader.GetAllFracaData();

            return null;
        }

        public FracaInfo UpdateFraca(string Fracaid, FracaInfo fracaInfo)
        {
            return _seviceDataSave.UpdateFraca(Fracaid, fracaInfo);
        }

        public void DeleteFraca(string Fracaid)
        {
            _seviceDataSave.DeleteFraca(Fracaid);
        }

        public FracaInfo AddNewFraca(FracaInfo fracainfo)
        {
          return  _seviceDataSave.SaveFraca(fracainfo);

        }

        public byte[] GetFracaPdfReport(string fracaId)
        {
             var FracaData= _serviceloader.GetFracaById(fracaId);
            if (FracaData == null || FracaData.FracaInfo == null || FracaData.FracaInfo.Count == 0)
                return null;
            return  _pdfReportMapper.GetMappedReport(FracaData.FracaInfo[0]);
        }

    }
}
