﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="SideBarTreeViewModel.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using M2C.Business.Contracts;
using M2C.Business.Mappers;
using M2C.Business.Mappers.IBChainMapper;
using M2C.Business.Models;
using M2C.Business.Models.Project;
using M2C.Business.Models.Project.IBComponents;
using M2C.Desktop.Core.Constants;
using M2C.Desktop.Core.ContextServices;
using M2C.Desktop.Core.GlobalComands;
using M2C.Desktop.Core.GlobalEvents;
using M2C.Desktop.Modules.CollectData.Events;
using Microsoft.Win32;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using M2C.Business.GlobalFields;

namespace M2C.Desktop.Modules.CollectData.ViewModels
{
    /// <summary>
    /// SideBarTree ViewModel
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public partial class SideBarTreeViewModel : BindableBase, IDisposable
    {
        /// <summary>
        /// The components command
        /// </summary>
        /// <summary>
        /// The components command
        /// </summary>
        /// <summary>
        /// The components command
        /// </summary>
        private IGlobalIBComponentsCommand _componentsCommand;

        /// <summary>
        /// The shared context service
        /// </summary>
        /// <summary>
        /// The shared context service
        /// </summary>
        /// <summary>
        /// The shared context service
        /// </summary>
        private readonly ISharedContextService sharedContextService;

        /// <summary>
        /// The event aggregator
        /// </summary>
        /// <summary>
        /// The event aggregator
        /// </summary>
        /// <summary>
        /// The event aggregator
        /// </summary>
        private readonly IEventAggregator eventAggregator;

        /// <summary>
        /// The installed base
        /// </summary>
        private InstalledBase _installedBase;

        /// <summary>
        /// The add factory
        /// </summary>
        private DelegateCommand<string> _addFactory;

        /// <summary>
        /// The import ib componenet
        /// </summary>
        private DelegateCommand _importIBComponenet;

        /// <summary>
        /// The export ib componenet
        /// </summary>
        private DelegateCommand _exportIBComponenet;

        /// <summary>
        /// The selected node
        /// </summary>
        private dynamic _selectedNode;

        /// <summary>
        /// Gets or sets the selected node.
        /// </summary>
        /// <value>The selected node.</value>
        public dynamic SelectedNode { get => _selectedNode; set => _selectedNode = value; }

        /// <summary>
        /// The project model
        /// </summary>
        private ProjectContextModel _ProjectModel = new ProjectContextModel();

        /// <summary>
        /// The plus menu
        /// </summary>
        private MenuItem plusMenu = new MenuItem();

        /// <summary>
        /// Gets the excel import.
        /// </summary>
        /// <value>The excel import.</value>
        private IExcelImport ExcelImport { get; }

        /// <summary>
        /// The file open dialogue
        /// </summary>
        private readonly IFileOpenDialogue fileOpenDialogue;

        /// <summary>
        /// The project change event
        /// </summary>
        private ProjectChangeEvent _projectChangeEvent;
        /// <summary>
        /// Gets the excel export.
        /// </summary>
        /// <value>The excel export.</value>
        private IExcelExport excelExport { get; }
        /// <summary>
        /// The LST inventory
        /// </summary>
        private List<Inventory> lstInventory;

        /// <summary>
        /// The save file dialog
        /// </summary>
        private readonly SaveFileDialog _saveFileDialog;

        /// <summary>
        /// Initializes a new instance of the <see cref="SideBarTreeViewModel" /> class.
        /// </summary>
        /// <param name="componentsCommand">The components command.</param>
        /// <param name="sharedContextService">The shared context service.</param>
        /// <param name="eventAggregator">The event aggregator.</param>
        /// <param name="excelImport">The excel import.</param>
        /// <param name="_fileOpenDialogue">The file open dialogue.</param>
        /// <param name="_excelExport">The excel export.</param>
        /// <param name="inventoryMapper">The inventory mapper.</param>
        public SideBarTreeViewModel(IGlobalIBComponentsCommand componentsCommand, ISharedContextService sharedContextService, IEventAggregator eventAggregator, IExcelImport excelImport,
             IFileOpenDialogue _fileOpenDialogue, IExcelExport _excelExport, IInventoryMapper inventoryMapper)
        {
            //Read-only variables
            ExcelImport = excelImport;
            this._componentsCommand = componentsCommand;
            this.sharedContextService = sharedContextService;
            this.eventAggregator = eventAggregator;
            fileOpenDialogue = _fileOpenDialogue;
            excelExport = _excelExport;
            _inventoryMapper = inventoryMapper;
            _ProjectModel = new ProjectContextModel();
            //delegate commands
            SelectedItem = new DelegateCommand<object>(OnSelectedItem);
            _importIBComponenet = new DelegateCommand(OnImportIbComponenet);
            _exportIBComponenet = new DelegateCommand(OnExportIbCommand);
            RootNodeCommand = new DelegateCommand(OnRootNodeCommand);

            //compound commnads
            this.ComponentsCommand.AddNodeCommand.RegisterCommand(AddComponents);
            this.ComponentsCommand.ImportIBComponenetCommand.RegisterCommand(_importIBComponenet);
            this.ComponentsCommand.ExportIBComponenetCommand.RegisterCommand(_exportIBComponenet);

            //EVENTS
            _projectChangeEvent = this.eventAggregator.GetEvent<ProjectChangeEvent>();

            //Model Initialization
            _ProjectModel = sharedContextService.Get<ProjectContextModel>(UIConstants.PROJECTCONTEXT);
            if (_ProjectModel != null && _ProjectModel?.InstalledBase == null)
                _ProjectModel.InstalledBase = new InstalledBase();

            InstalledBase = _ProjectModel?.InstalledBase;

            PlusMenu.MenuItems.Add(new MenuItem("Add Factory", "Factory"));
            OnRootNodeCommand();
            SideBarTreeViewModel_ContextMenu_init();
            _saveFileDialog = new SaveFileDialog();
        }

        /// <summary>
        /// Gets or sets the installed base.
        /// </summary>
        /// <value>The installed base.</value>
        public InstalledBase InstalledBase { get => _installedBase; set => SetProperty(ref _installedBase, value); }

        /// <summary>
        /// Gets the add components.
        /// </summary>
        /// <value>The add components.</value>
        public DelegateCommand<string> AddComponents => _addFactory ?? (_addFactory = new DelegateCommand<string>(OnAddComponents));

        /// <summary>
        /// Gets or sets the components command.
        /// </summary>
        /// <value>The components command.</value>
        public IGlobalIBComponentsCommand ComponentsCommand { get => _componentsCommand; set => SetProperty(ref _componentsCommand, value); }

        /// <summary>
        /// Importing the excel file
        /// </summary>
        public void OnImportIbComponenet()
        {
            string SelectedFileName = null;

            fileOpenDialogue.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            try
            {
                if (!fileOpenDialogue.ShowDialog()) return;
                SelectedFileName = fileOpenDialogue.FileName.Trim();
                eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.VISIBLE });
                // import Products from excel file
                ExcelImport.IBComponentImport(SelectedFileName, InstalledBase);

                //Update Application context object
                _ProjectModel.InstalledBase = InstalledBase;
                sharedContextService.Update(UIConstants.PROJECTCONTEXT, _ProjectModel);
                _projectChangeEvent.Publish(_ProjectModel);

                List<Node> configNodes = _ProjectModel.InstalledBase.GetAllNodes().Where(x => x.GetType() == typeof(ConfigNode)).ToList();
                lstInventory = ExcelImport.IbInventoryImport(SelectedFileName, configNodes);
                OnRootNodeCommand();
            }
            catch (ApplicationException ex)
            {
                MessageBox.Show("Import failed :Not able to import the file", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show($"Import failed : {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Import failed : Not able to import the file", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
            }
        }

        /// <summary>
        /// Exporting inventory details to Excel
        /// </summary>
        public void OnExportIbCommand()
        {
            try
            {

                string saveFilepath = string.Empty;
                if (ShowSaveFileDialog(ref saveFilepath))
                {
                    eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.VISIBLE });
                    excelExport.IBExcelExport(_ProjectModel.InstalledBase.Inventories, saveFilepath);
                    eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
                    if (saveFilepath != null)
                    {

                        if (MessageBox.Show("File generated successfully.\n Do want to open?", "File Generated",
                        MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                        {
                            System.Diagnostics.Process.Start(saveFilepath);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Export Failed", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                else
                {
                    return;
                }
                    
                
            }
            catch (Exception ex)
            {
                eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
                MessageBox.Show("Export failed", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                eventAggregator.GetEvent<BusyOverlayEvent>().Publish(new OverlayMessage() { status = OverlayStatus.HIDDEN });
            }
        }
        /// <summary>
        /// Save File dialog
        /// </summary>
        /// <param name="saveFilepath">The save filepath.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ShowSaveFileDialog(ref string saveFilepath)
        {
            _saveFileDialog.FileName = string.Empty;
            _saveFileDialog.Filter = "Excel Files| *.xls; *.xlsx; *.xlsm";
            if (_saveFileDialog.ShowDialog() == false)
            {
                return false;
            }
           
            saveFilepath = Path.ChangeExtension(_saveFileDialog.FileName, ".xlsx"); 
            return true;
            
        }


        /// <summary>
        /// Ons the add components.
        /// </summary>
        /// <param name="command">The command.</param>
        private void OnAddComponents(string command)
        {
            try
            {
                string[] commands = command?.Split('/');

                switch (commands?.Length)
                {
                    case 0:
                        return;
                    case 1:
                        AddSingleNode(commands[0]);
                        break;
                    default:
                        {
                            if (commands?.Length > 1)
                            {
                                var conf = new ConfigHandler();
                                var mc = new MachineHandler();
                                var ln = new LineHandler();
                                var ws = new WorkShopHandler();
                                var fh = new FactoryHandler();
                                var IBh = new InstallBaseHandler();

                                IBh.SetNext(fh).SetNext(ws).SetNext(ln).SetNext(mc).SetNext(conf);

                                AddNodeByChain.Add(IBh, commands.ToList(), SelectedNode ?? InstalledBase);
                            }

                            break;
                        }
                }

                //Updating Project context
                if (_ProjectModel == null) return;
                _ProjectModel.InstalledBase = InstalledBase;
                this.sharedContextService.Update<ProjectContextModel>(UIConstants.PROJECTCONTEXT, _ProjectModel);
                eventAggregator.GetEvent<ContextDataChangeEvent>().Publish(_ProjectModel);
                _projectChangeEvent.Publish(_ProjectModel);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Adds the single node.
        /// </summary>
        /// <param name="addNodeType">The node Type.</param>
        private void AddSingleNode(string addNodeType)
        {
            Enum.TryParse(addNodeType.ToUpper(), out NodeType nodeType);
            switch (nodeType)
            {
                case NodeType.FACTORY:
                    {
                        var ib = SelectedNode as InstalledBase ?? InstalledBase;
                        ib.Factories.Add(new FactoryNode(GlobalFiled.GenerateRandomId(), UIConstants.FACTORY, ib));
                    }
                    break;

                case NodeType.WORKSHOP:
                    {
                        if (SelectedNode != null)
                        {
                            var fc = SelectedNode as FactoryNode;
                            fc?.WorkShopNodes.Add(new WorkShopNode(GlobalFiled.GenerateRandomId(), UIConstants.WORKSHOP,
                                fc));
                        }
                    }
                    break;

                case NodeType.LINE:
                    {
                        if (SelectedNode != null)
                        {
                            var ws = SelectedNode as WorkShopNode;
                            ws?.LineNodes.Add(new LineNode(GlobalFiled.GenerateRandomId(), UIConstants.LINE, ws));
                        }
                    }
                    break;

                case NodeType.MACHINE:
                    {
                        if (SelectedNode != null)
                        {
                            if (SelectedNode is LineNode)
                            {
                                var ln = SelectedNode as LineNode;
                                ln?.MachineNodes.Add(new MachineNode(GlobalFiled.GenerateRandomId(), UIConstants.MACHINE, ln));
                            }
                            else
                            {
                                var ws = SelectedNode as WorkShopNode;
                                ws?.MachineNodes.Add(new MachineNode(GlobalFiled.GenerateRandomId(), UIConstants.MACHINE, ws));
                            }
                        }
                    }
                    break;

                case NodeType.PLC_CONFIG:
                    {
                        if (SelectedNode != null)
                        {
                            var ln = SelectedNode as MachineNode;
                            ln?.ConfigNodes.Add(new ConfigNode(GlobalFiled.GenerateRandomId(), UIConstants.PLC_CONFIGURATION, NodeType.PLC_CONFIG, ln));
                        }
                    }
                    break;

                case NodeType.MD_CONFIG:
                    {
                        if (SelectedNode != null)
                        {
                            var ln = SelectedNode as MachineNode;
                            ln?.ConfigNodes.Add(new ConfigNode(GlobalFiled.GenerateRandomId(), UIConstants.MOTION_DRIVE_CONFIGURATION, NodeType.MD_CONFIG, ln));
                        }
                    }
                    break;

                case NodeType.SHMI_CONFIG:
                    {
                        if (SelectedNode != null)
                        {
                            var ln = SelectedNode as MachineNode;
                            ln?.ConfigNodes.Add(new ConfigNode(GlobalFiled.GenerateRandomId(), UIConstants.SCADA_HMI_CONFIGURATION, NodeType.SHMI_CONFIG, ln));
                        }
                    }
                    break;

                case NodeType.OPEN_CONFIG:
                    {
                        if (SelectedNode != null)
                        {
                            var ln = SelectedNode as MachineNode;
                            ln?.ConfigNodes.Add(new ConfigNode(GlobalFiled.GenerateRandomId(), UIConstants.OPEN_CONFIGURATION, NodeType.OPEN_CONFIG, ln));
                        }
                    }
                    break;
            }
        }

        /// <summary>
        /// Gets or sets the selected item.
        /// </summary>
        /// <value>The selected item.</value>
        public DelegateCommand<object> SelectedItem { get; set; }

        /// <summary>
        /// Ons the selected item.
        /// </summary>
        /// <param name="obj">The object.</param>
        private void OnSelectedItem(object obj)
        {
            try
            {
                if (obj is RoutedPropertyChangedEventArgs<object> e) SelectedNode = e.NewValue;

                if (SelectedNode == null) return;

                var node = SelectedNode as Node;
                eventAggregator.GetEvent<IBTreeViewChangeEvent>().Publish(node);
                if (node != null) PlusMenu.SetMenu(node.NodeType);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Gets or sets the plus menu.
        /// </summary>
        /// <value>The plus menu.</value>
        public MenuItem PlusMenu { get => plusMenu; set => SetProperty(ref plusMenu, value); }

        /// <summary>
        /// Gets or sets the root node command.
        /// </summary>
        /// <value>The root node command.</value>
        public DelegateCommand RootNodeCommand { get; set; }

        /// <summary>
        /// Ons the root node command.
        /// </summary>
        private void OnRootNodeCommand()
        {
            var node = InstalledBase as Node;
            eventAggregator.GetEvent<IBTreeViewChangeEvent>().Publish(node);
            PlusMenu.SetMenu(node.NodeType);
        }

        /// <summary>
        /// Disposing the command components
        /// </summary>
        public void Dispose()
        {
            this.ComponentsCommand.AddNodeCommand.UnregisterCommand(AddComponents);
            this.ComponentsCommand.ImportIBComponenetCommand.UnregisterCommand(_importIBComponenet);
            this.ComponentsCommand.ExportIBComponenetCommand.UnregisterCommand(_exportIBComponenet);
        }
    }

    /// <summary>
    /// Dynamic menu item class
    /// </summary>
    /// <seealso cref="Prism.Mvvm.BindableBase" />
    public class MenuItem : BindableBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MenuItem" /> class.
        /// </summary>
        /// <param name="header">The header.</param>
        /// <param name="command">The command.</param>
        public MenuItem(string header, string command)
        {
            this.Header = header;
            this.Command = command;
            MenuItems = new ObservableCollection<MenuItem>();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuItem" /> class.
        /// </summary>
        public MenuItem()
        {
            MenuItems = new ObservableCollection<MenuItem>();
        }

        /// <summary>
        /// The header
        /// </summary>
        private string _header;

        /// <summary>
        /// The command
        /// </summary>
        private string _command;

        /// <summary>
        /// Gets or sets the header.
        /// </summary>
        /// <value>The header.</value>
        public string Header { get => _header; set => SetProperty(ref _header, value); }

        /// <summary>
        /// Gets or sets the command.
        /// </summary>
        /// <value>The command.</value>
        public string Command { get => _command; set => SetProperty(ref _command, value); }

        /// <summary>
        /// Gets or sets the menu items.
        /// </summary>
        /// <value>The menu items.</value>
        public ObservableCollection<MenuItem> MenuItems { get; set; }

        /// <summary>
        /// Sets the menu.
        /// </summary>
        /// <param name="nodeType">Type of the node.</param>
        public void SetMenu(NodeType nodeType)
        {
            switch (nodeType)
            {
                case NodeType.INSTALLEDBASE:
                    {
                        this.MenuItems.Clear();
                        this.MenuItems.Add(new MenuItem("Add Factory", "FACTORY"));
                    }
                    break;

                case NodeType.FACTORY:
                    {
                        this.MenuItems.Clear();
                        this.MenuItems.Add(new MenuItem("Add Workshop", "WORKSHOP"));
                    }
                    break;

                case NodeType.WORKSHOP:
                    {
                        this.MenuItems.Clear();
                        this.MenuItems.Add(new MenuItem("Add Line", "LINE"));
                        this.MenuItems.Add(new MenuItem("Add Machine", "MACHINE"));
                    }
                    break;

                case NodeType.LINE:
                    {
                        this.MenuItems.Clear();
                        this.MenuItems.Add(new MenuItem("Add Machine", "MACHINE"));
                    }
                    break;

                case NodeType.MACHINE:
                    {
                        this.MenuItems.Clear();
                        this.MenuItems.Add(new MenuItem("PLC", "PLC_config"));
                        this.MenuItems.Add(new MenuItem("Motion and Drive", "MD_config"));
                        this.MenuItems.Add(new MenuItem("Scada HMI", "SHMI_config"));
                        this.MenuItems.Add(new MenuItem("Open Configuration", "OPEN_config"));
                    }
                    break;

                default: { this.MenuItems.Clear(); } break;
            }
        }
    }
}