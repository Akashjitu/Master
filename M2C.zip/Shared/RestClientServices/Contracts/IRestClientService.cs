﻿// ***********************************************************************
// Assembly         : RestClientServices
// Author           : SESA56024
// Created          : 04-02-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="IRestClientService.cs" company="RestClientServices">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace RestClientServices.Contracts
{
    /// <summary>
    /// Interface IRestClientService
    /// </summary>
    public interface IRestClientService
    {
        /// <summary>
        /// Executes the specified request.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request">The request.</param>
        /// <returns>T.</returns>
        T Execute<T>(IRestServiceRequest request);

        /// <summary>
        /// Gets the service base path.
        /// </summary>
        /// <value>The service base path.</value>
        string ServiceBasePath { get; }
    }
}