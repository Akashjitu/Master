﻿// ***********************************************************************
// Assembly         : InputParserLibary
// Author           : SESA56024
// Created          : 02-11-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="IExcelWriter.cs" company="InputParserLibary">
//     Copyright (c) . All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************
using InputParserLibary.DataModels;
using System.Collections.Generic;

namespace InputParserLibary.Contracts
{
    /// <summary>
    /// Interface for the excel writing for Excel export
    /// </summary>
    public interface IExcelWriter
    {
        /// <summary>
        /// Gets or sets the file path.
        /// </summary>
        /// <value>The file path.</value>
        string FilePath { get; set; }
        /// <summary>
        /// Adds the work book.
        /// </summary>
        void AddWorkBook();

        /// <summary>
        /// Sets the work book.
        /// </summary>
        /// <param name="index">The index.</param>
        void SetWorkBook(int index);

        /// <summary>
        /// Adds the worksheet.
        /// </summary>
        /// <param name="Name">The name.</param>
        void AddWorksheet(string Name);

        /// <summary>
        /// Sets the active sheet.
        /// </summary>
        /// <param name="index">The index.</param>
        void SetActiveSheet(int index);

        /// <summary>
        /// Writes the specified columns.
        /// </summary>
        /// <param name="Columns">The columns.</param>
        /// <param name="Rows">The rows.</param>
        void Write(List<ExcelDataColumn> Columns, List<ExcelDataRow> Rows);

        /// <summary>
        /// Writes the specified columns.
        /// </summary>
        /// <param name="Columns">The columns.</param>
        /// <param name="Rows">The rows.</param>
        void Write(ExcelDataColumn Columns, ExcelDataRow Rows);
        /// <summary>
        /// Closes this instance.
        /// </summary>
        void Close();

    }
}