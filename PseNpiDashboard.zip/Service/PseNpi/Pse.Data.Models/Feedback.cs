﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pse.Data.Models
{
  public  class Feedback
    {
        public string FeedbackBody { get; set; }
    }
}
