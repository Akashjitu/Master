﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.CollectData
// Author           : SESA56024
// Created          : 01-13-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-07-2020
// ***********************************************************************
// <copyright file="DeviceTypeControl.xaml.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using M2C.Desktop.Core.CommonValidations;

namespace M2C.Desktop.Modules.CollectData.Views.InventoryControls
{
    /// <summary>
    /// Interaction logic for DeviceTypeControl.xaml
    /// </summary>
    public partial class DeviceTypeControl : UserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeviceTypeControl" /> class.
        /// </summary>
        public DeviceTypeControl()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Numbers the validation text box.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs" /> instance containing the event data.</param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            e.Handled = InputValidator.IsNumber(e.Text);
        }

        /// <summary>
        /// Handles the OnPreviewTextInput event of the ComboDeviceType control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs" /> instance containing the event data.</param>
        private void ComboDeviceType_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            comboDeviceType.IsDropDownOpen = true;
        }

        //private void ComboDeviceType_OnLostFocus(object sender, RoutedEventArgs e)
        //{
        //    comboDeviceType.IsDropDownOpen = false;
        //}
    }
}
