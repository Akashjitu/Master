﻿// ***********************************************************************
// Assembly         : M2C.Desktop.Modules.Charts.ReportData
// Author           : SESA56024
// Created          : 04-17-2020
//
// Last Modified By : SESA56024
// Last Modified On : 04-17-2020
// ***********************************************************************
// <copyright file="Topology.cs" company="">
//     Copyright ©  2017
// </copyright>
// <summary></summary>
// ***********************************************************************
namespace M2C.Desktop.Modules.Charts.ReportData.Models
{
    /// <summary>
    /// Class Topology.
    /// </summary>
    public class Topology
    {
        /// <summary>
        /// Gets or sets the factory.
        /// </summary>
        /// <value>The factory.</value>
        public string Factory { get; set; }
        /// <summary>
        /// Gets or sets the workhop.
        /// </summary>
        /// <value>The workhop.</value>
        public string Workhop { get; set; }
        /// <summary>
        /// Gets or sets the line.
        /// </summary>
        /// <value>The line.</value>
        public string Line { get; set; }
        /// <summary>
        /// Gets or sets the machine.
        /// </summary>
        /// <value>The machine.</value>
        public string Machine { get; set; }
        /// <summary>
        /// Gets or sets the configuration.
        /// </summary>
        /// <value>The configuration.</value>
        public string Configuration { get; set; }
        /// <summary>
        /// Gets or sets the criticality.
        /// </summary>
        /// <value>The criticality.</value>
        public string Criticality { get; set; }

        /// <summary>
        /// Determines whether the specified <see cref="System.Object" /> is equal to this instance.
        /// </summary>
        /// <param name="topologyObject">The <see cref="System.Object" /> to compare with this instance.</param>
        /// <returns><c>true</c> if the specified <see cref="System.Object" /> is equal to this instance; otherwise, <c>false</c>.</returns>
        public override bool Equals(object topologyObject)
        {
            if (topologyObject is Topology topology)
            {
                return (Factory.Equals(topology.Factory) &&
                        Workhop.Equals(topology.Workhop) &&
                        Line.Equals(topology.Line) &&
                        Machine.Equals(topology.Machine) &&
                        Configuration.Equals(topology.Configuration) &&
                        Criticality.Equals(topology.Criticality));

            }

            return false;
        }
    }
}