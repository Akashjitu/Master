﻿
namespace Pse.Services.Constants
{
    public class ServiceConstant
    {
        internal const string LoadBtweenShipDate = @"SELECT
                es.SITE                    AS P_SITE,
                es.SBU AS  P_SBU,
                es.PART AS  P_PART,
                es.QN AS  P_QN,
                es.NOTIFICATIONDATE AS  P_NOTIFICATIONDATE,
                es.MATERIALDESCRIPTION AS  P_MATERIALDESCRIPTION,
                es.CAUSE_CODE AS  P_CAUSE_CODE,
                es.CAUSE_CODE_DESCRIPTION AS  P_CAUSE_CODE_DESCRIPTION,
                es.CAR_ISSUE_DATE AS  P_CAR_ISSUE_DATE,
                es.TITLE AS  P_TITLE,
                es.MAKE AS  P_MAKE,
                es.CAUSE_TEXT AS  P_CAUSE_TEXT,
                es.RCCA_CAUSE AS  P_RCCA_CAUSE,
                es.RCCACAUSE_GROUP AS  P_RCCACAUSE_GROUP,
                es.IDO_CAUSED AS  P_IDO_CAUSED,
                es.STATUS AS  P_STATUS,
                es.REQ_TEXT AS  P_REQ_TEXT,
                es.FINDING_TEXT AS  P_FINDING_TEXT,
                es.FINDING_CODE AS  P_FINDING_CODE,
                es.FINDING_TYPE AS  P_FINDING_TYPE,
                es.DIRECT_CAUSE AS  P_DIRECT_CAUSE,
                es.CONTRIBUTING_CAUSE AS  P_CONTRIBUTING_CAUSE,
                es.ROOT_CAUSE AS  P_ROOT_CAUSE,
                es.SPECIFIC_ACTION AS  P_SPECIFIC_ACTION,
                es.PREVENTIVE_ACTION AS  P_PREVENTIVE_ACTION,
                es.SYSTEMIC_ACTION AS  P_SYSTEMIC_ACTION,
                es.QN_AGE AS  P_QN_AGE,
                es.CAR_TITLE AS  P_CAR_TITLE,
                es.LEVEL_DESCRIPTION AS  P_LEVEL_DESCRIPTION,
                es.REQUESTER AS  P_REQUESTER,
                es.EXPORT_CONTROL AS  P_EXPORT_CONTROL,
                es.MONTH AS  P_MONTH,
                es.YEAR AS  P_YEAR,
                es.ORIGINAL_SHIP_DATE AS  P_ORIGINAL_SHIP_DATE,
                es.ID AS  P_ID,
                es.CREATED_BY AS  P_CREATED_BY,
                es.UPDATED_BY AS  P_UPDATED_BY,
                es.CREATED_DATE AS  P_CREATED_DATE,
                es.UPDATED_DATE AS  P_UPDATED_DATE,
                es.ACTIVE AS  P_ACTIVE,
                es.SERIAL_NO AS  P_SERIAL_NO

      FROM TB_ESCAPES es
      

             WHERE es.ORIGINAL_SHIP_DATE BETWEEN {0} AND {1};";
    }
}
